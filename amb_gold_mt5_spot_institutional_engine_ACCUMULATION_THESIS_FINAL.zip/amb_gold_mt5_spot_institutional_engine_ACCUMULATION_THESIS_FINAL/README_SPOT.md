# AMB Gold MT5 Institutional Spot Engine

This is the Spot-only execution entrypoint built on top of the existing MT5/News/AI/Learning codebase.
The original unified `main.py` remains present for compatibility. Use `spot_main.py` for the separated Spot workflow.

## Windows prerequisites
- Windows 10/11
- MetaTrader 5 desktop open and logged in
- XAUUSD (or broker-specific symbol) visible in Market Watch
- Python 3.11+ recommended

## Install
```powershell
cd $env:USERPROFILE\Downloads
Expand-Archive -Force amb_gold_mt5_spot_institutional_engine.zip amb_gold_mt5_spot_institutional_engine
cd amb_gold_mt5_spot_institutional_engine
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -U pip setuptools wheel
pip install -r requirements.txt
```

## Full Spot run (News + MT5)
```powershell
python spot_main.py `
  --symbol XAUUSD `
  --days 3 `
  --workers 10 `
  --count 900 `
  --learning
```

## Heavy/exhaustive News mode
```powershell
python spot_main.py `
  --symbol XAUUSD `
  --days 3 `
  --workers 10 `
  --count 900 `
  --learning `
  --exhaustive
```

## Use an existing News/Macro context
```powershell
python spot_main.py `
  --symbol XAUUSD `
  --count 900 `
  --learning `
  --chart-only `
  --news-context outputs_spot\news\latest_macro_context.json
```

## Broker symbol examples
```powershell
python spot_main.py --symbol XAUUSDm --days 3 --workers 10 --count 900 --learning
python spot_main.py --symbol GOLD --days 3 --workers 10 --count 900 --learning
```

## Outputs
- `outputs_spot/latest_spot_decision.json`
- `outputs_spot/latest_spot_decision.txt`
- `outputs_spot/latest_spot_chatgpt_prompt.txt`
- `outputs_spot/news/...` (unchanged News engine outputs)

Use `--debug-full-output` to also write `outputs_spot/latest_spot_internal_debug.json`.

## Important behavior
- M5 is used for MT5 data-health/spread/reopen checks only and is excluded from Spot directional voting.
- M15 is timing-only.
- MN1/W1/D1/H4/H1 drive Spot direction.
- The program does not send orders to MetaTrader 5.


## LLM Contract V1.1

The Spot engine now publishes a dedicated `spot_opportunity` object.  It intentionally separates **setup discovery** from **execution permission**.  A valid long setup remains visible during market/spread/event/conviction WAIT states, so ChatGPT can always report the planned buy zone, ladder, invalidation and TP1/TP2/TP3 without falsely calling it an immediate BUY.

Important fields:

- `spot_opportunity.buy_setup_available`
- `spot_opportunity.setup_state`
- `spot_opportunity.execution_permission`
- `spot_opportunity.actionable_now`
- `spot_opportunity.best_buy_zone`
- `spot_opportunity.entry_status`
- `spot_opportunity.entry_ladder`
- `spot_opportunity.weighted_entry`
- `spot_opportunity.invalidation`
- `spot_opportunity.targets.tp1/tp2/tp3`
- `spot_opportunity.macro_risk`

`decision` remains the canonical answer to **can this be executed now?**.  `spot_opportunity` answers **is there a valid planned spot buy setup and where is it?**.

## Strategic 30-60 Day Target Engine

This build separates entry execution geometry from the slower spot thesis.

- TP1: tactical structural objective, generally a multi-session objective.
- TP2: swing structural objective, generally a multi-week objective.
- TP3: primary strategic 30-60 day objective.
- Runner: optional 45-90+ day continuation objective.

Targets are discovered from D1/W1/MN1 structure, buy-side/sell-side liquidity,
major swing levels, opposing higher-timeframe order blocks, volume-profile HVNs,
Fibonacci extensions, completed measured moves and weekly/monthly volatility
projections. Nearby evidence is clustered and scored. R:R validates target quality;
it does not create the primary targets.

The output also exposes two different invalidations:

- `entry_invalidation`: invalidates the planned entry geometry.
- `thesis_invalidation`: slower D1/W1/MN1 level that invalidates the 30-60 day thesis.

`TP3` is the main one-month-plus objective consumed by the ChatGPT contract.
Horizon estimates are scenario windows, never guaranteed time-to-target forecasts.

## 30-60 Day Staged Position Management
The spot engine now manages the existing structural objectives as one long-horizon thesis rather than adding more targets. `position_management_30_60d` contains adaptive staged realization at TP1/TP2/TP3/Runner, remaining core exposure, model-estimated reachability scores, thesis-survival scores, and D1/W1 review rules. Reachability scores are ranking estimates and are not empirical win probabilities. No automatic broker order is sent.

## V3 — Canonical Position Lifecycle + Adaptive De-risk

This version preserves the complete Spot/News/MT5/Strategic Target/Staged Exit stack and adds a persisted position-aware lifecycle.

Canonical lifecycle states:

- `FLAT_NO_SETUP`
- `PRE_ENTRY_WATCH`
- `ENTRY_ARMED`
- `POSITION_OPEN`
- `TP1_REALIZED`
- `STRATEGIC_CORE`
- `RUNNER_ONLY`
- `THESIS_INVALIDATED`
- `CLOSED`

The bot **does not infer an open position from price alone**. Until a position is explicitly registered, the lifecycle remains pre-entry even if market price happens to be above a target.

Register a paper/manual Spot fill after analysis:

```powershell
python spot_main.py --symbol XAUUSD --days 3 --workers 10 --count 900 --learning --paper-open-position
```

Register a specific actual/paper fill price:

```powershell
python spot_main.py --symbol XAUUSD --days 3 --workers 10 --count 900 --learning --paper-open-position --position-entry-price 4617.50 --position-note "manual paper fill"
```

Close the persisted position lifecycle:

```powershell
python spot_main.py --symbol XAUUSD --days 3 --workers 10 --count 900 --learning --paper-close-position --position-note "manual close"
```

The registry defaults to:

```text
state_spot/spot_position.json
```

Adaptive future allocation is reviewed only after a **new D1 or W1 close**. Intraday M5/M15 movement cannot change staged allocation. Already-realized stages are immutable. Confirmed deterioration may shift a bounded portion of future exposure toward the nearest objective; confirmed structural/macro improvement may preserve more future exposure for TP3/Runner.

## Spot Intelligence V2 upgrades

This release preserves the complete prior lifecycle/adaptive/staged-exit stack and adds horizon-aware spot intelligence:

- **Spot Execution Cost Gate V2**: a relative spread spike no longer blocks a 30–60D spot setup by itself. Cost is normalized to price bps, H1 ATR, zone width and execution-risk distance. Non-spread market/data hard gates remain fail-closed.
- **Corrected directional OTE**: long OTE is the 62–79% retracement measured down from the dealing-range high; short OTE is measured up from the low. The pre-V4 OTE value remains in diagnostics for backward comparison.
- **HTF trend/structure disagreement penalty**: W1/D1/H4 trend-versus-structure conflict reduces conviction instead of being silently averaged away.
- **Dual-risk model**: legacy tactical execution RR is retained, while `thesis_rr` uses the D1/W1 thesis invalidation and is the preferred risk metric for 30–60D interpretation.
- **Review milestones**: high-quality intermediate structural clusters are emitted as `REVIEW_THESIS_ONLY_NO_AUTOMATIC_EXIT`; they are not extra TP levels and do not change the staged-exit philosophy.
- **Compact LLM packet**: `latest_spot_chatgpt_prompt.txt` is decision-focused. Full forensic evidence is still retained in `latest_spot_decision.json` and `latest_spot_chatgpt_prompt_full.txt`.

The exit objectives remain exactly TP1 / TP2 / TP3 / Runner. Milestones are review checkpoints only.

## Pullback Quality / Cool-off Resolution (V5)

This release adds `AMB_SPOT_PULLBACK_QUALITY_V1` without removing any prior Spot, News, MT5, target, lifecycle, learning, or staged-exit capability.

The previous `late_extended -> WAIT` binary behavior is replaced by a multi-factor cool-off resolution layer. It evaluates:

- H1/H4/D1 RSI normalization
- H1/H4 statistical z-score reset
- H1/H4 volatility-percentile normalization
- H4/H1 swing-anchored VWAP reset
- distance and interaction with the institutional buy zone in H1 ATR units
- D1/H4/H1 trend / structure / external structure / MSS / Ichimoku thesis integrity
- H1/M15 timing recovery
- H1/M15 sell-side sweep rejection and bullish rejection candles
- macro opposition and thesis-invalidation hard-fail conditions

Canonical states:

- `OVEREXTENSION_PERSISTS`
- `COOL_OFF_INCOMPLETE`
- `COOL_OFF_PROGRESSING`
- `COOL_OFF_RESOLVED_ENTRY_ARMED`
- `COOL_OFF_RESOLVED_ENTRY_READY`
- `THESIS_RISK_BLOCKED`

`late_extended` is no longer an automatic execution block. A BUY can become actionable only when the cool-off layer confirms sufficient reset while D1/H4 thesis integrity remains intact and all pre-existing market / macro / data / cost / conviction gates also pass.

`ENTRY_ARMED` is explicitly not a fill and does not mean a position is open. The persistent Position Registry remains authoritative for post-fill lifecycle states.

## V6 — Adaptive Accumulation + Thesis Health + Falling-Knife Guard

This revision preserves every previous Spot feature and adds three coordinated layers:

- `AMB_SPOT_ADAPTIVE_ACCUMULATION_V1`: keeps the structural entry prices unchanged but adapts tranche sizing and determines which tranche(s) are eligible now. Spot accumulation does not require a scalp-grade M5/M15 trigger.
- `AMB_SPOT_THESIS_HEALTH_V1`: slow 30–60 day health monitor based on MN1/W1/D1/H4 structure, macro durability, trend quality, valuation and thesis invalidation. Canonical review clocks are D1/W1 closes.
- `AMB_SPOT_FALLING_KNIFE_GUARD_V1`: pauses NEW accumulation when downside structure/displacement/flow/volatility indicates a cascade. It does not mechanically close an existing 30–60 day position.

The position registry now supports partial paper fills. Existing `--paper-open-position` remains supported and represents a fully accumulated legacy/manual position.

Record an eligible paper tranche:

```powershell
python spot_main.py `
  --symbol XAUUSD `
  --days 3 `
  --workers 10 `
  --count 900 `
  --learning `
  --paper-fill-tranche 1
```

Optionally provide the actual fill price:

```powershell
python spot_main.py `
  --symbol XAUUSD `
  --days 3 `
  --workers 10 `
  --count 900 `
  --learning `
  --paper-fill-tranche 2 `
  --tranche-fill-price 4612.50 `
  --position-note "manual paper fill"
```

The registry tracks `accumulated_pct`, `actual_cost_basis`, individual `accumulation_fills`, target realization, thesis invalidation and adaptive exit allocation.
