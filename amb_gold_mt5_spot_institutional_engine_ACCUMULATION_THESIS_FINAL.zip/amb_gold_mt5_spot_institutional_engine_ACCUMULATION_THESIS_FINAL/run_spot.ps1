param(
    [string]$Symbol = "XAUUSD",
    [int]$Days = 3,
    [int]$Workers = 10,
    [int]$Count = 900,
    [switch]$Exhaustive,
    [switch]$DebugFullOutput
)

$ErrorActionPreference = "Stop"

$argsList = @(
    "spot_main.py",
    "--symbol", $Symbol,
    "--days", $Days,
    "--workers", $Workers,
    "--count", $Count,
    "--learning"
)
if ($Exhaustive) { $argsList += "--exhaustive" }
if ($DebugFullOutput) { $argsList += "--debug-full-output" }

python @argsList
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

Write-Host ""
Write-Host "=== SPOT DECISION ===" -ForegroundColor Cyan
Get-Content "outputs_spot\latest_spot_decision.txt"
