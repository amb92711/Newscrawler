# AMB Gold Unified AI Learning Engine — MT5 Windows Professional Edition

این نسخه برای **Windows + MetaTrader 5 live** بازنویسی شده است. بخش اخبار تقریباً همان V8.5 باقی مانده، فقط دو منبع سخت‌اسکرپ یعنی `kitco` و `mining` از لیست اجرای پیش‌فرض حذف شده‌اند و به جای آن‌ها دو منبع عملی‌تر اضافه شده‌اند:

- `fxempire_gold`
- `investing_gold`

## مهم‌ترین تغییرات نسخه MT5

- پیش‌فرض چارت از `Binance XAUTUSDT` به `MetaTrader 5 / XAUUSD` تغییر کرده است.
- اتصال مستقیم به ترمینال باز MT5 ویندوز با پکیج رسمی `MetaTrader5`.
- دریافت کندل‌های زنده چندتایم‌فریم از بروکر خودت:
  - M5
  - M15
  - H1
  - H4
  - D1
- دریافت Tick / Bid / Ask / Spread / Tick Volume / Real Volume در صورت ارائه بروکر.
- دریافت Market Book / Depth اگر بروکر برای نماد طلا ارائه کند.
- اضافه شدن اندیکاتورهای پیشرفته:
  - EMA 8/13/20/21/34/50/55/89/100/144/200/233
  - SMA 20/50/100/200
  - RSI 14
  - ATR 14
  - ADX 14
  - MACD
  - Bollinger Bands
  - Ichimoku Cloud: Tenkan, Kijun, Senkou A/B, Cloud Bias, TK Cross
  - SuperTrend 10/3
  - Stoch RSI
  - Session VWAP Proxy
  - Keltner Channel
  - Donchian Channel
  - Pivot R/S
  - Heikin Ashi
  - Candle Patterns: Pinbar / Engulfing
- Smart Money / Price Action قبلی حفظ شده:
  - BOS / CHOCH / MSS
  - Liquidity pools / sweeps
  - FVG
  - Order Blocks
  - Support / Resistance
  - Session Analysis
  - Volume Profile
  - AI Evidence Fusion
  - Learning Memory

## نصب روی Windows

اول MetaTrader 5 Desktop را باز کن و وارد حساب دمو یا واقعی شو. نماد طلا را در Market Watch اضافه کن، مثلاً:

- `XAUUSD`
- `XAUUSDm`
- `GOLD`
- `XAUUSD.r`

بعد در PowerShell:

```powershell
cd $env:USERPROFILE\Downloads
Expand-Archive -Force amb_gold_unified_ai_learning_engine_mt5_windows_pro.zip amb_gold_unified_ai_learning_engine_mt5_windows_pro
cd amb_gold_unified_ai_learning_engine_mt5_windows_pro
python -m venv .venv
.\.venv\Scripts\activate
python -m pip install -U pip setuptools wheel
pip install -r requirements.txt
```

## اجرای کامل News + MT5 Chart + AI Decision

```powershell
python main.py --provider mt5 --symbol XAUUSD --exhaustive --workers 10 --count 900 --learning
```

اگر نماد بروکر تو پسوند دارد:

```powershell
python main.py --provider mt5 --symbol XAUUSDm --exhaustive --workers 10 --count 900 --learning
```

یا:

```powershell
python main.py --provider mt5 --symbol GOLD --exhaustive --workers 10 --count 900 --learning
```

## اگر MT5 مسیر خاص دارد

```powershell
python main.py --provider mt5 --symbol XAUUSD --mt5-path "C:\Program Files\MetaTrader 5\terminal64.exe" --exhaustive --workers 10 --count 900 --learning
```

## اگر لاگین داخل ترمینال باز نیست

معمولاً لازم نیست این‌ها را بدهی، اما اگر خواستی:

```powershell
python main.py --provider mt5 --symbol XAUUSD --mt5-login 123456 --mt5-password "PASSWORD" --mt5-server "Broker-Server" --exhaustive --workers 10 --count 900 --learning
```

## تست فقط چارت MT5 با News قبلی

```powershell
python main.py --chart-only --provider mt5 --symbol XAUUSD --news-context outputs\news\latest_macro_context.json --count 900 --learning
```

## خروجی‌ها

```text
outputs/latest_final_decision.json
outputs/latest_final_decision.txt
outputs/latest_chatgpt_prompt.txt
outputs/news/
outputs/chart/
```

برای ChatGPT معمولاً این فایل کافی است:

```text
outputs/latest_chatgpt_prompt.txt
```

## نکات مهم MT5

- این نسخه روی Android/Termux برای MT5 اجرا نمی‌شود؛ چون پکیج رسمی `MetaTrader5` مخصوص Windows است.
- نسخه Binance هنوز برای تست باقی مانده و با `--provider binance` قابل اجراست، اما پیش‌فرض پروژه `mt5` است.
- AutoTrading لازم نیست روشن باشد؛ این پروژه فقط دیتا می‌خواند و معامله باز نمی‌کند.
- اگر نماد پیدا نشود، اسم دقیق نماد را از Market Watch بروکر بردار.

## اجرای بکاپ Binance برای تست

```bash
python main.py --provider binance --symbol XAUTUSDT --exhaustive --workers 10 --count 900 --learning
```

## MT5 Ultra Technical/Execution Upgrade

This build preserves the existing News, Macro, Learning, SMC, AI-fusion and MT5 functionality and adds a stricter institutional execution layer.

### Added technical evidence
- Ichimoku full cloud state (Tenkan/Kijun/Senkou/Chikou context retained)
- Supertrend, extended EMA/SMA stack, VWAP, Keltner, Donchian, Bollinger, pivots
- ROC, CCI, Williams %R, MFI
- OBV and Chaikin Money Flow
- DMI +DI/-DI spread, ADX trend quality
- Choppiness Index and Kaufman-style Efficiency Ratio
- Historical volatility, Bollinger/Keltner width and squeeze state
- Existing SMC/price-action stack is preserved: BOS, CHOCH, MSS, sweeps, liquidity, FVG, order blocks, S/R, sessions, volume profile, candle patterns, Heikin-Ashi

### Intelligent technical consensus
Advanced indicators are not converted into brittle BUY/SELL rules. They contribute continuous, timeframe-weighted evidence to the technical score. D1/H4 receive greater regime weight, while M5/M15 remain execution/timing evidence.

### RR-aware Execution Planner
Spot and scalp now have separate execution planners:
- Spot entries prioritize D1/H4/H1 zones.
- Scalp entries prioritize M5/M15/H1 zones.
- Stop/invalidation is always placed beyond the selected zone with ATR + live-spread buffer.
- TP1/TP2/TP3 are built from structural liquidity/SR first and R-multiple projections as fallback.
- Invalid geometry or missing coherent targets prevents a BUY/SELL approval.
- Output contains primary_entry, stop distance, ATR multiple, target RR, and execution quality.

### Probability calibration
The engine retains the raw evidence posterior but no longer presents extreme values as an empirical win probability. Final long/short probabilities are shrunk toward 50% according to evidence reliability and accumulated Learning samples. The JSON explicitly labels the semantics as `calibrated_evidence_posterior_not_empirical_win_rate`.

### News source change
The active news engine keeps its existing architecture. Kitco/Mining.com are not active default scrapers. Their old Google fallback queries have also been replaced with Reuters and FXEmpire gold queries. Existing FXEmpire Gold and Investing Gold specialist sources remain enabled.


## Ultra State Machine Upgrade

This build preserves all existing News/Macro, MT5, SMC, indicator, AI-fusion and learning features and adds a dedicated execution state machine.

Spot/Scalp states are now price-location aware:
- `BUY_NOW` / `SELL_NOW`
- `WAIT_PULLBACK_LONG` / `WAIT_PULLBACK_SHORT`
- `WAIT_RETEST_LONG` / `WAIT_RETEST_SHORT`
- `BREAKOUT_RETEST_LONG` / `BREAKOUT_RETEST_SHORT`
- `READY_LONG` / `READY_SHORT`
- `PREPARE_LONG` / `PREPARE_SHORT`
- `BLOCKED_LONG` / `BLOCKED_SHORT`
- `WAIT_COOLDOWN_LONG` / `WAIT_COOLDOWN_SHORT`

Execution now combines primary-zone location, ATR-normalized distance, M5/M15 timing alignment, H1/higher-timeframe alignment, recent BOS/CHOCH retest level, momentum overextension, spread, event risk, zone confluence, premium/discount location, RR geometry and AI confidence. Directional bias alone can no longer produce an immediate entry.

## Ultra Synchronized Execution Upgrade

This build preserves all prior News, MT5, technical, SMC, Ichimoku, AI-fusion and learning capabilities and adds a synchronized institutional execution layer.

Key additions:
- Canonical Execution State shared by fusion, AI inference, playbook, state machine and final decision.
- Consistency audit to detect semantic contradictions before output.
- Style-aware zone ranking: spot prioritizes D1/H4/H1; scalp prioritizes M15/M5/H1.
- ATR-normalized execution proximity so distant scalp zones cannot dominate due to a high historical score.
- Timing Quality and Setup Quality scores.
- Liquidity-sweep confirmation and active-session context in the execution state machine.
- Improved overextension logic using RSI/Bollinger plus efficiency/choppiness context.
- Watchlist zones/invalidation/targets remain visible when action is WAIT, while actionable entry fields stay empty.
- Invalidation model metadata and professional geometry/RR checks.
- Canonical trade permission is created only after price-location state-machine evaluation.

The AI fusion model remains responsible for direction/confidence. The execution state machine is responsible for whether that directional thesis is executable now.

## Market-Aware Execution Layer (V4)

This build preserves all previous News V8.5, MT5 chart intelligence, SMC, Ichimoku,
advanced indicators, AI evidence fusion, learning memory, execution planning and
canonical state synchronization. It adds an execution-grade market-state layer.

Canonical market states:

- `OPEN` -> execution may proceed if all other gates agree.
- `CLOSED_WEEKEND` -> directional bias/watchlist only; no live entry.
- `TERMINAL_DISCONNECTED` -> execution blocked until MT5 reconnects.
- `DATA_STALE` -> execution blocked until quote/M5 freshness recovers.
- `REOPEN_COOLDOWN` -> after a long market closure/gap, wait for initial M5 bars.
- `OPEN_SPREAD_EXTREME` -> execution blocked when live spread is extreme versus the broker's recent spread baseline.

The engine now reports:

- last tick age and quote freshness;
- M5/M15/H1/H4/D1 data ages and freshness grades;
- cross-timeframe timestamp coherence;
- dynamic spread ratio versus recent MT5 candle spread history;
- recent tick rate, micro price range and tick-path efficiency;
- weekend/reopen gap size and ATR multiple;
- bars elapsed after reopen and cooldown requirement;
- market/data quality score;
- canonical market execution gate;
- weekend outlook separated from executable signals.

When the market is closed, News/Macro can still run normally. The final packet keeps
bias, regime and watchlist zones, but Spot/Scalp execution remains `WAIT` and the
canonical permission becomes `MARKET_CLOSED`.

## Time synchronization + paper test

This build normalizes broker-server timestamp skew conservatively. Standard MT5 UTC epoch timestamps remain unchanged. If an impossible future tick is observed, the provider infers a quantized broker offset and applies the same correction to ticks and bars. The market-state engine uses signed ages and blocks `TIME_SYNC_FAULT` rather than treating a future timestamp as fresh.

Every run also writes paper-only testing outputs:

- `outputs/latest_paper_test_plan.json`
- `outputs/latest_paper_test_plan.txt`

`PAPER_READY` is emitted only when the normal Spot/Scalp production decision has already passed all market, news, risk, timing, zone and trigger gates. No order is sent to MetaTrader 5.

## MT5 Time-Coherence Final Patch

This build uses **independent tick/bar clock models**. It never assumes the same broker
UTC offset applies to both tick and candle history. When a live tick is fresh but M5/M15
history remains behind, the provider performs a bounded history refresh and, if unresolved,
returns `HISTORY_UNSYNCHRONIZED / BLOCKED_HISTORY_SYNC`. No synthetic candle is created and
Paper Test remains blocked until coherent fresh execution data is available.

Inspect `market_state.time_coherence` and `market_state.history_sync` in the final JSON for
full raw/normalized time diagnostics.


## Event Risk V2 + Institutional Feature Layer
- Event risk is now proximity/severity aware. A distant Medium USD speech no longer becomes HIGH merely because the title contains USD.
- Untimed TradingEconomics final/archive rows are kept as macro context but cannot independently block execution.
- Critical releases (FOMC/rates/CPI/PCE/NFP/Fed Chair) use tighter pre/post execution windows.
- New continuous technical evidence: KAMA, Aroon, Fisher Transform, swing-anchored VWAPs, relative-volume displacement quality, price z-score, and volatility-regime percentile.
- These features are bounded evidence inside the existing consensus/Fusion path; they do not bypass market, event, spread, state-machine, or paper-test gates.

## 30-60 Day Spot Upgrade

The spot-only path now includes `AMB_SPOT_STRATEGIC_TARGET_ENGINE_V2_30_60D`.
It preserves all prior functionality while replacing short-horizon target selection
in the final Spot contract with evidence-ranked D1/W1/MN1 objectives. See
`README_SPOT.md` for target semantics and invalidation separation.

## Spot V6 accumulation architecture

The Spot entry path is accumulation-first rather than scalp-trigger-first. New tranches require a valid structural buy plan, healthy slow thesis, acceptable market/event gates and falling-knife safety. H1/M15 timing modulates quality but does not replace MN1/W1/D1/H4 thesis logic. No order is sent to MetaTrader; all position registry operations are paper/manual state tracking.
