from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path
from typing import Any

from amb_gold_news.engine import run_engine
from amb_gold_news.report import render_report
from amb_chart.config import EngineConfig, DEFAULT_TIMEFRAMES, MT5_TIMEFRAMES
from amb_chart.providers.binance_xaut import BinanceXautProvider
from amb_chart.providers.mt5_live import MT5LiveProvider
from amb_chart.analysis.engine import analyze
from amb_chart.analysis.decision import build_final_decision_packet
from amb_chart.reporting.writer import write_outputs, write_final_outputs
from amb_chart.learning.memory import LearningMemory


def _load_json(path: Path) -> dict[str, Any]:
    with path.open('r', encoding='utf-8') as f:
        return json.load(f)


def _copy_final_outputs(chart_out: Path, root_out: Path) -> None:
    root_out.mkdir(parents=True, exist_ok=True)
    mapping = {
        'latest_final_decision.json': 'latest_final_decision.json',
        'latest_final_decision.txt': 'latest_final_decision.txt',
        'latest_chatgpt_prompt.txt': 'latest_chatgpt_prompt.txt',
        'latest_paper_test_plan.json': 'latest_paper_test_plan.json',
        'latest_paper_test_plan.txt': 'latest_paper_test_plan.txt',
    }
    for src_name, dst_name in mapping.items():
        src = chart_out / src_name
        if src.exists():
            shutil.copy2(src, root_out / dst_name)


def _attach_news_to_chart(chart: dict[str, Any], news_context_path: Path | None) -> dict[str, Any]:
    fusion = chart.setdefault('fusion_context', {})
    if news_context_path and news_context_path.exists():
        fusion['news_macro_context'] = {'attached': True, 'data': _load_json(news_context_path)}
    else:
        fusion['news_macro_context'] = {'attached': False}
    return chart


def _load_decision(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise FileNotFoundError(f'Decision file not found: {path}')
    return _load_json(path)


def _attach_learning_to_chart(chart: dict[str, Any], learning_profile: dict[str, Any] | None) -> dict[str, Any]:
    if learning_profile:
        chart.setdefault('fusion_context', {})['learning_profile'] = learning_profile
    return chart


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description='AMB Gold Unified News + Chart Final Decision Engine')
    p.add_argument('--symbol', default='XAUUSD', help='MT5 symbol name, e.g. XAUUSD, XAUUSDm, GOLD, XAUUSD.r')
    p.add_argument('--provider', default='mt5', choices=['mt5','binance'], help='Chart data provider. Default is mt5 for Windows MetaTrader 5 live data.')
    p.add_argument('--mt5-path', default=None, help='Optional terminal64.exe path')
    p.add_argument('--mt5-login', type=int, default=None, help='Optional MT5 login; usually not needed if terminal is already logged in')
    p.add_argument('--mt5-password', default=None, help='Optional MT5 password')
    p.add_argument('--mt5-server', default=None, help='Optional MT5 broker server')
    p.add_argument('--mt5-portable', action='store_true', help='Initialize MT5 in portable mode')
    p.add_argument('--count', type=int, default=900)
    p.add_argument('--days', type=int, default=7)
    p.add_argument('--workers', type=int, default=8)
    p.add_argument('--output-dir', default='outputs')
    p.add_argument('--skip-heavy', action='store_true', help='Skip Bloomberg/IG heavy public sources')
    p.add_argument('--no-google', action='store_true', help='Disable Google News fallback')
    p.add_argument('--no-source-caps', action='store_true', help='Do not cap background-heavy sources')
    p.add_argument('--exhaustive', action='store_true', help='Use 7+ days, heavy sources, Google fallback, no source caps')
    p.add_argument('--debug-full-output', action='store_true', help='Also write full internal chart debug JSON')
    p.add_argument('--news-only', action='store_true')
    p.add_argument('--chart-only', action='store_true', help='Skip news scraping and use --news-context if provided')
    p.add_argument('--news-context', default=None, help='Existing latest_macro_context.json to use instead of running news')
    p.add_argument('--from-chart-context', default=None, help='Rebuild final decision from an existing latest_chart_context/internal JSON')

    # Adaptive learning / self-calibration
    p.add_argument('--learning', action='store_true', help='Enable local adaptive learning multipliers and thresholds')
    p.add_argument('--state-dir', default='state', help='Directory for learning memory, pending predictions and history')
    p.add_argument('--horizon-minutes', type=int, default=60, help='Prediction horizon for learning records')
    p.add_argument('--auto-evaluate-pending', action='store_true', help='Evaluate due pending predictions using the current reference price after a new run')
    p.add_argument('--record-outcome', action='store_true', help='Update learning memory from a previous decision outcome and exit')
    p.add_argument('--decision-file', default=None, help='Decision JSON used by --record-outcome; default outputs/latest_final_decision.json')
    p.add_argument('--prediction-id', default=None, help='Prediction id used by --record-outcome')
    p.add_argument('--close-price', type=float, default=None, help='Observed close/current price for --record-outcome')
    p.add_argument('--outcome-direction', default=None, choices=['long','short','flat','neutral'], help='Observed direction for --record-outcome')
    p.add_argument('--outcome-pct', type=float, default=None, help='Observed percentage move for --record-outcome')
    p.add_argument('--notes', default='', help='Optional notes for --record-outcome')
    return p.parse_args()


def run_news(args: argparse.Namespace, root_out: Path) -> Path:
    news_out = root_out / 'news'
    news_out.mkdir(parents=True, exist_ok=True)
    days = max(args.days, 7) if args.exhaustive else args.days
    include_heavy = not args.skip_heavy
    include_google = not args.no_google
    source_caps = not args.no_source_caps
    if args.exhaustive:
        include_heavy = True
        include_google = True
        source_caps = False
    items, stats = run_engine(
        days=days,
        workers=args.workers,
        include_heavy=include_heavy,
        include_google=include_google,
        output_dir=str(news_out),
        source_caps=source_caps,
    )
    render_report(items, stats, output_dir=str(news_out))
    macro_path = news_out / 'latest_macro_context.json'
    if not macro_path.exists():
        raise RuntimeError(f'News engine did not create {macro_path}')
    return macro_path


def run_chart(args: argparse.Namespace, root_out: Path, macro_path: Path | None, learning_profile: dict[str, Any] | None = None) -> Path:
    chart_out = root_out / 'chart'
    chart_out.mkdir(parents=True, exist_ok=True)
    if args.from_chart_context:
        chart = _attach_learning_to_chart(_attach_news_to_chart(_load_json(Path(args.from_chart_context)), macro_path), learning_profile)
        decision = build_final_decision_packet(chart)
        write_final_outputs(str(chart_out), decision)
        _copy_final_outputs(chart_out, root_out)
        return chart_out

    if args.provider == 'mt5':
        timeframes = dict(MT5_TIMEFRAMES)
        provider = MT5LiveProvider(
            symbol=args.symbol,
            terminal_path=args.mt5_path,
            login=args.mt5_login,
            password=args.mt5_password,
            server=args.mt5_server,
            portable=args.mt5_portable,
        )
    else:
        timeframes = dict(DEFAULT_TIMEFRAMES)
        provider = BinanceXautProvider('XAUTUSDT')

    cfg = EngineConfig(
        symbol=args.symbol if args.provider == 'mt5' else 'XAUTUSDT',
        count=args.count,
        timeframes=timeframes,
        output_dir=str(chart_out),
        news_context_path=str(macro_path) if macro_path else None,
    )
    ctx = analyze(provider, cfg)
    if learning_profile:
        data = ctx.to_dict()
        data.setdefault('fusion_context', {})['learning_profile'] = learning_profile
        decision = build_final_decision_packet(data)
        data['fusion_context']['institutional_decision_packet'] = decision
        # Replace only the final packet outputs. The original internal chart remains available
        # when --debug-full-output is used.
        write_final_outputs(cfg.output_dir, decision)
        if args.debug_full_output:
            (Path(cfg.output_dir) / 'latest_internal_debug.json').write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    else:
        write_outputs(cfg.output_dir, ctx, debug_full=args.debug_full_output)
    _copy_final_outputs(chart_out, root_out)
    return chart_out


def main() -> None:
    args = parse_args()
    root_out = Path(args.output_dir)
    root_out.mkdir(parents=True, exist_ok=True)
    learning_memory = LearningMemory(args.state_dir)

    if args.record_outcome:
        decision_path = Path(args.decision_file) if args.decision_file else root_out / 'latest_final_decision.json'
        decision = _load_decision(decision_path) if decision_path.exists() else None
        update = learning_memory.record_outcome(
            prediction_id=args.prediction_id,
            decision=decision,
            close_price=args.close_price,
            outcome_direction=args.outcome_direction,
            outcome_pct=args.outcome_pct,
            notes=args.notes,
        )
        print('✅ Learning memory updated:')
        print(json.dumps(update, ensure_ascii=False, indent=2))
        return

    learning_profile = learning_memory.profile(enabled=True) if args.learning else None

    macro_path: Path | None = Path(args.news_context) if args.news_context else None
    if not args.chart_only:
        print('▶ Running News/Macro V8.5 ...')
        macro_path = run_news(args, root_out)
        print(f'✅ News macro context: {macro_path}')
    elif macro_path:
        print(f'▶ Using existing news context: {macro_path}')
    else:
        print('⚠️ Chart-only mode without --news-context: final decision will be WAIT by hard rule.')

    if args.news_only:
        return

    print('▶ Running Chart + Final Decision Engine ...')
    chart_out = run_chart(args, root_out, macro_path, learning_profile=learning_profile)
    print(f'✅ Chart outputs: {chart_out}')
    print(f'✅ Final decision: {root_out / "latest_final_decision.txt"}')
    print(f'✅ ChatGPT prompt: {root_out / "latest_chatgpt_prompt.txt"}')

    if args.learning:
        decision_path = root_out / 'latest_final_decision.json'
        if decision_path.exists():
            decision = _load_decision(decision_path)
            reg = learning_memory.register_prediction(decision, horizon_minutes=args.horizon_minutes)
            print(f'✅ Learning prediction registry: {json.dumps(reg, ensure_ascii=False)}')
            if args.auto_evaluate_pending:
                ref = ((decision.get('market_snapshot') or {}).get('reference_price'))
                if ref:
                    ev = learning_memory.auto_evaluate_pending(float(ref), min_age_minutes=args.horizon_minutes)
                    print(f'✅ Auto-evaluation: {json.dumps(ev, ensure_ascii=False)}')


if __name__ == '__main__':
    main()
