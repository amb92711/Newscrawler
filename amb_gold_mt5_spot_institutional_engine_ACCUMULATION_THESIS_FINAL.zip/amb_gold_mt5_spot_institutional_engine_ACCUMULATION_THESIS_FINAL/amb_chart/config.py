from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, Optional

DEFAULT_TIMEFRAMES = {
    "M5": "5m",
    "M15": "15m",
    "H1": "1h",
    "H4": "4h",
    "D1": "1d",
}
MT5_TIMEFRAMES = {"M5":"M5", "M15":"M15", "H1":"H1", "H4":"H4", "D1":"D1"}

@dataclass
class EngineConfig:
    symbol: str
    count: int = 900
    output_dir: str = "outputs"
    timeframes: Dict[str, str] = field(default_factory=lambda: dict(DEFAULT_TIMEFRAMES))
    swing_left: int = 3
    swing_right: int = 3
    internal_swing_left: int = 2
    internal_swing_right: int = 2
    zone_merge_atr: float = 0.35
    liquidity_tolerance_atr: float = 0.18
    fvg_min_atr: float = 0.08
    order_block_lookback: int = 180
    order_block_max_age: int = 220
    session_tz: str = "UTC"
    news_context_path: Optional[str] = None
    strict_single_symbol: bool = True
    related_symbols: Dict[str, str] = field(default_factory=dict)
