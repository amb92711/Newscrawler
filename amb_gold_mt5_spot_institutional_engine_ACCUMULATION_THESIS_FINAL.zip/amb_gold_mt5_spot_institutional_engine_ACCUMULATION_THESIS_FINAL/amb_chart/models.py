from __future__ import annotations
from dataclasses import dataclass, asdict, field
from typing import Any, Dict, List, Optional

@dataclass
class ProviderHealth:
    provider: str
    ok: bool
    symbol: str
    message: str
    details: Dict[str, Any] = field(default_factory=dict)

@dataclass
class TimeframeContext:
    timeframe: str
    candles: int
    last_time: str
    last_close: float
    trend: str
    momentum: str
    volatility: str
    structure: str
    ema: Dict[str, Optional[float]]
    rsi: Optional[float]
    atr: Optional[float]
    adx: Optional[float]
    macd: Dict[str, Optional[float]]
    bollinger: Dict[str, Optional[float]]
    swings: Dict[str, Any]
    advanced_structure: Dict[str, Any]
    liquidity: Dict[str, Any]
    fvg: List[Dict[str, Any]]
    order_blocks: List[Dict[str, Any]]
    support_resistance: Dict[str, List[float]]
    zones: Dict[str, Any]
    volume_profile: Dict[str, Any]
    session_analysis: Dict[str, Any]
    smt: Dict[str, Any]
    ichimoku: Dict[str, Optional[float]] = field(default_factory=dict)
    advanced_indicators: Dict[str, Any] = field(default_factory=dict)
    price_action: Dict[str, Any] = field(default_factory=dict)
    warnings: List[str] = field(default_factory=list)

@dataclass
class ChartContext:
    engine: str
    provider: str
    symbol: str
    generated_utc: str
    timeframes: Dict[str, TimeframeContext]
    market_microstructure: Dict[str, Any]
    mtf_bias: Dict[str, Any]
    probability: Dict[str, Any]
    trade_quality: Dict[str, Any]
    trade_map: Dict[str, Any]
    fusion_context: Dict[str, Any]
    risk_notes: List[str]
    data_quality: Dict[str, Any]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
