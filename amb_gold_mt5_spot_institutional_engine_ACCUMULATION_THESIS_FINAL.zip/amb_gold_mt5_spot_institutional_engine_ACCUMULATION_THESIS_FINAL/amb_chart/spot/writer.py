from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Mapping


def write_spot_outputs(output_dir: str | Path, packet: Dict[str, Any], debug_chart: Dict[str, Any] | None = None) -> Path:
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    (out / "latest_spot_decision.json").write_text(json.dumps(packet, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "latest_spot_decision.txt").write_text(render_spot_summary(packet), encoding="utf-8")
    # Default LLM packet is intentionally compact; the full forensic packet remains
    # available in latest_spot_decision.json and in the optional full prompt below.
    (out / "latest_spot_chatgpt_prompt.txt").write_text(render_spot_prompt(packet), encoding="utf-8")
    (out / "latest_spot_chatgpt_prompt_full.txt").write_text(render_spot_prompt_full(packet), encoding="utf-8")
    if debug_chart is not None:
        (out / "latest_spot_internal_debug.json").write_text(json.dumps(debug_chart, ensure_ascii=False, indent=2), encoding="utf-8")
    return out


def _price(x: Any) -> Any:
    return x.get("price") if isinstance(x, dict) else x


def _target_compact(t: Any) -> Any:
    if not isinstance(t, dict):
        return t
    h = t.get("horizon") or {}
    return {
        "role": t.get("role"),
        "price": t.get("price"),
        "execution_rr": t.get("execution_rr", t.get("rr")),
        "thesis_rr": t.get("thesis_rr"),
        "selection_score": t.get("selection_score"),
        "evidence_quality": t.get("evidence_quality"),
        "sources": t.get("sources"),
        "timeframes": t.get("timeframes"),
        "evidence_count": t.get("evidence_count"),
        "structural_evidence_count": t.get("structural_evidence_count"),
        "horizon": h,
    }


def _opportunity_compact(o: Mapping[str, Any]) -> Dict[str, Any]:
    targets = o.get("targets") or {}
    return {
        "directional_bias": o.get("directional_bias"),
        "buy_setup_available": o.get("buy_setup_available"),
        "setup_state": o.get("setup_state"),
        "execution_permission": o.get("execution_permission"),
        "actionable_now": o.get("actionable_now"),
        "current_execution_state": o.get("current_execution_state"),
        "block_or_wait_reason": o.get("block_or_wait_reason"),
        "market_gate": o.get("market_gate"),
        "spot_effective_market_gate": o.get("spot_effective_market_gate"),
        "spread_gate_overridden_for_spot": o.get("spread_gate_overridden_for_spot"),
        "spot_execution_cost_gate": o.get("spot_execution_cost_gate"),
        "pullback_quality": o.get("pullback_quality"),
        "accumulation_plan": o.get("accumulation_plan"),
        "thesis_health": o.get("thesis_health"),
        "falling_knife_guard": o.get("falling_knife_guard"),
        "reference_price": o.get("reference_price"),
        "entry_status": o.get("entry_status"),
        "best_buy_zone": o.get("best_buy_zone"),
        "entry_ladder": o.get("entry_ladder"),
        "weighted_entry": o.get("weighted_entry"),
        "invalidation": o.get("invalidation"),
        "thesis_invalidation": o.get("thesis_invalidation"),
        "dual_risk_model": o.get("dual_risk_model"),
        "targets": {
            "tp1": _target_compact(targets.get("tp1")),
            "tp2": _target_compact(targets.get("tp2")),
            "tp3": _target_compact(targets.get("tp3")),
        },
        "runner_target": _target_compact(o.get("runner_target")),
        "review_milestones": o.get("review_milestones") or [],
        "one_month_outlook": {
            "minimum_analysis_horizon_days": (o.get("one_month_outlook") or {}).get("minimum_analysis_horizon_days"),
            "macro_trend_durability_score": (o.get("one_month_outlook") or {}).get("macro_trend_durability_score"),
            "thesis_review_conditions": (o.get("one_month_outlook") or {}).get("thesis_review_conditions"),
        },
        "macro_risk": o.get("macro_risk"),
    }


def render_spot_summary(p: Dict[str, Any]) -> str:
    d = p.get("decision") or {}
    o = p.get("spot_opportunity") or {}
    h = p.get("higher_timeframe_consensus") or {}
    m = p.get("macro_context") or {}
    v = p.get("valuation") or {}
    f = p.get("spot_fusion") or {}
    market = p.get("market_state") or {}
    cost = p.get("spot_execution_cost_gate") or {}
    tg = o.get("targets") or {}
    lines: List[str] = []
    lines.append("AMB GOLD MT5 INSTITUTIONAL SPOT ENGINE — ACCUMULATION + THESIS HEALTH / 30-60 DAY")
    lines.append("=" * 104)
    lines.append(f"Symbol: {p.get('symbol')} | UTC: {p.get('generated_utc')} | Reference: {p.get('reference_price')}")
    lines.append(f"Directional bias: {o.get('directional_bias')} | HTF Score={h.get('score_0_100')} | Confidence={h.get('confidence')}")
    lines.append(f"HTF trend/structure disagreement: {h.get('trend_structure_disagreement')}")
    lines.append(f"Generic market: {market.get('status')} | Generic gate: {market.get('execution_gate')} | Spot effective gate: {o.get('spot_effective_market_gate')}")
    lines.append(f"Spot execution cost: acceptable={cost.get('acceptable_for_spot')} | quality={cost.get('execution_cost_quality_0_100')} | bps={cost.get('spread_bps_of_price')} | spread/risk={cost.get('spread_pct_execution_risk')}%")
    pb = p.get("pullback_quality") or {}
    lines.append(f"Pullback/Cool-off: {pb.get('state')} | quality={pb.get('quality_score_0_100')} | reset={pb.get('reset_score_0_100')} | confirmation={pb.get('confirmation_score_0_100')} | permission={pb.get('permission')}")
    thesis = p.get("thesis_health") or {}
    knife = p.get("falling_knife_guard") or {}
    acc = p.get("accumulation_plan") or {}
    lines.append(f"Thesis health: {thesis.get('health_score_0_100')} | {thesis.get('state')} | action={thesis.get('management_action')}")
    lines.append(f"Falling-knife guard: risk={knife.get('risk_score_0_100')} | level={knife.get('level')} | permission={knife.get('permission')}")
    lines.append(f"Accumulation: {acc.get('state')} | permission={acc.get('permission')} | new allocation now={acc.get('recommended_new_allocation_pct_now')}% | eligible={acc.get('eligible_tranches_now')}")
    lines.append(f"Macro: {m.get('bias')} | Event={m.get('event_risk')} | SpotBlocked={m.get('spot_blocks_trade')}")
    lines.append("-" * 104)
    lines.append("SPOT OPPORTUNITY — SETUP EXISTS INDEPENDENTLY FROM IMMEDIATE EXECUTION")
    lines.append(f"Setup: {o.get('setup_state')} | Permission: {o.get('execution_permission')} | Actionable now: {o.get('actionable_now')}")
    lines.append(f"Entry status: {o.get('entry_status')}")
    lines.append(f"Best buy zone: {o.get('best_buy_zone')}")
    lines.append(f"Structural entry ladder: {o.get('entry_ladder')}")
    lines.append(f"Adaptive accumulation ladder: {(o.get('accumulation_plan') or {}).get('adaptive_ladder')}")
    lines.append(f"Weighted entry: {o.get('weighted_entry')} | Entry invalidation: {o.get('invalidation')} | Thesis invalidation: {o.get('thesis_invalidation')}")
    lines.append(f"Dual risk: {o.get('dual_risk_model')}")
    lines.append(f"TP1: {_price(tg.get('tp1'))} | TP2: {_price(tg.get('tp2'))} | TP3 (30-60D): {_price(tg.get('tp3'))} | Runner: {_price(o.get('runner_target'))}")
    lines.append(f"Review milestones (NOT exits): {o.get('review_milestones')}")
    pm = p.get("position_management_30_60d") or {}
    life = p.get("position_lifecycle") or {}
    if pm.get("valid"):
        lines.append(f"Lifecycle: {life.get('state')} | Phase: {life.get('phase')} | Position open: {life.get('position_open')}")
        adapt = life.get("adaptive_reallocation") or {}
        lines.append(f"Adaptive allocation: {adapt.get('decision')} | Review eligible: {adapt.get('review_eligible')} | Effective future: {adapt.get('effective_future_weights_pct')}")
        for st in (life.get("canonical_stage_plan") or []):
            reach = st.get("reachability") or {}
            lines.append(f"  {st.get('role')}: {st.get('status')} | reduction {st.get('effective_future_reduction_pct')}% @ {st.get('price')} | reachability {reach.get('model_estimated_reachability_score_0_100')}/100")
    lines.append("-" * 104)
    lines.append(f"CURRENT DECISION: {d.get('action')} | STATE: {d.get('state')} | ACTIONABLE: {d.get('actionable')}")
    lines.append(f"Valuation: {v.get('valuation_zone')} | EQ={v.get('equilibrium')} | Corrected long OTE={v.get('ote_long_zone')}")
    lines.append(f"Fusion: {f.get('calibrated_score')} | reliability={f.get('reliability')} | {f.get('semantics')}")
    lines.append(f"Trend maturity: {p.get('trend_maturity')}")
    lines.append(f"Wyckoff proxy: {p.get('wyckoff_phase_proxy')}")
    lines.append("-" * 104)
    lines.append("TOP REASONS")
    for r in (p.get("reasons") or [])[:10]:
        lines.append(f"- {r}")
    lines.append("-" * 104)
    lines.append("PAPER/ANALYSIS ONLY: no MetaTrader order is sent by this program.")
    return "\n".join(lines)


def _prompt_header() -> str:
    return (
        "TASK: Analyze this SPOT-ONLY XAUUSD packet with a MINIMUM ONE-MONTH horizon. Do not provide futures/scalp trades.\n"
        "SEMANTIC CONTRACT:\n"
        "1) A buy zone can exist while immediate execution is WAIT. ALWAYS report best_buy_zone, entry_ladder, invalidations and supplied targets when a setup exists; never hide them because execution is blocked.\n"
        "2) For this Spot engine, actionable BUY means ACCUMULATE a permitted tranche, not an all-in market order. Obey accumulation_plan.recommended_new_allocation_pct_now and eligible_tranches_now.\n"
        "3) TP1/TP2/TP3/Runner are the ONLY exit objectives. review_milestones are thesis checkpoints, NOT extra take-profits.\n"
        "4) TP3 is the primary 30-60D objective; Runner is optional 45-90+ days.\n"
        "5) Use thesis_rr for long-horizon interpretation; execution_rr describes tactical entry-stop geometry. Do not present huge execution RR as long-horizon certainty.\n"
        "6) Reachability scores are uncalibrated model rankings, not win probabilities.\n"
        "7) Use corrected directional OTE semantics. Never reinterpret the legacy OTE diagnostic as the current long OTE.\n"
        "8) Generic market spread state may be scalp-conservative; obey spot_effective_market_gate and spot_execution_cost_gate for Spot, while all non-spread hard market/data gates remain binding.\n"
        "9) Use position_lifecycle as canonical. PRE_ENTRY_WATCH/ENTRY_ARMED mean no position is open; ACCUMULATING means a partial spot position exists and planned accumulation is incomplete.\n"
        "10) Adaptive reallocation may change only after a new D1/W1 close and cannot alter realized stages.\n"
        "11) pullback_quality is the cool-off layer and late_extended is NOT an automatic blocker; thesis_health is the canonical slow 30-60D thesis monitor, falling_knife_guard controls NEW accumulation safety, and accumulation_plan is the canonical staged-buy policy. Exact scalp-grade M5/M15 triggers are NOT required for Spot.\n"
        "12) Never add a tranche when falling_knife_guard blocks/pauses it or thesis_health is INVALIDATED/CRITICAL. Never invent prices or replace structural objectives with your own R multiples.\n"
        "13) Report actual_cost_basis and accumulated_pct from position_lifecycle when a paper/manual position registry exists; do not confuse planned weighted_entry with the real cost basis.\n"
        "OUTPUT: SPOT BIAS, CURRENT ACTION, EFFECTIVE EXECUTION GATE, THESIS HEALTH, FALLING-KNIFE RISK, PULLBACK QUALITY, ACCUMULATION STATE, ELIGIBLE TRANCHE(S), RECOMMENDED NEW ALLOCATION %, POSITION LIFECYCLE, ACTUAL COST BASIS/ACCUMULATED %, BEST BUY ZONE, STRUCTURAL ENTRY LADDER, ADAPTIVE ACCUMULATION LADDER, ENTRY/THESIS INVALIDATION, DUAL-RISK VIEW, TP1/TP2/TP3/RUNNER + HORIZONS, STAGED EXIT PLAN, REVIEW MILESTONES, ADAPTIVE EXIT REALLOCATION, REACHABILITY, MACRO RISK, 5 concise reasons.\n\n"
    )


def render_spot_prompt(p: Dict[str, Any]) -> str:
    life = p.get("position_lifecycle") or {}
    strategic = p.get("strategic_target_engine") or {}
    compact = {
        "contract": p.get("contract"),
        "symbol": p.get("symbol"),
        "generated_utc": p.get("generated_utc"),
        "reference_price": p.get("reference_price"),
        "spot_opportunity": _opportunity_compact(p.get("spot_opportunity") or {}),
        "decision": p.get("decision"),
        "market_state": {
            "status": (p.get("market_state") or {}).get("status"),
            "execution_gate": (p.get("market_state") or {}).get("execution_gate"),
            "data_state": (p.get("market_state") or {}).get("data_state"),
            "spread_regime": (p.get("market_state") or {}).get("spread_regime"),
            "data_quality_score": (p.get("market_state") or {}).get("data_quality_score"),
            "cross_timeframe_coherence": (p.get("market_state") or {}).get("cross_timeframe_coherence"),
        },
        "spot_execution_cost_gate": p.get("spot_execution_cost_gate"),
        "pullback_quality": p.get("pullback_quality"),
        "thesis_health": p.get("thesis_health"),
        "falling_knife_guard": p.get("falling_knife_guard"),
        "accumulation_plan": p.get("accumulation_plan"),
        "higher_timeframe_consensus": p.get("higher_timeframe_consensus"),
        "macro_context": p.get("macro_context"),
        "valuation": p.get("valuation"),
        "trend_maturity": p.get("trend_maturity"),
        "wyckoff_phase_proxy": p.get("wyckoff_phase_proxy"),
        "spot_fusion": p.get("spot_fusion"),
        "review_milestones": strategic.get("review_milestones") or [],
        "position_lifecycle": {
            "state": life.get("state"),
            "phase": life.get("phase"),
            "position_open": life.get("position_open"),
            "canonical": life.get("canonical"),
            "adaptive_reallocation": life.get("adaptive_reallocation"),
            "canonical_stage_plan": life.get("canonical_stage_plan"),
            "position_registry": life.get("position_registry"),
        },
        "reasons": (p.get("reasons") or [])[:10],
    }
    return _prompt_header() + json.dumps(compact, ensure_ascii=False, indent=2)


def render_spot_prompt_full(p: Dict[str, Any]) -> str:
    return _prompt_header() + json.dumps(p, ensure_ascii=False, indent=2)
