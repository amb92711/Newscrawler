from __future__ import annotations

"""Multi-timeframe falling-knife protection for 30-60 day XAUUSD spot accumulation.

This module is deliberately conservative about *new accumulation* while keeping the
slow D1/W1 thesis separate from intraday noise.  It does not generate entries and it
does not close positions.  It classifies whether a pullback looks orderly, stressed,
or like a structural downside cascade that should pause fresh buying.
"""

from typing import Any, Dict, List, Mapping
import math

FALLING_KNIFE_ENGINE_VERSION = "AMB_SPOT_FALLING_KNIFE_GUARD_V1"


def _d(v: Any) -> Dict[str, Any]:
    return v if isinstance(v, dict) else {}


def _l(v: Any) -> List[Any]:
    return v if isinstance(v, list) else []


def _f(v: Any, default: float = 0.0) -> float:
    try:
        x = float(v)
        return x if math.isfinite(x) else default
    except Exception:
        return default


def _s(v: Any) -> str:
    return str(v or "").strip().lower()


def _clamp(v: float, lo: float = 0.0, hi: float = 100.0) -> float:
    return max(lo, min(hi, float(v)))


def _tf(chart: Mapping[str, Any], name: str) -> Dict[str, Any]:
    return _d(_d(chart.get("timeframes")).get(name))


def _bear(v: Any) -> bool:
    s = _s(v)
    return "bear" in s or s in {"short", "sell_pressure"}


def _bull(v: Any) -> bool:
    s = _s(v)
    return "bull" in s or s in {"long", "buy_pressure"}


def _tf_risk(ctx: Mapping[str, Any], tf: str) -> Dict[str, Any]:
    adv = _d(ctx.get("advanced_structure"))
    ext = _d(adv.get("external"))
    internal = _d(adv.get("internal"))
    mss = _d(adv.get("mss"))
    indicators = _d(ctx.get("advanced_indicators"))
    pa = _d(indicators.get("institutional_price_action"))
    flow = _d(indicators.get("volume_flow"))
    regime = _d(indicators.get("regime_metrics"))
    tq = _d(indicators.get("trend_quality"))
    ich = _d(ctx.get("ichimoku"))
    vp = _d(ctx.get("volume_profile"))
    of = _d(vp.get("order_flow_proxy"))

    score = 0.0
    evidence: List[str] = []

    if _bear(ctx.get("trend")):
        score += 14.0
        evidence.append("trend_bearish")
    if _bear(ctx.get("structure")):
        score += 18.0
        evidence.append("structure_bearish")
    if _bear(ext.get("bias")):
        score += 20.0
        evidence.append("external_structure_bearish")
    if _bear(internal.get("bias")):
        score += 7.0
        evidence.append("internal_structure_bearish")
    if _bear(mss.get("type")):
        score += 9.0
        evidence.append("bearish_mss")

    cloud = _f(ich.get("cloud_bias"))
    if cloud < 0:
        score += 8.0
        evidence.append("below_ichimoku_cloud")

    impulse = _f(pa.get("institutional_impulse_score"))
    if impulse <= -3.5:
        score += 15.0
        evidence.append("strong_bearish_displacement")
    elif impulse <= -1.8:
        score += 8.0
        evidence.append("bearish_displacement")

    z = _f(pa.get("price_zscore_50"))
    if z <= -2.4:
        score += 10.0
        evidence.append("downside_statistical_shock")
    elif z <= -1.6:
        score += 5.0
        evidence.append("downside_extension")

    volpct = _f(regime.get("volatility_percentile"), 50.0)
    if volpct >= 95:
        score += 10.0
        evidence.append("extreme_volatility")
    elif volpct >= 88:
        score += 5.0
        evidence.append("high_volatility")

    cmf = _f(flow.get("cmf_20"))
    if cmf <= -0.18:
        score += 8.0
        evidence.append("strong_negative_cmf")
    elif cmf <= -0.08:
        score += 4.0
        evidence.append("negative_cmf")

    dmi = _f(tq.get("dmi_spread"))
    if dmi <= -18:
        score += 7.0
        evidence.append("negative_dmi_spread")

    pressure = of.get("pressure")
    if _bear(pressure):
        score += 6.0
        evidence.append("sell_pressure")
    elif _bull(pressure):
        score -= 4.0
        evidence.append("buy_pressure_offsets_risk")

    candle = _d(_d(ctx.get("price_action")).get("last_candle"))
    if candle.get("bearish_engulfing"):
        score += 5.0
        evidence.append("bearish_engulfing")
    if candle.get("bullish_pinbar") or candle.get("bullish_engulfing"):
        score -= 4.0
        evidence.append("bullish_rejection_offsets_risk")

    return {
        "timeframe": tf,
        "risk_0_100": round(_clamp(score), 2),
        "evidence": evidence,
        "hard_structure_break": bool(_bear(ctx.get("structure")) and _bear(ext.get("bias"))),
    }


def build_falling_knife_guard(
    *,
    chart: Mapping[str, Any],
    plan: Mapping[str, Any],
    macro: Mapping[str, Any],
) -> Dict[str, Any]:
    weights = {"D1": 0.34, "H4": 0.36, "H1": 0.22, "M15": 0.08}
    rows: Dict[str, Any] = {}
    weighted = 0.0
    hard_reasons: List[str] = []
    for tf, w in weights.items():
        row = _tf_risk(_tf(chart, tf), tf)
        rows[tf] = row
        weighted += _f(row.get("risk_0_100")) * w
        if tf in {"D1", "H4"} and row.get("hard_structure_break"):
            hard_reasons.append(f"{tf}_structure_and_external_bias_bearish")

    ref = _f(_d(chart.get("market_microstructure")).get("best_ask")) or _f(_d(chart.get("trade_map")).get("reference_price"))
    thesis = _d(plan.get("thesis_invalidation"))
    thesis_px = _f(thesis.get("price"))
    entry_inv = _f(plan.get("entry_invalidation"), _f(plan.get("invalidation")))
    if thesis_px > 0 and ref <= thesis_px:
        hard_reasons.append("price_below_thesis_invalidation")
        weighted += 35.0
    elif entry_inv > 0 and ref <= entry_inv:
        weighted += 14.0

    macro_bias = _s(macro.get("bias"))
    macro_conf = _f(macro.get("confidence"))
    if macro_bias in {"bearish", "short"} and macro_conf >= 65:
        weighted += 12.0
    if bool(macro.get("spot_blocks_trade")):
        hard_reasons.append("macro_event_or_regime_hard_block")

    risk = _clamp(weighted)
    if hard_reasons or risk >= 78:
        level = "CRITICAL"
        permission = "BLOCK_NEW_ACCUMULATION"
    elif risk >= 62:
        level = "HIGH"
        permission = "PAUSE_NEW_ACCUMULATION"
    elif risk >= 42:
        level = "MODERATE"
        permission = "REDUCED_ACCUMULATION_ONLY"
    else:
        level = "LOW"
        permission = "ALLOW_ACCUMULATION"

    return {
        "engine": FALLING_KNIFE_ENGINE_VERSION,
        "risk_score_0_100": round(risk, 2),
        "level": level,
        "permission": permission,
        "block_new_accumulation": permission in {"BLOCK_NEW_ACCUMULATION", "PAUSE_NEW_ACCUMULATION"},
        "hard_fail": bool(hard_reasons),
        "hard_fail_reasons": hard_reasons,
        "timeframe_risk": rows,
        "semantics": "new_spot_accumulation_safety_filter_not_position_exit_signal",
        "guardrails": {
            "D1_H4_structure_break_has_priority": True,
            "M15_alone_cannot_block_30_60d_thesis": True,
            "does_not_force_position_exit": True,
            "thesis_invalidation_is_separate": True,
        },
    }
