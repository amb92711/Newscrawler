from __future__ import annotations

"""Small local JSON registry for paper/manual spot-position lifecycle state."""

from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Mapping, Optional
import json
import uuid

ROLES = ("TP1", "TP2", "TP3", "RUNNER")


def _d(v: Any) -> Dict[str, Any]:
    return v if isinstance(v, dict) else {}


def _f(v: Any, default: float = 0.0) -> float:
    try:
        return float(v)
    except Exception:
        return default


class SpotPositionRegistry:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def load(self) -> Dict[str, Any]:
        if not self.path.exists():
            return {}
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
        except Exception:
            return {}

    def save(self, record: Mapping[str, Any]) -> Dict[str, Any]:
        data = dict(record)
        self.path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        return data

    def clear(self) -> None:
        if self.path.exists():
            self.path.unlink()

    def open_from_packet(self, packet: Mapping[str, Any], entry_price: Optional[float] = None, note: str = "") -> Dict[str, Any]:
        opp = _d(packet.get("spot_opportunity"))
        pm = _d(packet.get("position_management_30_60d"))
        if not bool(opp.get("buy_setup_available")):
            raise RuntimeError("Cannot register a spot position: current packet has no valid buy setup.")
        px = _f(entry_price, _f(opp.get("weighted_entry")))
        if px <= 0:
            raise RuntimeError("Cannot register a spot position without a valid entry price.")
        now = datetime.now(timezone.utc).isoformat()
        htf = _d(packet.get("higher_timeframe_consensus"))
        macro = _d(packet.get("macro_context"))
        chart_markers = _d(packet.get("position_lifecycle", {})).get("review_markers") or {}
        # Packet may not yet contain lifecycle markers on the opening run; writer/engine supplies target context below.
        stages = {str(x.get("role")): x for x in pm.get("stages", []) if isinstance(x, dict)}
        record = {
            "position_id": f"spot-{uuid.uuid4().hex[:12]}",
            "status": "open",
            "side": "long",
            "symbol": packet.get("symbol"),
            "opened_utc": now,
            "entry_price": px,
            "actual_cost_basis": px,
            "accumulated_pct": 100.0,
            "accumulation_complete": True,
            "accumulation_fills": [{"tranche": 0, "price": px, "allocation_pct": 100.0, "mode": "legacy_full_position_registration", "time": now}],
            "note": note,
            "realized_roles": [],
            "realized_pct": 0.0,
            "thesis_invalidated": False,
            "closed": False,
            "entry_snapshot": {
                "htf_score": htf.get("score_0_100"),
                "macro_score": macro.get("score_0_100"),
                "spot_fusion": _d(packet.get("spot_fusion")).get("calibrated_score"),
                "trend_maturity": _d(packet.get("trend_maturity")).get("phase"),
                "thesis_health_score": _d(packet.get("thesis_health")).get("health_score_0_100"),
            },
            "entry_review_markers": chart_markers,
            "last_allocation_review_markers": chart_markers,
            "targets": {r: _d(stages.get(r)).get("price") for r in ROLES},
            "allocation_weights_pct": _d(pm.get("allocation_policy")).get("stage_weights_pct", {}),
            "thesis_invalidation": _d(opp.get("thesis_invalidation")),
            "history": [{"time": now, "event": "POSITION_REGISTERED", "entry_price": px}],
        }
        return self.save(record)

    def fill_tranche_from_packet(self, packet: Mapping[str, Any], tranche: int, fill_price: Optional[float] = None, note: str = "") -> Dict[str, Any]:
        if tranche not in (1, 2, 3):
            raise RuntimeError("Spot accumulation tranche must be 1, 2, or 3.")
        opp = _d(packet.get("spot_opportunity"))
        acc = _d(packet.get("accumulation_plan"))
        rows = [x for x in acc.get("adaptive_ladder", []) if isinstance(x, dict)]
        row = next((x for x in rows if int(_f(x.get("tranche"))) == tranche), None)
        if row is None:
            raise RuntimeError(f"Tranche {tranche} is not present in the current accumulation plan.")
        if not bool(opp.get("buy_setup_available")):
            raise RuntimeError("Cannot fill a tranche: current packet has no valid spot buy setup.")
        if not bool(row.get("price_eligible_now")):
            raise RuntimeError(f"Tranche {tranche} is not price-eligible in the current packet.")
        if str(acc.get("permission") or "").upper() != "ACCUMULATE":
            raise RuntimeError(f"Current accumulation permission is {acc.get('permission')}; new tranche fill is not allowed.")

        planned_px = _f(row.get("price"))
        px = _f(fill_price, planned_px)
        if px <= 0:
            raise RuntimeError("A valid fill price is required.")
        alloc = _f(row.get("adaptive_allocation_pct"), _f(row.get("original_allocation_pct")))
        if alloc <= 0:
            raise RuntimeError("Current tranche allocation is invalid.")

        rec = self.load()
        now = datetime.now(timezone.utc).isoformat()
        if rec and str(rec.get("status") or "").lower() == "closed":
            raise RuntimeError("The registered spot position is closed; clear/start a new lifecycle before adding a tranche.")
        if not rec:
            htf = _d(packet.get("higher_timeframe_consensus"))
            macro = _d(packet.get("macro_context"))
            pm = _d(packet.get("position_management_30_60d"))
            stages = {str(x.get("role")): x for x in pm.get("stages", []) if isinstance(x, dict)}
            markers = _d(packet.get("position_lifecycle", {})).get("review_markers") or {}
            rec = {
                "position_id": f"spot-{uuid.uuid4().hex[:12]}",
                "status": "open",
                "side": "long",
                "symbol": packet.get("symbol"),
                "opened_utc": now,
                "note": note,
                "realized_roles": [],
                "realized_pct": 0.0,
                "thesis_invalidated": False,
                "closed": False,
                "entry_snapshot": {
                    "htf_score": htf.get("score_0_100"),
                    "macro_score": macro.get("score_0_100"),
                    "spot_fusion": _d(packet.get("spot_fusion")).get("calibrated_score"),
                    "trend_maturity": _d(packet.get("trend_maturity")).get("phase"),
                    "thesis_health_score": _d(packet.get("thesis_health")).get("health_score_0_100"),
                },
                "entry_review_markers": markers,
                "last_allocation_review_markers": markers,
                "targets": {r: _d(stages.get(r)).get("price") for r in ROLES},
                "allocation_weights_pct": _d(pm.get("allocation_policy")).get("stage_weights_pct", {}),
                "thesis_invalidation": _d(opp.get("thesis_invalidation")),
                "accumulation_fills": [],
                "history": [],
            }
        fills = [x for x in rec.get("accumulation_fills", []) if isinstance(x, dict)]
        if any(int(_f(x.get("tranche"))) == tranche for x in fills):
            raise RuntimeError(f"Tranche {tranche} is already recorded as filled.")
        fills.append({"tranche": tranche, "price": px, "allocation_pct": alloc, "planned_price": planned_px, "note": note, "time": now})
        rec["accumulation_fills"] = fills
        accumulated = min(100.0, sum(_f(x.get("allocation_pct")) for x in fills))
        notional = sum(_f(x.get("price")) * _f(x.get("allocation_pct")) for x in fills)
        cost_basis = notional / max(sum(_f(x.get("allocation_pct")) for x in fills), 1e-9)
        rec["accumulated_pct"] = round(accumulated, 2)
        rec["accumulation_complete"] = accumulated >= 99.0
        rec["actual_cost_basis"] = round(cost_basis, 6)
        rec["entry_price"] = round(cost_basis, 6)
        rec.setdefault("history", []).append({"time": now, "event": "ACCUMULATION_TRANCHE_FILLED", "tranche": tranche, "fill_price": px, "allocation_pct": alloc, "accumulated_pct": accumulated})
        rec["last_seen_utc"] = now
        return self.save(rec)

    def close(self, reason: str = "manual_close") -> Dict[str, Any]:
        rec = self.load()
        if not rec:
            return {}
        now = datetime.now(timezone.utc).isoformat()
        rec["status"] = "closed"
        rec["closed"] = True
        rec["closed_utc"] = now
        rec["close_reason"] = reason
        rec.setdefault("history", []).append({"time": now, "event": "POSITION_CLOSED", "reason": reason})
        return self.save(rec)

    def update_from_packet(self, packet: Mapping[str, Any]) -> Dict[str, Any]:
        rec = self.load()
        if not rec or str(rec.get("status") or "").lower() != "open":
            return rec
        ref = _f(packet.get("reference_price"))
        pm = _d(packet.get("position_management_30_60d"))
        stages = {str(x.get("role")): x for x in pm.get("stages", []) if isinstance(x, dict)}
        realized = set(str(x) for x in rec.get("realized_roles", []) if str(x) in ROLES)
        weights = _d(rec.get("allocation_weights_pct")) or _d(pm.get("allocation_policy")).get("stage_weights_pct", {})
        now = datetime.now(timezone.utc).isoformat()
        changed = False
        for role in ROLES:
            if role in realized:
                continue
            px = _f(_d(stages.get(role)).get("price"), _f(_d(rec.get("targets")).get(role)))
            if px > 0 and ref >= px:  # current spot engine is long-only for executable opportunities
                realized.add(role)
                rec.setdefault("history", []).append({"time": now, "event": f"{role}_REACHED", "reference_price": ref, "target_price": px})
                changed = True
        rec["realized_roles"] = [r for r in ROLES if r in realized]
        rec["realized_pct"] = round(sum(_f(weights.get(r)) for r in realized), 2)

        thesis_px = _f(_d(rec.get("thesis_invalidation")).get("price"))
        if thesis_px > 0 and ref <= thesis_px and not rec.get("thesis_invalidated"):
            rec["thesis_invalidated"] = True
            rec.setdefault("history", []).append({"time": now, "event": "THESIS_INVALIDATED", "reference_price": ref, "thesis_price": thesis_px})
            changed = True
        if "RUNNER" in realized:
            rec["status"] = "closed"
            rec["closed"] = True
            rec["closed_utc"] = now
            rec["close_reason"] = "runner_objective_reached"
            changed = True

        lifecycle = _d(packet.get("position_lifecycle"))
        adaptive = _d(lifecycle.get("adaptive_reallocation"))
        review_clock = _d(adaptive.get("review_clock"))
        if adaptive.get("review_eligible") and review_clock.get("current_markers"):
            rec["last_allocation_review_markers"] = review_clock.get("current_markers")
            rec["last_adaptive_review"] = {
                "time": now,
                "decision": adaptive.get("decision"),
                "effective_future_weights_pct": adaptive.get("effective_future_weights_pct"),
                "reason": adaptive.get("reason"),
                "evidence": adaptive.get("evidence"),
            }
            rec.setdefault("history", []).append({
                "time": now,
                "event": "ALLOCATION_REVIEW",
                "decision": adaptive.get("decision"),
                "effective_future_weights_pct": adaptive.get("effective_future_weights_pct"),
            })
            changed = True
        if adaptive.get("effective_future_weights_pct"):
            rec["latest_effective_future_weights_pct"] = adaptive.get("effective_future_weights_pct")
        rec["last_seen_utc"] = now
        rec["last_reference_price"] = ref
        return self.save(rec) if changed or rec else rec
