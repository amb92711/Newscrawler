from __future__ import annotations

from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple
import math

from amb_chart.analysis.execution import build_execution_plan
from amb_chart.spot.strategic_targets import build_strategic_target_plan, build_thesis_invalidation, TARGET_ENGINE_VERSION
from amb_chart.spot.position_management import build_staged_exit_plan, EXIT_ENGINE_VERSION
from amb_chart.spot.lifecycle import build_position_lifecycle, LIFECYCLE_ENGINE_VERSION, REALLOCATION_ENGINE_VERSION
from amb_chart.spot.pullback_quality import build_pullback_quality, PULLBACK_ENGINE_VERSION
from amb_chart.spot.falling_knife import build_falling_knife_guard, FALLING_KNIFE_ENGINE_VERSION
from amb_chart.spot.thesis_health import build_thesis_health, THESIS_HEALTH_ENGINE_VERSION
from amb_chart.spot.accumulation import build_accumulation_plan, ACCUMULATION_ENGINE_VERSION


SPOT_ENGINE_VERSION = "AMB_GOLD_SPOT_INSTITUTIONAL_ENGINE_V6_ACCUMULATION_THESIS_HEALTH"

# M5 is intentionally excluded from directional voting. M15 is timing-only.
DIRECTION_WEIGHTS: Dict[str, float] = {
    "MN1": 1.15,
    "W1": 1.55,
    "D1": 2.25,
    "H4": 1.85,
    "H1": 1.10,
}
TIMING_WEIGHTS: Dict[str, float] = {"H1": 1.0, "M15": 0.55}


def _d(v: Any) -> Dict[str, Any]:
    return v if isinstance(v, dict) else {}


def _l(v: Any) -> List[Any]:
    return v if isinstance(v, list) else []


def _f(v: Any, default: float = 0.0) -> float:
    try:
        if v is None or v == "":
            return default
        x = float(v)
        return x if math.isfinite(x) else default
    except Exception:
        return default


def _s(v: Any) -> str:
    return str(v or "").strip().lower()


def _clamp(v: float, lo: float = 0.0, hi: float = 100.0) -> float:
    return max(lo, min(hi, float(v)))


def _tf(chart: Mapping[str, Any], name: str) -> Dict[str, Any]:
    return _d(_d(chart.get("timeframes")).get(name))


def _reference(chart: Mapping[str, Any]) -> float:
    micro = _d(chart.get("market_microstructure"))
    return (
        _f(micro.get("best_ask"))
        or _f(micro.get("last"))
        or _f(_d(chart.get("trade_map")).get("reference_price"))
        or _f(_tf(chart, "M15").get("last_close"))
        or _f(_tf(chart, "H1").get("last_close"))
    )


def _atr(chart: Mapping[str, Any], tf: str, fallback: float = 1.0) -> float:
    return max(_f(_tf(chart, tf).get("atr"), fallback), 1e-9)


def _tf_direction(ctx: Mapping[str, Any]) -> Tuple[float, List[str]]:
    """Continuous directional evidence for a higher timeframe.

    Returned score is approximately [-10,+10]. It deliberately blends independent
    trend families instead of allowing one indicator to dictate the result.
    """
    score = 0.0
    notes: List[str] = []
    trend = _s(ctx.get("trend"))
    structure = _s(ctx.get("structure"))
    momentum = _s(ctx.get("momentum"))
    adv = _d(ctx.get("advanced_structure"))
    ext = _d(adv.get("external"))
    internal = _d(adv.get("internal"))
    mss = _d(adv.get("mss"))

    if "bull" in trend:
        score += 2.0 if "strong" not in trend else 2.6
        notes.append("trend_bullish")
    elif "bear" in trend:
        score -= 2.0 if "strong" not in trend else 2.6
        notes.append("trend_bearish")

    for label, weight in ((structure, 1.4), (_s(ext.get("bias")), 1.2), (_s(internal.get("bias")), 0.65)):
        if "bull" in label:
            score += weight
        elif "bear" in label:
            score -= weight

    mss_type = _s(mss.get("type"))
    if "bull" in mss_type:
        score += 1.1
        notes.append("mss_bullish")
    elif "bear" in mss_type:
        score -= 1.1
        notes.append("mss_bearish")

    if "bull" in momentum:
        score += 0.75
    elif "bear" in momentum:
        score -= 0.75

    ich = _d(ctx.get("ichimoku"))
    cloud = int(_f(ich.get("cloud_bias"), 0))
    tk = int(_f(ich.get("tk_cross"), 0))
    score += 1.05 * max(-1, min(1, cloud))
    score += 0.45 * max(-1, min(1, tk))
    if cloud > 0:
        notes.append("ichimoku_above_cloud")
    elif cloud < 0:
        notes.append("ichimoku_below_cloud")

    ind = _d(ctx.get("advanced_indicators"))
    adaptive = _d(ind.get("adaptive_trend"))
    tq = _d(ind.get("trend_quality"))
    flow = _d(ind.get("volume_flow"))
    pa = _d(ind.get("institutional_price_action"))
    anchored = _d(ind.get("anchored_vwap"))

    aroon = _f(adaptive.get("aroon_osc"))
    if abs(aroon) >= 15:
        score += max(-0.8, min(0.8, aroon / 100.0))
    fisher = _f(adaptive.get("fisher"))
    score += max(-0.45, min(0.45, fisher / 5.0))
    dmi = _f(tq.get("dmi_spread"))
    score += max(-0.65, min(0.65, dmi / 35.0))
    cmf = _f(flow.get("cmf_20"))
    score += max(-0.55, min(0.55, cmf * 2.0))
    impulse = _f(pa.get("institutional_impulse_score"))
    score += max(-0.55, min(0.55, impulse / 5.0))
    avwap_lo = _f(anchored.get("low_distance_atr"), 0.0)
    avwap_hi = _f(anchored.get("high_distance_atr"), 0.0)
    # Price above both anchored VWAPs is supportive, below both is adverse.
    if avwap_lo > 0.05 and avwap_hi > 0.05:
        score += 0.45
    elif avwap_lo < -0.05 and avwap_hi < -0.05:
        score -= 0.45

    rsi = _f(ctx.get("rsi"), 50.0)
    # RSI is used symmetrically as trend confirmation only, never as standalone reversal.
    if 52 <= rsi <= 70:
        score += 0.35
    elif 30 <= rsi <= 48:
        score -= 0.35

    return max(-10.0, min(10.0, score)), notes


def _higher_timeframe_consensus(chart: Mapping[str, Any]) -> Dict[str, Any]:
    weighted = 0.0
    capacity = 0.0
    details: Dict[str, Any] = {}
    present = 0
    disagreement_total = 0.0
    disagreement_count = 0
    for tf, weight in DIRECTION_WEIGHTS.items():
        ctx = _tf(chart, tf)
        if not ctx:
            details[tf] = {"available": False, "weight": weight}
            continue
        raw_pre, notes = _tf_direction(ctx)
        trend = _s(ctx.get("trend"))
        structure = _s(ctx.get("structure"))
        trend_sign = 1 if "bull" in trend else -1 if "bear" in trend else 0
        structure_sign = 1 if "bull" in structure else -1 if "bear" in structure else 0
        disagreement = bool(trend_sign and structure_sign and trend_sign != structure_sign)
        # Higher-timeframe trend/structure disagreement is important for 30-60 day
        # spot.  It should reduce conviction without instantly flipping direction.
        penalty = 0.0
        if disagreement:
            penalty = {"MN1": 1.35, "W1": 1.80, "D1": 1.65, "H4": 1.15, "H1": 0.70}.get(tf, 1.0)
            raw = raw_pre - penalty * trend_sign
            disagreement_total += penalty * weight
            disagreement_count += 1
            notes = list(notes) + ["trend_structure_disagreement_penalty"]
        else:
            raw = raw_pre
        raw = max(-10.0, min(10.0, raw))
        weighted += weight * raw
        capacity += weight * 10.0
        present += 1
        details[tf] = {
            "available": True,
            "weight": weight,
            "raw_score_pre_penalty": round(raw_pre, 3),
            "raw_score": round(raw, 3),
            "weighted_score": round(raw * weight, 3),
            "trend": ctx.get("trend"),
            "structure": ctx.get("structure"),
            "momentum": ctx.get("momentum"),
            "trend_structure_disagreement": disagreement,
            "disagreement_penalty": round(penalty, 3),
            "notes": notes,
        }
    normalized = 50.0 if capacity <= 0 else 50.0 + 50.0 * weighted / capacity
    normalized = _clamp(normalized)
    if normalized >= 61:
        bias = "bullish"
    elif normalized <= 39:
        bias = "bearish"
    else:
        bias = "neutral_mixed"
    coverage = present / max(len(DIRECTION_WEIGHTS), 1)
    disagreement_ratio = disagreement_count / max(present, 1)
    confidence = _clamp(abs(normalized - 50.0) * 1.55 * (0.62 + 0.38 * coverage) * (1.0 - 0.28 * disagreement_ratio))
    return {
        "bias": bias,
        "score_0_100": round(normalized, 2),
        "confidence": round(confidence, 2),
        "coverage": round(coverage, 3),
        "directional_timeframes": list(DIRECTION_WEIGHTS.keys()),
        "excluded_from_direction": ["M15", "M5"],
        "trend_structure_disagreement": {
            "count": disagreement_count,
            "ratio": round(disagreement_ratio, 3),
            "weighted_penalty": round(disagreement_total, 3),
            "semantics": "conviction_penalty_not_direction_override",
        },
        "details": details,
    }


def _dealing_range(chart: Mapping[str, Any]) -> Dict[str, Any]:
    ref = _reference(chart)
    candidates: List[Tuple[str, float, float]] = []
    for tf in ("D1", "H4", "W1"):
        ctx = _tf(chart, tf)
        swings = _d(ctx.get("swings"))
        highs = [(_f(x.get("price"))) for x in _l(swings.get("highs")) if isinstance(x, dict) and _f(x.get("price")) > 0]
        lows = [(_f(x.get("price"))) for x in _l(swings.get("lows")) if isinstance(x, dict) and _f(x.get("price")) > 0]
        if highs and lows:
            hi, lo = max(highs[-12:]), min(lows[-12:])
            if hi > lo:
                candidates.append((tf, lo, hi))
    if not candidates:
        atr = _atr(chart, "D1", _atr(chart, "H4", 1.0))
        lo, hi, source = ref - atr * 2.5, ref + atr * 2.5, "atr_fallback"
    else:
        source, lo, hi = candidates[0]
        # Prefer D1 if present; otherwise H4/W1 order above.
        for tf, c_lo, c_hi in candidates:
            if tf == "D1":
                source, lo, hi = tf, c_lo, c_hi
                break
    width = max(hi - lo, 1e-9)
    pos = _clamp((ref - lo) / width * 100.0)
    eq = lo + width * 0.5
    fib = {
        "0.236": lo + width * 0.236,
        "0.382": lo + width * 0.382,
        "0.500": eq,
        "0.618": lo + width * 0.618,
        "0.705": lo + width * 0.705,
        "0.786": lo + width * 0.786,
    }
    if pos < 45:
        zone = "discount"
    elif pos > 55:
        zone = "premium"
    else:
        zone = "equilibrium"
    # OTE must be expressed as a *retracement* from the active dealing-range extreme.
    # For a long thesis, retracement is measured down from the range high; for a
    # short thesis it is measured up from the range low.  The old lo+ratio*width
    # representation is preserved as diagnostics because earlier packets exposed it.
    legacy_ote = {"low": round(fib["0.618"], 6), "high": round(fib["0.786"], 6)}
    long_ote_low = hi - width * 0.786
    long_ote_high = hi - width * 0.618
    short_ote_low = lo + width * 0.618
    short_ote_high = lo + width * 0.786
    return {
        "source_timeframe": source,
        "low": round(lo, 6),
        "high": round(hi, 6),
        "equilibrium": round(eq, 6),
        "price_position_pct": round(pos, 2),
        "valuation_zone": zone,
        "fib_levels": {k: round(v, 6) for k, v in fib.items()},
        "ote_long_zone": {"low": round(min(long_ote_low, long_ote_high), 6), "high": round(max(long_ote_low, long_ote_high), 6), "semantics": "62_79pct_retracement_from_range_high"},
        "ote_short_zone": {"low": round(min(short_ote_low, short_ote_high), 6), "high": round(max(short_ote_low, short_ote_high), 6), "semantics": "62_79pct_retracement_from_range_low"},
        "legacy_ote_long_zone_pre_v4": legacy_ote,
        "ote_model_version": "CORRECTED_DIRECTIONAL_RETRACEMENT_V2",
    }


def _macro_overlay(chart: Mapping[str, Any]) -> Dict[str, Any]:
    fusion = _d(chart.get("fusion_context"))
    news_wrap = _d(fusion.get("news_macro_context"))
    data = _d(news_wrap.get("data")) if news_wrap.get("attached") else {}
    mc = _d(data.get("macro_context"))
    regime = _d(data.get("market_regime"))
    event = _d(data.get("event_window"))
    bias_components = _d(data.get("bias_components"))
    combined = _d(bias_components.get("combined_bias"))
    validation = _d(data.get("market_validation"))

    bias = _s(mc.get("final_gold_context_bias") or combined.get("bias") or mc.get("gold_news_bias") or "neutral")
    score = 50.0
    if bias in {"bullish", "long"}:
        score = 68.0
    elif bias in {"bearish", "short"}:
        score = 32.0
    news_bias = _s(mc.get("gold_news_bias"))
    if news_bias == "bullish":
        score += 7.0
    elif news_bias == "bearish":
        score -= 7.0
    market_bias = _s(mc.get("gold_market_bias") or _d(bias_components.get("market_validation_bias")).get("bias"))
    if market_bias == "bullish":
        score += 6.0
    elif market_bias == "bearish":
        score -= 6.0
    elif market_bias == "mixed":
        score += 0.0
    score = _clamp(score)

    event_level = _s(event.get("risk_level") or mc.get("event_risk") or "unknown").upper()
    spot_blocks = bool(event.get("spot_blocks_trade", False))
    confidence = _f(regime.get("confidence"), _f(mc.get("regime_confidence"), 0.5)) * 100.0
    return {
        "attached": bool(news_wrap.get("attached")),
        "bias": bias or "neutral",
        "score_0_100": round(score, 2),
        "confidence": round(_clamp(confidence), 2),
        "news_bias": news_bias or "unknown",
        "market_validation_bias": market_bias or "unknown",
        "event_risk": event_level,
        "spot_blocks_trade": spot_blocks,
        "execution_mode": event.get("execution_mode"),
        "macro_regime": regime.get("regime") or mc.get("macro_regime"),
        "combined_conflict": bool(combined.get("conflict") or mc.get("bias_conflict")),
        "validation_verdict_counts": validation.get("verdict_counts"),
        "next_events": _l(event.get("upcoming_key_events"))[:5],
    }


def _trend_maturity(chart: Mapping[str, Any], htf: Mapping[str, Any]) -> Dict[str, Any]:
    score = 0.0
    reasons: List[str] = []
    over = 0.0
    for tf, weight in (("D1", 1.4), ("H4", 1.1), ("H1", 0.7)):
        ctx = _tf(chart, tf)
        if not ctx:
            continue
        adx = _f(ctx.get("adx"))
        rsi = _f(ctx.get("rsi"), 50.0)
        ind = _d(ctx.get("advanced_indicators"))
        pa = _d(ind.get("institutional_price_action"))
        tq = _d(ind.get("trend_quality"))
        reg = _d(ind.get("regime_metrics"))
        z = abs(_f(pa.get("price_zscore_50")))
        er = _f(tq.get("efficiency_ratio_10"))
        volpct = _f(reg.get("volatility_percentile"), 50.0)
        if adx >= 25:
            score += weight * min(1.0, adx / 50.0)
        if er >= 0.35:
            score += weight * min(0.8, er)
        if rsi >= 74 or rsi <= 26:
            over += weight * 0.8
            reasons.append(f"{tf}_rsi_extreme")
        if z >= 2.0:
            over += weight * min(1.2, z / 2.5)
            reasons.append(f"{tf}_statistical_overextension")
        if volpct >= 90:
            over += weight * 0.45
            reasons.append(f"{tf}_volatility_extreme")
    if over >= 2.0:
        phase = "late_extended"
    elif score >= 2.2:
        phase = "healthy_trend"
    elif score >= 1.2:
        phase = "developing_trend"
    else:
        phase = "fragile_or_range"
    return {
        "phase": phase,
        "trend_strength_score": round(score, 3),
        "overextension_score": round(over, 3),
        "overextended": over >= 2.0,
        "reasons": reasons[:8],
    }


def _wyckoff_proxy(chart: Mapping[str, Any], htf: Mapping[str, Any]) -> Dict[str, Any]:
    h4 = _tf(chart, "H4")
    d1 = _tf(chart, "D1")
    bias = _s(htf.get("bias"))
    h4_tq = _d(_d(h4.get("advanced_indicators")).get("trend_quality"))
    h4_pa = _d(_d(h4.get("advanced_indicators")).get("institutional_price_action"))
    h4_vol = _d(h4.get("volume_profile"))
    pressure = _s(_d(h4_vol.get("order_flow_proxy")).get("pressure"))
    chop = _f(h4_tq.get("choppiness_14"), 50.0)
    impulse = _f(h4_pa.get("institutional_impulse_score"))
    d1_structure = _s(d1.get("structure"))

    if bias == "bullish" and chop < 50 and impulse >= 0:
        phase = "markup"
    elif bias == "bearish" and chop < 50 and impulse <= 0:
        phase = "markdown"
    elif chop >= 58 and pressure in {"buy_pressure", "balanced"} and "bull" in d1_structure:
        phase = "reaccumulation"
    elif chop >= 58 and pressure in {"sell_pressure", "balanced"} and "bear" in d1_structure:
        phase = "redistribution"
    elif chop >= 58:
        phase = "balance_accumulation_distribution_unknown"
    else:
        phase = "transition"
    return {
        "phase": phase,
        "h4_choppiness": round(chop, 3),
        "h4_institutional_impulse": round(impulse, 3),
        "h4_orderflow_pressure": pressure or "unknown",
        "note": "Wyckoff-style deterministic proxy; not a literal tape-reading classification.",
    }


def _zone_bounds(zone: Mapping[str, Any]) -> Tuple[float, float]:
    level = _f(zone.get("level"))
    lo = _f(zone.get("low"), level)
    hi = _f(zone.get("high"), level)
    return (hi, lo) if hi < lo else (lo, hi)


def _zone_confluence_score(chart: Mapping[str, Any], zone: Mapping[str, Any], valuation: Mapping[str, Any]) -> Dict[str, Any]:
    lo, hi = _zone_bounds(zone)
    mid = (lo + hi) / 2.0
    score = _f(zone.get("execution_score"), _f(zone.get("rank_score"), _f(zone.get("score"), 50.0)))
    components: List[Dict[str, Any]] = []
    tf = str(zone.get("timeframe") or "")
    source = _s(zone.get("source"))
    status = _s(zone.get("status"))

    if tf == "D1":
        score += 12; components.append({"factor": "D1_zone", "points": 12})
    elif tf == "H4":
        score += 10; components.append({"factor": "H4_zone", "points": 10})
    elif tf == "H1":
        score += 5; components.append({"factor": "H1_zone", "points": 5})
    if "order_block" in source:
        score += 8; components.append({"factor": "order_block", "points": 8})
    if "fvg" in source:
        score += 5; components.append({"factor": "fvg", "points": 5})
    if status == "fresh":
        score += 10; components.append({"factor": "fresh", "points": 10})
    elif status == "mitigated":
        score -= 4; components.append({"factor": "mitigated", "points": -4})

    fib = _d(valuation.get("fib_levels"))
    atr = _atr(chart, "H1", 1.0)
    for key in ("0.382", "0.500", "0.618", "0.705", "0.786"):
        lv = _f(fib.get(key))
        if lv and abs(mid - lv) <= atr * 0.35:
            score += 5
            components.append({"factor": f"fib_{key}_confluence", "points": 5})
            break

    ctx = _tf(chart, tf or "H1")
    ind = _d(ctx.get("advanced_indicators"))
    av = _d(ind.get("anchored_vwap"))
    ich = _d(ctx.get("ichimoku"))
    for name, lv in (
        ("avwap_swing_low", _f(av.get("from_swing_low"))),
        ("kijun", _f(ich.get("kijun"))),
        ("ema20", _f(_d(ctx.get("ema")).get("20"))),
        ("ema50", _f(_d(ctx.get("ema")).get("50"))),
    ):
        if lv and lo - atr * 0.25 <= lv <= hi + atr * 0.25:
            score += 4
            components.append({"factor": name, "points": 4})

    return {"score": round(_clamp(score, 0, 150), 2), "components": components, "mid": round(mid, 6)}


def _rank_spot_zones(chart: Mapping[str, Any], side: str, valuation: Mapping[str, Any]) -> List[Dict[str, Any]]:
    plan = build_execution_plan(dict(chart), side, style="spot")
    base_candidates = _l(plan.get("entry_zones"))
    # Fallback to trade_map candidates when execution plan only exposes primary/candidates differently.
    if not base_candidates:
        tm = _d(chart.get("trade_map"))
        base_candidates = _l(tm.get("buy_zones" if side == "long" else "sell_zones"))
    out: List[Dict[str, Any]] = []
    ref = _reference(chart)
    atr = _atr(chart, "H1", 1.0)
    for z in base_candidates:
        if not isinstance(z, dict):
            continue
        tf = str(z.get("timeframe") or "")
        if tf not in {"D1", "H4", "H1"}:
            continue
        lo, hi = _zone_bounds(z)
        if lo <= 0 or hi <= 0:
            continue
        conf = _zone_confluence_score(chart, z, valuation)
        distance = 0.0 if lo <= ref <= hi else min(abs(ref - lo), abs(ref - hi))
        distance_atr = distance / atr
        executable = distance_atr <= 2.25
        score = conf["score"] - max(0.0, distance_atr - 0.4) * 7.5
        item = dict(z)
        item.update({
            "spot_confluence_score": round(score, 2),
            "confluence": conf,
            "distance_from_price": round(distance, 6),
            "distance_atr_h1": round(distance_atr, 3),
            "spot_executable_distance": executable,
            "low": round(lo, 6),
            "high": round(hi, 6),
        })
        out.append(item)
    return sorted(out, key=lambda x: (_f(x.get("spot_confluence_score")), -_f(x.get("distance_atr_h1"), 99)), reverse=True)


def _tranche_ladder(zone: Mapping[str, Any], side: str) -> List[Dict[str, Any]]:
    lo, hi = _zone_bounds(zone)
    width = max(hi - lo, 0.0)
    if width <= 0:
        return []
    if side == "long":
        levels = [hi - width * 0.18, hi - width * 0.50, lo + width * 0.16]
    else:
        levels = [lo + width * 0.18, lo + width * 0.50, hi - width * 0.16]
    weights = [0.30, 0.40, 0.30]
    return [
        {"tranche": i + 1, "price": round(px, 6), "allocation_weight": wt}
        for i, (px, wt) in enumerate(zip(levels, weights))
    ]


def _spot_targets(chart: Mapping[str, Any], side: str, entry: float, stop: float) -> List[Dict[str, Any]]:
    risk = abs(entry - stop)
    if risk <= 0:
        return []
    levels: List[Tuple[float, str, str]] = []
    for tf in ("H1", "H4", "D1", "W1"):
        ctx = _tf(chart, tf)
        sr = _d(ctx.get("support_resistance"))
        arr = _l(sr.get("resistances" if side == "long" else "supports"))
        for lv in arr:
            p = _f(lv)
            if (side == "long" and p > entry) or (side == "short" and 0 < p < entry):
                levels.append((p, "structure", tf))
        for pool in _l(_d(ctx.get("liquidity")).get("pools")):
            if not isinstance(pool, dict):
                continue
            typ, p = _s(pool.get("type")), _f(pool.get("level"))
            if side == "long" and typ == "bsl" and p > entry:
                levels.append((p, "liquidity", tf))
            elif side == "short" and typ == "ssl" and 0 < p < entry:
                levels.append((p, "liquidity", tf))
    # Add RR projections so the plan never has empty targets.
    for rr in (1.0, 1.8, 2.8, 4.0):
        p = entry + risk * rr if side == "long" else entry - risk * rr
        levels.append((p, "rr_projection", f"{rr}R"))

    unique: Dict[float, Tuple[float, str, str]] = {}
    for p, source, tf in levels:
        key = round(p, 4)
        old = unique.get(key)
        if old is None or (old[1] == "rr_projection" and source != "rr_projection"):
            unique[key] = (p, source, tf)
    ordered = sorted(unique.values(), key=lambda x: x[0], reverse=(side == "short"))
    candidates: List[Dict[str, Any]] = []
    for p, source, tf in ordered:
        reward = (p - entry) if side == "long" else (entry - p)
        rr = reward / risk
        if rr >= 0.75:
            candidates.append({"price": round(p, 6), "rr": round(rr, 2), "source": source, "timeframe": tf})
    selected: List[Dict[str, Any]] = []
    for desired in (1.0, 1.75, 2.5):
        opts = [x for x in candidates if x["rr"] >= desired and x not in selected]
        if opts:
            selected.append(opts[0])
    return selected[:3]


def _annotate_dual_risk(
    strategic: Dict[str, Any],
    *,
    entry: float,
    entry_stop: float,
    thesis_stop: Mapping[str, Any],
) -> Dict[str, Any]:
    """Preserve legacy execution RR while exposing thesis-aware RR for 30-60D spot."""
    execution_risk = abs(entry - entry_stop)
    thesis_px = _f(_d(thesis_stop).get("price"))
    thesis_risk = abs(entry - thesis_px) if thesis_px > 0 else 0.0

    def annotate(t: Any) -> Any:
        if not isinstance(t, dict):
            return t
        px = _f(t.get("price"))
        if px <= 0:
            return t
        reward = abs(px - entry)
        t = dict(t)
        legacy = _f(t.get("rr"))
        t["execution_rr"] = round(reward / max(execution_risk, 1e-9), 2) if execution_risk > 0 else None
        t["thesis_rr"] = round(reward / max(thesis_risk, 1e-9), 2) if thesis_risk > 0 else None
        t["rr"] = round(legacy, 2) if legacy else t.get("execution_rr")
        t["rr_semantics"] = "legacy_rr_is_execution_setup_rr; thesis_rr_is_preferred_for_30_60d_interpretation"
        return t

    out = dict(strategic)
    for k in ("tp1", "tp2", "tp3", "runner"):
        out[k] = annotate(out.get(k))
    out["targets"] = [annotate(x) for x in _l(out.get("targets"))]
    out["all_objectives"] = [annotate(x) for x in _l(out.get("all_objectives"))]
    one = dict(_d(out.get("one_month_outlook")))
    one["primary_30_60d_objective"] = annotate(one.get("primary_30_60d_objective"))
    one["runner_45_90d_objective"] = annotate(one.get("runner_45_90d_objective"))
    out["one_month_outlook"] = one
    out["dual_risk_model"] = {
        "entry_price": round(entry, 6),
        "execution_invalidation": round(entry_stop, 6),
        "execution_risk_distance": round(execution_risk, 6),
        "thesis_invalidation": round(thesis_px, 6) if thesis_px > 0 else None,
        "thesis_risk_distance": round(thesis_risk, 6) if thesis_risk > 0 else None,
        "preferred_rr_for_long_horizon": "thesis_rr",
        "semantics": "execution_stop_and_thesis_invalidation_are_distinct_risk_denominators",
    }
    return out


def _spot_execution_plan(
    chart: Mapping[str, Any],
    side: str,
    zones: Sequence[Mapping[str, Any]],
    *,
    valuation: Mapping[str, Any],
    macro: Mapping[str, Any],
    maturity: Mapping[str, Any],
) -> Dict[str, Any]:
    """Build entry geometry and a structural 30-60 day target plan.

    Entry placement remains H1/H4/D1 execution geometry. Targets are deliberately
    delegated to the strategic target engine so short-horizon R projections cannot
    masquerade as one-month spot objectives.
    """
    if side not in {"long", "short"} or not zones:
        return {"valid": False, "reason": "no_ranked_spot_zone"}
    zone = dict(zones[0])
    lo, hi = _zone_bounds(zone)
    atr = _atr(chart, "H1", 1.0)
    micro = _d(chart.get("market_microstructure"))
    spread = _f(micro.get("spread"), 0.0)
    buffer = max(atr * 0.28, spread * 2.5, (hi - lo) * 0.12)
    ladder = _tranche_ladder(zone, side)
    if not ladder:
        return {"valid": False, "reason": "invalid_zone_geometry"}
    weighted_entry = sum(_f(x["price"]) * _f(x["allocation_weight"]) for x in ladder)
    stop = lo - buffer if side == "long" else hi + buffer
    risk = abs(weighted_entry - stop)
    if risk <= 0:
        return {"valid": False, "reason": "invalid_stop_geometry"}

    strategic = build_strategic_target_plan(
        chart=chart,
        valuation=valuation,
        side=side,
        entry=weighted_entry,
        stop=stop,
        macro=macro,
        maturity=maturity,
    )
    if not strategic.get("valid"):
        return {
            "valid": False,
            "reason": strategic.get("reason") or "insufficient_strategic_targets",
            "strategic_target_plan": strategic,
            "primary_zone": {"low": round(lo, 6), "high": round(hi, 6), "timeframe": zone.get("timeframe"), "source": zone.get("source"), "status": zone.get("status"), "confluence_score": zone.get("spot_confluence_score")},
            "entry_ladder": ladder,
            "weighted_entry": round(weighted_entry, 6),
            "invalidation": round(stop, 6),
            "risk_distance": round(risk, 6),
        }

    thesis_invalidation = build_thesis_invalidation(chart, side, stop)
    strategic = _annotate_dual_risk(
        dict(strategic), entry=weighted_entry, entry_stop=stop, thesis_stop=thesis_invalidation
    )
    targets = _l(strategic.get("targets"))
    min_rr = _f(targets[0].get("thesis_rr"), _f(targets[0].get("rr"))) if targets else 0.0
    return {
        "valid": bool(len(targets) >= 3 and min_rr >= 1.0),
        "side": side,
        "primary_zone": {"low": round(lo, 6), "high": round(hi, 6), "timeframe": zone.get("timeframe"), "source": zone.get("source"), "status": zone.get("status"), "confluence_score": zone.get("spot_confluence_score")},
        "entry_ladder": ladder,
        "weighted_entry": round(weighted_entry, 6),
        "invalidation": round(stop, 6),
        "entry_invalidation": round(stop, 6),
        "thesis_invalidation": thesis_invalidation,
        "risk_distance": round(risk, 6),
        "atr_buffer": round(buffer, 6),
        "targets": targets[:3],
        "runner_target": strategic.get("runner"),
        "minimum_rr": round(min_rr, 2),
        "minimum_rr_semantics": "minimum_thesis_rr_for_30_60d_spot",
        "dual_risk_model": strategic.get("dual_risk_model"),
        "review_milestones": strategic.get("review_milestones", []),
        "zone_distance_atr": zone.get("distance_atr_h1"),
        "strategic_target_plan": strategic,
        "target_engine": TARGET_ENGINE_VERSION,
        "holding_horizon_days": {"minimum": 30, "primary": "30-60", "runner": "45-90+"},
    }


def _timing_overlay(chart: Mapping[str, Any], side: str) -> Dict[str, Any]:
    score = 0.0
    details: Dict[str, Any] = {}
    max_score = sum(TIMING_WEIGHTS.values()) * 10.0
    for tf, weight in TIMING_WEIGHTS.items():
        ctx = _tf(chart, tf)
        raw, notes = _tf_direction(ctx) if ctx else (0.0, [])
        signed = raw if side == "long" else -raw
        score += max(-10.0, min(10.0, signed)) * weight
        details[tf] = {"raw": round(raw, 3), "aligned_score": round(signed, 3), "weight": weight, "notes": notes}
    normalized = _clamp(50.0 + 50.0 * score / max(max_score, 1e-9))
    return {"score_0_100": round(normalized, 2), "aligned": normalized >= 55.0, "details": details}


def _spot_execution_cost_model(chart: Mapping[str, Any], plan: Mapping[str, Any]) -> Dict[str, Any]:
    """Translate generic spread state into a holding-horizon-aware Spot cost gate.

    Relative spread spikes matter for scalping, but a 30-60 day spot entry should be
    judged by the absolute transaction cost versus H1 ATR, zone width and the planned
    execution risk.  This model never overrides stale data, time sync, market closure,
    reopen cooldown or history-sync gates; it only adjudicates BLOCKED_SPREAD_REGIME.
    """
    market = _d(_d(chart.get("fusion_context")).get("market_state"))
    spread_regime = _d(market.get("spread_regime"))
    spread = _f(spread_regime.get("live_spread"), _f(_d(chart.get("market_microstructure")).get("spread"), 0.0))
    ref = max(_reference(chart), 1e-9)
    h1_atr = _atr(chart, "H1", 1.0)
    zone = _d(plan.get("primary_zone"))
    lo, hi = _zone_bounds(zone) if zone else (0.0, 0.0)
    zone_width = max(hi - lo, 0.0)
    execution_risk = max(_f(plan.get("risk_distance")), 0.0)
    bps = spread / ref * 10000.0 if spread > 0 else 0.0
    atr_pct = spread / h1_atr * 100.0 if spread > 0 else 0.0
    zone_pct = spread / zone_width * 100.0 if spread > 0 and zone_width > 0 else 0.0
    risk_pct = spread / execution_risk * 100.0 if spread > 0 and execution_risk > 0 else 0.0
    ratio = _f(spread_regime.get("ratio_to_median"), 0.0)

    # Fail-closed only when absolute cost is meaningful for a swing/spot entry.
    hard_block = bool(
        spread > 0 and (
            bps >= 2.5 or
            atr_pct >= 6.0 or
            (execution_risk > 0 and risk_pct >= 8.0) or
            (zone_width > 0 and zone_pct >= 12.0)
        )
    )
    relative_spike_only = bool(spread_regime.get("state") == "extreme" and not hard_block)
    acceptable = not hard_block
    quality = _clamp(100.0 - min(45.0, bps * 10.0) - min(25.0, atr_pct * 2.5) - min(20.0, risk_pct * 1.5))
    return {
        "engine": "AMB_SPOT_EXECUTION_COST_GATE_V2",
        "acceptable_for_spot": acceptable,
        "hard_block": hard_block,
        "relative_spread_spike_only": relative_spike_only,
        "generic_spread_state": spread_regime.get("state"),
        "live_spread": round(spread, 8) if spread else None,
        "ratio_to_recent_median": round(ratio, 3) if ratio else None,
        "spread_bps_of_price": round(bps, 4),
        "spread_pct_h1_atr": round(atr_pct, 3),
        "spread_pct_zone_width": round(zone_pct, 3) if zone_width > 0 else None,
        "spread_pct_execution_risk": round(risk_pct, 3) if execution_risk > 0 else None,
        "execution_cost_quality_0_100": round(quality, 2),
        "policy": "spot_cost_relative_to_price_atr_zone_and_risk_not_median_ratio_alone",
    }


def _spot_state(*, chart: Mapping[str, Any], side: str, htf: Mapping[str, Any], macro: Mapping[str, Any], maturity: Mapping[str, Any], plan: Mapping[str, Any], timing: Mapping[str, Any], execution_cost: Mapping[str, Any], pullback_quality: Mapping[str, Any], thesis_health: Mapping[str, Any], falling_knife: Mapping[str, Any], accumulation: Mapping[str, Any]) -> Dict[str, Any]:
    """Canonical spot execution state.

    Spot is accumulation-oriented: exact micro triggers are not hard requirements. A
    new tranche can become actionable when the slow thesis is healthy, the price is
    at/near a structural value zone, and the falling-knife guard permits new buying.
    Market/data/event hard gates remain binding.
    """
    market = _d(_d(chart.get("fusion_context")).get("market_state"))
    gate = str(market.get("execution_gate") or "")
    if gate and gate != "ALLOW_EXECUTION":
        if gate == "BLOCKED_SPREAD_REGIME" and bool(execution_cost.get("acceptable_for_spot")):
            gate = "ALLOW_EXECUTION_SPOT_COST_OVERRIDE"
        else:
            return {"state": "MARKET_BLOCKED", "action": "WAIT", "actionable": False, "reason": f"market_gate:{gate}"}
    if not macro.get("attached"):
        return {"state": "WAIT_MACRO", "action": "WAIT", "actionable": False, "reason": "news_macro_context_not_attached"}
    if macro.get("spot_blocks_trade"):
        return {"state": "WAIT_EVENT_WINDOW", "action": "WAIT", "actionable": False, "reason": f"spot_macro_event_gate:{macro.get('event_risk')}"}
    if side != "long":
        return {"state": "AVOID_NEW_SPOT_BUY", "action": "WAIT", "actionable": False, "reason": "higher_timeframe_spot_bias_not_long"}
    if not plan.get("valid"):
        return {"state": "WAIT_VALID_GEOMETRY", "action": "WAIT", "actionable": False, "reason": str(plan.get("reason"))}

    health = _f(thesis_health.get("health_score_0_100"), 0.0)
    if bool(thesis_health.get("hard_fail")) or _s(thesis_health.get("state")) in {"invalidated", "critical"}:
        return {"state": "WAIT_THESIS_HEALTH", "action": "WAIT", "actionable": False, "reason": "slow_spot_thesis_not_healthy_enough_for_new_accumulation", "thesis_health": round(health, 2)}
    if bool(falling_knife.get("block_new_accumulation")):
        return {"state": "WAIT_FALLING_KNIFE", "action": "WAIT", "actionable": False, "reason": f"falling_knife_guard:{falling_knife.get('permission')}", "falling_knife_risk": falling_knife.get("risk_score_0_100")}

    macro_bias = _s(macro.get("bias"))
    if macro_bias in {"bearish", "short"} and _f(macro.get("confidence")) >= 65:
        return {"state": "WAIT_MACRO_CONFLICT", "action": "WAIT", "actionable": False, "reason": "macro_bias_materially_opposes_long_spot"}

    acc_permission = str(accumulation.get("permission") or "")
    acc_state = str(accumulation.get("state") or "")
    if acc_permission == "ACCUMULATE" and _f(accumulation.get("recommended_new_allocation_pct_now")) > 0:
        return {
            "state": "BUY_NOW",
            "action": "BUY",
            "actionable": True,
            "reason": "spot_accumulation_conditions_satisfied_without_scalp_trigger_requirement",
            "accumulation_state": acc_state,
            "recommended_new_allocation_pct": accumulation.get("recommended_new_allocation_pct_now"),
            "eligible_tranches": accumulation.get("eligible_tranches_now"),
            "thesis_health": round(health, 2),
            "falling_knife_risk": falling_knife.get("risk_score_0_100"),
            "pullback_quality_score": pullback_quality.get("quality_score_0_100"),
        }
    if acc_permission in {"ARMED", "WATCH"}:
        if bool(maturity.get("overextended")) and not bool(pullback_quality.get("entry_armed")):
            return {
                "state": "WAIT_COOL_OFF_LONG",
                "action": "WAIT",
                "actionable": False,
                "reason": "cool_off_quality_not_yet_sufficient",
                "thesis_health": round(health, 2),
                "falling_knife_risk": falling_knife.get("risk_score_0_100"),
                "pullback_quality_score": pullback_quality.get("quality_score_0_100"),
                "accumulation_state": acc_state,
            }
        return {
            "state": "ENTRY_ARMED_COOL_OFF_LONG" if acc_permission == "ARMED" else "WATCH_ACCUMULATION_ZONE",
            "action": "WAIT",
            "actionable": False,
            "reason": acc_state or "spot_accumulation_not_yet_price_eligible",
            "thesis_health": round(health, 2),
            "falling_knife_risk": falling_knife.get("risk_score_0_100"),
            "pullback_quality_score": pullback_quality.get("quality_score_0_100"),
        }
    if acc_permission == "PAUSE":
        return {"state": "PAUSE_ACCUMULATION", "action": "WAIT", "actionable": False, "reason": acc_state, "thesis_health": round(health, 2)}
    if acc_permission == "HOLD":
        return {"state": "ACCUMULATION_COMPLETE", "action": "WAIT", "actionable": False, "reason": "planned_accumulation_complete"}

    # Defensive fallback preserves the existing cool-off semantics.
    if bool(pullback_quality.get("hard_fail")):
        return {"state": "WAIT_PULLBACK_THESIS_RISK", "action": "WAIT", "actionable": False, "reason": "pullback_quality_hard_fail"}
    return {"state": "WAIT", "action": "WAIT", "actionable": False, "reason": "no_clean_spot_accumulation_state"}

def _fusion_score(htf: Mapping[str, Any], macro: Mapping[str, Any], timing: Mapping[str, Any], maturity: Mapping[str, Any], zones: Sequence[Mapping[str, Any]], learning_profile: Optional[Mapping[str, Any]]) -> Dict[str, Any]:
    h = _f(htf.get("score_0_100"), 50.0)
    m = _f(macro.get("score_0_100"), 50.0) if macro.get("attached") else 50.0
    t = _f(timing.get("score_0_100"), 50.0)
    z = _f(zones[0].get("spot_confluence_score"), 50.0) if zones else 40.0
    z = min(z, 100.0)
    maturity_penalty = min(20.0, _f(maturity.get("overextension_score")) * 5.0)

    # Spot horizon intentionally privileges HTF structure and macro over micro timing.
    raw = h * 0.42 + m * 0.28 + z * 0.20 + t * 0.10 - maturity_penalty
    reliability = 0.72
    samples = 0
    if learning_profile:
        metrics = _d(learning_profile.get("metrics"))
        samples = int(_f(metrics.get("samples"), 0))
        # Shrink less as local calibration evidence accumulates.
        reliability = min(0.92, 0.72 + min(samples, 200) / 200.0 * 0.20)
    calibrated = 50.0 + (raw - 50.0) * reliability
    return {
        "raw_score": round(_clamp(raw), 2),
        "calibrated_score": round(_clamp(calibrated), 2),
        "reliability": round(reliability, 3),
        "learning_samples": samples,
        "components": {"higher_timeframe": round(h, 2), "macro": round(m, 2), "zone_quality": round(z, 2), "timing": round(t, 2), "maturity_penalty": round(maturity_penalty, 2)},
        "semantics": "spot_directional_conviction_not_empirical_win_probability",
    }



def _price_location(reference: float, zone: Mapping[str, Any], atr: float) -> Dict[str, Any]:
    lo, hi = _zone_bounds(zone) if zone else (0.0, 0.0)
    if lo <= 0 or hi <= 0:
        return {
            "relation": "NO_VALID_ZONE",
            "distance": None,
            "distance_atr": None,
            "inside_zone": False,
        }
    if lo <= reference <= hi:
        relation = "INSIDE_ZONE"
        distance = 0.0
    elif reference > hi:
        relation = "ABOVE_ZONE"
        distance = reference - hi
    else:
        relation = "BELOW_ZONE"
        distance = lo - reference
    return {
        "relation": relation,
        "distance": round(distance, 6),
        "distance_atr": round(distance / max(atr, 1e-9), 3),
        "inside_zone": relation == "INSIDE_ZONE",
        "zone_low": round(lo, 6),
        "zone_high": round(hi, 6),
    }


def _target_ladder_view(plan: Mapping[str, Any]) -> Dict[str, Any]:
    targets = [x for x in _l(plan.get("targets")) if isinstance(x, dict)]
    return {
        "tp1": targets[0] if len(targets) > 0 else None,
        "tp2": targets[1] if len(targets) > 1 else None,
        "tp3": targets[2] if len(targets) > 2 else None,
        "all_targets": targets[:3],
        "target_basis": "D1_W1_MN1_structural_liquidity_clusters_with_RR_validation",
        "target_horizon": "spot_30_60_day_aware",
        "revalidate_after_fill": True,
        "note": "TP1/TP2/TP3 are evidence-ranked spot objectives. RR validates usefulness but does not generate the targets. Recompute after a materially different fill, weekly structure change, or macro-regime reversal.",
    }


def _spot_opportunity_contract(
    *,
    chart: Mapping[str, Any],
    side: str,
    htf: Mapping[str, Any],
    macro: Mapping[str, Any],
    plan: Mapping[str, Any],
    state: Mapping[str, Any],
    accumulation: Mapping[str, Any],
    thesis_health: Mapping[str, Any],
    falling_knife: Mapping[str, Any],
) -> Dict[str, Any]:
    """LLM-facing setup contract independent from immediate execution permission.

    The key semantic invariant is: a valid long setup may exist while the current
    execution state is WAIT/BLOCKED.  In that case the plan remains visible as a
    WATCH plan, never as an immediate market order.
    """
    ref = _reference(chart)
    zone = _d(plan.get("primary_zone")) if plan.get("valid") else {}
    location = _price_location(ref, zone, _atr(chart, "H1", 1.0))
    long_setup = side == "long" and bool(plan.get("valid"))
    actionable = bool(state.get("actionable")) and state.get("action") == "BUY"
    market = _d(_d(chart.get("fusion_context")).get("market_state"))

    execution_state = str(state.get("state") or "")
    acc_permission = str(accumulation.get("permission") or "")
    if not long_setup:
        setup_state = "NO_BUY_SETUP"
    elif actionable and acc_permission == "ACCUMULATE":
        setup_state = "BUY_NOW"
    elif acc_permission == "ARMED":
        setup_state = "ENTRY_ARMED_BUY_ON_PULLBACK"
    elif acc_permission in {"PAUSE", "BLOCK"}:
        setup_state = "BUY_ZONE_PRESENT_BUT_SAFETY_PAUSED"
    elif location.get("relation") == "ABOVE_ZONE":
        setup_state = "BUY_ON_PULLBACK_WATCH"
    elif location.get("relation") == "INSIDE_ZONE":
        setup_state = "BUY_ZONE_PRESENT_WATCH"
    elif location.get("relation") == "BELOW_ZONE":
        setup_state = "WAIT_RECLAIM_BUY_ZONE"
    else:
        setup_state = "WATCH_BUY_SETUP"

    if actionable:
        permission = "ACTIONABLE_NOW"
    elif long_setup:
        permission = "WATCH_ONLY"
    else:
        permission = "NO_LONG_PERMISSION"

    targets = _target_ladder_view(plan) if plan.get("valid") else _target_ladder_view({})
    return {
        "directional_bias": htf.get("bias"),
        "buy_setup_available": long_setup,
        "setup_state": setup_state,
        "execution_permission": permission,
        "actionable_now": actionable,
        "current_execution_state": state.get("state"),
        "current_execution_action": state.get("action"),
        "block_or_wait_reason": state.get("reason"),
        "market_gate": market.get("execution_gate"),
        "spot_effective_market_gate": state.get("spot_effective_market_gate"),
        "spread_gate_overridden_for_spot": state.get("spread_gate_overridden_for_spot"),
        "spot_execution_cost_gate": _d(plan.get("spot_execution_cost_gate")),
        "pullback_quality": _d(plan.get("pullback_quality")),
        "accumulation_plan": _d(accumulation),
        "thesis_health": _d(thesis_health),
        "falling_knife_guard": _d(falling_knife),
        "reference_price": round(ref, 6),
        "entry_status": location,
        "best_buy_zone": zone if long_setup else None,
        "entry_ladder": _l(plan.get("entry_ladder")) if long_setup else [],
        "weighted_entry": plan.get("weighted_entry") if long_setup else None,
        "invalidation": plan.get("invalidation") if long_setup else None,
        "risk_distance": plan.get("risk_distance") if long_setup else None,
        "minimum_rr": plan.get("minimum_rr") if long_setup else None,
        "minimum_rr_semantics": plan.get("minimum_rr_semantics") if long_setup else None,
        "dual_risk_model": plan.get("dual_risk_model") if long_setup else None,
        "review_milestones": plan.get("review_milestones") if long_setup else [],
        "targets": targets,
        "runner_target": plan.get("runner_target") if long_setup else None,
        "thesis_invalidation": plan.get("thesis_invalidation") if long_setup else None,
        "strategic_target_plan": plan.get("strategic_target_plan") if long_setup else None,
        "one_month_outlook": _d(_d(plan.get("strategic_target_plan")).get("one_month_outlook")) if long_setup else None,
        "macro_risk": {
            "bias": macro.get("bias"),
            "event_risk": macro.get("event_risk"),
            "spot_blocks_trade": bool(macro.get("spot_blocks_trade")),
            "execution_mode": macro.get("execution_mode"),
            "combined_conflict": macro.get("combined_conflict"),
        },
        "semantic_rules": {
            "zone_exists_independent_of_permission": True,
            "watch_zone_is_not_market_order": True,
            "buy_now_requires_actionable_now": True,
            "never_invent_prices": True,
            "targets_tied_to_planned_entry": True,
        },
    }

def build_spot_decision_packet(
    chart: Dict[str, Any],
    learning_profile: Optional[Mapping[str, Any]] = None,
    position_record: Optional[Mapping[str, Any]] = None,
) -> Dict[str, Any]:
    now = datetime.now(timezone.utc).isoformat()
    htf = _higher_timeframe_consensus(chart)
    valuation = _dealing_range(chart)
    macro = _macro_overlay(chart)
    maturity = _trend_maturity(chart, htf)
    wyckoff = _wyckoff_proxy(chart, htf)

    side = "long" if htf.get("bias") == "bullish" else ("short" if htf.get("bias") == "bearish" else "none")
    zones = _rank_spot_zones(chart, side if side in {"long", "short"} else "long", valuation)
    plan = _spot_execution_plan(
        chart,
        side,
        zones,
        valuation=valuation,
        macro=macro,
        maturity=maturity,
    )
    timing = _timing_overlay(chart, side if side in {"long", "short"} else "long")
    pullback_quality = build_pullback_quality(
        chart=chart,
        plan=plan,
        timing=timing,
        maturity=maturity,
        htf=htf,
        macro=macro,
    ) if side == "long" and plan.get("valid") else {
        "engine": PULLBACK_ENGINE_VERSION,
        "state": "NOT_APPLICABLE",
        "quality_score_0_100": 0.0,
        "entry_ready": False,
        "entry_armed": False,
        "hard_fail": False,
    }
    strategic = _d(plan.get("strategic_target_plan"))
    thesis_health = build_thesis_health(
        chart=chart, htf=htf, macro=macro, strategic=strategic, maturity=maturity, valuation=valuation, position_record=position_record
    ) if side == "long" and plan.get("valid") else {
        "engine": THESIS_HEALTH_ENGINE_VERSION, "state": "NOT_APPLICABLE", "health_score_0_100": 0.0, "hard_fail": False
    }
    falling_knife = build_falling_knife_guard(chart=chart, plan=plan, macro=macro) if side == "long" and plan.get("valid") else {
        "engine": FALLING_KNIFE_ENGINE_VERSION, "level": "NOT_APPLICABLE", "risk_score_0_100": 0.0, "block_new_accumulation": False, "hard_fail": False
    }
    accumulation = build_accumulation_plan(
        chart=chart, plan=plan, pullback=pullback_quality, falling_knife=falling_knife, thesis_health=thesis_health,
        macro=macro, valuation=valuation, maturity=maturity, position_record=position_record
    ) if side == "long" and plan.get("valid") else {
        "engine": ACCUMULATION_ENGINE_VERSION, "valid": False, "state": "NOT_APPLICABLE", "permission": "NONE", "tranches": []
    }
    execution_cost = _spot_execution_cost_model(chart, plan)
    if isinstance(plan, dict):
        plan["spot_execution_cost_gate"] = execution_cost
        plan["pullback_quality"] = pullback_quality
        plan["thesis_health"] = thesis_health
        plan["falling_knife_guard"] = falling_knife
        plan["accumulation_plan"] = accumulation
    state = _spot_state(chart=chart, side=side, htf=htf, macro=macro, maturity=maturity, plan=plan, timing=timing, execution_cost=execution_cost, pullback_quality=pullback_quality, thesis_health=thesis_health, falling_knife=falling_knife, accumulation=accumulation)
    generic_gate = str(_d(_d(chart.get("fusion_context")).get("market_state")).get("execution_gate") or "")
    spread_override = generic_gate == "BLOCKED_SPREAD_REGIME" and bool(execution_cost.get("acceptable_for_spot"))
    state["generic_market_gate"] = generic_gate or None
    state["spot_effective_market_gate"] = "ALLOW_EXECUTION_SPOT_COST_OVERRIDE" if spread_override else (generic_gate or "ALLOW_EXECUTION")
    state["spread_gate_overridden_for_spot"] = spread_override
    fusion = _fusion_score(htf, macro, timing, maturity, zones, learning_profile)

    # Conviction threshold cannot override hard execution states.
    if state.get("action") == "BUY" and _f(fusion.get("calibrated_score")) < 58.0:
        state = {"state": "WAIT_CONVICTION", "action": "WAIT", "actionable": False, "reason": "spot_fusion_conviction_below_58"}

    opportunity = _spot_opportunity_contract(
        chart=chart, side=side, htf=htf, macro=macro, plan=plan, state=state, accumulation=accumulation, thesis_health=thesis_health, falling_knife=falling_knife
    )

    staged_exit = build_staged_exit_plan(
        reference_price=_reference(chart),
        side=side,
        strategic=_d(plan.get("strategic_target_plan")),
        thesis_invalidation=_d(plan.get("thesis_invalidation")),
        fusion=fusion,
        maturity=maturity,
        macro=macro,
    ) if plan.get("valid") and side in {"long", "short"} else {"valid": False, "engine": EXIT_ENGINE_VERSION, "reason": "no_valid_spot_plan"}

    # Canonical lifecycle is position-aware.  The legacy price-only management state
    # is preserved for diagnostics, but it is no longer allowed to imply that a
    # position exists before a fill/registration is persisted.
    position_lifecycle = build_position_lifecycle(
        chart=chart,
        opportunity=opportunity,
        decision=state,
        position_record=position_record,
        staged_exit=staged_exit,
        htf=htf,
        macro=macro,
        maturity=maturity,
        strategic=_d(plan.get("strategic_target_plan")),
    )
    if staged_exit.get("valid"):
        staged_exit["legacy_price_only_management_state"] = staged_exit.get("management_state")
        staged_exit["management_state"] = {
            "state": position_lifecycle.get("state"),
            "phase": position_lifecycle.get("phase"),
            "position_open": position_lifecycle.get("position_open"),
            "meaning": _d(position_lifecycle.get("canonical")).get("meaning"),
        }
        staged_exit["adaptive_reallocation"] = position_lifecycle.get("adaptive_reallocation")

    market = _d(_d(chart.get("fusion_context")).get("market_state"))
    ref = _reference(chart)
    targets = _l(plan.get("targets")) if plan.get("valid") else []
    entry = _d(plan.get("primary_zone")) if plan.get("valid") else None

    reasons = [
        f"HTF bias={htf.get('bias')} score={htf.get('score_0_100')} confidence={htf.get('confidence')}",
        f"Macro bias={macro.get('bias')} score={macro.get('score_0_100')} event_risk={macro.get('event_risk')}",
        f"Valuation={valuation.get('valuation_zone')} position={valuation.get('price_position_pct')}% OTE-long={valuation.get('ote_long_zone')}",
        f"Trend maturity={maturity.get('phase')} overextension={maturity.get('overextension_score')}",
        f"Wyckoff proxy={wyckoff.get('phase')}",
        f"Spot fusion={fusion.get('calibrated_score')} reliability={fusion.get('reliability')}",
        f"Spot execution cost gate={execution_cost.get('acceptable_for_spot')} quality={execution_cost.get('execution_cost_quality_0_100')}",
        f"Pullback quality={pullback_quality.get('quality_score_0_100')} state={pullback_quality.get('state')}",
        f"Thesis health={thesis_health.get('health_score_0_100')} state={thesis_health.get('state')}",
        f"Falling-knife risk={falling_knife.get('risk_score_0_100')} level={falling_knife.get('level')}",
        f"Accumulation={accumulation.get('state')} new_allocation={accumulation.get('recommended_new_allocation_pct_now')}",
        f"State={state.get('state')}: {state.get('reason')}",
    ]

    return {
        "contract": "AMB_GOLD_SPOT_DECISION_V6_ACCUMULATION_THESIS_HEALTH",
        "engine": SPOT_ENGINE_VERSION,
        "symbol": chart.get("symbol"),
        "data_provider": chart.get("provider") or chart.get("data_provider"),
        "generated_utc": now,
        "spot_only": True,
        "paper_only": True,
        "reference_price": round(ref, 6),
        "market_state": market,
        "spot_execution_cost_gate": execution_cost,
        "higher_timeframe_consensus": htf,
        "macro_context": macro,
        "valuation": valuation,
        "trend_maturity": maturity,
        "wyckoff_phase_proxy": wyckoff,
        "timing_overlay": timing,
        "pullback_quality": pullback_quality,
        "thesis_health": thesis_health,
        "falling_knife_guard": falling_knife,
        "accumulation_plan": accumulation,
        "spot_fusion": fusion,
        "entry_zone_ranking": zones[:8],
        "execution_plan": plan,
        "strategic_target_engine": plan.get("strategic_target_plan") if plan.get("valid") else plan.get("strategic_target_plan"),
        "spot_opportunity": opportunity,
        "position_management_30_60d": staged_exit,
        "position_lifecycle": position_lifecycle,
        "decision": {
            "action": state.get("action"),
            "state": state.get("state"),
            "actionable": bool(state.get("actionable")),
            "side": "long" if side == "long" else None,
            "reason": state.get("reason"),
            "primary_entry_zone": entry,
            "entry_ladder": _l(plan.get("entry_ladder")) if plan.get("valid") else [],
            "weighted_entry": plan.get("weighted_entry") if plan.get("valid") else None,
            "invalidation": plan.get("invalidation") if plan.get("valid") else None,
            "entry_invalidation": plan.get("entry_invalidation") if plan.get("valid") else None,
            "thesis_invalidation": plan.get("thesis_invalidation") if plan.get("valid") else None,
            "targets": targets,
            "runner_target": plan.get("runner_target") if plan.get("valid") else None,
            "minimum_rr": plan.get("minimum_rr") if plan.get("valid") else None,
            "minimum_rr_semantics": plan.get("minimum_rr_semantics") if plan.get("valid") else None,
            "dual_risk_model": plan.get("dual_risk_model") if plan.get("valid") else None,
            "review_milestones": plan.get("review_milestones") if plan.get("valid") else [],
            "generic_market_gate": state.get("generic_market_gate"),
            "spot_effective_market_gate": state.get("spot_effective_market_gate"),
            "spread_gate_overridden_for_spot": state.get("spread_gate_overridden_for_spot"),
            "pullback_quality_score": pullback_quality.get("quality_score_0_100"),
            "pullback_quality_state": pullback_quality.get("state"),
            "thesis_health_score": thesis_health.get("health_score_0_100"),
            "thesis_health_state": thesis_health.get("state"),
            "falling_knife_risk": falling_knife.get("risk_score_0_100"),
            "falling_knife_level": falling_knife.get("level"),
            "accumulation_state": accumulation.get("state"),
            "recommended_new_allocation_pct": accumulation.get("recommended_new_allocation_pct_now"),
            "eligible_tranches": accumulation.get("eligible_tranches_now"),
            "watchlist_only": not bool(state.get("actionable")),
        },
        "holding_horizon": {
            "mode": "institutional_spot_30_60_day",
            "minimum_analysis_horizon_days": 30,
            "primary_target_horizon_days": "30-60",
            "runner_horizon_days": "45-90+",
            "directional_timeframes": ["MN1", "W1", "D1", "H4", "H1"],
            "timing_timeframes": ["H1", "M15"],
            "M5_role": "data_health_only_not_directional",
            "review_triggers": ["D1_structure_change", "W1_structure_change", "thesis_invalidation", "macro_regime_change", "high_impact_event_window", "monthly_or_weekly_target_cluster_reached", "target_hit", "staged_exit_review"],
        },
        "reasons": reasons,
        "chatgpt_instruction": "Treat this as SPOT-only XAUUSD context with a minimum one-month analytical horizon. Always report the supplied buy zone, entry ladder, entry invalidation, thesis invalidation, TP1/TP2/TP3 and runner when a setup exists, even if immediate execution is WAIT/BLOCKED. TP3 is the primary 30-60 day strategic objective. Use position_lifecycle as the canonical position state: PRE_ENTRY_WATCH/ENTRY_ARMED do not mean a position exists. Once a position is registered, follow POSITION_OPEN -> TP1_REALIZED -> STRATEGIC_CORE -> RUNNER_ONLY -> CLOSED/THESIS_INVALIDATED. Adaptive de-risk/reallocation is allowed only after a new D1/W1 close and never retroactively changes realized stages. Use pullback_quality as the cool-off layer, thesis_health as the canonical slow 30-60D thesis monitor, falling_knife_guard as the safety filter for NEW accumulation, and accumulation_plan as the canonical staged-buy policy. Spot accumulation does NOT require a scalp-grade trigger: value-zone interaction + healthy slow thesis + falling-knife safety can authorize a tranche. A watch zone is not a market order. Never invent prices or replace structural targets with your own R-multiples.",
    }
