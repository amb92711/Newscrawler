from __future__ import annotations

"""30-90 day staged-exit and thesis-survival engine for XAUUSD spot.

This module does not create new price targets.  It consumes the structural target
ladder produced by strategic_targets.py and converts it into a position-management
plan: staged reductions, runner retention, target reachability, thesis survival,
review cadence, and dynamic actions when objectives are reached or the thesis
weakens.  Percentages are analytical paper allocations, not broker orders.
"""

from typing import Any, Dict, List, Mapping, Optional
import math

EXIT_ENGINE_VERSION = "AMB_SPOT_STAGED_EXIT_ENGINE_V1_30_90D"


def _d(v: Any) -> Dict[str, Any]:
    return v if isinstance(v, dict) else {}


def _l(v: Any) -> List[Any]:
    return v if isinstance(v, list) else []


def _f(v: Any, default: float = 0.0) -> float:
    try:
        x = float(v)
        return x if math.isfinite(x) else default
    except Exception:
        return default


def _s(v: Any) -> str:
    return str(v or "").strip().lower()


def _clamp(x: float, lo: float = 0.0, hi: float = 100.0) -> float:
    return max(lo, min(hi, x))


def _sigmoid(x: float) -> float:
    if x >= 0:
        z = math.exp(-x)
        return 1.0 / (1.0 + z)
    z = math.exp(x)
    return z / (1.0 + z)


def _target_quality(t: Mapping[str, Any]) -> float:
    q = _s(t.get("evidence_quality"))
    base = {
        "institutional_structural": 88.0,
        "structural": 74.0,
        "projection_only": 48.0,
        "fallback_volatility_projection": 36.0,
    }.get(q, 50.0)
    structural = _f(t.get("structural_evidence_count"))
    evidence = _f(t.get("evidence_count"))
    selection = _f(t.get("selection_score"), 50.0)
    return _clamp(base + min(8.0, structural * 2.0) + min(4.0, evidence) + (selection - 50.0) * 0.08)


def _macro_durability(strategic: Mapping[str, Any]) -> float:
    return _f(_d(strategic.get("one_month_outlook")).get("macro_trend_durability_score"), 50.0)


def _reachability(target: Mapping[str, Any], strategic: Mapping[str, Any], fusion: Mapping[str, Any], maturity: Mapping[str, Any], role_index: int) -> Dict[str, Any]:
    horizon = _d(target.get("horizon"))
    distance_watr = _f(horizon.get("distance_weekly_atr"), 1.0)
    quality = _target_quality(target)
    durability = _macro_durability(strategic)
    conviction = _f(fusion.get("calibrated_score"), 50.0)
    reliability = _f(fusion.get("reliability"), 0.5) * 100.0
    phase = _s(maturity.get("phase"))
    maturity_adj = {"developing_trend": 8.0, "healthy_trend": 10.0, "late_extended": -12.0}.get(phase, 0.0)
    role_penalty = (role_index - 1) * 5.5
    distance_penalty = max(0.0, distance_watr - 0.6) * 7.5

    latent = (
        (quality - 55.0) * 0.030
        + (durability - 50.0) * 0.020
        + (conviction - 50.0) * 0.022
        + (reliability - 50.0) * 0.012
        + maturity_adj * 0.035
        - role_penalty * 0.035
        - distance_penalty * 0.030
    )
    model_score = _clamp(20.0 + 72.0 * _sigmoid(latent))
    survival = _clamp(model_score + (durability - 50.0) * 0.12 - role_index * 2.0)
    return {
        "model_estimated_reachability_score_0_100": round(model_score, 2),
        "thesis_survival_score_0_100": round(survival, 2),
        "evidence_quality_score_0_100": round(quality, 2),
        "distance_weekly_atr": round(distance_watr, 3),
        "semantics": "model_estimated_reachability_not_empirical_probability",
        "calibration_status": "uncalibrated_until_sufficient_spot_outcome_history",
    }


def _allocation_weights(strategic: Mapping[str, Any], maturity: Mapping[str, Any], macro: Mapping[str, Any]) -> Dict[str, float]:
    phase = _s(maturity.get("phase"))
    macro_bias = _s(macro.get("bias"))
    durability = _macro_durability(strategic)

    # Base staged realization: retain meaningful exposure for the 30-60D objective.
    weights = {"TP1": 0.20, "TP2": 0.25, "TP3": 0.35, "RUNNER": 0.20}
    if phase == "late_extended":
        weights = {"TP1": 0.30, "TP2": 0.30, "TP3": 0.28, "RUNNER": 0.12}
    elif phase in {"healthy_trend", "developing_trend"} and durability >= 65.0:
        weights = {"TP1": 0.15, "TP2": 0.20, "TP3": 0.40, "RUNNER": 0.25}
    if macro_bias in {"bearish", "short"} or durability < 38.0:
        weights = {"TP1": 0.35, "TP2": 0.30, "TP3": 0.25, "RUNNER": 0.10}
    return weights


def _management_state(reference: float, side: str, targets: Mapping[str, Mapping[str, Any]], thesis: Mapping[str, Any]) -> Dict[str, Any]:
    reached: List[str] = []
    for role in ("TP1", "TP2", "TP3", "RUNNER"):
        px = _f(_d(targets.get(role)).get("price"))
        if px <= 0:
            continue
        if (side == "long" and reference >= px) or (side == "short" and reference <= px):
            reached.append(role)
    thesis_px = _f(thesis.get("price"))
    thesis_broken = bool(thesis_px > 0 and ((side == "long" and reference <= thesis_px) or (side == "short" and reference >= thesis_px)))
    if thesis_broken:
        state = "THESIS_INVALIDATED"
    elif "RUNNER" in reached:
        state = "RUNNER_OBJECTIVE_REACHED"
    elif "TP3" in reached:
        state = "STRATEGIC_OBJECTIVE_REACHED"
    elif "TP2" in reached:
        state = "SWING_OBJECTIVE_REACHED"
    elif "TP1" in reached:
        state = "TACTICAL_OBJECTIVE_REACHED"
    else:
        state = "HOLD_AND_REVIEW"
    return {"state": state, "reached_objectives": reached, "thesis_broken": thesis_broken}


def build_staged_exit_plan(
    *,
    reference_price: float,
    side: str,
    strategic: Mapping[str, Any],
    thesis_invalidation: Mapping[str, Any],
    fusion: Mapping[str, Any],
    maturity: Mapping[str, Any],
    macro: Mapping[str, Any],
) -> Dict[str, Any]:
    if not strategic.get("valid") or side not in {"long", "short"}:
        return {"valid": False, "engine": EXIT_ENGINE_VERSION, "reason": "no_valid_strategic_target_plan"}

    raw_targets = {
        "TP1": _d(strategic.get("tp1")),
        "TP2": _d(strategic.get("tp2")),
        "TP3": _d(strategic.get("tp3")),
        "RUNNER": _d(strategic.get("runner")),
    }
    if any(_f(raw_targets[r].get("price")) <= 0 for r in ("TP1", "TP2", "TP3")):
        return {"valid": False, "engine": EXIT_ENGINE_VERSION, "reason": "missing_core_objectives"}

    weights = _allocation_weights(strategic, maturity, macro)
    stages: List[Dict[str, Any]] = []
    for idx, role in enumerate(("TP1", "TP2", "TP3", "RUNNER"), start=1):
        t = raw_targets[role]
        if not t:
            continue
        reach = _reachability(t, strategic, fusion, maturity, idx)
        horizon = _d(t.get("horizon"))
        stages.append({
            "role": role,
            "price": _f(t.get("price")),
            "planned_reduction_pct": round(weights[role] * 100.0, 1),
            "planned_remaining_after_pct": round(100.0 - sum(weights[x] * 100.0 for x in ("TP1", "TP2", "TP3", "RUNNER")[:idx]), 1),
            "horizon": horizon,
            "reachability": reach,
            "evidence_quality": t.get("evidence_quality"),
            "sources": t.get("sources"),
            "timeframes": t.get("timeframes"),
        })

    mgmt = _management_state(reference_price, side, raw_targets, thesis_invalidation)
    durability = _macro_durability(strategic)
    review = {
        "normal_review_cadence": "daily_after_D1_close_plus_weekly_after_W1_close",
        "event_driven_reviews": [
            "high_impact_US_macro_window",
            "FOMC_or_Fed_regime_shift",
            "D1_structure_break_or_reclaim",
            "W1_structure_change",
            "material_volatility_regime_change",
            "target_cluster_reached",
            "entry_or_thesis_invalidation_test",
        ],
        "do_not_react_to": ["isolated_M5_noise", "single_intraday_wick_without_D1_confirmation"],
    }

    return {
        "valid": True,
        "engine": EXIT_ENGINE_VERSION,
        "philosophy": "manage_one_30_60_day_spot_thesis_with_staged_realization_not_more_targets",
        "side": side,
        "reference_price": round(reference_price, 6),
        "management_state": mgmt,
        "allocation_policy": {
            "basis": "adaptive_to_trend_maturity_and_macro_durability",
            "initial_position_pct": 100.0,
            "stage_weights_pct": {k: round(v * 100.0, 1) for k, v in weights.items()},
            "macro_trend_durability_score": round(durability, 2),
            "note": "Percentages describe paper position-management intent, not automatic broker orders.",
        },
        "stages": stages,
        "risk_management": {
            "entry_invalidation_is_not_thesis_invalidation": True,
            "thesis_invalidation": dict(thesis_invalidation),
            "after_tp1": "do_not_mechanically_move_stop_to_breakeven; re-anchor only if D1 structure confirms a higher support regime",
            "after_tp2": "protect realized gains while preserving core exposure toward TP3; use D1/W1 structure, not intraday noise",
            "after_tp3": "strategic objective achieved; retain only runner allocation while W1/MN1 thesis remains intact",
            "runner_exit": "exit/reassess on runner objective, W1 thesis break, macro-regime reversal, or monthly structural exhaustion",
        },
        "review_protocol": review,
        "semantic_rules": {
            "targets_are_objectives_not_orders": True,
            "reachability_is_not_empirical_probability": True,
            "no_automatic_stop_ratchet_from_intraday_noise": True,
            "tp3_is_primary_30_60_day_objective": True,
            "runner_is_optional_not_required": True,
        },
    }
