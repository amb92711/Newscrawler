from __future__ import annotations

"""Institutional pullback / cool-off resolution engine for XAUUSD spot.

The engine answers a narrow question that the generic overextension flag cannot:
has a bullish 30-60 day thesis cooled off enough to permit a high-quality spot
entry without confusing a healthy retracement with a broken thesis?

It is deliberately *not* a standalone signal generator.  It consumes the existing
HTF thesis, execution zone, timing layer and market structure and returns a bounded
quality score plus explicit hard-fail / soft-wait semantics.  The caller remains
responsible for macro, market-state, spread, data-quality and conviction gates.
"""

from typing import Any, Dict, List, Mapping, Tuple
import math

PULLBACK_ENGINE_VERSION = "AMB_SPOT_PULLBACK_QUALITY_V1"


def _d(v: Any) -> Dict[str, Any]:
    return v if isinstance(v, dict) else {}


def _l(v: Any) -> List[Any]:
    return v if isinstance(v, list) else []


def _f(v: Any, default: float = 0.0) -> float:
    try:
        if v is None or v == "":
            return default
        x = float(v)
        return x if math.isfinite(x) else default
    except Exception:
        return default


def _s(v: Any) -> str:
    return str(v or "").strip().lower()


def _clamp(v: float, lo: float = 0.0, hi: float = 100.0) -> float:
    return max(lo, min(hi, float(v)))


def _tf(chart: Mapping[str, Any], name: str) -> Dict[str, Any]:
    return _d(_d(chart.get("timeframes")).get(name))


def _zone_bounds(zone: Mapping[str, Any]) -> Tuple[float, float]:
    level = _f(zone.get("level"))
    lo = _f(zone.get("low"), level)
    hi = _f(zone.get("high"), level)
    return (hi, lo) if hi < lo else (lo, hi)


def _reference(chart: Mapping[str, Any]) -> float:
    micro = _d(chart.get("market_microstructure"))
    return (
        _f(micro.get("best_ask"))
        or _f(micro.get("last"))
        or _f(_d(chart.get("trade_map")).get("reference_price"))
        or _f(_tf(chart, "M15").get("last_close"))
        or _f(_tf(chart, "H1").get("last_close"))
    )


def _atr(chart: Mapping[str, Any], tf: str, fallback: float = 1.0) -> float:
    return max(_f(_tf(chart, tf).get("atr"), fallback), 1e-9)


def _direction_sign(value: Any) -> int:
    s = _s(value)
    if "bull" in s or s in {"long", "buy_pressure"}:
        return 1
    if "bear" in s or s in {"short", "sell_pressure"}:
        return -1
    return 0


def _rsi_reset_score(ctx: Mapping[str, Any]) -> Dict[str, Any]:
    rsi = _f(ctx.get("rsi"), 50.0)
    if 48.0 <= rsi <= 68.0:
        score = 100.0
        state = "normalized_supportive"
    elif 68.0 < rsi <= 73.0:
        score = 78.0
        state = "warm_but_acceptable"
    elif 73.0 < rsi <= 78.0:
        score = 48.0
        state = "still_extended"
    elif rsi > 78.0:
        score = 18.0
        state = "extreme_overextension_persists"
    elif 42.0 <= rsi < 48.0:
        score = 72.0
        state = "deep_reset_watch_reclaim"
    elif 35.0 <= rsi < 42.0:
        score = 42.0
        state = "weak_reset_risk"
    else:
        score = 18.0
        state = "oversold_thesis_stress"
    return {"rsi": round(rsi, 3), "score_0_100": score, "state": state}


def _zscore_reset_score(ctx: Mapping[str, Any]) -> Dict[str, Any]:
    pa = _d(_d(ctx.get("advanced_indicators")).get("institutional_price_action"))
    z = abs(_f(pa.get("price_zscore_50")))
    if z <= 0.85:
        score = 100.0
        state = "statistically_reset"
    elif z <= 1.35:
        score = 82.0
        state = "mostly_reset"
    elif z <= 1.90:
        score = 58.0
        state = "partial_reset"
    elif z <= 2.40:
        score = 32.0
        state = "extended"
    else:
        score = 12.0
        state = "extreme_extension"
    return {"abs_price_zscore_50": round(z, 3), "score_0_100": score, "state": state}


def _volatility_reset_score(ctx: Mapping[str, Any]) -> Dict[str, Any]:
    reg = _d(_d(ctx.get("advanced_indicators")).get("regime_metrics"))
    vol = _f(reg.get("volatility_percentile"), 50.0)
    if 25.0 <= vol <= 78.0:
        score = 92.0
        state = "normal_to_constructive"
    elif 78.0 < vol <= 88.0:
        score = 70.0
        state = "elevated"
    elif 88.0 < vol <= 95.0:
        score = 42.0
        state = "high"
    elif vol > 95.0:
        score = 18.0
        state = "extreme"
    else:
        score = 75.0
        state = "compressed"
    return {"volatility_percentile": round(vol, 3), "score_0_100": score, "state": state}


def _structure_integrity(chart: Mapping[str, Any]) -> Dict[str, Any]:
    rows = []
    score = 0.0
    total = 0.0
    weights = {"D1": 4.0, "H4": 3.0, "H1": 1.6}
    hard_break = False
    for tf, w in weights.items():
        c = _tf(chart, tf)
        trend = _direction_sign(c.get("trend"))
        structure = _direction_sign(c.get("structure"))
        adv = _d(c.get("advanced_structure"))
        external = _direction_sign(_d(adv.get("external")).get("bias"))
        internal = _direction_sign(_d(adv.get("internal")).get("bias"))
        mss = _direction_sign(_d(adv.get("mss")).get("type"))
        cloud = int(max(-1, min(1, _f(_d(c.get("ichimoku")).get("cloud_bias"), 0))))
        local = 0.0
        local += trend * 0.28
        local += structure * 0.28
        local += external * 0.20
        local += internal * 0.08
        local += mss * 0.09
        local += cloud * 0.07
        local = max(-1.0, min(1.0, local))
        score += w * local
        total += w
        if tf in {"D1", "H4"} and structure < 0 and external < 0:
            hard_break = True
        rows.append({
            "timeframe": tf,
            "trend": c.get("trend"),
            "structure": c.get("structure"),
            "external_bias": _d(adv.get("external")).get("bias"),
            "internal_bias": _d(adv.get("internal")).get("bias"),
            "mss": _d(adv.get("mss")).get("type"),
            "cloud_bias": cloud,
            "integrity_unit": round(local, 3),
        })
    normalized = _clamp(50.0 + 50.0 * score / max(total, 1e-9))
    return {
        "score_0_100": round(normalized, 2),
        "hard_structure_break": hard_break,
        "details": rows,
        "state": "thesis_intact" if normalized >= 62 and not hard_break else "thesis_stressed" if normalized >= 45 and not hard_break else "thesis_break_risk",
    }


def _zone_interaction(chart: Mapping[str, Any], zone: Mapping[str, Any]) -> Dict[str, Any]:
    ref = _reference(chart)
    lo, hi = _zone_bounds(zone)
    atr = _atr(chart, "H1", 1.0)
    if lo <= 0 or hi <= 0:
        return {"score_0_100": 0.0, "relation": "NO_ZONE", "distance_atr": None}
    if lo <= ref <= hi:
        relation = "INSIDE_ZONE"
        distance = 0.0
        score = 100.0
    elif ref > hi:
        relation = "ABOVE_ZONE"
        distance = ref - hi
        da = distance / atr
        if da <= 0.20:
            score = 84.0
        elif da <= 0.50:
            score = 68.0
        elif da <= 0.90:
            score = 46.0
        elif da <= 1.60:
            score = 26.0
        else:
            score = 10.0
    else:
        relation = "BELOW_ZONE"
        distance = lo - ref
        da = distance / atr
        if da <= 0.18:
            score = 66.0
        elif da <= 0.45:
            score = 42.0
        else:
            score = 16.0
    return {
        "score_0_100": round(score, 2),
        "relation": relation,
        "reference_price": round(ref, 6),
        "zone_low": round(lo, 6),
        "zone_high": round(hi, 6),
        "distance": round(distance, 6),
        "distance_atr": round(distance / atr, 3),
    }


def _liquidity_rejection_score(chart: Mapping[str, Any]) -> Dict[str, Any]:
    evidence: List[Dict[str, Any]] = []
    score = 35.0
    for tf, weight in (("H1", 1.0), ("M15", 0.65)):
        c = _tf(chart, tf)
        sweeps = [x for x in _l(_d(c.get("liquidity")).get("sweeps")) if isinstance(x, dict)]
        last = sweeps[-6:]
        sell_sweeps = [x for x in last if _s(x.get("type")).startswith("sell_side_sweep")]
        buy_sweeps = [x for x in last if _s(x.get("type")).startswith("buy_side_sweep")]
        if sell_sweeps:
            pts = 30.0 * weight
            score += pts
            evidence.append({"timeframe": tf, "kind": "sell_side_sweep_rejection", "count": len(sell_sweeps), "points": round(pts, 2)})
        if buy_sweeps:
            pts = 15.0 * weight
            score -= pts
            evidence.append({"timeframe": tf, "kind": "buy_side_sweep_adverse", "count": len(buy_sweeps), "points": round(-pts, 2)})
        pa = _d(c.get("price_action"))
        candle = _d(pa.get("last_candle"))
        if candle.get("bullish_pinbar") or candle.get("bullish_engulfing"):
            pts = 18.0 * weight
            score += pts
            evidence.append({"timeframe": tf, "kind": "bullish_rejection_candle", "points": round(pts, 2)})
        if candle.get("bearish_pinbar") or candle.get("bearish_engulfing"):
            pts = 10.0 * weight
            score -= pts
            evidence.append({"timeframe": tf, "kind": "bearish_rejection_candle", "points": round(-pts, 2)})
    return {
        "score_0_100": round(_clamp(score), 2),
        "evidence": evidence,
        "state": "confirmed_rejection" if score >= 70 else "constructive" if score >= 52 else "unconfirmed" if score >= 35 else "adverse",
    }


def _timing_recovery(chart: Mapping[str, Any], timing: Mapping[str, Any]) -> Dict[str, Any]:
    h1 = _tf(chart, "H1")
    m15 = _tf(chart, "M15")
    h1_sign = _direction_sign(h1.get("momentum")) + _direction_sign(_d(h1.get("advanced_structure")).get("mss", {}).get("type"))
    m15_sign = _direction_sign(m15.get("momentum")) + _direction_sign(_d(m15.get("advanced_structure")).get("mss", {}).get("type"))
    base = _f(timing.get("score_0_100"), 50.0)
    bonus = 0.0
    if h1_sign > 0:
        bonus += 7.0
    if m15_sign > 0:
        bonus += 7.0
    if h1_sign < 0:
        bonus -= 8.0
    if m15_sign < 0:
        bonus -= 8.0
    score = _clamp(base + bonus)
    return {
        "score_0_100": round(score, 2),
        "base_timing_score": round(base, 2),
        "h1_recovery_sign": h1_sign,
        "m15_recovery_sign": m15_sign,
        "state": "recovery_confirmed" if score >= 68 else "recovering" if score >= 55 else "not_recovered",
    }


def _avwap_reset(chart: Mapping[str, Any]) -> Dict[str, Any]:
    vals = []
    details = []
    for tf, weight in (("H4", 1.0), ("H1", 0.8)):
        c = _tf(chart, tf)
        av = _d(_d(c.get("advanced_indicators")).get("anchored_vwap"))
        dlo = _f(av.get("low_distance_atr"), 0.0)
        dhi = _f(av.get("high_distance_atr"), 0.0)
        # Ideal long cool-off: price not far above both AVWAP anchors, but not decisively below both.
        avg = (dlo + dhi) / 2.0
        if -0.35 <= avg <= 0.75:
            local = 92.0
        elif 0.75 < avg <= 1.35:
            local = 68.0
        elif 1.35 < avg <= 2.0:
            local = 40.0
        elif avg > 2.0:
            local = 18.0
        elif -0.80 <= avg < -0.35:
            local = 58.0
        else:
            local = 24.0
        vals.append((local, weight))
        details.append({"timeframe": tf, "low_distance_atr": round(dlo, 3), "high_distance_atr": round(dhi, 3), "mean_distance_atr": round(avg, 3), "score": local})
    score = sum(v * w for v, w in vals) / max(sum(w for _, w in vals), 1e-9) if vals else 50.0
    return {"score_0_100": round(score, 2), "details": details}


def build_pullback_quality(
    *,
    chart: Mapping[str, Any],
    plan: Mapping[str, Any],
    timing: Mapping[str, Any],
    maturity: Mapping[str, Any],
    htf: Mapping[str, Any],
    macro: Mapping[str, Any],
) -> Dict[str, Any]:
    zone = _d(plan.get("primary_zone"))
    zone_state = _zone_interaction(chart, zone)
    h4_rsi = _rsi_reset_score(_tf(chart, "H4"))
    h1_rsi = _rsi_reset_score(_tf(chart, "H1"))
    d1_rsi = _rsi_reset_score(_tf(chart, "D1"))
    h4_z = _zscore_reset_score(_tf(chart, "H4"))
    h1_z = _zscore_reset_score(_tf(chart, "H1"))
    h4_vol = _volatility_reset_score(_tf(chart, "H4"))
    h1_vol = _volatility_reset_score(_tf(chart, "H1"))
    structure = _structure_integrity(chart)
    rejection = _liquidity_rejection_score(chart)
    recovery = _timing_recovery(chart, timing)
    avwap = _avwap_reset(chart)

    reset_score = (
        h4_rsi["score_0_100"] * 0.17
        + h1_rsi["score_0_100"] * 0.13
        + d1_rsi["score_0_100"] * 0.06
        + h4_z["score_0_100"] * 0.12
        + h1_z["score_0_100"] * 0.08
        + h4_vol["score_0_100"] * 0.07
        + h1_vol["score_0_100"] * 0.05
        + avwap["score_0_100"] * 0.10
        + zone_state["score_0_100"] * 0.22
    )
    confirmation_score = (
        structure["score_0_100"] * 0.42
        + recovery["score_0_100"] * 0.33
        + rejection["score_0_100"] * 0.25
    )
    # Cool-off is useful only if both dimensions exist: enough reset AND intact/recovering thesis.
    harmonic = 0.0
    if reset_score > 0 and confirmation_score > 0:
        harmonic = 2.0 * reset_score * confirmation_score / (reset_score + confirmation_score)

    macro_bias = _s(macro.get("bias"))
    macro_conflict_penalty = 12.0 if macro_bias in {"bearish", "short"} else 0.0
    htf_score = _f(htf.get("score_0_100"), 50.0)
    htf_penalty = max(0.0, 58.0 - htf_score) * 0.8
    quality = _clamp(harmonic - macro_conflict_penalty - htf_penalty)

    hard_fail_reasons: List[str] = []
    if structure.get("hard_structure_break"):
        hard_fail_reasons.append("D1_or_H4_external_structure_broken")
    if macro_bias in {"bearish", "short"} and _f(macro.get("confidence"), 0.0) >= 65.0:
        hard_fail_reasons.append("macro_materially_opposes_long_thesis")
    thesis_inv = _d(plan.get("thesis_invalidation"))
    thesis_px = _f(thesis_inv.get("price"))
    ref = _reference(chart)
    if thesis_px > 0 and ref <= thesis_px:
        hard_fail_reasons.append("price_at_or_below_thesis_invalidation")

    inside = zone_state.get("relation") == "INSIDE_ZONE"
    near = zone_state.get("relation") == "ABOVE_ZONE" and _f(zone_state.get("distance_atr"), 99.0) <= 0.35
    recovery_confirmed = _f(recovery.get("score_0_100")) >= 64.0
    structure_ok = _f(structure.get("score_0_100")) >= 62.0 and not hard_fail_reasons
    rejection_ok = _f(rejection.get("score_0_100")) >= 50.0

    if hard_fail_reasons:
        state = "THESIS_RISK_BLOCKED"
        permission = "BLOCK"
    elif quality >= 72.0 and inside and recovery_confirmed and structure_ok:
        state = "COOL_OFF_RESOLVED_ENTRY_READY"
        permission = "ENTRY_READY"
    elif quality >= 66.0 and (inside or near) and recovery_confirmed and structure_ok:
        state = "COOL_OFF_RESOLVED_ENTRY_ARMED"
        permission = "ENTRY_ARMED"
    elif quality >= 58.0 and structure_ok:
        state = "COOL_OFF_PROGRESSING"
        permission = "WATCH"
    elif quality >= 45.0:
        state = "COOL_OFF_INCOMPLETE"
        permission = "WAIT"
    else:
        state = "OVEREXTENSION_PERSISTS"
        permission = "WAIT"

    reasons: List[str] = []
    reasons.append(f"reset_score={reset_score:.2f}")
    reasons.append(f"confirmation_score={confirmation_score:.2f}")
    reasons.append(f"zone_relation={zone_state.get('relation')} distance_atr={zone_state.get('distance_atr')}")
    reasons.append(f"structure_integrity={structure.get('score_0_100')}")
    reasons.append(f"timing_recovery={recovery.get('score_0_100')}")
    reasons.append(f"liquidity_rejection={rejection.get('score_0_100')}")
    if _s(maturity.get("phase")) == "late_extended":
        reasons.append("late_extended_requires_cool_off_confirmation")
    if rejection_ok:
        reasons.append("rejection_or_sweep_evidence_constructive")
    reasons.extend(hard_fail_reasons)

    return {
        "engine": PULLBACK_ENGINE_VERSION,
        "quality_score_0_100": round(quality, 2),
        "reset_score_0_100": round(reset_score, 2),
        "confirmation_score_0_100": round(confirmation_score, 2),
        "state": state,
        "permission": permission,
        "cool_off_resolved": state in {"COOL_OFF_RESOLVED_ENTRY_READY", "COOL_OFF_RESOLVED_ENTRY_ARMED"},
        "entry_ready": state == "COOL_OFF_RESOLVED_ENTRY_READY",
        "entry_armed": state in {"COOL_OFF_RESOLVED_ENTRY_READY", "COOL_OFF_RESOLVED_ENTRY_ARMED"},
        "hard_fail": bool(hard_fail_reasons),
        "hard_fail_reasons": hard_fail_reasons,
        "zone_interaction": zone_state,
        "overextension_reset": {
            "D1_rsi": d1_rsi,
            "H4_rsi": h4_rsi,
            "H1_rsi": h1_rsi,
            "H4_zscore": h4_z,
            "H1_zscore": h1_z,
            "H4_volatility": h4_vol,
            "H1_volatility": h1_vol,
            "anchored_vwap_reset": avwap,
        },
        "thesis_integrity": structure,
        "timing_recovery": recovery,
        "liquidity_rejection": rejection,
        "guardrails": {
            "does_not_override_market_or_event_gates": True,
            "cannot_arm_entry_if_D1_H4_structure_is_broken": True,
            "requires_zone_proximity_for_entry_arm": True,
            "late_extended_is_not_an_automatic_block": True,
            "intraday_noise_cannot_invalidate_D1_W1_thesis": True,
        },
        "reasons": reasons,
        "semantics": "cool_off_quality_for_spot_entry_timing_not_empirical_probability",
    }
