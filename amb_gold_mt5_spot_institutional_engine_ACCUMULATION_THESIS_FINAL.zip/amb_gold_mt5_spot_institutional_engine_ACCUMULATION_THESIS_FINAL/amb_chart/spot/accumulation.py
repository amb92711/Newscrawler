from __future__ import annotations

"""Adaptive 30-60 day spot accumulation engine.

The engine keeps the original structural entry ladder intact and produces a separate,
context-aware allocation policy.  It intentionally does not require a scalp-grade
M5/M15 trigger.  New buying requires value-zone interaction, slow-thesis health and
falling-knife safety; H1/M15 timing only modulates allocation aggressiveness.
"""

from typing import Any, Dict, List, Mapping, Optional
import math

ACCUMULATION_ENGINE_VERSION = "AMB_SPOT_ADAPTIVE_ACCUMULATION_V1"


def _d(v: Any) -> Dict[str, Any]: return v if isinstance(v, dict) else {}
def _l(v: Any) -> List[Any]: return v if isinstance(v, list) else []
def _f(v: Any, default: float = 0.0) -> float:
    try:
        x = float(v); return x if math.isfinite(x) else default
    except Exception: return default
def _s(v: Any) -> str: return str(v or "").strip().lower()
def _clamp(v: float) -> float: return max(0.0, min(100.0, float(v)))


def _normalize(vals: List[float]) -> List[float]:
    vals = [max(0.0, float(x)) for x in vals]
    s = sum(vals)
    if s <= 1e-9:
        return [0.0 for _ in vals]
    rounded = [round(v / s * 100.0, 2) for v in vals]
    drift = round(100.0 - sum(rounded), 2)
    if rounded:
        rounded[-1] = round(rounded[-1] + drift, 2)
    return rounded


def _dynamic_weights(
    *,
    thesis: Mapping[str, Any],
    falling: Mapping[str, Any],
    pullback: Mapping[str, Any],
    macro: Mapping[str, Any],
    valuation: Mapping[str, Any],
    maturity: Mapping[str, Any],
) -> Dict[str, Any]:
    health = _f(thesis.get("health_score_0_100"), 50.0)
    knife = _f(falling.get("risk_score_0_100"), 50.0)
    pb = _f(pullback.get("quality_score_0_100"), 50.0)
    macro_score = _f(macro.get("score_0_100"), 50.0)
    zone = _s(valuation.get("valuation_zone"))
    phase = _s(maturity.get("phase"))

    # Baseline is the existing 30/40/30 ladder.  Adjustments alter sizing only,
    # never the supplied structural prices.
    raw = [30.0, 40.0, 30.0]
    reasons: List[str] = []
    if phase == "late_extended" or knife >= 42:
        raw[0] -= 8.0; raw[2] += 8.0
        reasons.append("favor_deeper_tranche_due_extension_or_downside_risk")
    if health >= 80 and pb >= 68 and knife < 32:
        raw[0] += 7.0; raw[2] -= 5.0; raw[1] -= 2.0
        reasons.append("strong_thesis_and_orderly_pullback_allow_more_upper_zone_size")
    if macro_score < 50:
        raw[0] -= 5.0; raw[2] += 5.0
        reasons.append("macro_not_confirming_shift_size_deeper")
    elif macro_score >= 70:
        raw[0] += 3.0; raw[1] += 2.0; raw[2] -= 5.0
        reasons.append("macro_supportive")
    if zone == "premium":
        raw[0] -= 7.0; raw[2] += 7.0
        reasons.append("premium_valuation_prefers_deeper_accumulation")
    elif zone == "discount":
        raw[0] += 5.0; raw[2] -= 5.0
        reasons.append("discount_valuation_allows_earlier_accumulation")
    weights = _normalize(raw)
    return {"weights_pct": weights, "reasons": reasons}


def build_accumulation_plan(
    *,
    chart: Mapping[str, Any],
    plan: Mapping[str, Any],
    pullback: Mapping[str, Any],
    falling_knife: Mapping[str, Any],
    thesis_health: Mapping[str, Any],
    macro: Mapping[str, Any],
    valuation: Mapping[str, Any],
    maturity: Mapping[str, Any],
    position_record: Optional[Mapping[str, Any]] = None,
) -> Dict[str, Any]:
    ladder = [dict(x) for x in _l(plan.get("entry_ladder")) if isinstance(x, dict)]
    if not bool(plan.get("valid")) or len(ladder) < 1:
        return {"engine": ACCUMULATION_ENGINE_VERSION, "valid": False, "state": "NO_VALID_SPOT_PLAN", "permission": "NONE", "tranches": []}

    ref = _f(_d(chart.get("market_microstructure")).get("best_ask")) or _f(_d(chart.get("trade_map")).get("reference_price"))
    h1 = _d(_d(chart.get("timeframes")).get("H1"))
    atr = max(_f(h1.get("atr"), 1.0), 1e-9)
    zone = _d(plan.get("primary_zone"))
    lo = _f(zone.get("low")); hi = _f(zone.get("high"))
    if hi < lo: lo, hi = hi, lo
    tolerance = atr * 0.08

    dyn = _dynamic_weights(thesis=thesis_health, falling=falling_knife, pullback=pullback, macro=macro, valuation=valuation, maturity=maturity)
    weights = dyn["weights_pct"]
    health = _f(thesis_health.get("health_score_0_100"), 0.0)
    knife = _f(falling_knife.get("risk_score_0_100"), 100.0)
    pb = _f(pullback.get("quality_score_0_100"), 0.0)
    macro_block = bool(macro.get("spot_blocks_trade"))
    hard_block = bool(thesis_health.get("hard_fail")) or bool(falling_knife.get("hard_fail")) or macro_block

    position = _d(position_record)
    fills = [x for x in _l(position.get("accumulation_fills")) if isinstance(x, dict)]
    filled_ids = {int(_f(x.get("tranche"))) for x in fills if _f(x.get("tranche")) > 0}
    accumulated_pct = _f(position.get("accumulated_pct"), 100.0 if position and not fills else 0.0)

    tranche_rows: List[Dict[str, Any]] = []
    eligible: List[int] = []
    for idx, row in enumerate(ladder, start=1):
        px = _f(row.get("price"))
        # A tranche becomes price-eligible when ask reaches its level within a small
        # H1-ATR tolerance.  Deeper prints can make multiple earlier tranches eligible.
        price_eligible = px > 0 and ref <= px + tolerance and ref >= max(_f(_d(plan.get("thesis_invalidation")).get("price")), 0.0)
        already = idx in filled_ids
        if price_eligible and not already:
            eligible.append(idx)
        tranche_rows.append({
            "tranche": idx,
            "price": round(px, 6),
            "original_allocation_pct": round(_f(row.get("allocation_weight")) * 100.0, 2),
            "adaptive_allocation_pct": weights[idx - 1] if idx - 1 < len(weights) else 0.0,
            "price_eligible_now": bool(price_eligible),
            "already_filled": already,
            "distance_from_reference": round(px - ref, 6),
            "distance_atr": round((px - ref) / atr, 3),
        })

    inside_or_near = (lo - tolerance <= ref <= hi + tolerance) if lo > 0 and hi > 0 else False
    safe = not hard_block and knife < 62 and health >= 55
    minimum_quality = pb >= 48 or inside_or_near

    # Maximum cumulative size permitted by current quality.  This makes spot entry
    # gradual without requiring scalp-grade confirmation.
    if not safe:
        max_cumulative = accumulated_pct
    elif health >= 80 and knife < 32 and pb >= 68:
        max_cumulative = 100.0
    elif health >= 68 and knife < 45 and pb >= 56:
        max_cumulative = 75.0
    else:
        max_cumulative = 45.0

    cumulative_eligible = sum(tranche_rows[i - 1]["adaptive_allocation_pct"] for i in eligible)
    available_add = max(0.0, min(100.0 - accumulated_pct, max_cumulative - accumulated_pct, cumulative_eligible))

    if hard_block or knife >= 78 or health < 42:
        state = "BLOCKED_FALLING_KNIFE_OR_THESIS"
        permission = "BLOCK"
    elif 62 <= knife < 78 or 42 <= health < 55:
        state = "PAUSE_ACCUMULATION"
        permission = "PAUSE"
    elif not inside_or_near and not eligible:
        state = "WATCH_ACCUMULATION_ZONE"
        permission = "WATCH"
    elif not minimum_quality:
        state = "ACCUMULATION_ARMED_WAIT_QUALITY"
        permission = "ARMED"
    elif eligible and available_add > 0:
        state = "ACCUMULATE_" + "_".join(f"T{i}" for i in eligible)
        permission = "ACCUMULATE"
    elif position and accumulated_pct >= 99.0:
        state = "ACCUMULATION_COMPLETE"
        permission = "HOLD"
    else:
        state = "ACCUMULATION_ARMED"
        permission = "ARMED"

    return {
        "engine": ACCUMULATION_ENGINE_VERSION,
        "valid": True,
        "state": state,
        "permission": permission,
        "actionable_accumulation_now": permission == "ACCUMULATE",
        "reference_price": round(ref, 6),
        "zone": {"low": lo, "high": hi, "tolerance_h1_atr": round(tolerance, 6)},
        "adaptive_ladder": tranche_rows,
        "eligible_tranches_now": eligible,
        "recommended_new_allocation_pct_now": round(available_add, 2),
        "max_cumulative_allocation_pct_current_conditions": round(max_cumulative, 2),
        "accumulated_pct_registry": round(accumulated_pct, 2),
        "remaining_unaccumulated_pct": round(max(0.0, 100.0 - accumulated_pct), 2),
        "actual_cost_basis": position.get("actual_cost_basis") or position.get("entry_price"),
        "dynamic_allocation": dyn,
        "inputs": {
            "thesis_health_0_100": round(health, 2),
            "falling_knife_risk_0_100": round(knife, 2),
            "pullback_quality_0_100": round(pb, 2),
            "macro_score_0_100": round(_f(macro.get("score_0_100"), 50.0), 2),
            "valuation_zone": valuation.get("valuation_zone"),
            "trend_maturity": maturity.get("phase"),
        },
        "guardrails": {
            "does_not_require_scalp_trigger": True,
            "M15_H1_only_modulate_quality_not_slow_thesis": True,
            "falling_knife_can_pause_new_adds": True,
            "thesis_invalidation_blocks_new_adds": True,
            "structural_entry_prices_are_not_modified": True,
            "paper_only_no_MT5_order_sent": True,
        },
        "semantics": "adaptive_spot_accumulation_policy_not_order_execution",
    }
