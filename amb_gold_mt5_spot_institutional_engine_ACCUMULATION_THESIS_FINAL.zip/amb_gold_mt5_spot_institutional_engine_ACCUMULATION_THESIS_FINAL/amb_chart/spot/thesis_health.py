from __future__ import annotations

"""Slow thesis-health engine for 30-60 day XAUUSD spot positions."""

from typing import Any, Dict, List, Mapping, Optional
import math

THESIS_HEALTH_ENGINE_VERSION = "AMB_SPOT_THESIS_HEALTH_V1"


def _d(v: Any) -> Dict[str, Any]: return v if isinstance(v, dict) else {}
def _f(v: Any, default: float = 0.0) -> float:
    try:
        x = float(v); return x if math.isfinite(x) else default
    except Exception: return default
def _s(v: Any) -> str: return str(v or "").strip().lower()
def _clamp(v: float) -> float: return max(0.0, min(100.0, float(v)))
def _tf(chart: Mapping[str, Any], name: str) -> Dict[str, Any]: return _d(_d(chart.get("timeframes")).get(name))
def _bear(v: Any) -> bool:
    s = _s(v); return "bear" in s or s == "short"
def _bull(v: Any) -> bool:
    s = _s(v); return "bull" in s or s == "long"


def _slow_structure(chart: Mapping[str, Any]) -> Dict[str, Any]:
    weights = {"MN1": 0.16, "W1": 0.28, "D1": 0.34, "H4": 0.22}
    total = 0.0
    details = {}
    hard = []
    for tf, w in weights.items():
        c = _tf(chart, tf)
        adv = _d(c.get("advanced_structure"))
        ext = _d(adv.get("external"))
        mss = _d(adv.get("mss"))
        score = 50.0
        score += 16 if _bull(c.get("trend")) else -16 if _bear(c.get("trend")) else 0
        score += 17 if _bull(c.get("structure")) else -17 if _bear(c.get("structure")) else 0
        score += 12 if _bull(ext.get("bias")) else -12 if _bear(ext.get("bias")) else 0
        score += 7 if _bull(mss.get("type")) else -7 if _bear(mss.get("type")) else 0
        cloud = _f(_d(c.get("ichimoku")).get("cloud_bias"))
        score += 6 if cloud > 0 else -6 if cloud < 0 else 0
        score = _clamp(score)
        total += score * w
        if tf in {"W1", "D1"} and _bear(c.get("structure")) and _bear(ext.get("bias")):
            hard.append(f"{tf}_slow_structure_break")
        details[tf] = {"score_0_100": round(score, 2), "trend": c.get("trend"), "structure": c.get("structure"), "external_bias": ext.get("bias"), "mss": mss.get("type")}
    return {"score_0_100": round(total, 2), "details": details, "hard_fail_reasons": hard}


def _quality(chart: Mapping[str, Any]) -> Dict[str, Any]:
    vals = []
    details = {}
    for tf, w in (("W1", 0.35), ("D1", 0.40), ("H4", 0.25)):
        c = _tf(chart, tf)
        ai = _d(c.get("advanced_indicators"))
        tq = _d(ai.get("trend_quality"))
        flow = _d(ai.get("volume_flow"))
        pa = _d(ai.get("institutional_price_action"))
        adx = _f(c.get("adx"), 20.0)
        er = _f(tq.get("efficiency_ratio_10"), 0.35)
        chop = _f(tq.get("choppiness_14"), 50.0)
        cmf = _f(flow.get("cmf_20"), 0.0)
        impulse = _f(pa.get("institutional_impulse_score"), 0.0)
        local = 50.0 + min(18.0, max(-12.0, (adx - 20.0) * 0.8)) + (er - 0.35) * 35.0 - max(0.0, chop - 55.0) * 0.7 + cmf * 35.0 + max(-8.0, min(8.0, impulse * 2.0))
        local = _clamp(local)
        vals.append(local * w)
        details[tf] = {"score_0_100": round(local, 2), "adx": round(adx, 2), "efficiency_ratio": round(er, 3), "choppiness": round(chop, 2), "cmf": round(cmf, 3), "institutional_impulse": round(impulse, 3)}
    return {"score_0_100": round(sum(vals), 2), "details": details}


def build_thesis_health(
    *,
    chart: Mapping[str, Any],
    htf: Mapping[str, Any],
    macro: Mapping[str, Any],
    strategic: Mapping[str, Any],
    maturity: Mapping[str, Any],
    valuation: Mapping[str, Any],
    position_record: Optional[Mapping[str, Any]] = None,
) -> Dict[str, Any]:
    structural = _slow_structure(chart)
    quality = _quality(chart)
    macro_score = _f(macro.get("score_0_100"), 50.0)
    macro_conf = _f(macro.get("confidence"), 50.0)
    durability = _f(_d(strategic.get("one_month_outlook")).get("macro_trend_durability_score"), macro_score)
    macro_component = _clamp(macro_score * 0.58 + durability * 0.32 + macro_conf * 0.10)
    htf_score = _f(htf.get("score_0_100"), 50.0)

    valuation_zone = _s(valuation.get("valuation_zone"))
    valuation_component = 72.0 if valuation_zone == "discount" else 62.0 if valuation_zone == "equilibrium" else 48.0
    phase = _s(maturity.get("phase"))
    maturity_component = 78.0 if phase in {"healthy_trend", "developing_trend"} else 60.0 if phase in {"late_extended", "transition"} else 48.0

    score = structural["score_0_100"] * 0.38 + htf_score * 0.18 + macro_component * 0.20 + quality["score_0_100"] * 0.14 + valuation_component * 0.05 + maturity_component * 0.05
    hard = list(structural.get("hard_fail_reasons") or [])
    ref = _f(_d(chart.get("market_microstructure")).get("best_ask")) or _f(_d(chart.get("trade_map")).get("reference_price"))
    thesis_px = _f(_d(strategic.get("thesis_invalidation")).get("price"))
    if thesis_px > 0 and ref <= thesis_px:
        hard.append("price_below_thesis_invalidation")
    if bool(macro.get("spot_blocks_trade")) and _s(macro.get("event_risk")) in {"high", "critical"}:
        # Event windows block new buying but do not by themselves kill an existing slow thesis.
        event_pause = True
    else:
        event_pause = False

    if hard:
        state = "INVALIDATED"
        action = "EXIT_THESIS_REVIEW"
        score = min(score, 24.0)
    elif score >= 80:
        state = "STRONG"
        action = "HOLD_CORE_ALLOW_ACCUMULATION"
    elif score >= 68:
        state = "HEALTHY"
        action = "HOLD_CORE_ALLOW_ACCUMULATION"
    elif score >= 55:
        state = "WATCH"
        action = "HOLD_CORE_PAUSE_AGGRESSIVE_ADDS"
    elif score >= 42:
        state = "DETERIORATING"
        action = "PAUSE_ACCUMULATION_REVIEW_D1_W1"
    else:
        state = "CRITICAL"
        action = "DE_RISK_OR_EXIT_ON_SLOW_CONFIRMATION"

    if event_pause and state not in {"INVALIDATED", "CRITICAL"}:
        action = "HOLD_EXISTING_PAUSE_NEW_ACCUMULATION_EVENT_WINDOW"

    position = _d(position_record)
    entry_snapshot = _d(position.get("entry_snapshot"))
    entry_health = _f(entry_snapshot.get("thesis_health_score"), score)
    delta_from_entry = score - entry_health if position else 0.0

    return {
        "engine": THESIS_HEALTH_ENGINE_VERSION,
        "health_score_0_100": round(_clamp(score), 2),
        "state": state,
        "management_action": action,
        "hard_fail": bool(hard),
        "hard_fail_reasons": hard,
        "event_pause_new_accumulation": event_pause,
        "components": {
            "slow_structure": structural,
            "higher_timeframe_consensus": round(htf_score, 2),
            "macro_durability": round(macro_component, 2),
            "trend_quality": quality,
            "valuation": {"zone": valuation.get("valuation_zone"), "score_0_100": valuation_component},
            "maturity": {"phase": maturity.get("phase"), "score_0_100": maturity_component},
        },
        "position_comparison": {
            "position_registered": bool(position),
            "health_at_entry": round(entry_health, 2) if position else None,
            "health_delta_from_entry": round(delta_from_entry, 2) if position else None,
        },
        "review_policy": {
            "canonical_clocks": ["D1_close", "W1_close"],
            "intraday_noise_does_not_flip_thesis": True,
            "macro_regime_reversal_requires_slow_confirmation_unless_hard_event_shock": True,
        },
        "semantics": "30_60d_thesis_health_score_not_empirical_win_probability",
    }
