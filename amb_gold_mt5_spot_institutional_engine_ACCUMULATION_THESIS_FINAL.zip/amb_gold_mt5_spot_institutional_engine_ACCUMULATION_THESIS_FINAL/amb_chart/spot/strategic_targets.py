from __future__ import annotations

"""Institutional 30-60 day target engine for XAUUSD spot analysis.

This module intentionally does not generate targets from arbitrary fixed R-multiples.
It discovers structural / liquidity / supply / volatility objectives from D1/W1/MN1,
clusters nearby evidence, scores each cluster, and then selects a tactical, swing and
strategic target.  R:R is a validation metric only.
"""

from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple
import math


TARGET_ENGINE_VERSION = "AMB_SPOT_STRATEGIC_TARGET_ENGINE_V2_30_60D"


@dataclass(frozen=True)
class TargetEvidence:
    price: float
    source: str
    timeframe: str
    base_score: float
    kind: str
    details: Dict[str, Any]


def _d(v: Any) -> Dict[str, Any]:
    return v if isinstance(v, dict) else {}


def _l(v: Any) -> List[Any]:
    return v if isinstance(v, list) else []


def _f(v: Any, default: float = 0.0) -> float:
    try:
        if v is None or v == "":
            return default
        x = float(v)
        return x if math.isfinite(x) else default
    except Exception:
        return default


def _s(v: Any) -> str:
    return str(v or "").strip().lower()


def _tf(chart: Mapping[str, Any], name: str) -> Dict[str, Any]:
    return _d(_d(chart.get("timeframes")).get(name))


def _atr(chart: Mapping[str, Any], tf: str, fallback: float = 1.0) -> float:
    return max(_f(_tf(chart, tf).get("atr"), fallback), 1e-9)


def _reference(chart: Mapping[str, Any]) -> float:
    micro = _d(chart.get("market_microstructure"))
    return (
        _f(micro.get("best_ask"))
        or _f(micro.get("last"))
        or _f(_d(chart.get("trade_map")).get("reference_price"))
        or _f(_tf(chart, "H1").get("last_close"))
    )


def _timeframe_score(tf: str) -> float:
    return {"MN1": 18.0, "W1": 14.0, "D1": 8.0, "H4": 3.0}.get(tf, 0.0)


def _source_score(source: str) -> float:
    return {
        "resistance": 72.0,
        "buy_side_liquidity": 78.0,
        "swing_high": 70.0,
        "bearish_order_block": 76.0,
        "volume_hvn": 58.0,
        "fib_extension_1.272": 66.0,
        "fib_extension_1.414": 70.0,
        "fib_extension_1.618": 76.0,
        "measured_move": 72.0,
        "weekly_volatility_projection": 52.0,
        "monthly_volatility_projection": 55.0,
    }.get(source, 50.0)


def _append(
    out: List[TargetEvidence],
    *,
    price: float,
    source: str,
    timeframe: str,
    kind: str,
    details: Optional[Dict[str, Any]] = None,
) -> None:
    if price <= 0 or not math.isfinite(price):
        return
    base = _source_score(source) + _timeframe_score(timeframe)
    out.append(
        TargetEvidence(
            price=float(price),
            source=source,
            timeframe=timeframe,
            base_score=base,
            kind=kind,
            details=dict(details or {}),
        )
    )


def _collect_structural_evidence(chart: Mapping[str, Any], entry: float, side: str) -> List[TargetEvidence]:
    out: List[TargetEvidence] = []
    for tf in ("D1", "W1", "MN1"):
        ctx = _tf(chart, tf)
        if not ctx:
            continue

        sr = _d(ctx.get("support_resistance"))
        structural = _l(sr.get("resistances" if side == "long" else "supports"))
        for p in structural:
            px = _f(p)
            if (side == "long" and px > entry) or (side == "short" and 0 < px < entry):
                _append(out, price=px, source="resistance" if side == "long" else "support", timeframe=tf, kind="structure")

        pools = _l(_d(ctx.get("liquidity")).get("pools"))
        for pool in pools:
            if not isinstance(pool, dict):
                continue
            typ = _s(pool.get("type"))
            px = _f(pool.get("level"))
            if side == "long" and typ == "bsl" and px > entry:
                _append(out, price=px, source="buy_side_liquidity", timeframe=tf, kind="liquidity", details={"touches": pool.get("touches"), "quality": pool.get("quality")})
            elif side == "short" and typ == "ssl" and 0 < px < entry:
                _append(out, price=px, source="sell_side_liquidity", timeframe=tf, kind="liquidity", details={"touches": pool.get("touches"), "quality": pool.get("quality")})

        swings = _d(ctx.get("swings"))
        arr = _l(swings.get("highs" if side == "long" else "lows"))
        for sw in arr[-16:]:
            if not isinstance(sw, dict):
                continue
            px = _f(sw.get("price"))
            if (side == "long" and px > entry) or (side == "short" and 0 < px < entry):
                _append(out, price=px, source="swing_high" if side == "long" else "swing_low", timeframe=tf, kind="swing", details={"time": sw.get("time"), "index": sw.get("index")})

        # Opposing higher-timeframe order blocks are meaningful supply/demand objectives.
        for ob in _l(ctx.get("order_blocks")):
            if not isinstance(ob, dict):
                continue
            typ = _s(ob.get("type"))
            status = _s(ob.get("status"))
            if status == "invalidated":
                continue
            lo, hi = _f(ob.get("low")), _f(ob.get("high"))
            if lo <= 0 or hi <= 0:
                continue
            px = (lo + hi) / 2.0
            if side == "long" and "bearish" in typ and px > entry:
                _append(out, price=px, source="bearish_order_block", timeframe=tf, kind="supply", details={"low": lo, "high": hi, "status": status, "score": ob.get("score")})
            elif side == "short" and "bullish" in typ and 0 < px < entry:
                _append(out, price=px, source="bullish_order_block", timeframe=tf, kind="demand", details={"low": lo, "high": hi, "status": status, "score": ob.get("score")})

        vp = _d(ctx.get("volume_profile"))
        for hvn in _l(vp.get("hvn"))[:8]:
            if not isinstance(hvn, dict):
                continue
            px = _f(hvn.get("level"))
            if (side == "long" and px > entry) or (side == "short" and 0 < px < entry):
                _append(out, price=px, source="volume_hvn", timeframe=tf, kind="volume_magnet", details={"share": hvn.get("share")})
    return out


def _dealing_range_extensions(valuation: Mapping[str, Any], side: str) -> List[TargetEvidence]:
    lo, hi = _f(valuation.get("low")), _f(valuation.get("high"))
    if lo <= 0 or hi <= lo:
        return []
    width = hi - lo
    out: List[TargetEvidence] = []
    if side == "long":
        for ratio in (1.272, 1.414, 1.618):
            px = hi + width * (ratio - 1.0)
            _append(out, price=px, source=f"fib_extension_{ratio:.3f}", timeframe="D1", kind="projection", details={"base_range_low": lo, "base_range_high": hi, "ratio": ratio})
    else:
        for ratio in (1.272, 1.414, 1.618):
            px = lo - width * (ratio - 1.0)
            if px > 0:
                _append(out, price=px, source=f"fib_extension_{ratio:.3f}", timeframe="D1", kind="projection", details={"base_range_low": lo, "base_range_high": hi, "ratio": ratio})
    return out


def _measured_move_evidence(chart: Mapping[str, Any], side: str) -> List[TargetEvidence]:
    out: List[TargetEvidence] = []
    for tf in ("D1", "W1"):
        ctx = _tf(chart, tf)
        swings = _d(ctx.get("swings"))
        highs = [x for x in _l(swings.get("highs")) if isinstance(x, dict) and _f(x.get("price")) > 0]
        lows = [x for x in _l(swings.get("lows")) if isinstance(x, dict) and _f(x.get("price")) > 0]
        if not highs or not lows:
            continue
        # Use the most recent completed impulse and subsequent pullback swing when possible.
        h = highs[-1]
        h_idx = int(_f(h.get("index"), -1))
        prior_lows = [x for x in lows if int(_f(x.get("index"), -1)) < h_idx]
        post_lows = [x for x in lows if int(_f(x.get("index"), -1)) > h_idx]
        if side == "long" and prior_lows:
            origin = prior_lows[-1]
            impulse = _f(h.get("price")) - _f(origin.get("price"))
            anchor = _f(post_lows[-1].get("price")) if post_lows else _f(h.get("price"))
            if impulse > 0:
                px = anchor + impulse
                _append(out, price=px, source="measured_move", timeframe=tf, kind="projection", details={"impulse": impulse, "origin": origin.get("price"), "anchor": anchor})
        elif side == "short" and highs:
            # Symmetric short measured move using latest low and prior high.
            low = lows[-1]
            l_idx = int(_f(low.get("index"), -1))
            prior_highs = [x for x in highs if int(_f(x.get("index"), -1)) < l_idx]
            post_highs = [x for x in highs if int(_f(x.get("index"), -1)) > l_idx]
            if prior_highs:
                origin = prior_highs[-1]
                impulse = _f(origin.get("price")) - _f(low.get("price"))
                anchor = _f(post_highs[-1].get("price")) if post_highs else _f(low.get("price"))
                px = anchor - impulse
                if impulse > 0 and px > 0:
                    _append(out, price=px, source="measured_move", timeframe=tf, kind="projection", details={"impulse": impulse, "origin": origin.get("price"), "anchor": anchor})
    return out


def _volatility_projection_evidence(chart: Mapping[str, Any], entry: float, side: str) -> List[TargetEvidence]:
    w_atr = _atr(chart, "W1", _atr(chart, "D1", 1.0) * math.sqrt(5.0))
    m_atr = _atr(chart, "MN1", w_atr * math.sqrt(4.2))
    out: List[TargetEvidence] = []
    direction = 1.0 if side == "long" else -1.0
    for mult in (0.75, 1.25, 1.75, 2.25):
        px = entry + direction * w_atr * mult
        if px > 0:
            _append(out, price=px, source="weekly_volatility_projection", timeframe="W1", kind="volatility_projection", details={"weekly_atr": w_atr, "multiple": mult})
    for mult in (0.5, 0.8, 1.1):
        px = entry + direction * m_atr * mult
        if px > 0:
            _append(out, price=px, source="monthly_volatility_projection", timeframe="MN1", kind="volatility_projection", details={"monthly_atr": m_atr, "multiple": mult})
    return out


def _cluster_evidence(evidence: Sequence[TargetEvidence], tolerance: float) -> List[Dict[str, Any]]:
    if not evidence:
        return []
    ordered = sorted(evidence, key=lambda x: x.price)
    clusters: List[List[TargetEvidence]] = []
    for ev in ordered:
        if not clusters:
            clusters.append([ev])
            continue
        center = sum(x.price * max(x.base_score, 1.0) for x in clusters[-1]) / sum(max(x.base_score, 1.0) for x in clusters[-1])
        if abs(ev.price - center) <= tolerance:
            clusters[-1].append(ev)
        else:
            clusters.append([ev])

    out: List[Dict[str, Any]] = []
    for group in clusters:
        weights = [max(x.base_score, 1.0) for x in group]
        center = sum(x.price * w for x, w in zip(group, weights)) / sum(weights)
        sources = sorted({x.source for x in group})
        timeframes = sorted({x.timeframe for x in group}, key=lambda x: {"H4": 0, "D1": 1, "W1": 2, "MN1": 3}.get(x, -1), reverse=True)
        kinds = sorted({x.kind for x in group})
        structural_count = sum(1 for x in group if x.kind in {"structure", "liquidity", "swing", "supply", "demand", "volume_magnet"})
        projection_count = len(group) - structural_count
        base = max(x.base_score for x in group)
        score = base + min(18.0, (len(sources) - 1) * 5.0) + min(12.0, (len(timeframes) - 1) * 4.0)
        if structural_count >= 2:
            score += 8.0
        if structural_count == 0:
            score -= 12.0
        out.append({
            "price": round(center, 6),
            "cluster_score": round(max(0.0, min(150.0, score)), 2),
            "evidence_count": len(group),
            "structural_evidence_count": structural_count,
            "projection_evidence_count": projection_count,
            "sources": sources,
            "timeframes": timeframes,
            "kinds": kinds,
            "evidence": [
                {
                    "price": round(x.price, 6),
                    "source": x.source,
                    "timeframe": x.timeframe,
                    "kind": x.kind,
                    "base_score": round(x.base_score, 2),
                    "details": x.details,
                }
                for x in group
            ],
        })
    return out


def _horizon_days(distance: float, weekly_atr: float, role: str) -> Dict[str, Any]:
    weekly_atr = max(weekly_atr, 1e-9)
    atr_weeks = distance / weekly_atr
    # This is an estimated travel window, not a promise. The role floor prevents
    # a nearby structural level from masquerading as a 30-60 day strategic target.
    empirical_days = atr_weeks * 5.0 / 0.70
    floors = {"TP1": (5, 15), "TP2": (12, 30), "TP3": (25, 60), "RUNNER": (35, 90)}
    lo, hi = floors.get(role, (5, 60))
    midpoint = max(float(lo), min(float(hi), empirical_days))
    spread = max(3.0, midpoint * 0.35)
    est_lo = max(lo, int(round(midpoint - spread)))
    est_hi = min(hi, int(round(midpoint + spread)))
    if est_hi <= est_lo:
        est_hi = min(hi, est_lo + 3)
    return {
        "estimated_trading_days": {"low": int(est_lo), "high": int(est_hi)},
        "estimated_calendar_horizon": {
            "low_days": int(round(est_lo * 7.0 / 5.0)),
            "high_days": int(round(est_hi * 7.0 / 5.0)),
        },
        "distance_weekly_atr": round(atr_weeks, 3),
        "semantics": "scenario_horizon_not_time_guarantee",
    }


def _role_fit(distance_watr: float, role: str) -> float:
    desired = {
        "TP1": (0.35, 1.10, 0.70),
        "TP2": (0.85, 2.00, 1.35),
        "TP3": (1.50, 3.50, 2.30),
        "RUNNER": (2.20, 5.50, 3.40),
    }[role]
    lo, hi, center = desired
    if distance_watr < lo:
        return max(0.0, 1.0 - (lo - distance_watr) / max(lo, 1e-9))
    if distance_watr > hi:
        return max(0.0, 1.0 - (distance_watr - hi) / max(hi, 1e-9))
    width = max(center - lo, hi - center, 1e-9)
    return max(0.55, 1.0 - abs(distance_watr - center) / width * 0.45)


def _choose_role_target(
    clusters: Sequence[Dict[str, Any]],
    *,
    role: str,
    side: str,
    entry: float,
    stop: float,
    reference: float,
    weekly_atr: float,
    previous_price: Optional[float],
) -> Optional[Dict[str, Any]]:
    risk = abs(entry - stop)
    if risk <= 0:
        return None
    # Do not publish a target already behind the live market when the plan is a pullback entry.
    live_floor = max(entry, reference) if side == "long" else min(entry, reference)
    min_rr = {"TP1": 1.20, "TP2": 2.00, "TP3": 3.00, "RUNNER": 4.00}[role]
    min_spacing = weekly_atr * {"TP1": 0.0, "TP2": 0.20, "TP3": 0.30, "RUNNER": 0.40}[role]
    candidates: List[Tuple[float, Dict[str, Any]]] = []

    for c in clusters:
        px = _f(c.get("price"))
        if side == "long":
            if px <= live_floor:
                continue
            if previous_price is not None and px <= previous_price + min_spacing:
                continue
            reward = px - entry
        else:
            if px <= 0 or px >= live_floor:
                continue
            if previous_price is not None and px >= previous_price - min_spacing:
                continue
            reward = entry - px
        rr = reward / risk
        if rr < min_rr:
            continue
        dist = abs(px - entry)
        watr = dist / max(weekly_atr, 1e-9)
        fit = _role_fit(watr, role)
        structural = int(_f(c.get("structural_evidence_count")))
        score = _f(c.get("cluster_score")) * fit
        score += min(16.0, structural * 4.0)
        # Prefer genuine structure over pure projections for the first three targets.
        if structural == 0 and role != "RUNNER":
            score -= 18.0
        candidates.append((score, dict(c)))

    if not candidates:
        return None
    candidates.sort(key=lambda x: x[0], reverse=True)
    score, best = candidates[0]
    px = _f(best.get("price"))
    rr = ((px - entry) if side == "long" else (entry - px)) / risk
    horizon = _horizon_days(abs(px - entry), weekly_atr, role)
    evidence_quality = "institutional_structural" if int(_f(best.get("structural_evidence_count"))) >= 2 else (
        "structural" if int(_f(best.get("structural_evidence_count"))) >= 1 else "projection_only"
    )
    return {
        "role": role,
        "price": round(px, 6),
        "rr": round(rr, 2),
        "selection_score": round(score, 2),
        "evidence_quality": evidence_quality,
        "sources": best.get("sources"),
        "timeframes": best.get("timeframes"),
        "evidence_count": best.get("evidence_count"),
        "structural_evidence_count": best.get("structural_evidence_count"),
        "cluster": best,
        "horizon": horizon,
    }


def _fallback_projection_target(
    evidence: Sequence[TargetEvidence],
    *,
    role: str,
    side: str,
    entry: float,
    stop: float,
    reference: float,
    weekly_atr: float,
    previous_price: Optional[float],
) -> Optional[Dict[str, Any]]:
    # Fallbacks are explicit and lower-confidence. They never pretend to be structural targets.
    role_mult = {"TP1": 0.85, "TP2": 1.55, "TP3": 2.40, "RUNNER": 3.60}[role]
    direction = 1.0 if side == "long" else -1.0
    px = entry + direction * weekly_atr * role_mult
    live_floor = max(entry, reference) if side == "long" else min(entry, reference)
    if side == "long":
        px = max(px, live_floor + weekly_atr * 0.15)
        if previous_price is not None:
            px = max(px, previous_price + weekly_atr * 0.25)
    else:
        px = min(px, live_floor - weekly_atr * 0.15)
        if previous_price is not None:
            px = min(px, previous_price - weekly_atr * 0.25)
    if px <= 0:
        return None
    risk = abs(entry - stop)
    rr = abs(px - entry) / max(risk, 1e-9)
    return {
        "role": role,
        "price": round(px, 6),
        "rr": round(rr, 2),
        "selection_score": 35.0,
        "evidence_quality": "fallback_volatility_projection",
        "sources": ["weekly_atr_fallback"],
        "timeframes": ["W1"],
        "evidence_count": 0,
        "structural_evidence_count": 0,
        "cluster": None,
        "horizon": _horizon_days(abs(px - entry), weekly_atr, role),
        "warning": "No sufficiently strong structural cluster satisfied the role constraints; this is a volatility projection and requires revalidation.",
    }


def _review_milestones(
    clusters: Sequence[Mapping[str, Any]],
    *,
    side: str,
    entry: float,
    objectives: Sequence[Mapping[str, Any]],
    weekly_atr: float,
) -> List[Dict[str, Any]]:
    """Select structural checkpoints without turning them into extra exits.

    Milestones are deliberately *not* targets.  They are D1/W1/MN1 structural,
    volume, supply or projection clusters where the thesis should be reviewed while
    preserving the canonical TP1/TP2/TP3/Runner staged-exit ladder.
    """
    prices = [_f(_d(x).get("price")) for x in objectives if _f(_d(x).get("price")) > 0]
    if not prices:
        return []
    far = max(prices) if side == "long" else min(prices)
    objective_prices = prices
    min_sep = max(weekly_atr * 0.10, entry * 0.0012)
    candidates: List[Dict[str, Any]] = []
    for c in clusters:
        px = _f(c.get("price"))
        if px <= 0:
            continue
        in_path = (side == "long" and entry < px < far) or (side == "short" and far < px < entry)
        if not in_path:
            continue
        if any(abs(px - opx) < min_sep for opx in objective_prices):
            continue
        structural = int(_f(c.get("structural_evidence_count")))
        score = _f(c.get("cluster_score"))
        if structural <= 0 and score < 72.0:
            continue
        candidates.append({
            "price": round(px, 6),
            "cluster_score": round(score, 2),
            "structural_evidence_count": structural,
            "evidence_count": int(_f(c.get("evidence_count"))),
            "sources": list(c.get("sources") or []),
            "timeframes": list(c.get("timeframes") or []),
            "kinds": list(c.get("kinds") or []),
            "distance_weekly_atr_from_entry": round(abs(px - entry) / max(weekly_atr, 1e-9), 3),
            "action": "REVIEW_THESIS_ONLY_NO_AUTOMATIC_EXIT",
        })
    candidates.sort(key=lambda x: x["price"], reverse=(side == "short"))
    # Keep path coverage while preventing a verbose pseudo-target ladder.
    selected: List[Dict[str, Any]] = []
    for c in candidates:
        if selected and abs(_f(c.get("price")) - _f(selected[-1].get("price"))) < min_sep:
            if _f(c.get("cluster_score")) > _f(selected[-1].get("cluster_score")):
                selected[-1] = c
            continue
        selected.append(c)
        if len(selected) >= 6:
            break
    for i, c in enumerate(selected, start=1):
        c["milestone_id"] = f"M{i}"
        c["semantics"] = "review_checkpoint_not_take_profit"
    return selected


def build_strategic_target_plan(
    *,
    chart: Mapping[str, Any],
    valuation: Mapping[str, Any],
    side: str,
    entry: float,
    stop: float,
    macro: Optional[Mapping[str, Any]] = None,
    maturity: Optional[Mapping[str, Any]] = None,
) -> Dict[str, Any]:
    """Build a 30-60 day aware target ladder for spot XAUUSD.

    TP1/TP2/TP3 are selected from evidence clusters. A runner is also exposed for
    trend continuation. RR validates target usefulness but never creates primary
    structural evidence.
    """
    if side not in {"long", "short"} or entry <= 0 or stop <= 0 or entry == stop:
        return {"valid": False, "reason": "invalid_target_geometry", "engine": TARGET_ENGINE_VERSION, "targets": []}

    reference = _reference(chart)
    d1_atr = _atr(chart, "D1", _atr(chart, "H4", 1.0) * 2.0)
    w1_atr = _atr(chart, "W1", d1_atr * math.sqrt(5.0))
    mn1_atr = _atr(chart, "MN1", w1_atr * math.sqrt(4.2))
    tolerance = max(d1_atr * 0.28, w1_atr * 0.08, max(entry, 1.0) * 0.0015)

    evidence: List[TargetEvidence] = []
    evidence.extend(_collect_structural_evidence(chart, entry, side))
    evidence.extend(_dealing_range_extensions(valuation, side))
    evidence.extend(_measured_move_evidence(chart, side))
    evidence.extend(_volatility_projection_evidence(chart, entry, side))

    # Remove evidence that is already behind the planned entry direction.
    evidence = [
        x for x in evidence
        if (side == "long" and x.price > entry) or (side == "short" and 0 < x.price < entry)
    ]
    clusters = _cluster_evidence(evidence, tolerance)

    targets: List[Dict[str, Any]] = []
    prev: Optional[float] = None
    for role in ("TP1", "TP2", "TP3", "RUNNER"):
        chosen = _choose_role_target(
            clusters,
            role=role,
            side=side,
            entry=entry,
            stop=stop,
            reference=reference,
            weekly_atr=w1_atr,
            previous_price=prev,
        )
        if chosen is None:
            chosen = _fallback_projection_target(
                evidence,
                role=role,
                side=side,
                entry=entry,
                stop=stop,
                reference=reference,
                weekly_atr=w1_atr,
                previous_price=prev,
            )
        if chosen is None:
            break
        targets.append(chosen)
        prev = _f(chosen.get("price"))

    if len(targets) < 3:
        return {
            "valid": False,
            "reason": "insufficient_strategic_target_evidence",
            "engine": TARGET_ENGINE_VERSION,
            "targets": targets,
            "candidate_clusters": clusters[:30],
        }

    macro = _d(macro)
    maturity = _d(maturity)
    macro_bias = _s(macro.get("bias"))
    macro_conf = _f(macro.get("confidence"))
    maturity_phase = _s(maturity.get("phase"))
    durability = 50.0
    if (side == "long" and macro_bias in {"bullish", "long"}) or (side == "short" and macro_bias in {"bearish", "short"}):
        durability += min(18.0, macro_conf * 0.18)
    elif macro_bias in {"mixed", "neutral", "neutral_mixed", "unknown", ""}:
        durability += 0.0
    else:
        durability -= min(20.0, macro_conf * 0.20)
    if maturity_phase == "healthy_trend":
        durability += 12.0
    elif maturity_phase == "developing_trend":
        durability += 7.0
    elif maturity_phase == "late_extended":
        durability -= 12.0
    durability = max(0.0, min(100.0, durability))

    tp1, tp2, tp3 = targets[0], targets[1], targets[2]
    runner = targets[3] if len(targets) > 3 else None
    milestones = _review_milestones(
        clusters, side=side, entry=entry, objectives=targets, weekly_atr=w1_atr
    )
    one_month = {
        "minimum_analysis_horizon_days": 30,
        "primary_30_60d_objective": tp3,
        "runner_45_90d_objective": runner,
        "macro_trend_durability_score": round(durability, 2),
        "weekly_atr": round(w1_atr, 6),
        "monthly_atr": round(mn1_atr, 6),
        "thesis_review_conditions": [
            "weekly_structure_break",
            "daily_thesis_invalidation",
            "macro_regime_reversal",
            "monthly_or_weekly_target_cluster_reached",
            "material_volatility_regime_change",
        ],
        "note": "The 30-60 day objective is a scenario target, not a guaranteed time-to-target forecast.",
    }

    return {
        "valid": True,
        "engine": TARGET_ENGINE_VERSION,
        "methodology": "D1_W1_MN1_structure_liquidity_supply_clusters_plus_fib_measured_move_and_volatility_validation",
        "target_generation_policy": "structure_first_rr_validation_only",
        "reference_price": round(reference, 6),
        "planned_entry": round(entry, 6),
        "entry_invalidation": round(stop, 6),
        "d1_atr": round(d1_atr, 6),
        "w1_atr": round(w1_atr, 6),
        "mn1_atr": round(mn1_atr, 6),
        "cluster_tolerance": round(tolerance, 6),
        "tp1": tp1,
        "tp2": tp2,
        "tp3": tp3,
        "runner": runner,
        "targets": targets[:3],
        "all_objectives": targets,
        "review_milestones": milestones,
        "milestone_policy": "review_checkpoints_only_do_not_increase_number_of_exit_targets",
        "one_month_outlook": one_month,
        "candidate_clusters": sorted(clusters, key=lambda x: _f(x.get("cluster_score")), reverse=True)[:30],
        "evidence_count": len(evidence),
    }


def build_thesis_invalidation(chart: Mapping[str, Any], side: str, entry_stop: float) -> Dict[str, Any]:
    """Derive a slower thesis invalidation independent from the tactical entry stop."""
    if side not in {"long", "short"}:
        return {"available": False, "reason": "no_directional_side"}
    w1_atr = _atr(chart, "W1", _atr(chart, "D1", 1.0) * math.sqrt(5.0))
    candidates: List[Tuple[float, str, str]] = []
    for tf in ("D1", "W1", "MN1"):
        ctx = _tf(chart, tf)
        sr = _d(ctx.get("support_resistance"))
        arr = _l(sr.get("supports" if side == "long" else "resistances"))
        for lv in arr:
            p = _f(lv)
            if p <= 0:
                continue
            if (side == "long" and p < entry_stop) or (side == "short" and p > entry_stop):
                candidates.append((p, "support_resistance", tf))
        swings = _d(ctx.get("swings"))
        arr2 = _l(swings.get("lows" if side == "long" else "highs"))
        for sw in arr2[-12:]:
            if not isinstance(sw, dict):
                continue
            p = _f(sw.get("price"))
            if p <= 0:
                continue
            if (side == "long" and p < entry_stop) or (side == "short" and p > entry_stop):
                candidates.append((p, "swing", tf))
    if not candidates:
        px = entry_stop - w1_atr * 0.35 if side == "long" else entry_stop + w1_atr * 0.35
        return {
            "available": True,
            "price": round(max(px, 1e-6), 6),
            "source": "weekly_atr_fallback",
            "timeframe": "W1",
            "semantics": "thesis_invalidation_not_entry_stop",
        }
    # Closest slower structure beyond the tactical stop, with a small weekly ATR buffer.
    if side == "long":
        base, src, tf = max(candidates, key=lambda x: x[0])
        px = base - w1_atr * 0.08
    else:
        base, src, tf = min(candidates, key=lambda x: x[0])
        px = base + w1_atr * 0.08
    return {
        "available": True,
        "price": round(max(px, 1e-6), 6),
        "base_level": round(base, 6),
        "source": src,
        "timeframe": tf,
        "weekly_atr_buffer": round(w1_atr * 0.08, 6),
        "semantics": "thesis_invalidation_not_entry_stop",
    }
