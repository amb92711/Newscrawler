from __future__ import annotations

"""Canonical lifecycle + adaptive de-risk engine for 30-90 day XAUUSD spot positions.

The engine deliberately separates *setup existence* from *position existence*.
Without a persisted position record it can only emit PRE_ENTRY_WATCH / ENTRY_ARMED.
Once a paper/manual position is registered, states progress monotonically through the
realized-target lifecycle and allocation changes are allowed only on a new D1/W1 close.
"""

from typing import Any, Dict, List, Mapping, Optional, Sequence
import math

LIFECYCLE_ENGINE_VERSION = "AMB_SPOT_POSITION_LIFECYCLE_V2_ACCUMULATION"
REALLOCATION_ENGINE_VERSION = "AMB_SPOT_ADAPTIVE_DERISK_V1"
ROLES: Sequence[str] = ("TP1", "TP2", "TP3", "RUNNER")


def _d(v: Any) -> Dict[str, Any]:
    return v if isinstance(v, dict) else {}


def _l(v: Any) -> List[Any]:
    return v if isinstance(v, list) else []


def _f(v: Any, default: float = 0.0) -> float:
    try:
        x = float(v)
        return x if math.isfinite(x) else default
    except Exception:
        return default


def _s(v: Any) -> str:
    return str(v or "").strip().lower()


def _clamp(v: float, lo: float = 0.0, hi: float = 100.0) -> float:
    return max(lo, min(hi, float(v)))


def _stage_map(staged_exit: Mapping[str, Any]) -> Dict[str, Dict[str, Any]]:
    out: Dict[str, Dict[str, Any]] = {}
    for st in _l(staged_exit.get("stages")):
        if isinstance(st, dict) and str(st.get("role") or "") in ROLES:
            out[str(st.get("role"))] = st
    return out


def _position_open(position: Mapping[str, Any]) -> bool:
    return _s(position.get("status")) == "open"


def _reached_from_record(position: Mapping[str, Any]) -> List[str]:
    vals = [str(x) for x in _l(position.get("realized_roles")) if str(x) in ROLES]
    return [r for r in ROLES if r in vals]


def _canonical_state(
    *,
    opportunity: Mapping[str, Any],
    decision: Mapping[str, Any],
    position: Mapping[str, Any],
    staged_exit: Mapping[str, Any],
) -> Dict[str, Any]:
    if position and (_s(position.get("status")) == "closed" or bool(position.get("closed"))):
        return {
            "state": "CLOSED",
            "phase": "closed",
            "position_open": False,
            "reached_objectives": _reached_from_record(position),
            "realized_pct": round(_f(position.get("realized_pct")), 2),
            "remaining_pct": 0.0,
            "entry_price": position.get("entry_price"),
            "opened_utc": position.get("opened_utc"),
            "closed_utc": position.get("closed_utc"),
            "position_id": position.get("position_id"),
            "meaning": "Position lifecycle is complete; a new setup requires a new position registration.",
        }
    if not _position_open(position):
        execution_state = str(decision.get("state") or "")
        opportunity_state = str(opportunity.get("setup_state") or "")
        accumulation = _d(opportunity.get("accumulation_plan"))
        acc_permission = _s(accumulation.get("permission"))
        armed = (
            (bool(opportunity.get("actionable_now")) and _s(decision.get("action")) == "buy")
            or execution_state in {"ENTRY_ARMED_COOL_OFF_LONG", "ENTRY_ARMED_ACCUMULATION_LONG"}
            or opportunity_state in {"ENTRY_ARMED_BUY_ON_PULLBACK", "ENTRY_ARMED_ACCUMULATION", "ACCUMULATE_NOW"}
            or acc_permission in {"armed", "accumulate"}
        )
        if armed:
            return {
                "state": "ENTRY_ARMED",
                "phase": "pre_entry",
                "position_open": False,
                "meaning": "Cool-off/entry conditions are armed, but no persisted spot position is registered yet. ENTRY_ARMED is not a fill.",
            }
        if bool(opportunity.get("buy_setup_available")):
            return {
                "state": "PRE_ENTRY_WATCH",
                "phase": "pre_entry",
                "position_open": False,
                "meaning": "A spot buy plan exists, but no position has been registered as filled.",
            }
        return {
            "state": "FLAT_NO_SETUP",
            "phase": "pre_entry",
            "position_open": False,
            "meaning": "No open position and no valid spot setup.",
        }

    reached = _reached_from_record(position)
    thesis_broken = bool(position.get("thesis_invalidated"))
    accumulated_pct = _f(position.get("accumulated_pct"), 100.0 if position and not position.get("accumulation_fills") else 0.0)
    if thesis_broken:
        state, phase = "THESIS_INVALIDATED", "risk_exit"
    elif bool(position.get("closed")) or _s(position.get("status")) == "closed":
        state, phase = "CLOSED", "closed"
    elif "RUNNER" in reached:
        state, phase = "CLOSED", "closed"
    elif "TP3" in reached:
        state, phase = "RUNNER_ONLY", "runner"
    elif "TP2" in reached:
        state, phase = "STRATEGIC_CORE", "strategic_core"
    elif "TP1" in reached:
        state, phase = "TP1_REALIZED", "post_tactical"
    elif accumulated_pct < 99.0:
        state, phase = "ACCUMULATING", "accumulation"
    else:
        state, phase = "POSITION_OPEN", "open_position"

    return {
        "state": state,
        "phase": phase,
        "position_open": state not in {"CLOSED"},
        "reached_objectives": reached,
        "realized_pct": round(_f(position.get("realized_pct")), 2),
        "remaining_pct": round(max(0.0, 100.0 - _f(position.get("realized_pct"))), 2),
        "entry_price": position.get("entry_price"),
        "actual_cost_basis": position.get("actual_cost_basis") or position.get("entry_price"),
        "accumulated_pct": round(accumulated_pct, 2),
        "opened_utc": position.get("opened_utc"),
        "position_id": position.get("position_id"),
        "meaning": {
            "ACCUMULATING": "A partial spot position exists; additional tranches are governed by the adaptive accumulation and falling-knife safety engines.",
            "POSITION_OPEN": "Planned accumulation is complete; manage toward TP1 without reacting to intraday noise.",
            "TP1_REALIZED": "Tactical reduction is realized; protect thesis while preserving swing/core exposure.",
            "STRATEGIC_CORE": "TP1/TP2 reductions are realized; remaining exposure is the 30-60D strategic core.",
            "RUNNER_ONLY": "Primary 30-60D objective is realized; only optional runner exposure remains.",
            "THESIS_INVALIDATED": "Slow spot thesis is invalidated; remaining exposure should be reassessed/closed.",
            "CLOSED": "Position lifecycle is complete.",
        }.get(state, state),
    }


def _current_review_markers(chart: Mapping[str, Any]) -> Dict[str, Any]:
    tfs = _d(chart.get("timeframes"))
    return {
        "D1": _d(tfs.get("D1")).get("last_time"),
        "W1": _d(tfs.get("W1")).get("last_time"),
    }


def _new_confirmation_close(position: Mapping[str, Any], chart: Mapping[str, Any]) -> Dict[str, Any]:
    current = _current_review_markers(chart)
    prior = _d(position.get("last_allocation_review_markers")) or _d(position.get("entry_review_markers"))
    changed = [tf for tf in ("D1", "W1") if current.get(tf) and current.get(tf) != prior.get(tf)]
    return {"eligible": bool(changed), "new_closed_timeframes": changed, "current_markers": current, "prior_markers": prior}


def _confirmation_strength(htf: Mapping[str, Any]) -> Dict[str, Any]:
    details = _d(htf.get("details"))
    vals = []
    signs = []
    for tf in ("D1", "W1"):
        raw = _f(_d(details.get(tf)).get("raw_score"))
        vals.append(raw)
        signs.append("bullish" if raw >= 1.5 else "bearish" if raw <= -1.5 else "mixed")
    avg = sum(vals) / max(len(vals), 1)
    return {
        "d1_w1_average_raw_score": round(avg, 3),
        "D1": signs[0] if signs else "unknown",
        "W1": signs[1] if len(signs) > 1 else "unknown",
        "both_bullish": all(x == "bullish" for x in signs),
        "any_bearish": any(x == "bearish" for x in signs),
    }


def _normalize_weights(weights: Dict[str, float], total: float) -> Dict[str, float]:
    s = sum(max(0.0, v) for v in weights.values())
    if s <= 1e-9:
        return {k: 0.0 for k in weights}
    return {k: round(max(0.0, v) / s * total, 2) for k, v in weights.items()}


def _adaptive_reallocation(
    *,
    position: Mapping[str, Any],
    chart: Mapping[str, Any],
    staged_exit: Mapping[str, Any],
    htf: Mapping[str, Any],
    macro: Mapping[str, Any],
    maturity: Mapping[str, Any],
    strategic: Mapping[str, Any],
) -> Dict[str, Any]:
    base = {k: _f(_d(staged_exit.get("allocation_policy")).get("stage_weights_pct", {}).get(k)) for k in ROLES}
    if not _position_open(position):
        return {
            "engine": REALLOCATION_ENGINE_VERSION,
            "active": False,
            "review_eligible": False,
            "decision": "PRE_ENTRY_NO_REALLOCATION",
            "base_weights_pct": base,
            "effective_future_weights_pct": base,
            "reason": "Adaptive reallocation begins only after a persisted position is open.",
        }

    reached = set(_reached_from_record(position))
    realized_pct = _f(position.get("realized_pct"))
    remaining_pct = max(0.0, 100.0 - realized_pct)
    future_roles = [r for r in ROLES if r not in reached]
    persisted_effective = _d(position.get("latest_effective_future_weights_pct"))
    current_future = {
        r: (0.0 if r in reached else _f(persisted_effective.get(r), base.get(r, 0.0)))
        for r in ROLES
    }
    if future_roles:
        current_future.update(_normalize_weights({r: current_future[r] for r in future_roles}, remaining_pct))

    review = _new_confirmation_close(position, chart)
    entry_snapshot = _d(position.get("entry_snapshot"))
    entry_htf = _f(entry_snapshot.get("htf_score"), _f(htf.get("score_0_100"), 50.0))
    entry_macro = _f(entry_snapshot.get("macro_score"), _f(macro.get("score_0_100"), 50.0))
    htf_now = _f(htf.get("score_0_100"), 50.0)
    macro_now = _f(macro.get("score_0_100"), 50.0)
    htf_delta = htf_now - entry_htf
    macro_delta = macro_now - entry_macro
    confirm = _confirmation_strength(htf)
    thesis_broken = bool(position.get("thesis_invalidated"))
    phase = _s(maturity.get("phase"))
    durability = _f(_d(strategic.get("one_month_outlook")).get("macro_trend_durability_score"), 50.0)

    evidence = {
        "htf_score_now": round(htf_now, 2),
        "htf_score_at_entry": round(entry_htf, 2),
        "htf_delta": round(htf_delta, 2),
        "macro_score_now": round(macro_now, 2),
        "macro_score_at_entry": round(entry_macro, 2),
        "macro_delta": round(macro_delta, 2),
        "d1_w1_confirmation": confirm,
        "trend_maturity": phase,
        "macro_trend_durability_score": round(durability, 2),
        "thesis_invalidated": thesis_broken,
    }

    if not review.get("eligible"):
        return {
            "engine": REALLOCATION_ENGINE_VERSION,
            "active": True,
            "review_eligible": False,
            "decision": "LOCK_CURRENT_ALLOCATION",
            "base_weights_pct": base,
            "effective_future_weights_pct": current_future,
            "remaining_position_pct": round(remaining_pct, 2),
            "evidence": evidence,
            "review_clock": review,
            "last_confirmed_reallocation": _d(position.get("last_adaptive_review")),
            "reason": "No new D1/W1 close since the last allocation review; avoid intraday over-management.",
        }

    proposed = dict(current_future)
    decision = "HOLD_ALLOCATION"
    reason = "New D1/W1 close, but evidence change is not strong enough to alter the staged exit plan."

    deterioration = thesis_broken or confirm.get("any_bearish") or htf_delta <= -9.0 or macro_delta <= -12.0 or macro_now < 40.0
    improvement = (
        not thesis_broken
        and confirm.get("both_bullish")
        and htf_delta >= 4.0
        and macro_delta >= 6.0
        and durability >= 60.0
        and phase in {"healthy_trend", "developing_trend"}
    )

    unreached_near = [r for r in ("TP1", "TP2") if r in future_roles]
    unreached_far = [r for r in ("TP3", "RUNNER") if r in future_roles]

    if deterioration and future_roles:
        decision = "DE_RISK_EARLIER"
        # Shift up to 12% of the remaining position from far objectives toward the nearest unreached objective.
        shift_cap = min(12.0, remaining_pct * 0.18)
        available = sum(proposed.get(r, 0.0) for r in unreached_far)
        shift = min(shift_cap, available * 0.45)
        if shift > 0 and unreached_near:
            receiver = unreached_near[0]
            for r in reversed(unreached_far):
                take = min(proposed.get(r, 0.0), shift / max(len(unreached_far), 1))
                proposed[r] = max(0.0, proposed.get(r, 0.0) - take)
                proposed[receiver] = proposed.get(receiver, 0.0) + take
            reason = "Confirmed D1/W1 or macro deterioration: realize more exposure at the nearest objective and reduce distant runner dependence."
        elif thesis_broken:
            reason = "Thesis invalidation overrides normal staged realization; reassess remaining exposure immediately."
    elif improvement and future_roles:
        decision = "EXTEND_STRATEGIC_CORE"
        # Shift modestly from nearer future exits into TP3/runner; never from already-realized stages.
        shift_cap = min(10.0, remaining_pct * 0.15)
        available = sum(proposed.get(r, 0.0) for r in unreached_near)
        shift = min(shift_cap, available * 0.35)
        if shift > 0 and unreached_far:
            donor_roles = list(unreached_near)
            receiver_weights = {"TP3": 0.65, "RUNNER": 0.35}
            for donor in donor_roles:
                take = min(proposed.get(donor, 0.0), shift / max(len(donor_roles), 1))
                proposed[donor] = max(0.0, proposed.get(donor, 0.0) - take)
                receivers = [r for r in unreached_far if r in receiver_weights]
                norm = sum(receiver_weights[r] for r in receivers) or 1.0
                for r in receivers:
                    proposed[r] = proposed.get(r, 0.0) + take * receiver_weights[r] / norm
            reason = "New D1/W1 confirmation plus stronger macro durability: preserve more exposure for TP3/runner while retaining staged realization."

    # Keep realized stages at zero in future allocation and normalize exactly to remaining position.
    norm_future = _normalize_weights({r: proposed.get(r, 0.0) for r in future_roles}, remaining_pct) if future_roles else {r: 0.0 for r in ROLES}
    effective = {r: (0.0 if r in reached else norm_future.get(r, 0.0)) for r in ROLES}
    return {
        "engine": REALLOCATION_ENGINE_VERSION,
        "active": True,
        "review_eligible": True,
        "decision": decision,
        "base_weights_pct": base,
        "effective_future_weights_pct": effective,
        "remaining_position_pct": round(remaining_pct, 2),
        "already_realized_roles": [r for r in ROLES if r in reached],
        "evidence": evidence,
        "review_clock": review,
        "reason": reason,
        "guardrails": {
            "requires_new_D1_or_W1_close": True,
            "never_reallocates_realized_stages": True,
            "intraday_noise_cannot_change_allocation": True,
            "thesis_invalidation_overrides_extension": True,
            "max_single_review_shift_pct_of_original_position": 12.0,
        },
    }


def build_position_lifecycle(
    *,
    chart: Mapping[str, Any],
    opportunity: Mapping[str, Any],
    decision: Mapping[str, Any],
    position_record: Optional[Mapping[str, Any]],
    staged_exit: Mapping[str, Any],
    htf: Mapping[str, Any],
    macro: Mapping[str, Any],
    maturity: Mapping[str, Any],
    strategic: Mapping[str, Any],
) -> Dict[str, Any]:
    position = _d(position_record)
    canonical = _canonical_state(opportunity=opportunity, decision=decision, position=position, staged_exit=staged_exit)
    adaptive = _adaptive_reallocation(
        position=position,
        chart=chart,
        staged_exit=staged_exit,
        htf=htf,
        macro=macro,
        maturity=maturity,
        strategic=strategic,
    )
    stage_by_role = _stage_map(staged_exit)
    realized = set(_reached_from_record(position))
    effective = _d(adaptive.get("effective_future_weights_pct"))
    canonical_stage_plan: List[Dict[str, Any]] = []
    for role in ROLES:
        st = _d(stage_by_role.get(role))
        if not st:
            continue
        canonical_stage_plan.append({
            "role": role,
            "price": st.get("price"),
            "status": "REALIZED" if role in realized else ("FUTURE" if _position_open(position) else "PRE_ENTRY_PLANNED"),
            "baseline_reduction_pct": st.get("planned_reduction_pct"),
            "effective_future_reduction_pct": 0.0 if role in realized else _f(effective.get(role), _f(st.get("planned_reduction_pct"))),
            "horizon": st.get("horizon"),
            "reachability": st.get("reachability"),
        })
    thesis_overlay = _d(opportunity.get("thesis_health"))
    accumulation_overlay = _d(opportunity.get("accumulation_plan"))
    falling_overlay = _d(opportunity.get("falling_knife_guard"))
    return {
        "valid": True,
        "engine": LIFECYCLE_ENGINE_VERSION,
        "review_markers": _current_review_markers(chart),
        "state": canonical.get("state"),
        "phase": canonical.get("phase"),
        "position_open": canonical.get("position_open"),
        "canonical": canonical,
        "adaptive_reallocation": adaptive,
        "canonical_stage_plan": canonical_stage_plan,
        "thesis_health_overlay": {
            "state": thesis_overlay.get("state"),
            "health_score_0_100": thesis_overlay.get("health_score_0_100"),
            "management_action": thesis_overlay.get("management_action"),
        },
        "accumulation_overlay": {
            "state": accumulation_overlay.get("state"),
            "permission": accumulation_overlay.get("permission"),
            "recommended_new_allocation_pct_now": accumulation_overlay.get("recommended_new_allocation_pct_now"),
            "eligible_tranches_now": accumulation_overlay.get("eligible_tranches_now"),
        },
        "falling_knife_overlay": {
            "risk_score_0_100": falling_overlay.get("risk_score_0_100"),
            "level": falling_overlay.get("level"),
            "permission": falling_overlay.get("permission"),
        },
        "position_registry": {
            "registered": bool(position),
            "position_id": position.get("position_id"),
            "status": position.get("status") or "flat",
            "entry_price": position.get("entry_price"),
            "opened_utc": position.get("opened_utc"),
            "realized_roles": _reached_from_record(position),
            "realized_pct": round(_f(position.get("realized_pct")), 2),
            "accumulated_pct": round(_f(position.get("accumulated_pct"), 100.0 if position and not position.get("accumulation_fills") else 0.0), 2),
            "actual_cost_basis": position.get("actual_cost_basis") or position.get("entry_price"),
            "accumulation_fills": _l(position.get("accumulation_fills")),
        },
        "semantic_rules": {
            "pre_entry_watch_is_not_hold": True,
            "entry_armed_is_not_position_open": True,
            "position_states_require_persisted_position_record": True,
            "realized_target_states_are_monotonic": True,
            "allocation_changes_require_new_D1_or_W1_close": True,
            "partial_spot_fills_create_ACCUMULATING_state": True,
            "accumulation_and_exit_lifecycles_are_separate": True,
        },
    }
