from __future__ import annotations
from typing import Any, Dict, List
import time, requests
from amb_chart.models import ProviderHealth
from amb_chart.utils.time import ms_to_iso

class BinanceXautProvider:
    name='binance_xaut_public'
    REST_BASE='https://api.binance.com'
    def __init__(self, symbol: str='XAUTUSDT', timeout: int=20, retries: int=3):
        self.symbol=symbol.upper()
        if self.symbol!='XAUTUSDT': raise ValueError('This build is locked to XAUTUSDT.')
        self.timeout=timeout; self.retries=retries; self._last_health={}
    def _get(self,path:str,params:Dict[str,Any]|None=None):
        last=None
        for attempt in range(1,self.retries+1):
            try:
                r=requests.get(self.REST_BASE+path,params=params or {},timeout=self.timeout,headers={'User-Agent':'AMB-Gold-Chart-SMC-Pro/2.0'})
                r.raise_for_status(); return r.json()
            except Exception as exc:
                last=exc; time.sleep(min(2*attempt,6))
        raise RuntimeError(f'Binance request failed {path}: {last}')
    def fetch_klines(self, interval: str, limit: int, symbol: str | None=None) -> List[Dict[str,Any]]:
        sym=(symbol or self.symbol).upper()
        raw=self._get('/api/v3/klines', {'symbol':sym,'interval':interval,'limit':min(limit,1000)})
        rows=[]
        for k in raw:
            rows.append({'time':ms_to_iso(int(k[0])),'open':float(k[1]),'high':float(k[2]),'low':float(k[3]),'close':float(k[4]),'volume':float(k[5])})
        return rows
    def fetch_multi_timeframe(self,timeframes:Dict[str,str],count:int)->Dict[str,List[Dict[str,Any]]]:
        out={}; details={}
        for label,interval in timeframes.items():
            rows=self.fetch_klines(interval,count); out[label]=rows; details[label]={'interval':interval,'candles':len(rows),'last_time':rows[-1]['time'] if rows else None}
        self._last_health=details; return out
    def fetch_related_multi_timeframe(self, related: Dict[str,str], timeframes: Dict[str,str], count:int):
        out={}
        for name,sym in related.items():
            tfmap={}
            for label, interval in timeframes.items():
                try: tfmap[label]=self.fetch_klines(interval,min(count,700),symbol=sym)
                except Exception: tfmap[label]=[]
            out[name]=tfmap
        return out
    def order_book(self,limit:int=100): return self._get('/api/v3/depth', {'symbol':self.symbol,'limit':limit})
    def book_ticker(self): return self._get('/api/v3/ticker/bookTicker', {'symbol':self.symbol})
    def recent_trades(self,limit:int=500): return self._get('/api/v3/trades', {'symbol':self.symbol,'limit':limit})
    def market_microstructure(self)->Dict[str,Any]:
        micro={'symbol':self.symbol}
        try:
            t=self.book_ticker(); bid=float(t.get('bidPrice',0) or 0); ask=float(t.get('askPrice',0) or 0)
            micro.update({'best_bid':bid,'best_ask':ask,'spread':round(ask-bid,8) if bid and ask else None,'bid_qty':float(t.get('bidQty',0) or 0),'ask_qty':float(t.get('askQty',0) or 0)})
        except Exception as exc: micro['book_ticker_error']=str(exc)
        try:
            depth=self.order_book(100); bids=[(float(p),float(q)) for p,q in depth.get('bids',[])]; asks=[(float(p),float(q)) for p,q in depth.get('asks',[])]
            bid_notional=sum(p*q for p,q in bids[:20]); ask_notional=sum(p*q for p,q in asks[:20])
            micro['depth_top20_bid_notional']=round(bid_notional,3); micro['depth_top20_ask_notional']=round(ask_notional,3)
            if bid_notional+ask_notional>0: micro['depth_imbalance']=round((bid_notional-ask_notional)/(bid_notional+ask_notional),4)
            micro['largest_bid_levels']=sorted([{'price':p,'qty':q,'notional':round(p*q,3)} for p,q in bids[:50]],key=lambda x:x['notional'],reverse=True)[:8]
            micro['largest_ask_levels']=sorted([{'price':p,'qty':q,'notional':round(p*q,3)} for p,q in asks[:50]],key=lambda x:x['notional'],reverse=True)[:8]
        except Exception as exc: micro['depth_error']=str(exc)
        try:
            trades=self.recent_trades(500)
            buy_qty=sum(float(x['qty']) for x in trades if not x.get('isBuyerMaker'))
            sell_qty=sum(float(x['qty']) for x in trades if x.get('isBuyerMaker'))
            total=buy_qty+sell_qty
            micro['recent_trade_buy_qty']=round(buy_qty,6); micro['recent_trade_sell_qty']=round(sell_qty,6)
            micro['recent_trade_delta']=round(buy_qty-sell_qty,6); micro['recent_trade_imbalance']=round((buy_qty-sell_qty)/total,4) if total else 0
        except Exception as exc: micro['trades_error']=str(exc)
        return micro
    def health(self)->ProviderHealth:
        try: return ProviderHealth(self.name, True, self.symbol, 'Binance public REST OK', {'last_fetch':self._last_health,'ticker':self.book_ticker()})
        except Exception as exc: return ProviderHealth(self.name, False, self.symbol, str(exc), {'last_fetch':self._last_health})
