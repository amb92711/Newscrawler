from __future__ import annotations
import json

def run_debug_stream(symbol: str = 'XAUTUSDT'):
    import websocket
    url = f"wss://stream.binance.com:9443/ws/{symbol.lower()}@kline_1m"
    count=0
    def on_message(ws, message):
        nonlocal count
        msg=json.loads(message); k=msg.get('k',{})
        print({"symbol":k.get('s'),"interval":k.get('i'),"close":k.get('c'),"closed":k.get('x')})
        count+=1
        if count>=5: ws.close()
    ws=websocket.WebSocketApp(url,on_message=on_message)
    ws.run_forever()
