from __future__ import annotations

import time
from datetime import datetime, timezone, timedelta
from typing import Any, Dict, List, Optional, Tuple

from amb_chart.models import ProviderHealth


class MT5LiveProvider:
    """Execution-grade Windows MetaTrader 5 provider for XAUUSD-style symbols.

    Time policy
    -----------
    Official MT5 Python timestamps are UTC epoch seconds. Some broker bridges, however,
    can expose *tick* timestamps encoded as server-wall-clock epoch while historical
    bars remain normal UTC epoch. Therefore tick and bar clocks are calibrated
    independently. No timestamp is ever silently clamped to the current time.

    History policy
    --------------
    If a fresh normalized tick exists while execution bars are materially old, the
    provider performs a bounded history refresh/retry sequence. If the broker terminal
    still returns old bars, the condition is exposed as HISTORY_UNSYNCHRONIZED so the
    market-state engine can block execution instead of treating old candles as live.
    """

    name = "mt5_live_windows"

    TIMEFRAME_MAP = {
        "M1": "TIMEFRAME_M1", "M2": "TIMEFRAME_M2", "M3": "TIMEFRAME_M3",
        "M4": "TIMEFRAME_M4", "M5": "TIMEFRAME_M5", "M6": "TIMEFRAME_M6",
        "M10": "TIMEFRAME_M10", "M12": "TIMEFRAME_M12", "M15": "TIMEFRAME_M15",
        "M20": "TIMEFRAME_M20", "M30": "TIMEFRAME_M30", "H1": "TIMEFRAME_H1",
        "H2": "TIMEFRAME_H2", "H3": "TIMEFRAME_H3", "H4": "TIMEFRAME_H4",
        "H6": "TIMEFRAME_H6", "H8": "TIMEFRAME_H8", "H12": "TIMEFRAME_H12",
        "D1": "TIMEFRAME_D1", "W1": "TIMEFRAME_W1", "MN1": "TIMEFRAME_MN1",
    }

    TF_SECONDS = {
        "M1": 60, "M2": 120, "M3": 180, "M4": 240, "M5": 300, "M6": 360,
        "M10": 600, "M12": 720, "M15": 900, "M20": 1200, "M30": 1800,
        "H1": 3600, "H2": 7200, "H3": 10800, "H4": 14400, "H6": 21600,
        "H8": 28800, "H12": 43200, "D1": 86400, "W1": 604800,
        "MN1": 2592000,
    }

    def __init__(
        self,
        symbol: str = "XAUUSD",
        terminal_path: Optional[str] = None,
        login: Optional[int] = None,
        password: Optional[str] = None,
        server: Optional[str] = None,
        portable: bool = False,
        timeout: int = 60_000,
    ):
        self.symbol = symbol
        self.terminal_path = terminal_path
        self.login = login
        self.password = password
        self.server = server
        self.portable = portable
        self.timeout = timeout
        self.mt5 = None
        self._initialized = False
        self._last_health: Dict[str, Any] = {}
        self._clock_models: Dict[str, Dict[str, Any]] = {}
        self._history_sync: Dict[str, Any] = {}

    @staticmethod
    def _system_epoch() -> int:
        # time.time() is timezone independent and is the canonical process clock anchor.
        return int(time.time())

    @staticmethod
    def _iso_from_epoch(epoch: int | None) -> str:
        if epoch is None or epoch <= 0:
            return ""
        return datetime.fromtimestamp(int(epoch), tz=timezone.utc).isoformat()

    @staticmethod
    def _quantize_offset(delta_seconds: float) -> int:
        # Broker timezone offsets are normally 15/30/60 minute multiples. 15m is
        # conservative enough for non-hour offsets while rejecting second-level noise.
        return int(round(float(delta_seconds) / 900.0) * 900)

    def _model(self, symbol: Optional[str] = None) -> Dict[str, Any]:
        sym = symbol or self.symbol
        return self._clock_models.setdefault(sym, {
            "tick_offset_seconds": 0,
            "tick_offset_source": "mt5_utc_epoch_default",
            "bar_offset_seconds": 0,
            "bar_offset_source": "mt5_utc_epoch_default",
            "calibrated": False,
            "calibrated_utc": None,
            "tick_raw_epoch": None,
            "tick_normalized_epoch": None,
            "bar_raw_epoch": None,
            "bar_normalized_epoch": None,
            "warnings": [],
        })

    def _import_mt5(self):
        if self.mt5 is None:
            try:
                import MetaTrader5 as mt5  # type: ignore
            except Exception as exc:
                raise RuntimeError(
                    "MetaTrader5 Python package is not available. Install on Windows with: pip install MetaTrader5"
                ) from exc
            self.mt5 = mt5
        return self.mt5

    def _initialize(self) -> None:
        if self._initialized:
            return
        mt5 = self._import_mt5()
        kwargs: Dict[str, Any] = {"timeout": self.timeout, "portable": self.portable}
        if self.terminal_path:
            kwargs["path"] = self.terminal_path
        if self.login is not None:
            kwargs["login"] = int(self.login)
        if self.password:
            kwargs["password"] = self.password
        if self.server:
            kwargs["server"] = self.server
        ok = mt5.initialize(**kwargs)
        if not ok:
            code, msg = mt5.last_error()
            raise RuntimeError(f"MT5 initialize failed: {code} {msg}")
        if not mt5.symbol_select(self.symbol, True):
            code, msg = mt5.last_error()
            raise RuntimeError(f"MT5 symbol_select failed for {self.symbol}: {code} {msg}")
        self._initialized = True

    def _tf_const(self, label_or_const: str):
        mt5 = self._import_mt5()
        key = str(label_or_const).upper()
        attr = self.TIMEFRAME_MAP.get(key, key)
        if not hasattr(mt5, attr):
            raise ValueError(f"Unsupported MT5 timeframe: {label_or_const}")
        return getattr(mt5, attr)

    def _read_latest_bar_raw(self, timeframe: str = "M5") -> Optional[int]:
        try:
            mt5 = self._import_mt5()
            rates = mt5.copy_rates_from_pos(self.symbol, self._tf_const(timeframe), 0, 2)
            if rates is None or len(rates) == 0:
                return None
            return int(rates[-1][0])
        except Exception:
            return None

    def _calibrate_clock_models(self, force: bool = False) -> None:
        """Calibrate tick and bar clocks independently for the current symbol.

        We only apply an offset when a raw timestamp is materially in the *future*
        relative to the process UTC epoch. Old bars are never "fixed" by adding time;
        old bars are a history synchronization/data freshness problem, not a timezone
        problem. This prevents false-fresh execution data.
        """
        model = self._model()
        if model.get("calibrated") and not force:
            return
        self._initialize()

        mt5 = self._import_mt5()
        now_s = self._system_epoch()
        warnings: List[str] = []

        tick = mt5.symbol_info_tick(self.symbol)
        tick_raw = int(getattr(tick, "time", 0) or 0) if tick is not None else 0
        bar_raw = self._read_latest_bar_raw("M5") or 0

        tick_offset = 0
        tick_source = "mt5_utc_epoch_default"
        if tick_raw > 0:
            delta = tick_raw - now_s
            if 10 * 60 <= delta <= 14 * 3600:
                q = self._quantize_offset(delta)
                if 10 * 60 <= q <= 14 * 3600:
                    tick_offset = q
                    tick_source = "future_tick_wall_clock_inferred"
            elif delta > 14 * 3600:
                warnings.append(f"tick_epoch_extreme_future_delta={delta}")

        bar_offset = 0
        bar_source = "mt5_utc_epoch_default"
        if bar_raw > 0:
            delta = bar_raw - now_s
            # Bars and ticks may have different encodings on broker bridges.
            if 10 * 60 <= delta <= 14 * 3600:
                q = self._quantize_offset(delta)
                if 10 * 60 <= q <= 14 * 3600:
                    bar_offset = q
                    bar_source = "future_bar_wall_clock_inferred"
            elif delta > 14 * 3600:
                warnings.append(f"bar_epoch_extreme_future_delta={delta}")

        tick_norm = tick_raw - tick_offset if tick_raw else None
        bar_norm = bar_raw - bar_offset if bar_raw else None

        model.update({
            "tick_offset_seconds": int(tick_offset),
            "tick_offset_source": tick_source,
            "bar_offset_seconds": int(bar_offset),
            "bar_offset_source": bar_source,
            "calibrated": True,
            "calibrated_utc": self._iso_from_epoch(now_s),
            "system_epoch": now_s,
            "system_utc": self._iso_from_epoch(now_s),
            "tick_raw_epoch": tick_raw or None,
            "tick_raw_utc_interpretation": self._iso_from_epoch(tick_raw or None),
            "tick_normalized_epoch": tick_norm,
            "tick_normalized_utc": self._iso_from_epoch(tick_norm),
            "bar_raw_epoch": bar_raw or None,
            "bar_raw_utc_interpretation": self._iso_from_epoch(bar_raw or None),
            "bar_normalized_epoch": bar_norm,
            "bar_normalized_utc": self._iso_from_epoch(bar_norm),
            "tick_bar_raw_delta_seconds": (tick_raw - bar_raw) if tick_raw and bar_raw else None,
            "tick_bar_normalized_delta_seconds": (tick_norm - bar_norm) if tick_norm and bar_norm else None,
            "warnings": warnings,
        })

    def _normalize_tick_epoch(self, ts: Any) -> Optional[int]:
        try:
            self._calibrate_clock_models()
            raw = int(ts)
            return raw - int(self._model().get("tick_offset_seconds") or 0)
        except Exception:
            return None

    def _normalize_bar_epoch(self, ts: Any) -> Optional[int]:
        try:
            self._calibrate_clock_models()
            raw = int(ts)
            return raw - int(self._model().get("bar_offset_seconds") or 0)
        except Exception:
            return None

    def _tick_to_iso(self, ts: Any) -> str:
        return self._iso_from_epoch(self._normalize_tick_epoch(ts))

    def _bar_to_iso(self, ts: Any) -> str:
        return self._iso_from_epoch(self._normalize_bar_epoch(ts))

    def _fetch_rates_array(self, timeframe: str, limit: int):
        mt5 = self._import_mt5()
        return mt5.copy_rates_from_pos(self.symbol, self._tf_const(timeframe), 0, int(limit))

    def _history_refresh(self, timeframe: str, limit: int) -> Tuple[Any, Dict[str, Any]]:
        """Bounded best-effort MT5 history refresh without fabricating bars."""
        mt5 = self._import_mt5()
        diag: Dict[str, Any] = {
            "attempted": True,
            "timeframe": timeframe,
            "attempts": [],
            "result": "unknown",
        }
        best = None
        for attempt in range(1, 4):
            try:
                mt5.symbol_select(self.symbol, True)
                # copy_rates_from with an explicit UTC anchor can prompt the terminal to
                # request history for the current window on some broker terminals.
                anchor = datetime.now(timezone.utc) + timedelta(minutes=2)
                explicit = mt5.copy_rates_from(self.symbol, self._tf_const(timeframe), anchor, int(limit))
                positional = self._fetch_rates_array(timeframe, limit)
                candidates = [x for x in (explicit, positional) if x is not None and len(x) > 0]
                if candidates:
                    current = max(candidates, key=lambda arr: int(arr[-1][0]))
                    if best is None or int(current[-1][0]) > int(best[-1][0]):
                        best = current
                    diag["attempts"].append({
                        "attempt": attempt,
                        "last_raw_epoch": int(current[-1][0]),
                        "bars": int(len(current)),
                        "last_error": mt5.last_error(),
                    })
                else:
                    diag["attempts"].append({"attempt": attempt, "bars": 0, "last_error": mt5.last_error()})
            except Exception as exc:
                diag["attempts"].append({"attempt": attempt, "error": str(exc), "last_error": mt5.last_error()})
            if attempt < 3:
                time.sleep(0.35 * attempt)
        diag["result"] = "history_returned" if best is not None else "no_history"
        return best, diag

    def _rows_from_rates(self, timeframe: str, rates: Any) -> List[Dict[str, Any]]:
        """Convert MT5 rates into normalized row dictionaries.

        MetaTrader5 normally returns a NumPy structured ndarray.  Such arrays
        must never be used in boolean context (``rates or []`` raises
        ``ValueError: truth value of an array is ambiguous``).  This parser
        therefore handles None, empty ndarrays, structured records, and plain
        sequences explicitly.
        """
        rows: List[Dict[str, Any]] = []
        if rates is None:
            return rows

        try:
            rate_count = len(rates)
        except TypeError:
            rate_count = 0
        if rate_count == 0:
            return rows

        model = self._model()
        dtype = getattr(rates, "dtype", None)
        names = tuple(getattr(dtype, "names", ()) or ())
        name_set = set(names)

        def field(record: Any, name: str, index: int, default: float = 0.0) -> Any:
            if name in name_set:
                try:
                    return record[name]
                except (KeyError, IndexError, TypeError, ValueError):
                    pass
            try:
                return record[index]
            except (KeyError, IndexError, TypeError, ValueError):
                return default

        for r in rates:
            raw_time = field(r, "time", 0, 0)
            try:
                raw_epoch = int(raw_time)
            except (TypeError, ValueError, OverflowError):
                continue
            if raw_epoch <= 0:
                continue

            tick_volume = float(field(r, "tick_volume", 5, 0.0) or 0.0)
            spread_points = float(field(r, "spread", 6, 0.0) or 0.0)
            real_volume = float(field(r, "real_volume", 7, 0.0) or 0.0)
            norm_epoch = self._normalize_bar_epoch(raw_epoch)

            rows.append({
                "time": self._iso_from_epoch(norm_epoch),
                "normalized_time_epoch": norm_epoch,
                "raw_time_epoch": raw_epoch,
                "bar_time_offset_seconds": int(model.get("bar_offset_seconds") or 0),
                "bar_time_offset_source": model.get("bar_offset_source"),
                "open": float(field(r, "open", 1, 0.0) or 0.0),
                "high": float(field(r, "high", 2, 0.0) or 0.0),
                "low": float(field(r, "low", 3, 0.0) or 0.0),
                "close": float(field(r, "close", 4, 0.0) or 0.0),
                "volume": real_volume if real_volume > 0 else tick_volume,
                "tick_volume": tick_volume,
                "real_volume": real_volume,
                "spread": spread_points,
                "mt5_timeframe": timeframe,
            })
        return rows

    def fetch_rates(self, timeframe: str, limit: int) -> List[Dict[str, Any]]:
        self._initialize()
        self._calibrate_clock_models()
        mt5 = self._import_mt5()
        rates = self._fetch_rates_array(timeframe, limit)
        if rates is None:
            code, msg = mt5.last_error()
            raise RuntimeError(f"MT5 copy_rates_from_pos failed for {self.symbol} {timeframe}: {code} {msg}")
        rows = self._rows_from_rates(timeframe, rates)
        self._last_health[timeframe] = {
            "candles": len(rows),
            "last_time": rows[-1]["time"] if rows else None,
            "last_raw_epoch": rows[-1]["raw_time_epoch"] if rows else None,
        }
        return rows

    def _assess_history_vs_tick(self, out: Dict[str, List[Dict[str, Any]]]) -> Dict[str, Any]:
        self._calibrate_clock_models(force=True)
        mt5 = self._import_mt5()
        tick = mt5.symbol_info_tick(self.symbol)
        tick_raw = int(getattr(tick, "time", 0) or 0) if tick is not None else 0
        tick_norm = self._normalize_tick_epoch(tick_raw) if tick_raw else None
        now_s = self._system_epoch()
        tick_age = (now_s - tick_norm) if tick_norm else None
        m5 = out.get("M5") or []
        m15 = out.get("M15") or []
        m5_epoch = m5[-1].get("normalized_time_epoch") if m5 else None
        m15_epoch = m15[-1].get("normalized_time_epoch") if m15 else None
        tick_fresh = tick_age is not None and -120 <= tick_age <= 300
        m5_gap = (tick_norm - int(m5_epoch)) if tick_norm and m5_epoch else None
        m15_gap = (tick_norm - int(m15_epoch)) if tick_norm and m15_epoch else None
        suspected = bool(tick_fresh and m5_gap is not None and m5_gap > 30 * 60)
        return {
            "suspected": suspected,
            "tick_fresh": tick_fresh,
            "tick_age_seconds": tick_age,
            "tick_normalized_utc": self._iso_from_epoch(tick_norm),
            "m5_last_utc": self._iso_from_epoch(int(m5_epoch)) if m5_epoch else None,
            "m15_last_utc": self._iso_from_epoch(int(m15_epoch)) if m15_epoch else None,
            "tick_to_m5_gap_seconds": m5_gap,
            "tick_to_m15_gap_seconds": m15_gap,
        }

    def fetch_multi_timeframe(self, timeframes: Dict[str, str], count: int) -> Dict[str, List[Dict[str, Any]]]:
        self._initialize()
        self._calibrate_clock_models(force=True)
        out: Dict[str, List[Dict[str, Any]]] = {}
        for label, tf in timeframes.items():
            out[label] = self.fetch_rates(tf, count)

        sync = self._assess_history_vs_tick(out)
        if sync.get("suspected"):
            refresh_diag: Dict[str, Any] = {}
            for label in ("M5", "M15", "H1"):
                tf = timeframes.get(label)
                if not tf:
                    continue
                refreshed, diag = self._history_refresh(tf, count)
                refresh_diag[label] = diag
                if refreshed is not None and len(refreshed) > 0:
                    new_rows = self._rows_from_rates(tf, refreshed)
                    if new_rows and (not out.get(label) or new_rows[-1]["time"] > out[label][-1]["time"]):
                        out[label] = new_rows
            sync_after = self._assess_history_vs_tick(out)
            sync.update({
                "refresh_attempted": True,
                "refresh": refresh_diag,
                "after_refresh": sync_after,
                "resolved": not bool(sync_after.get("suspected")),
            })
        else:
            sync.update({"refresh_attempted": False, "resolved": True})
        self._history_sync = sync
        return out

    def fetch_related_multi_timeframe(self, related: Dict[str, str], timeframes: Dict[str, str], count: int):
        out: Dict[str, Dict[str, List[Dict[str, Any]]]] = {}
        main = self.symbol
        for name, sym in related.items():
            tfmap: Dict[str, List[Dict[str, Any]]] = {}
            try:
                self.symbol = sym
                self._initialized = False
                self._model(sym)["calibrated"] = False
                for label, tf in timeframes.items():
                    tfmap[label] = self.fetch_rates(tf, min(count, 700))
            except Exception:
                for label in timeframes:
                    tfmap[label] = []
            finally:
                self.symbol = main
                self._initialized = False
            out[name] = tfmap
        self._initialize()
        self._calibrate_clock_models(force=True)
        return out

    def market_microstructure(self) -> Dict[str, Any]:
        self._initialize()
        self._calibrate_clock_models(force=True)
        mt5 = self._import_mt5()
        info = mt5.symbol_info(self.symbol)
        tick = mt5.symbol_info_tick(self.symbol)
        model = self._model()
        micro: Dict[str, Any] = {
            "symbol": self.symbol,
            "provider": self.name,
            "system_epoch": self._system_epoch(),
            "system_utc": self._iso_from_epoch(self._system_epoch()),
            "time_sync": dict(model),
            "history_sync": dict(self._history_sync),
        }
        if info is not None:
            d = info._asdict()
            micro.update({
                "digits": d.get("digits"), "point": d.get("point"),
                "trade_contract_size": d.get("trade_contract_size"), "currency_profit": d.get("currency_profit"),
                "spread_points": d.get("spread"), "spread_float": d.get("spread_float"),
                "trade_mode": d.get("trade_mode"), "trade_stops_level": d.get("trade_stops_level"),
                "trade_freeze_level": d.get("trade_freeze_level"), "trade_tick_size": d.get("trade_tick_size"),
                "trade_tick_value": d.get("trade_tick_value"), "volume_min": d.get("volume_min"),
                "volume_max": d.get("volume_max"), "volume_step": d.get("volume_step"),
                "session_deals": d.get("session_deals"), "session_buy_orders": d.get("session_buy_orders"),
                "session_sell_orders": d.get("session_sell_orders"), "session_volume": d.get("session_volume"),
                "session_turnover": d.get("session_turnover"),
                "select": d.get("select"), "visible": d.get("visible"),
            })
        if tick is not None:
            td = tick._asdict()
            bid = float(td.get("bid") or 0.0)
            ask = float(td.get("ask") or 0.0)
            last = float(td.get("last") or 0.0)
            raw_epoch = int(td.get("time") or 0)
            norm_epoch = self._normalize_tick_epoch(raw_epoch)
            micro.update({
                "time": self._iso_from_epoch(norm_epoch),
                "normalized_time_epoch": norm_epoch,
                "raw_time_epoch": raw_epoch,
                "raw_time_utc_interpretation": self._iso_from_epoch(raw_epoch),
                "tick_time_offset_seconds": int(model.get("tick_offset_seconds") or 0),
                "tick_time_offset_source": model.get("tick_offset_source"),
                # Backward compatible aliases used by existing reports.
                "server_time_offset_seconds": int(model.get("tick_offset_seconds") or 0),
                "server_time_offset_source": model.get("tick_offset_source"),
                "time_msc": td.get("time_msc"), "flags": td.get("flags"),
                "best_bid": bid, "best_ask": ask, "last": last,
                "spread": round(ask - bid, 8) if bid and ask else None,
                "bid_qty": float(td.get("volume_real") or td.get("volume") or 0.0), "ask_qty": None,
            })
        point = float(micro.get("point") or 0.01)
        spread = micro.get("spread")
        micro["spread_ok"] = True if spread is None else float(spread) <= max(point * 80, 0.80)

        try:
            if mt5.market_book_add(self.symbol):
                book = mt5.market_book_get(self.symbol) or []
                bids, asks = [], []
                for row in book:
                    rd = row._asdict()
                    price = float(rd.get("price") or 0.0)
                    volume = float(rd.get("volume_real") or rd.get("volume") or 0.0)
                    typ = int(rd.get("type") or 0)
                    item = {"price": price, "qty": volume, "notional": round(price * volume, 3)}
                    if typ in (1, 3): bids.append(item)
                    elif typ in (2, 4): asks.append(item)
                bid_notional = sum(x["notional"] for x in bids[:20])
                ask_notional = sum(x["notional"] for x in asks[:20])
                total = bid_notional + ask_notional
                micro.update({
                    "depth_available": bool(book),
                    "depth_top20_bid_notional": round(bid_notional, 3),
                    "depth_top20_ask_notional": round(ask_notional, 3),
                    "depth_imbalance": round((bid_notional - ask_notional) / total, 4) if total else 0.0,
                    "largest_bid_levels": sorted(bids, key=lambda x: x["notional"], reverse=True)[:8],
                    "largest_ask_levels": sorted(asks, key=lambda x: x["notional"], reverse=True)[:8],
                })
                mt5.market_book_release(self.symbol)
            else:
                micro["depth_available"] = False
                micro["depth_note"] = "Broker/terminal did not provide market book for this symbol."
        except Exception as exc:
            micro["depth_available"] = False
            micro["depth_error"] = str(exc)

        try:
            utc_from = datetime.now(timezone.utc) - timedelta(minutes=45)
            ticks = mt5.copy_ticks_from(self.symbol, utc_from, 3000, mt5.COPY_TICKS_ALL)
            if ticks is not None and len(ticks) > 0:
                buy = sell = 0.0
                prev = None
                for t in ticks:
                    price = float(t[3]) if len(t) > 3 else 0.0
                    vol = float(t[7]) if len(t) > 7 else 1.0
                    if prev is not None:
                        if price > prev: buy += vol
                        elif price < prev: sell += vol
                    prev = price
                total = buy + sell
                micro["recent_trade_buy_qty"] = round(buy, 6)
                micro["recent_trade_sell_qty"] = round(sell, 6)
                micro["recent_trade_delta"] = round(buy - sell, 6)
                micro["recent_trade_imbalance"] = round((buy - sell) / total, 4) if total else 0.0
                micro["tick_count"] = int(len(ticks))
                prices = [float(t[3]) for t in ticks if len(t) > 3 and float(t[3]) > 0]
                if prices:
                    micro["recent_tick_price_range"] = round(max(prices) - min(prices), 8)
                    changes = sum(1 for a, b in zip(prices, prices[1:]) if a != b)
                    micro["recent_tick_change_count"] = int(changes)
                    micro["recent_tick_rate_per_minute"] = round(len(prices) / 45.0, 3)
                    path = sum(abs(b-a) for a, b in zip(prices, prices[1:]))
                    net = abs(prices[-1] - prices[0]) if len(prices) > 1 else 0.0
                    micro["recent_tick_efficiency"] = round(net / path, 4) if path > 0 else 0.0
        except Exception as exc:
            micro["ticks_error"] = str(exc)
        return micro

    def health(self) -> ProviderHealth:
        try:
            self._initialize()
            self._calibrate_clock_models(force=True)
            mt5 = self._import_mt5()
            info = mt5.terminal_info()
            acc = mt5.account_info()
            model = self._model()
            details = {
                "last_fetch": self._last_health,
                "terminal": info._asdict() if info else None,
                "account": {k: v for k, v in (acc._asdict().items() if acc else []) if k in {"login", "server", "company", "currency", "leverage"}},
                "time_normalization": {
                    "policy": "independent_tick_bar_clock_models",
                    "tick_offset_seconds": int(model.get("tick_offset_seconds") or 0),
                    "tick_offset_source": model.get("tick_offset_source"),
                    "bar_offset_seconds": int(model.get("bar_offset_seconds") or 0),
                    "bar_offset_source": model.get("bar_offset_source"),
                    "system_utc": model.get("system_utc"),
                    "tick_raw_epoch": model.get("tick_raw_epoch"),
                    "tick_normalized_utc": model.get("tick_normalized_utc"),
                    "bar_raw_epoch": model.get("bar_raw_epoch"),
                    "bar_normalized_utc": model.get("bar_normalized_utc"),
                    "warnings": model.get("warnings", []),
                },
                "history_sync": dict(self._history_sync),
            }
            ok = bool(info is None or getattr(info, "connected", True))
            msg = "MetaTrader 5 live connection OK" if ok else "MetaTrader 5 terminal is not connected"
            return ProviderHealth(self.name, ok, self.symbol, msg, details)
        except Exception as exc:
            return ProviderHealth(self.name, False, self.symbol, str(exc), {"last_fetch": self._last_health, "history_sync": self._history_sync})
