from __future__ import annotations
from pathlib import Path
from typing import Any, Dict, List
import json


def write_outputs(output_dir: str, ctx, debug_full: bool = False) -> Path:
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    data = ctx.to_dict()
    decision = data.get('fusion_context', {}).get('institutional_decision_packet', {})
    write_final_outputs(output_dir, decision)
    if debug_full:
        (out / 'latest_internal_debug.json').write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    return out


def write_final_outputs(output_dir: str, decision: Dict[str, Any]) -> Path:
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    (out / 'latest_final_decision.json').write_text(json.dumps(decision, ensure_ascii=False, indent=2), encoding='utf-8')
    (out / 'latest_final_decision.txt').write_text(render_final_summary(decision), encoding='utf-8')
    (out / 'latest_chatgpt_prompt.txt').write_text(render_chatgpt_prompt(decision), encoding='utf-8')
    (out / 'latest_paper_test_plan.json').write_text(json.dumps(decision.get('paper_test', {}), ensure_ascii=False, indent=2), encoding='utf-8')
    (out / 'latest_paper_test_plan.txt').write_text(render_paper_test_plan(decision), encoding='utf-8')
    return out


def _line_value(value: Any) -> str:
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False)
    return str(value)


def render_final_summary(d: Dict[str, Any]) -> str:
    if not d:
        return 'No final decision packet was generated.'
    dec = d.get('decision', {}) or {}
    spot = dec.get('spot', {}) or {}
    scalp = dec.get('scalp', {}) or {}
    macro = d.get('macro_context', {}) or {}
    regime = d.get('market_regime', {}) or {}
    board = d.get('scoreboard', {}) or {}
    fusion = board.get('fusion', {}) or {}
    risk = board.get('risk', {}) or {}
    playbook = d.get('execution_playbook', {}) or {}
    ai = d.get('ai_inference', {}) or {}
    sm = d.get('execution_state_machine', {}) or {}
    canonical = d.get('canonical_execution', {}) or {}
    audit = d.get('consistency_audit', {}) or {}
    market_state = d.get('market_state', {}) or {}
    weekend = d.get('weekend_outlook', {}) or {}
    lines: List[str] = []
    lines.append('AMB GOLD UNIFIED NEWS+CHART FINAL ENGINE')
    lines.append('=' * 78)
    lines.append(f"Symbol: {d.get('symbol')} | Provider: {d.get('data_provider')} | UTC: {d.get('generated_utc')}")
    lines.append(f"Regime: {regime.get('name')} | Phase: {regime.get('phase')} | Playbook: {playbook.get('name')}")
    lines.append(f"Market: {market_state.get('status')} | Gate: {market_state.get('execution_gate')} | Data: {market_state.get('data_state')} | Quality: {market_state.get('data_quality_score')}")
    tc = market_state.get('time_coherence', {}) or {}
    lines.append(f"Time Sync: future_fault={tc.get('future_clock_fault')} | tick_offset_s={tc.get('tick_offset_seconds')} ({tc.get('tick_offset_source')}) | bar_offset_s={tc.get('bar_offset_seconds')} ({tc.get('bar_offset_source')})")
    hs = market_state.get('history_sync', {}) or {}
    lines.append(f"History Sync: suspected={hs.get('suspected')} | refresh_attempted={hs.get('refresh_attempted')} | resolved={hs.get('resolved')} | tick_to_m5_gap_s={hs.get('tick_to_m5_gap_seconds')}")
    if weekend.get('enabled'):
        lines.append(f"Weekend Outlook: side={weekend.get('directional_side')} regime={weekend.get('regime')} | EXECUTION DISABLED")
    lines.append(f"Macro: attached={macro.get('attached')} gold_bias={macro.get('gold_bias')} event_risk={(macro.get('event_risk') or {}).get('level')} confidence={macro.get('confidence')}")
    lines.append(f"Fusion/AI: long={fusion.get('long')} short={fusion.get('short')} bias={fusion.get('bias')} confidence={fusion.get('confidence')} model={fusion.get('model')}")
    lines.append(f"Execution State: {canonical.get('state') or ai.get('execution_state')} | Permission: {canonical.get('permission') or ai.get('trade_permission')} | Direction: {ai.get('direction')}")
    lines.append(f"Consistency: {audit.get('consistent')} | Issues: {audit.get('issues')}")
    lines.append(f"Execution SM: Spot={(sm.get('spot') or {}).get('state')} | Scalp={(sm.get('scalp') or {}).get('state')}")
    lines.append(f"Risk: {risk.get('level')} score={risk.get('score')} reasons={risk.get('reasons')}")
    lines.append('-' * 78)
    lines.append(f"SPOT: {spot.get('action')} | side={spot.get('side')}")
    lines.append(f"Primary entry: {spot.get('primary_entry')}")
    lines.append(f"Entry candidates: {spot.get('entry_zones')}")
    lines.append(f"Invalidation: {spot.get('invalidation')} | Targets: {spot.get('targets')}")
    lines.append(f"Reason: {spot.get('reason')}")
    if spot.get('action') == 'WAIT' and spot.get('watchlist_primary_entry'):
        lines.append(f"Spot watchlist zone: {spot.get('watchlist_primary_entry')}")
        lines.append(f"Spot watchlist invalidation: {spot.get('watchlist_invalidation')} | Targets: {spot.get('watchlist_targets')}")
    lines.append('-' * 78)
    lines.append(f"SCALP: {scalp.get('action')} | side={scalp.get('side')}")
    lines.append(f"Primary entry: {scalp.get('primary_entry')}")
    lines.append(f"Entry candidates: {scalp.get('entry_zones')}")
    lines.append(f"Invalidation: {scalp.get('invalidation')} | Targets: {scalp.get('targets')}")
    trig = scalp.get('trigger') or {}
    lines.append(f"Trigger ready: {trig.get('ready')} | {trig.get('reason')}")
    lines.append(f"Reason: {scalp.get('reason')}")
    if scalp.get('action') == 'WAIT' and scalp.get('watchlist_primary_entry'):
        lines.append(f"Scalp watchlist zone: {scalp.get('watchlist_primary_entry')}")
        lines.append(f"Scalp watchlist invalidation: {scalp.get('watchlist_invalidation')} | Targets: {scalp.get('watchlist_targets')}")
    paper = d.get('paper_test', {}) or {}
    if paper:
        ps = paper.get('spot', {}) or {}
        pc = paper.get('scalp', {}) or {}
        lines.append('-' * 78)
        lines.append(f"PAPER TEST: Spot={ps.get('status')} | Scalp={pc.get('status')} | mode={paper.get('mode')}")
        if pc.get('status') == 'PAPER_READY':
            lines.append(f"Scalp paper entry: {pc.get('entry')} | SL: {pc.get('invalidation')} | TP: {pc.get('targets')}")
    lines.append('-' * 78)
    lines.append('BLOCKERS')
    blockers = dec.get('blockers') or []
    if blockers:
        for b in blockers:
            lines.append(f"- {b}")
    else:
        lines.append('- none')
    warnings = dec.get('warnings') or []
    if warnings:
        lines.append('-' * 78)
        lines.append('WARNINGS')
        for w in warnings[:8]:
            lines.append(f"- {w}")
    lines.append('-' * 78)
    lines.append('TOP REASONS')
    for r in (d.get('reasons') or [])[:10]:
        lines.append(f"- {r}")
    return '\n'.join(lines)


def render_chatgpt_prompt(d: Dict[str, Any]) -> str:
    if not d:
        return 'No final decision packet was generated.'
    # Strictly compact LLM packet: decision + scores + reasons only.
    compact = {
        'contract': d.get('contract'),
        'symbol': d.get('symbol'),
        'generated_utc': d.get('generated_utc'),
        'hard_rules': d.get('hard_rules'),
        'market_regime': d.get('market_regime'),
        'market_state': d.get('market_state'),
        'weekend_outlook': d.get('weekend_outlook'),
        'macro_context': d.get('macro_context'),
        'scoreboard': d.get('scoreboard'),
        'execution_playbook': d.get('execution_playbook'),
        'ai_inference': d.get('ai_inference'),
        'execution_state_machine': d.get('execution_state_machine'),
        'canonical_execution': d.get('canonical_execution'),
        'consistency_audit': d.get('consistency_audit'),
        'decision': d.get('decision'),
        'paper_test': d.get('paper_test'),
        'reasons': (d.get('reasons') or [])[:10],
    }
    lines: List[str] = []
    lines.append('TASK: Give final Spot Gold and Scalp Gold decision from this unified News+Chart AI final packet.')
    lines.append('Rules: obey hard_rules; if market_state is not OPEN/ALLOW_EXECUTION, execution must be WAIT; PREPARE/watchlist/weekend outlook are not entries; do not invent entries outside packet.')
    lines.append('Output exactly: SPOT, SCALP, Entry, Invalidation, TP1/TP2/TP3, Trigger, 5 reasons.')
    lines.append('')
    lines.append(json.dumps(compact, ensure_ascii=False, indent=2))
    return '\n'.join(lines)


def render_paper_test_plan(d: Dict[str, Any]) -> str:
    paper = d.get('paper_test', {}) or {}
    lines: List[str] = []
    lines.append('AMB GOLD PAPER TEST PLAN - NO LIVE ORDERS')
    lines.append('=' * 78)
    lines.append(f"Symbol: {d.get('symbol')} | UTC: {d.get('generated_utc')} | Market: {(d.get('market_state') or {}).get('status')}")
    for style in ('spot', 'scalp'):
        c = paper.get(style, {}) or {}
        lines.append('-' * 78)
        lines.append(f"{style.upper()}: {c.get('status')} | action={c.get('action')} | state={c.get('setup_state')}")
        lines.append(f"Entry: {c.get('entry')}")
        lines.append(f"Invalidation: {c.get('invalidation')} | Targets: {c.get('targets')}")
        if style == 'scalp':
            trig = c.get('trigger') or {}
            lines.append(f"Trigger: ready={trig.get('ready')} | {trig.get('reason')}")
        lines.append(f"Reason: {c.get('reason')}")
    lines.append('-' * 78)
    lines.append('PAPER ONLY: this engine does not send orders to MetaTrader 5.')
    return '\n'.join(lines)


# Compatibility aliases used by older callers/tests.
def render_decision_summary(d: Dict[str, Any]) -> str:
    return render_final_summary(d)


def render_decision_prompt(d: Dict[str, Any]) -> str:
    return render_chatgpt_prompt(d)
