from __future__ import annotations

"""Local adaptive learning memory for AMB Gold.

This module provides a lightweight, offline, deterministic learning layer that can
run inside Termux. It does not need sklearn, TensorFlow, OpenAI, or paid APIs.

What it learns:
- feature multipliers for the local AI fusion model
- decision thresholds for spot/scalp permissions
- recent prediction history and calibration metrics

How it learns:
- every decision can be registered as a pending prediction
- after the market moves, the user or auto-evaluator records an outcome
- the feature weights are nudged based on whether the contributing evidence was
  aligned with the realized market direction
- confidence and threshold stats are updated over time

This is not a magic predictive model. It is an online calibration layer that makes
fixed-weight fusion adaptive to the user's observed market/data environment.
"""

from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
import hashlib
import json
import math


DEFAULT_FEATURE_WEIGHTS: Dict[str, float] = {
    "technical_probability": 1.00,
    "macro_direction": 1.00,
    "market_regime": 1.00,
    "playbook_state": 1.00,
    "execution_trigger": 1.00,
    "orderflow_microstructure": 1.00,
}

DEFAULT_THRESHOLDS: Dict[str, float] = {
    "spot_confidence": 32.0,
    "scalp_confidence": 38.0,
    "ready_confidence": 30.0,
    "execute_confidence": 35.0,
    "max_risk_for_entry": 54.0,
}


@dataclass
class LearningProfile:
    version: str
    enabled: bool
    feature_multipliers: Dict[str, float]
    thresholds: Dict[str, float]
    metrics: Dict[str, Any]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class LearningMemory:
    def __init__(self, state_dir: str | Path = "state") -> None:
        self.state_dir = Path(state_dir)
        self.state_dir.mkdir(parents=True, exist_ok=True)
        self.state_path = self.state_dir / "learning_state.json"
        self.pending_path = self.state_dir / "pending_predictions.jsonl"
        self.history_path = self.state_dir / "learning_history.jsonl"
        self.state = self._load_state()

    def _default_state(self) -> Dict[str, Any]:
        return {
            "version": "AMB_LEARNING_MEMORY_V1",
            "created_utc": datetime.now(timezone.utc).isoformat(),
            "updated_utc": datetime.now(timezone.utc).isoformat(),
            "feature_multipliers": dict(DEFAULT_FEATURE_WEIGHTS),
            "thresholds": dict(DEFAULT_THRESHOLDS),
            "metrics": {
                "samples": 0,
                "correct_direction": 0,
                "wrong_direction": 0,
                "flat_outcomes": 0,
                "win_rate": None,
                "mean_abs_error": None,
                "brier_score": None,
                "last_update_utc": None,
            },
            "notes": [
                "Local online calibration only; not financial advice.",
                "Requires repeated prediction/outcome cycles to become useful.",
            ],
        }

    def _load_state(self) -> Dict[str, Any]:
        if self.state_path.exists():
            try:
                with self.state_path.open("r", encoding="utf-8") as f:
                    data = json.load(f)
                data.setdefault("feature_multipliers", dict(DEFAULT_FEATURE_WEIGHTS))
                data.setdefault("thresholds", dict(DEFAULT_THRESHOLDS))
                data.setdefault("metrics", self._default_state()["metrics"])
                return data
            except Exception:
                backup = self.state_path.with_suffix(".broken.json")
                try:
                    self.state_path.replace(backup)
                except Exception:
                    pass
        st = self._default_state()
        self._save_state(st)
        return st

    def _save_state(self, state: Optional[Dict[str, Any]] = None) -> None:
        st = state or self.state
        st["updated_utc"] = datetime.now(timezone.utc).isoformat()
        tmp = self.state_path.with_suffix(".tmp")
        tmp.write_text(json.dumps(st, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self.state_path)

    def profile(self, enabled: bool = True) -> Dict[str, Any]:
        return LearningProfile(
            version=str(self.state.get("version", "AMB_LEARNING_MEMORY_V1")),
            enabled=bool(enabled),
            feature_multipliers={k: float(v) for k, v in self.state.get("feature_multipliers", {}).items()},
            thresholds={k: float(v) for k, v in self.state.get("thresholds", {}).items()},
            metrics=dict(self.state.get("metrics", {})),
        ).to_dict()

    def _append_jsonl(self, path: Path, row: Dict[str, Any]) -> None:
        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")

    def _read_jsonl(self, path: Path) -> List[Dict[str, Any]]:
        if not path.exists():
            return []
        rows: List[Dict[str, Any]] = []
        with path.open("r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                    if isinstance(obj, dict):
                        rows.append(obj)
                except Exception:
                    continue
        return rows

    def _rewrite_jsonl(self, path: Path, rows: List[Dict[str, Any]]) -> None:
        tmp = path.with_suffix(".tmp")
        with tmp.open("w", encoding="utf-8") as f:
            for row in rows:
                f.write(json.dumps(row, ensure_ascii=False) + "\n")
        tmp.replace(path)

    def register_prediction(self, decision: Dict[str, Any], horizon_minutes: int = 60) -> Dict[str, Any]:
        pred = make_prediction_record(decision, horizon_minutes=horizon_minutes)
        if not pred.get("prediction_id"):
            raise ValueError("Could not build prediction record from decision packet")
        # Do not duplicate exact prediction id.
        existing = self._read_jsonl(self.pending_path)
        if any(x.get("prediction_id") == pred["prediction_id"] for x in existing):
            return {"registered": False, "reason": "already_registered", "prediction_id": pred["prediction_id"]}
        self._append_jsonl(self.pending_path, pred)
        return {"registered": True, "prediction_id": pred["prediction_id"], "horizon_minutes": horizon_minutes}

    def record_outcome(
        self,
        *,
        prediction_id: str | None = None,
        decision: Optional[Dict[str, Any]] = None,
        close_price: Optional[float] = None,
        outcome_direction: Optional[str] = None,
        outcome_pct: Optional[float] = None,
        notes: str = "",
    ) -> Dict[str, Any]:
        pending = self._read_jsonl(self.pending_path)
        pred: Optional[Dict[str, Any]] = None
        if prediction_id:
            pred = next((x for x in pending if x.get("prediction_id") == prediction_id), None)
        if pred is None and decision:
            temp = make_prediction_record(decision)
            pid = temp.get("prediction_id")
            pred = next((x for x in pending if x.get("prediction_id") == pid), None) or temp
        if pred is None:
            raise ValueError("Prediction not found. Provide --prediction-id or --decision-file.")

        reference = _float(pred.get("reference_price"), None)
        if outcome_pct is None:
            if close_price is None or reference is None or reference == 0:
                raise ValueError("Provide --close-price or --outcome-pct for learning update.")
            outcome_pct = ((float(close_price) - reference) / reference) * 100.0
        realized = normalize_outcome_direction(outcome_direction, outcome_pct)
        update = self._apply_learning(pred, realized, float(outcome_pct), close_price=close_price, notes=notes)

        # Remove from pending if it was there.
        pending = [x for x in pending if x.get("prediction_id") != pred.get("prediction_id")]
        self._rewrite_jsonl(self.pending_path, pending)
        self._append_jsonl(self.history_path, update)
        self._save_state()
        return update

    def auto_evaluate_pending(self, current_price: float, min_age_minutes: int = 60) -> Dict[str, Any]:
        now = datetime.now(timezone.utc)
        pending = self._read_jsonl(self.pending_path)
        evaluated: List[Dict[str, Any]] = []
        keep: List[Dict[str, Any]] = []
        for pred in pending:
            created = parse_dt(pred.get("created_utc"))
            horizon = int(pred.get("horizon_minutes") or min_age_minutes)
            if created is None:
                keep.append(pred)
                continue
            age = (now - created).total_seconds() / 60.0
            if age >= max(min_age_minutes, horizon):
                reference = _float(pred.get("reference_price"), None)
                if reference:
                    pct = ((current_price - reference) / reference) * 100.0
                    realized = normalize_outcome_direction(None, pct)
                    upd = self._apply_learning(pred, realized, pct, close_price=current_price, notes="auto_evaluated")
                    evaluated.append(upd)
                    self._append_jsonl(self.history_path, upd)
                else:
                    keep.append(pred)
            else:
                keep.append(pred)
        self._rewrite_jsonl(self.pending_path, keep)
        if evaluated:
            self._save_state()
        return {"evaluated": len(evaluated), "remaining_pending": len(keep), "updates": evaluated[:5]}

    def _apply_learning(self, pred: Dict[str, Any], realized: str, outcome_pct: float, close_price: Optional[float], notes: str) -> Dict[str, Any]:
        predicted = str(pred.get("direction") or "neutral")
        probs = pred.get("probabilities") or {}
        p_long = _float(probs.get("long"), 50.0) / 100.0
        p_short = _float(probs.get("short"), 50.0) / 100.0
        if realized == "long":
            actual_prob_long = 1.0
        elif realized == "short":
            actual_prob_long = 0.0
        else:
            actual_prob_long = 0.5
        brier = (p_long - actual_prob_long) ** 2
        correct = (predicted == realized) if realized in {"long", "short"} else False
        flat = realized == "flat"
        abs_error = abs((p_long if predicted == "long" else p_short) - (1.0 if correct else 0.0))

        # Adaptive weight update.
        # Features aligned with the realized direction are rewarded when the move is non-flat.
        # Features that voted against the realized direction are penalized. Flat outcomes slightly
        # decay all aggressive directional features toward 1.0.
        lr_base = 0.035
        move_strength = min(1.0, abs(outcome_pct) / 0.35)  # XAUT/XAU scalps often move <0.35%.
        multipliers = self.state.setdefault("feature_multipliers", dict(DEFAULT_FEATURE_WEIGHTS))
        feature_updates: Dict[str, Dict[str, float]] = {}
        for feat in pred.get("features", []):
            if not isinstance(feat, dict):
                continue
            name = str(feat.get("name") or "")
            if not name:
                continue
            feat_side = normalize_side(str(feat.get("side") or "neutral"))
            old = float(multipliers.get(name, DEFAULT_FEATURE_WEIGHTS.get(name, 1.0)))
            if realized == "flat" or feat_side == "neutral":
                delta = (1.0 - old) * 0.015
            elif feat_side == realized:
                delta = lr_base * move_strength * max(0.25, abs(_float(feat.get("contribution"), 0.0)))
            else:
                delta = -lr_base * move_strength * max(0.25, abs(_float(feat.get("contribution"), 0.0)))
            new = clamp(old + delta, 0.55, 1.65)
            multipliers[name] = round(new, 5)
            feature_updates[name] = {"old": round(old, 5), "new": round(new, 5), "delta": round(new - old, 5)}

        # Threshold calibration: if many wrong decisions happen, become more conservative;
        # if correct and strong, cautiously allow lower thresholds.
        thresholds = self.state.setdefault("thresholds", dict(DEFAULT_THRESHOLDS))
        if realized in {"long", "short"}:
            if correct:
                thresholds["spot_confidence"] = round(clamp(float(thresholds.get("spot_confidence", 32.0)) - 0.08 * move_strength, 28.0, 42.0), 3)
                thresholds["scalp_confidence"] = round(clamp(float(thresholds.get("scalp_confidence", 38.0)) - 0.08 * move_strength, 34.0, 48.0), 3)
            else:
                thresholds["spot_confidence"] = round(clamp(float(thresholds.get("spot_confidence", 32.0)) + 0.16 * move_strength, 28.0, 42.0), 3)
                thresholds["scalp_confidence"] = round(clamp(float(thresholds.get("scalp_confidence", 38.0)) + 0.16 * move_strength, 34.0, 48.0), 3)

        self._update_metrics(correct=correct, flat=flat, abs_error=abs_error, brier=brier)
        return {
            "type": "learning_update",
            "prediction_id": pred.get("prediction_id"),
            "created_utc": pred.get("created_utc"),
            "updated_utc": datetime.now(timezone.utc).isoformat(),
            "predicted_direction": predicted,
            "realized_direction": realized,
            "reference_price": pred.get("reference_price"),
            "close_price": close_price,
            "outcome_pct": round(outcome_pct, 6),
            "correct": bool(correct),
            "flat": bool(flat),
            "brier": round(brier, 6),
            "feature_updates": feature_updates,
            "thresholds": dict(thresholds),
            "metrics": dict(self.state.get("metrics", {})),
            "notes": notes,
        }

    def _update_metrics(self, *, correct: bool, flat: bool, abs_error: float, brier: float) -> None:
        m = self.state.setdefault("metrics", self._default_state()["metrics"])
        n = int(m.get("samples") or 0)
        n2 = n + 1
        m["samples"] = n2
        if correct:
            m["correct_direction"] = int(m.get("correct_direction") or 0) + 1
        elif flat:
            m["flat_outcomes"] = int(m.get("flat_outcomes") or 0) + 1
        else:
            m["wrong_direction"] = int(m.get("wrong_direction") or 0) + 1
        decisive = max(1, int(m.get("correct_direction") or 0) + int(m.get("wrong_direction") or 0))
        m["win_rate"] = round((int(m.get("correct_direction") or 0) / decisive) * 100.0, 2)
        m["mean_abs_error"] = running_mean(_float(m.get("mean_abs_error"), 0.0), abs_error, n)
        m["brier_score"] = running_mean(_float(m.get("brier_score"), 0.0), brier, n)
        m["last_update_utc"] = datetime.now(timezone.utc).isoformat()


def make_prediction_record(decision: Dict[str, Any], horizon_minutes: int = 60) -> Dict[str, Any]:
    ai = decision.get("ai_inference") or {}
    market = decision.get("market_snapshot") or {}
    ref = _float(market.get("reference_price"), None)
    if ref is None:
        ref = infer_reference_from_decision(decision)
    payload = {
        "contract": "AMB_LEARNING_PREDICTION_V1",
        "created_utc": decision.get("generated_utc") or datetime.now(timezone.utc).isoformat(),
        "horizon_minutes": int(horizon_minutes),
        "symbol": decision.get("symbol"),
        "direction": normalize_side(str(ai.get("direction") or decision.get("scoreboard", {}).get("fusion", {}).get("bias") or "neutral")),
        "execution_state": ai.get("execution_state"),
        "trade_permission": ai.get("trade_permission"),
        "confidence": _float(ai.get("confidence"), 0.0),
        "probabilities": {
            "long": _float(ai.get("long_probability"), 50.0),
            "short": _float(ai.get("short_probability"), 50.0),
        },
        "reference_price": ref,
        "features": ai.get("features") or [],
        "decision_actions": {
            "spot": (decision.get("decision") or {}).get("spot", {}).get("action"),
            "scalp": (decision.get("decision") or {}).get("scalp", {}).get("action"),
        },
    }
    seed = json.dumps({k: payload[k] for k in ("created_utc", "symbol", "direction", "reference_price", "confidence")}, sort_keys=True)
    payload["prediction_id"] = hashlib.sha256(seed.encode("utf-8")).hexdigest()[:16]
    return payload


def register_prediction_from_decision(decision: Dict[str, Any], state_dir: str | Path = "state", horizon_minutes: int = 60) -> Dict[str, Any]:
    return LearningMemory(state_dir).register_prediction(decision, horizon_minutes=horizon_minutes)


def record_outcome_from_decision(
    decision: Dict[str, Any],
    state_dir: str | Path = "state",
    close_price: Optional[float] = None,
    outcome_direction: Optional[str] = None,
    outcome_pct: Optional[float] = None,
    notes: str = "",
) -> Dict[str, Any]:
    return LearningMemory(state_dir).record_outcome(decision=decision, close_price=close_price, outcome_direction=outcome_direction, outcome_pct=outcome_pct, notes=notes)


def normalize_side(side: str) -> str:
    s = str(side or "").lower()
    if s in {"long", "buy", "bullish"} or "bull" in s:
        return "long"
    if s in {"short", "sell", "bearish"} or "bear" in s:
        return "short"
    return "neutral"


def normalize_outcome_direction(outcome_direction: Optional[str], outcome_pct: Optional[float]) -> str:
    if outcome_direction:
        s = normalize_side(outcome_direction)
        if s in {"long", "short"}:
            return s
        if str(outcome_direction).lower() in {"flat", "neutral", "wait", "none"}:
            return "flat"
    pct = float(outcome_pct or 0.0)
    # Dead zone avoids treating tiny noise as a directional outcome.
    if pct > 0.035:
        return "long"
    if pct < -0.035:
        return "short"
    return "flat"


def infer_reference_from_decision(decision: Dict[str, Any]) -> Optional[float]:
    # Prefer explicit market snapshot. Fallback to first zone midpoint.
    for side in ("scalp", "spot"):
        d = (decision.get("decision") or {}).get(side) or {}
        zones = d.get("entry_zones") or []
        if zones and isinstance(zones[0], dict):
            lo = _float(zones[0].get("low"), None)
            hi = _float(zones[0].get("high"), None)
            lvl = _float(zones[0].get("level"), None)
            if lo is not None and hi is not None:
                return (lo + hi) / 2.0
            if lvl is not None:
                return lvl
    return None


def parse_dt(v: Any) -> Optional[datetime]:
    try:
        s = str(v or "")
        if not s:
            return None
        if s.endswith("Z"):
            s = s[:-1] + "+00:00"
        dt = datetime.fromisoformat(s)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except Exception:
        return None


def _float(v: Any, default: Optional[float] = 0.0) -> Optional[float]:
    try:
        if v is None or v == "":
            return default
        x = float(v)
        if math.isnan(x):
            return default
        return x
    except Exception:
        return default


def clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, float(v)))


def running_mean(old: float, new: float, n_old: int) -> float:
    return round(((old * n_old) + float(new)) / max(1, n_old + 1), 6)
