from __future__ import annotations
from typing import Any, Dict, List, Tuple


def _as_dict(value: Any) -> Dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _as_list(value: Any) -> List[Any]:
    return value if isinstance(value, list) else []


def _txt(value: Any) -> str:
    return str(value or '')


def _num(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return default


def _tf_weight(tf: str) -> float:
    return {'D1': 4.0, 'H4': 3.0, 'H1': 2.0, 'M15': 1.0, 'M5': 0.55}.get(tf, 1.0)


def probability_engine(contexts: Dict[str, Any], mtf: Dict[str, Any], micro: Dict[str, Any]) -> Dict[str, Any]:
    """Evidence-based probability, not blind indicator scoring.

    Output is intentionally conservative. A low confidence is useful: it tells ChatGPT
    not to force a scalp when chart evidence is conflicted.
    """
    long_score = 50.0
    short_score = 50.0
    reasons: List[str] = []
    evidence: List[Dict[str, Any]] = []

    for tf, ctx in contexts.items():
        w = _tf_weight(tf)
        trend = _txt(getattr(ctx, 'trend', ''))
        structure = _txt(getattr(ctx, 'structure', ''))
        momentum = _txt(getattr(ctx, 'momentum', ''))
        rsi = _num(getattr(ctx, 'rsi', None), 50)
        adv = _as_dict(getattr(ctx, 'advanced_structure', {}))
        mss = _as_dict(adv.get('mss'))
        events = _as_list(adv.get('events'))
        liq = _as_dict(getattr(ctx, 'liquidity', {}))
        sweeps = _as_list(liq.get('sweeps'))
        vp = _as_dict(getattr(ctx, 'volume_profile', {}))
        ofp = _as_dict(vp.get('order_flow_proxy'))
        ichi = _as_dict(getattr(ctx, 'ichimoku', {}))
        adv_ind = _as_dict(getattr(ctx, 'advanced_indicators', {}))
        pa = _as_dict(getattr(ctx, 'price_action', {}))

        # Trend and structure base.
        if 'bullish' in trend:
            long_score += 4.0 * w
            reasons.append(f'{tf} bullish trend')
            evidence.append({'tf': tf, 'side': 'long', 'kind': 'trend', 'weight': round(4*w, 2)})
        if 'bearish' in trend:
            short_score += 4.0 * w
            reasons.append(f'{tf} bearish trend')
            evidence.append({'tf': tf, 'side': 'short', 'kind': 'trend', 'weight': round(4*w, 2)})
        if structure.startswith('bullish'):
            long_score += 3.0 * w
            evidence.append({'tf': tf, 'side': 'long', 'kind': 'swing_structure', 'weight': round(3*w, 2)})
        if structure.startswith('bearish'):
            short_score += 3.0 * w
            evidence.append({'tf': tf, 'side': 'short', 'kind': 'swing_structure', 'weight': round(3*w, 2)})

        # Advanced BOS/CHOCH/MSS.
        mss_type = _txt(mss.get('type'))
        if mss_type.startswith('bullish'):
            add = 7.0 * w if mss.get('strength') == 'high' else 5.0 * w
            long_score += add
            reasons.append(f'{tf} {mss_type}')
            evidence.append({'tf': tf, 'side': 'long', 'kind': 'mss', 'weight': round(add, 2), 'detail': mss})
        if mss_type.startswith('bearish'):
            add = 7.0 * w if mss.get('strength') == 'high' else 5.0 * w
            short_score += add
            reasons.append(f'{tf} {mss_type}')
            evidence.append({'tf': tf, 'side': 'short', 'kind': 'mss', 'weight': round(add, 2), 'detail': mss})
        for ev in events[-4:]:
            et = _txt(_as_dict(ev).get('type'))
            disp = _num(_as_dict(ev).get('displacement_atr'), 0)
            add = (2.0 + min(disp, 2.0)) * w
            if et.endswith('UP'):
                long_score += add
                evidence.append({'tf': tf, 'side': 'long', 'kind': et, 'weight': round(add, 2)})
            if et.endswith('DOWN'):
                short_score += add
                evidence.append({'tf': tf, 'side': 'short', 'kind': et, 'weight': round(add, 2)})

        # Momentum. Overbought/oversold is not a reversal by itself; treat carefully.
        if momentum == 'bullish':
            long_score += 2.0 * w
        elif momentum == 'bearish':
            short_score += 2.0 * w
        elif momentum == 'oversold_bearish' and tf in ('M5', 'M15'):
            long_score += 0.8 * w  # scalp bounce potential only
            short_score += 1.2 * w
        elif momentum == 'overbought_bullish' and tf in ('M5', 'M15'):
            short_score += 0.8 * w
            long_score += 1.2 * w
        if rsi >= 60:
            long_score += 0.75 * w
        if rsi <= 40:
            short_score += 0.75 * w

        # Institutional indicator confluence: Ichimoku, SuperTrend, VWAP, StochRSI and candle signals.
        cloud_bias = _num(ichi.get('cloud_bias'), 0)
        tk_cross = _num(ichi.get('tk_cross'), 0)
        if cloud_bias > 0:
            long_score += 2.2 * w
            evidence.append({'tf': tf, 'side': 'long', 'kind': 'ichimoku_cloud_bullish', 'weight': round(2.2*w, 2)})
        elif cloud_bias < 0:
            short_score += 2.2 * w
            evidence.append({'tf': tf, 'side': 'short', 'kind': 'ichimoku_cloud_bearish', 'weight': round(2.2*w, 2)})
        if tk_cross > 0:
            long_score += 1.2 * w
        elif tk_cross < 0:
            short_score += 1.2 * w
        st_dir = _num(_as_dict(adv_ind.get('supertrend')).get('direction'), 0)
        if st_dir > 0:
            long_score += 2.4 * w
            evidence.append({'tf': tf, 'side': 'long', 'kind': 'supertrend_bullish', 'weight': round(2.4*w, 2)})
        elif st_dir < 0:
            short_score += 2.4 * w
            evidence.append({'tf': tf, 'side': 'short', 'kind': 'supertrend_bearish', 'weight': round(2.4*w, 2)})
        pvwap = _num(_as_dict(adv_ind.get('vwap')).get('price_vs_vwap'), 0)
        if pvwap > 0:
            long_score += min(1.8, abs(pvwap) / 4.0) * w
        elif pvwap < 0:
            short_score += min(1.8, abs(pvwap) / 4.0) * w
        sk = _num(_as_dict(adv_ind.get('stoch_rsi')).get('k'), 50)
        sd = _num(_as_dict(adv_ind.get('stoch_rsi')).get('d'), 50)
        if sk > sd and sk < 80:
            long_score += 0.8 * w
        elif sk < sd and sk > 20:
            short_score += 0.8 * w
        lc = _as_dict(pa.get('last_candle'))
        if lc.get('bullish_engulfing') or lc.get('bullish_pinbar'):
            long_score += 1.6 * w
            evidence.append({'tf': tf, 'side': 'long', 'kind': 'bullish_price_action', 'weight': round(1.6*w, 2)})
        if lc.get('bearish_engulfing') or lc.get('bearish_pinbar'):
            short_score += 1.6 * w
            evidence.append({'tf': tf, 'side': 'short', 'kind': 'bearish_price_action', 'weight': round(1.6*w, 2)})

        # Liquidity sweeps: sell-side sweep/rejection is long evidence; buy-side sweep/rejection is short evidence.
        for s in sweeps[-5:]:
            st = _txt(_as_dict(s).get('type'))
            if st.startswith('sell_side'):
                long_score += 2.2 * w
                evidence.append({'tf': tf, 'side': 'long', 'kind': 'sell_side_sweep_rejection', 'weight': round(2.2*w, 2)})
            if st.startswith('buy_side'):
                short_score += 2.2 * w
                evidence.append({'tf': tf, 'side': 'short', 'kind': 'buy_side_sweep_rejection', 'weight': round(2.2*w, 2)})

        # Volume/order-flow proxy.
        pressure = _txt(ofp.get('pressure'))
        imb = _num(ofp.get('imbalance'), 0)
        if pressure == 'buy_pressure':
            long_score += min(4.0, abs(imb) * 12) * w
        elif pressure == 'sell_pressure':
            short_score += min(4.0, abs(imb) * 12) * w

    micro = _as_dict(micro)
    depth_imb = micro.get('depth_imbalance')
    if isinstance(depth_imb, (float, int)):
        if depth_imb > 0.15:
            long_score += 5.0
            reasons.append('order book bid imbalance')
            evidence.append({'tf': 'micro', 'side': 'long', 'kind': 'depth_bid_imbalance', 'weight': 5.0})
        if depth_imb < -0.15:
            short_score += 5.0
            reasons.append('order book ask imbalance')
            evidence.append({'tf': 'micro', 'side': 'short', 'kind': 'depth_ask_imbalance', 'weight': 5.0})
    trade_imb = micro.get('recent_trade_imbalance')
    if isinstance(trade_imb, (float, int)):
        if trade_imb > 0.18:
            long_score += 3.0
            reasons.append('recent trades buy imbalance')
        if trade_imb < -0.18:
            short_score += 3.0
            reasons.append('recent trades sell imbalance')

    total = max(long_score + short_score, 1.0)
    long_prob = round(100 * long_score / total, 2)
    short_prob = round(100 * short_score / total, 2)
    confidence = round(abs(long_prob - short_prob), 2)
    bias = 'long' if long_prob > short_prob + 7 else ('short' if short_prob > long_prob + 7 else 'balanced')

    # Scalp readiness is stricter than directional bias.
    scalp_readiness = 'NO_TRADE'
    if confidence >= 22 and bias in ('long', 'short'):
        scalp_readiness = 'READY_AFTER_TRIGGER'
    elif confidence >= 12 and bias in ('long', 'short'):
        scalp_readiness = 'WATCH_FOR_TRIGGER'

    return {
        'long_probability': long_prob,
        'short_probability': short_prob,
        'bias': bias,
        'confidence': confidence,
        'scalp_readiness': scalp_readiness,
        'long_score_raw': round(long_score, 3),
        'short_score_raw': round(short_score, 3),
        'reasons': reasons[-16:],
        'top_evidence': sorted(evidence, key=lambda x: _num(x.get('weight')), reverse=True)[:18],
    }


def trade_quality(contexts: Dict[str, Any], probability: Dict[str, Any], trade_map: Dict[str, Any]) -> Dict[str, Any]:
    probability = _as_dict(probability)
    trade_map = _as_dict(trade_map)
    components: Dict[str, float] = {}

    confidence = _num(probability.get('confidence'), 0)
    components['mtf_alignment'] = min(100.0, confidence * 2.25)

    side = probability.get('bias')
    zones = trade_map.get('sell_zones', []) if side == 'short' else trade_map.get('buy_zones', [])
    zones = _as_list(zones)
    zone_scores = []
    for z in zones:
        zd = _as_dict(z)
        score = zd.get('score')
        if isinstance(score, (int, float)):
            zone_scores.append(float(score))
        elif zd.get('quality') == 'order_block':
            zone_scores.append(68.0)
        elif zd.get('quality') == 'imbalance':
            zone_scores.append(62.0)
        elif zd.get('quality') == 'sr':
            zone_scores.append(55.0)
    components['zone_quality'] = min(100.0, (max(zone_scores) if zone_scores else 0) + min(20, len(zones) * 2.5))

    structure = 45.0
    for tf, ctx in contexts.items():
        w = _tf_weight(tf)
        adv = _as_dict(getattr(ctx, 'advanced_structure', {}))
        if _as_list(adv.get('events')):
            structure += 2.5 * w
        if _as_dict(adv.get('mss')):
            structure += 4.0 * w
        if _txt(_as_dict(adv.get('external')).get('bias')) in ('bullish', 'bearish'):
            structure += 1.0 * w
    components['structure_quality'] = min(100.0, structure)

    liq_points = 0.0
    for ctx in contexts.values():
        liq = _as_dict(getattr(ctx, 'liquidity', {}))
        liq_points += len(_as_list(liq.get('pools'))) * 1.25
        liq_points += len(_as_list(liq.get('sweeps'))) * 2.25
    components['liquidity_quality'] = min(100.0, liq_points * 3.0)

    vol = 40.0
    for ctx in contexts.values():
        vp = _as_dict(getattr(ctx, 'volume_profile', {}))
        if vp.get('available'):
            vol += 6.0
        pressure = _txt(_as_dict(vp.get('order_flow_proxy')).get('pressure'))
        if pressure in ('buy_pressure', 'sell_pressure'):
            vol += 3.0
    components['volume_quality'] = min(100.0, vol)

    components['macro_ready'] = 50.0
    # If chart is too conflicted, reduce execution quality even when zones exist.
    conflict_penalty = 0.0 if confidence >= 15 else 8.0
    total = round(max(0.0, sum(components.values()) / len(components) - conflict_penalty), 2)
    grade = 'A+' if total >= 92 else ('A' if total >= 82 else ('B' if total >= 70 else ('C' if total >= 60 else 'D')))
    return {
        'score': total,
        'grade': grade,
        'components': {k: round(v, 2) for k, v in components.items()},
        'execution_suitability': 'SCALP_READY_AFTER_TRIGGER' if total >= 78 and confidence >= 15 else ('WATCH_ONLY' if total >= 65 else 'NO_TRADE_CONTEXT'),
        'note': 'Technical quality only. Final Buy/Sell/Wait requires News/Macro V8.5 and live spread/event-risk checks.',
    }
