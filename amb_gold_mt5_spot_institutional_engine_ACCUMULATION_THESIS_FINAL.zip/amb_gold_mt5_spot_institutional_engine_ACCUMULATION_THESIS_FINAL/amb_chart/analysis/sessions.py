from __future__ import annotations
from typing import Any, Dict
import pandas as pd

SESSIONS_UTC = {
    "asia": (0, 7),
    "london": (7, 13),
    "new_york": (13, 21),
    "ny_killzone": (13, 16),
    "london_close": (15, 17),
}

def session_analysis(df: pd.DataFrame) -> Dict[str, Any]:
    if df.empty:
        return {}
    work = df.tail(min(len(df), 220)).copy()
    ts = pd.to_datetime(work['time'], utc=True, errors='coerce')
    work['hour'] = ts.dt.hour
    out = {}
    for name, (start, end) in SESSIONS_UTC.items():
        part = work[(work['hour'] >= start) & (work['hour'] < end)] if start < end else work[(work['hour'] >= start) | (work['hour'] < end)]
        if part.empty:
            continue
        open_ = float(part.iloc[0]['open']); close=float(part.iloc[-1]['close'])
        rng=float(part['high'].max()-part['low'].min())
        out[name] = {"high": round(float(part['high'].max()),6), "low": round(float(part['low'].min()),6), "range": round(rng,6), "direction":"bullish" if close>open_ else ("bearish" if close<open_ else "flat"), "volume": round(float(part.get('volume', pd.Series()).sum()),6), "candles": int(len(part))}
    # current active
    h = int(ts.iloc[-1].hour) if not ts.empty else None
    active = [k for k,(s,e) in SESSIONS_UTC.items() if h is not None and ((s <= h < e) if s < e else (h >= s or h < e))]
    out['active_sessions'] = active
    return out
