from __future__ import annotations
from typing import Any, Dict, List


def _d(v: Any) -> Dict[str, Any]:
    return v if isinstance(v, dict) else {}


def _l(v: Any) -> List[Any]:
    return v if isinstance(v, list) else []


def _n(v: Any, default: float = 0.0) -> float:
    try:
        if v is None or v == '':
            return default
        return float(v)
    except Exception:
        return default


def _s(v: Any) -> str:
    return str(v or '').strip().lower()


def _clamp(v: float, lo: float = 0.0, hi: float = 100.0) -> float:
    return max(lo, min(hi, v))


def _tf(chart: Dict[str, Any], tf: str) -> Dict[str, Any]:
    return _d(_d(chart.get('timeframes')).get(tf))


def _adv(c: Dict[str, Any]) -> Dict[str, Any]:
    return _d(c.get('advanced_structure'))


def _tf_side(c: Dict[str, Any]) -> str:
    pieces = [
        _s(c.get('trend')),
        _s(c.get('structure')),
        _s(_d(_adv(c).get('external')).get('bias')),
        _s(_d(_adv(c).get('internal')).get('bias')),
        _s(_d(_adv(c).get('mss')).get('type')),
    ]
    bull = sum(1 for x in pieces if 'bull' in x or x == 'long')
    bear = sum(1 for x in pieces if 'bear' in x or x == 'short')
    return 'long' if bull > bear else 'short' if bear > bull else 'mixed'


def _latest_break_level(c: Dict[str, Any], side: str) -> float | None:
    events = [e for e in _l(_adv(c).get('events')) if isinstance(e, dict)]
    wanted = {'long': ('bos_up', 'choch_up'), 'short': ('bos_down', 'choch_down')}[side]
    for e in reversed(events):
        if _s(e.get('type')) in wanted:
            lv = _n(e.get('level'))
            if lv > 0:
                return lv
    return None


def _overextension(chart: Dict[str, Any], side: str) -> Dict[str, Any]:
    score = 0.0
    reasons: List[str] = []
    for tf, w in (('M15', 1.0), ('H1', 0.8)):
        c = _tf(chart, tf)
        rsi = _n(c.get('rsi'), 50.0)
        bb = _d(c.get('bollinger'))
        close = _n(c.get('last_close'))
        upper = _n(bb.get('upper'))
        lower = _n(bb.get('lower'))
        adv_ind = _d(c.get('advanced_indicators'))
        tq = _d(adv_ind.get('trend_quality'))
        chop = _n(tq.get('choppiness_14'), 50.0)
        er = _n(tq.get('efficiency_ratio_10'), 0.0)
        if side == 'long':
            if rsi >= 72:
                score += 1.0 * w
                reasons.append(f'{tf}_rsi_overbought')
            if upper and close > upper:
                score += 0.9 * w
                reasons.append(f'{tf}_above_bb_upper')
        else:
            if rsi <= 28:
                score += 1.0 * w
                reasons.append(f'{tf}_rsi_oversold')
            if lower and close < lower:
                score += 0.9 * w
                reasons.append(f'{tf}_below_bb_lower')
        # Efficient impulse + low choppiness can mean legitimate trend continuation;
        # reduce false overextension penalties in that case.
        if er >= 0.45 and chop <= 45:
            score -= 0.25 * w
    score = max(0.0, score)
    return {'score': round(score, 3), 'high': score >= 1.25, 'reasons': reasons}


def _zone_relation(plan: Dict[str, Any], reference: float, atr: float, side: str) -> Dict[str, Any]:
    loc = _d(plan.get('price_location'))
    if loc:
        return {
            'relation': loc.get('relation') or ('inside_zone' if loc.get('inside_primary_zone') else 'unknown'),
            'distance_atr': loc.get('distance_atr'),
            'inside': bool(loc.get('inside_primary_zone')),
            'chase_risk': bool(loc.get('chase_risk')),
        }
    p = _d(plan.get('primary_entry'))
    lo = _n(p.get('low'))
    hi = _n(p.get('high'))
    if not lo or not hi:
        return {'relation': 'no_zone', 'distance_atr': None, 'inside': False, 'chase_risk': False}
    if lo <= reference <= hi:
        return {'relation': 'inside_zone', 'distance_atr': 0.0, 'inside': True, 'chase_risk': False}
    if reference > hi:
        dist = (reference - hi) / max(atr, 1e-9)
        return {'relation': 'above_zone', 'distance_atr': round(dist, 3), 'inside': False, 'chase_risk': side == 'long'}
    dist = (lo - reference) / max(atr, 1e-9)
    return {'relation': 'below_zone', 'distance_atr': round(dist, 3), 'inside': False, 'chase_risk': side == 'short'}


def _session_context(chart: Dict[str, Any]) -> Dict[str, Any]:
    # Prefer M15 session analysis for execution timing, then M5.
    for tf in ('M15', 'M5', 'H1'):
        s = _d(_tf(chart, tf).get('session_analysis'))
        if s:
            active = _l(s.get('active_sessions'))
            return {'source_tf': tf, 'active_sessions': active, 'active': bool(active)}
    return {'source_tf': None, 'active_sessions': [], 'active': False}


def _liquidity_confirmation(chart: Dict[str, Any], side: str) -> Dict[str, Any]:
    wanted = 'sell_side_sweep_rejection' if side == 'long' else 'buy_side_sweep_rejection'
    hits: List[Dict[str, Any]] = []
    for tf in ('M5', 'M15'):
        c = _tf(chart, tf)
        liq = _d(c.get('liquidity'))
        sweeps = _l(liq.get('sweeps'))[-8:]
        for s in sweeps:
            if isinstance(s, dict) and _s(s.get('type')) == wanted:
                hits.append({'timeframe': tf, 'type': s.get('type'), 'level': s.get('swept_level'), 'time': s.get('time')})
    return {'confirmed': bool(hits), 'hits': hits[-4:]}


def _setup_quality(*, plan: Dict[str, Any], timing_aligned: bool, higher_aligned: bool, trigger_ready: bool,
                   liquidity_ok: bool, spread_ok: bool, event_level: str, ai_confidence: float,
                   overextended: bool, style: str) -> Dict[str, Any]:
    score = 0.0
    reasons: List[str] = []
    plan_q = _n(plan.get('quality'), 0.0)
    timing_q = _n(_d(plan.get('timing_quality')).get('score'), 50.0)
    score += plan_q * 0.28
    score += timing_q * 0.22
    score += _clamp(ai_confidence) * 0.24
    if higher_aligned:
        score += 8
        reasons.append('higher_tf_aligned')
    if timing_aligned:
        score += 8
        reasons.append('m5_m15_aligned')
    if trigger_ready:
        score += 7
        reasons.append('trigger_ready')
    if liquidity_ok:
        score += 4
        reasons.append('liquidity_confirmation')
    if spread_ok:
        score += 3
    else:
        score -= 20
    if event_level == 'medium':
        score -= 5 if style == 'spot' else 9
        reasons.append('medium_event_risk')
    elif event_level == 'high':
        score -= 35
        reasons.append('high_event_risk')
    if overextended:
        score -= 15
        reasons.append('overextended')
    return {'score': round(_clamp(score), 2), 'reasons': reasons}


def evaluate_execution_state(*, chart: Dict[str, Any], side: str, style: str, plan: Dict[str, Any],
                             trigger: Dict[str, Any], macro: Dict[str, Any], micro: Dict[str, Any],
                             regime: Dict[str, Any], ai_confidence: float, blockers: List[str],
                             market_state: Dict[str, Any] | None = None) -> Dict[str, Any]:
    if side not in {'long', 'short'}:
        return {'state': 'WAIT', 'actionable': False, 'reason': 'No directional side.', 'mode': 'none', 'diagnostics': {}}
    ms = _d(market_state)
    ms_status = _s(ms.get('status')).upper()
    if ms_status == 'CLOSED_WEEKEND':
        return {
            'state': 'MARKET_CLOSED_WATCH_' + side.upper(),
            'actionable': False, 'side': side, 'style': style, 'mode': 'weekend_outlook',
            'reason': 'Market is closed for the weekend; preserve directional bias and zones as reopen watchlist only.',
            'diagnostics': {'market_state': ms, 'blockers': blockers},
        }
    if ms_status == 'REOPEN_COOLDOWN':
        return {
            'state': 'REOPEN_COOLDOWN_' + side.upper(),
            'actionable': False, 'side': side, 'style': style, 'mode': 'reopen_cooldown',
            'reason': 'Market has reopened after a long closure; wait for initial bars and spread normalization.',
            'diagnostics': {'market_state': ms, 'blockers': blockers},
        }
    if ms_status == 'TERMINAL_DISCONNECTED':
        return {
            'state': 'TERMINAL_DISCONNECTED_' + side.upper(),
            'actionable': False, 'side': side, 'style': style, 'mode': 'terminal_disconnected',
            'reason': 'MT5 terminal is disconnected; execution is disabled until broker connectivity is restored.',
            'diagnostics': {'market_state': ms, 'blockers': blockers},
        }
    if ms_status == 'TIME_SYNC_FAULT':
        return {
            'state': 'TIME_SYNC_BLOCKED_' + side.upper(),
            'actionable': False, 'side': side, 'style': style, 'mode': 'time_sync_fault',
            'reason': 'MT5 tick/bar timestamps are not time-coherent after normalization; execution is disabled.',
            'diagnostics': {'market_state': ms, 'blockers': blockers},
        }
    if ms_status == 'HISTORY_UNSYNCHRONIZED':
        return {
            'state': 'HISTORY_SYNC_BLOCKED_' + side.upper(),
            'actionable': False, 'side': side, 'style': style, 'mode': 'history_unsynchronized',
            'reason': 'MT5 quote is fresh but execution bars are not synchronized; execution is disabled until M5/M15 history catches up.',
            'diagnostics': {'market_state': ms, 'blockers': blockers},
        }
    if ms_status == 'DATA_STALE':
        return {
            'state': 'DATA_STALE_' + side.upper(),
            'actionable': False, 'side': side, 'style': style, 'mode': 'stale_data',
            'reason': 'Execution data is stale; directional context is watchlist-only until fresh MT5 data arrives.',
            'diagnostics': {'market_state': ms, 'blockers': blockers},
        }
    if ms_status == 'OPEN_SPREAD_EXTREME':
        return {
            'state': 'SPREAD_BLOCKED_' + side.upper(),
            'actionable': False, 'side': side, 'style': style, 'mode': 'spread_regime_block',
            'reason': 'Spread is extreme relative to recent broker history.',
            'diagnostics': {'market_state': ms, 'blockers': blockers},
        }
    if blockers:
        return {
            'state': 'BLOCKED_' + side.upper(),
            'actionable': False,
            'reason': 'Hard blockers active: ' + '; '.join(blockers),
            'mode': 'blocked',
            'diagnostics': {'blockers': blockers},
        }

    ref = _n(_d(chart.get('trade_map')).get('reference_price')) or _n(_tf(chart, 'M15').get('last_close'))
    tf = 'H1' if style == 'spot' else 'M15'
    atr = max(_n(_tf(chart, tf).get('atr'), 1.0), 1e-9)
    relation = _zone_relation(plan, ref, atr, side)
    m5 = _tf_side(_tf(chart, 'M5'))
    m15 = _tf_side(_tf(chart, 'M15'))
    h1 = _tf_side(_tf(chart, 'H1'))
    h4 = _tf_side(_tf(chart, 'H4'))
    timing_aligned = m5 == side and m15 == side
    higher_aligned = (h1 == side and h4 == side) or (_s(regime.get('primary_side')) == side and h1 == side)
    over = _overextension(chart, side)
    spread_ok = bool(micro.get('spread_ok', True))
    event_level = _s(_d(macro.get('event_risk')).get('level'))
    session = _session_context(chart)
    liquidity = _liquidity_confirmation(chart, side)

    levels = [x for x in (_latest_break_level(_tf(chart, 'M15'), side), _latest_break_level(_tf(chart, 'H1'), side)) if x]
    break_level = levels[0] if levels else None
    retest_distance_atr = abs(ref - break_level) / atr if break_level else None
    retest_near = bool(break_level and retest_distance_atr <= (0.45 if style == 'spot' else 0.30))
    trigger_ready = bool(trigger.get('ready')) and _s(trigger.get('side')) == side
    plan_valid = bool(plan.get('valid'))
    zone_quality = _n(plan.get('quality'))
    timing_quality = _n(_d(plan.get('timing_quality')).get('score'), 50.0)
    setup_quality = _setup_quality(
        plan=plan,
        timing_aligned=timing_aligned,
        higher_aligned=higher_aligned,
        trigger_ready=trigger_ready,
        liquidity_ok=bool(liquidity.get('confirmed')),
        spread_ok=spread_ok,
        event_level=event_level,
        ai_confidence=ai_confidence,
        overextended=bool(over.get('high')),
        style=style,
    )

    state = 'WAIT'
    mode = 'wait'
    actionable = False
    reason = 'Insufficient execution confluence.'

    if not plan_valid:
        reason = 'No valid RR-aware execution plan.'
    elif not spread_ok:
        reason = 'Spread is not acceptable.'
    elif relation.get('inside'):
        # Spot may enter inside an institutional zone without M5/M15 perfection, but
        # requires strong higher-TF alignment and adequate setup quality.
        if style == 'spot' and higher_aligned and ai_confidence >= 28 and setup_quality['score'] >= 58 and not over['high']:
            state = 'BUY_NOW' if side == 'long' else 'SELL_NOW'
            mode = 'institutional_pullback_entry'
            actionable = True
            reason = 'Price is inside the primary institutional zone with aligned higher-timeframe structure and acceptable setup quality.'
        elif style == 'scalp' and trigger_ready and timing_aligned and ai_confidence >= 34 and setup_quality['score'] >= 64 and not over['high']:
            state = 'BUY_NOW' if side == 'long' else 'SELL_NOW'
            mode = 'micro_trigger_entry'
            actionable = True
            reason = 'Price is inside the execution zone with M5/M15 alignment and confirmed trigger.'
        else:
            state = 'READY_' + side.upper()
            mode = 'in_zone_wait_trigger'
            reason = 'Price is in the primary zone; directional setup is valid but final timing confirmation is incomplete.'
    else:
        dist = relation.get('distance_atr')
        chasing = bool(relation.get('chase_risk'))
        if chasing:
            if retest_near and timing_aligned and trigger_ready and not over['high'] and ai_confidence >= 34 and setup_quality['score'] >= 64:
                state = 'BREAKOUT_RETEST_' + side.upper()
                mode = 'breakout_retest'
                actionable = True
                reason = f'Breakout retest is near structural break ({round(break_level, 6)}), with aligned execution trigger.'
            elif dist is not None and dist <= 0.55:
                state = 'WAIT_RETEST_' + side.upper()
                mode = 'near_retest'
                reason = 'Price has left the primary pullback zone; wait for a clean retest instead of chasing.'
            else:
                state = 'WAIT_PULLBACK_' + side.upper()
                mode = 'pullback'
                reason = 'Directional bias is valid but price is extended away from the primary entry zone.'
        else:
            state = 'PREPARE_' + side.upper()
            mode = 'deep_pullback_reclaim'
            reason = 'Price is beyond the primary zone on the adverse side; wait for reclaim and renewed structure confirmation.'

    if over['high'] and actionable:
        state = 'WAIT_COOLDOWN_' + side.upper()
        actionable = False
        mode = 'overextended'
        reason = 'Momentum is overextended; wait for normalization or a cleaner retest.'

    if event_level == 'medium' and actionable and style == 'scalp':
        state = 'PREPARE_' + side.upper()
        actionable = False
        mode = 'event_caution'
        reason = 'Medium event risk: scalp execution requires reaction confirmation rather than immediate entry.'

    # If the setup quality is weak, downgrade any non-actionable READY to PREPARE.
    if not actionable and state.startswith('READY_') and setup_quality['score'] < 52:
        state = 'PREPARE_' + side.upper()
        mode = 'quality_not_ready'
        reason = 'Price location is acceptable but aggregate execution quality is not yet strong enough.'

    return {
        'state': state,
        'actionable': actionable,
        'side': side,
        'style': style,
        'mode': mode,
        'reason': reason,
        'setup_quality': setup_quality,
        'diagnostics': {
            'reference_price': round(ref, 6),
            'zone_relation': relation,
            'atr': round(atr, 6),
            'm5_side': m5,
            'm15_side': m15,
            'h1_side': h1,
            'h4_side': h4,
            'timing_aligned': timing_aligned,
            'higher_aligned': higher_aligned,
            'trigger_ready': trigger_ready,
            'zone_quality': round(zone_quality, 2),
            'timing_quality': round(timing_quality, 2),
            'break_level': round(break_level, 6) if break_level else None,
            'retest_distance_atr': round(retest_distance_atr, 3) if retest_distance_atr is not None else None,
            'overextension': over,
            'liquidity_confirmation': liquidity,
            'session_context': session,
            'event_risk': event_level.upper(),
            'spread_ok': spread_ok,
            'ai_confidence': round(ai_confidence, 2),
        },
    }
