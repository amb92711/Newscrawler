from __future__ import annotations
from datetime import datetime, timezone
from typing import Any, Dict, List
from dataclasses import asdict
import json
import math
import pandas as pd

from amb_chart.config import EngineConfig
from amb_chart.models import ChartContext, TimeframeContext
from amb_chart.analysis.indicators import enrich_indicators
from amb_chart.analysis.structure import (
    detect_swings, classify_trend, classify_momentum, classify_volatility, detect_structure,
    advanced_market_structure, support_resistance_from_swings, liquidity_pools, liquidity_sweeps,
    fair_value_gaps, order_blocks, build_zones,
)
from amb_chart.analysis.volume import volume_profile, order_flow_proxy
from amb_chart.analysis.sessions import session_analysis
from amb_chart.analysis.smt import smt_analysis
from amb_chart.analysis.probability import probability_engine, trade_quality
from amb_chart.analysis.decision import build_institutional_decision_packet
from amb_chart.analysis.market_state import assess_market_state


def _last_float(df: pd.DataFrame, col: str):
    try:
        v = df[col].iloc[-1]
        if v is None or math.isnan(float(v)):
            return None
        return round(float(v), 6)
    except Exception:
        return None


def _normalize_df(rows: List[Dict[str, Any]]) -> pd.DataFrame:
    df = pd.DataFrame(rows)
    if df.empty:
        return df
    for col in ['time', 'open', 'high', 'low', 'close', 'volume']:
        if col not in df:
            df[col] = 0.0 if col != 'time' else ''
    for col in ['open', 'high', 'low', 'close', 'volume', 'spread', 'bid_close', 'ask_close', 'real_volume']:
        if col in df:
            df[col] = pd.to_numeric(df[col], errors='coerce')
    return df.dropna(subset=['open', 'high', 'low', 'close']).reset_index(drop=True)


def _safe_close(ctx: TimeframeContext | None) -> float:
    try:
        return float(ctx.last_close) if ctx else 0.0
    except Exception:
        return 0.0




def _last_int(df: pd.DataFrame, col: str):
    try:
        v = df[col].iloc[-1]
        if v is None or math.isnan(float(v)):
            return None
        return int(float(v))
    except Exception:
        return None


def _indicator_bundle(df: pd.DataFrame) -> Dict[str, Any]:
    return {
        'sma': {'20': _last_float(df, 'sma_20'), '50': _last_float(df, 'sma_50'), '100': _last_float(df, 'sma_100'), '200': _last_float(df, 'sma_200')},
        'ema_extended': {'8': _last_float(df, 'ema_8'), '13': _last_float(df, 'ema_13'), '21': _last_float(df, 'ema_21'), '34': _last_float(df, 'ema_34'), '55': _last_float(df, 'ema_55'), '89': _last_float(df, 'ema_89'), '144': _last_float(df, 'ema_144'), '233': _last_float(df, 'ema_233')},
        'supertrend': {'value': _last_float(df, 'supertrend_10_3'), 'direction': _last_int(df, 'supertrend_direction')},
        'stoch_rsi': {'k': _last_float(df, 'stoch_rsi_k'), 'd': _last_float(df, 'stoch_rsi_d')},
        'vwap': {'session': _last_float(df, 'vwap_session'), 'price_vs_vwap': _last_float(df, 'price_vs_vwap')},
        'keltner': {'upper': _last_float(df, 'kc_upper'), 'mid': _last_float(df, 'kc_mid'), 'lower': _last_float(df, 'kc_lower')},
        'donchian': {'upper': _last_float(df, 'donchian_upper'), 'mid': _last_float(df, 'donchian_mid'), 'lower': _last_float(df, 'donchian_lower')},
        'pivots': {'pivot': _last_float(df, 'pivot'), 'r1': _last_float(df, 'pivot_r1'), 's1': _last_float(df, 'pivot_s1'), 'r2': _last_float(df, 'pivot_r2'), 's2': _last_float(df, 'pivot_s2')},
        'momentum_advanced': {'roc_12': _last_float(df, 'roc_12'), 'cci_20': _last_float(df, 'cci_20'), 'williams_r_14': _last_float(df, 'williams_r_14'), 'mfi_14': _last_float(df, 'mfi_14')},
        'volume_flow': {'obv': _last_float(df, 'obv'), 'cmf_20': _last_float(df, 'cmf_20')},
        'trend_quality': {'plus_di_14': _last_float(df, 'plus_di_14'), 'minus_di_14': _last_float(df, 'minus_di_14'), 'dmi_spread': _last_float(df, 'dmi_spread'), 'efficiency_ratio_10': _last_float(df, 'efficiency_ratio_10'), 'choppiness_14': _last_float(df, 'choppiness_14')},
        'volatility_advanced': {'historical_vol_20': _last_float(df, 'hist_vol_20'), 'bb_width': _last_float(df, 'bb_width'), 'kc_width': _last_float(df, 'kc_width'), 'squeeze_on': bool(_last_int(df, 'squeeze_on') or 0)},
        'adaptive_trend': {'kama': _last_float(df, 'kama_10_2_30'), 'aroon_up': _last_float(df, 'aroon_up_25'), 'aroon_down': _last_float(df, 'aroon_down_25'), 'aroon_osc': _last_float(df, 'aroon_osc_25'), 'fisher': _last_float(df, 'fisher_10')},
        'anchored_vwap': {'from_swing_low': _last_float(df, 'avwap_from_swing_low'), 'from_swing_high': _last_float(df, 'avwap_from_swing_high'), 'low_distance_atr': _last_float(df, 'avwap_low_distance_atr'), 'high_distance_atr': _last_float(df, 'avwap_high_distance_atr')},
        'institutional_price_action': {'relative_volume_20': _last_float(df, 'relative_volume_20'), 'displacement_efficiency': _last_float(df, 'displacement_efficiency'), 'impulse_atr': _last_float(df, 'impulse_atr'), 'institutional_impulse_score': _last_float(df, 'institutional_impulse_score'), 'close_location_value': _last_float(df, 'close_location_value'), 'price_zscore_50': _last_float(df, 'price_zscore_50')},
        'regime_metrics': {'volatility_percentile': _last_float(df, 'volatility_regime_pct')},
    }


def _ichimoku_bundle(df: pd.DataFrame) -> Dict[str, Any]:
    return {
        'tenkan': _last_float(df, 'ichimoku_tenkan'),
        'kijun': _last_float(df, 'ichimoku_kijun'),
        'span_a': _last_float(df, 'ichimoku_span_a'),
        'span_b': _last_float(df, 'ichimoku_span_b'),
        'cloud_top': _last_float(df, 'ichimoku_cloud_top'),
        'cloud_bottom': _last_float(df, 'ichimoku_cloud_bottom'),
        'cloud_bias': _last_int(df, 'ichimoku_cloud_bias'),
        'tk_cross': _last_int(df, 'ichimoku_tk_cross'),
    }


def _price_action_bundle(df: pd.DataFrame) -> Dict[str, Any]:
    if df.empty:
        return {}
    return {
        'last_candle': {
            'body_pct': _last_float(df, 'candle_body_pct'),
            'upper_wick_pct': _last_float(df, 'upper_wick_pct'),
            'lower_wick_pct': _last_float(df, 'lower_wick_pct'),
            'body_to_atr': _last_float(df, 'body_to_atr'),
            'bullish_engulfing': bool(_last_int(df, 'bullish_engulfing') or 0),
            'bearish_engulfing': bool(_last_int(df, 'bearish_engulfing') or 0),
            'bullish_pinbar': bool(_last_int(df, 'bullish_pinbar') or 0),
            'bearish_pinbar': bool(_last_int(df, 'bearish_pinbar') or 0),
        },
        'heikin_ashi': {
            'open': _last_float(df, 'ha_open'), 'high': _last_float(df, 'ha_high'), 'low': _last_float(df, 'ha_low'), 'close': _last_float(df, 'ha_close'),
            'bias': 'bullish' if _last_float(df, 'ha_close') and _last_float(df, 'ha_open') and _last_float(df, 'ha_close') > _last_float(df, 'ha_open') else 'bearish',
        },
    }

def analyze_timeframe(label: str, rows: List[Dict[str, Any]], cfg: EngineConfig, related: Dict[str, pd.DataFrame] | None = None) -> TimeframeContext:
    df = _normalize_df(rows)
    warnings: List[str] = []
    if df.empty or len(df) < 120:
        warnings.append(f'Low candle count for institutional context: {len(df)}')
    df = enrich_indicators(df) if not df.empty else df
    major = detect_swings(df, cfg.swing_left, cfg.swing_right, limit=42) if not df.empty else {'highs': [], 'lows': [], 'last_high': None, 'last_low': None}
    internal = detect_swings(df, cfg.internal_swing_left, cfg.internal_swing_right, limit=52) if not df.empty else major
    st = detect_structure(df, major) if not df.empty else {'label': 'unknown', 'events': []}
    adv = advanced_market_structure(df, major, internal) if not df.empty else {'mss': {}, 'events': []}
    sr = support_resistance_from_swings(df, major, cfg.zone_merge_atr) if not df.empty else {'supports': [], 'resistances': []}
    liq = liquidity_pools(df, major, cfg.liquidity_tolerance_atr) if not df.empty else {'pools': []}
    liq['sweeps'] = liquidity_sweeps(df, major) if not df.empty else []
    fvg = fair_value_gaps(df, cfg.fvg_min_atr) if not df.empty else []
    obs = order_blocks(df, cfg.order_block_lookback, cfg.order_block_max_age, fvg) if not df.empty else []
    zones = build_zones(df, sr, fvg, obs) if not df.empty else {'buy_zones': [], 'sell_zones': []}
    vp = volume_profile(df) if not df.empty else {}
    vp['order_flow_proxy'] = order_flow_proxy(df) if not df.empty else {}
    sess = session_analysis(df) if not df.empty else {}
    smt = smt_analysis(df, related) if not df.empty else {'available': False, 'signals': []}
    last = df.iloc[-1] if not df.empty else None
    return TimeframeContext(
        timeframe=label,
        candles=int(len(df)),
        last_time=str(last['time']) if last is not None else '',
        last_close=round(float(last['close']), 6) if last is not None else 0.0,
        trend=classify_trend(df) if not df.empty else 'unknown',
        momentum=classify_momentum(df) if not df.empty else 'unknown',
        volatility=classify_volatility(df) if not df.empty else 'unknown',
        structure=st['label'],
        ema={'20': _last_float(df, 'ema_20'), '50': _last_float(df, 'ema_50'), '200': _last_float(df, 'ema_200')},
        rsi=_last_float(df, 'rsi_14'),
        atr=_last_float(df, 'atr_14'),
        adx=_last_float(df, 'adx_14'),
        macd={'line': _last_float(df, 'macd'), 'signal': _last_float(df, 'macd_signal'), 'hist': _last_float(df, 'macd_hist')},
        bollinger={'upper': _last_float(df, 'bb_upper'), 'mid': _last_float(df, 'bb_mid'), 'lower': _last_float(df, 'bb_lower')},
        swings=major,
        advanced_structure=adv,
        liquidity=liq,
        fvg=fvg,
        order_blocks=obs,
        support_resistance=sr,
        zones=zones,
        volume_profile=vp,
        session_analysis=sess,
        smt=smt,
        ichimoku=_ichimoku_bundle(df) if not df.empty else {},
        advanced_indicators=_indicator_bundle(df) if not df.empty else {},
        price_action=_price_action_bundle(df) if not df.empty else {},
        warnings=warnings,
    )


def mtf_bias(contexts: Dict[str, TimeframeContext]) -> Dict[str, Any]:
    weights = {'D1': 4.0, 'H4': 3.0, 'H1': 2.0, 'M15': 1.0, 'M5': 0.55}
    bull = bear = mixed = 0.0
    details: Dict[str, Any] = {}
    for tf, ctx in contexts.items():
        w = weights.get(tf, 1.0)
        signal = 'mixed'
        adv = ctx.advanced_structure or {}
        external = adv.get('external') or {}
        internal = adv.get('internal') or {}
        mss = adv.get('mss') or {}
        trend = str(ctx.trend or '')
        structure = str(ctx.structure or '')
        if 'bullish' in trend:
            bull += w
            signal = 'bullish'
        if 'bearish' in trend:
            bear += w
            signal = 'bearish' if signal == 'mixed' else signal
        if structure.startswith('bullish'):
            bull += w * 0.75
            signal = 'bullish'
        if structure.startswith('bearish'):
            bear += w * 0.75
            signal = 'bearish'
        if str(external.get('bias')) == 'bullish':
            bull += w * 0.75
        if str(external.get('bias')) == 'bearish':
            bear += w * 0.75
        if str(internal.get('bias')) == 'bullish':
            bull += w * 0.35
        if str(internal.get('bias')) == 'bearish':
            bear += w * 0.35
        mt = str(mss.get('type') or '')
        if mt.startswith('bullish'):
            bull += w * 1.0
            signal = 'bullish'
        if mt.startswith('bearish'):
            bear += w * 1.0
            signal = 'bearish'
        if signal == 'mixed':
            mixed += w
        details[tf] = {
            'trend': ctx.trend,
            'structure': ctx.structure,
            'external_bias': external.get('bias'),
            'internal_bias': internal.get('bias'),
            'momentum': ctx.momentum,
            'weight': w,
            'signal': signal,
            'mss': mss,
        }
    bias = 'bullish' if bull > bear * 1.22 else ('bearish' if bear > bull * 1.22 else 'mixed_wait')
    return {'bias': bias, 'bull_score': round(bull, 2), 'bear_score': round(bear, 2), 'mixed_score': round(mixed, 2), 'details': details}


def _zone_distance(z: Dict[str, Any], price: float) -> float:
    low = float(z.get('low', z.get('level', price)) or price)
    high = float(z.get('high', z.get('level', price)) or price)
    if low <= price <= high:
        return 0.0
    return min(abs(price - low), abs(price - high))


def _rank_zones(zones: List[Dict[str, Any]], price: float, side: str) -> List[Dict[str, Any]]:
    ranked = []
    for z in zones:
        item = dict(z)
        score = float(item.get('score', 55 if item.get('quality') == 'sr' else 65) or 50)
        if item.get('status') == 'fresh':
            score += 12
        if item.get('status') == 'open':
            score += 8
        dist = _zone_distance(item, price)
        item['distance_from_reference'] = round(dist, 6)
        item['rank_score'] = round(score - min(25, dist / max(price, 1) * 1000), 2)
        item['side'] = side
        ranked.append(item)
    return sorted(ranked, key=lambda x: x.get('rank_score', 0), reverse=True)


def build_trade_map(contexts: Dict[str, TimeframeContext], bias: Dict[str, Any], probability: Dict[str, Any] | None = None) -> Dict[str, Any]:
    exec_ctx = contexts.get('M15') or contexts.get('H1') or next(iter(contexts.values()))
    h1 = contexts.get('H1', exec_ctx)
    close = _safe_close(exec_ctx)
    buy: List[Dict[str, Any]] = []
    sell: List[Dict[str, Any]] = []
    for tf in ['D1', 'H4', 'H1', 'M15', 'M5']:
        ctx = contexts.get(tf)
        if not ctx:
            continue
        for z in ctx.zones.get('buy_zones', [])[-5:]:
            buy.append({'timeframe': tf, **z})
        for z in ctx.zones.get('sell_zones', [])[:5]:
            sell.append({'timeframe': tf, **z})
    buy = _rank_zones(buy, close, 'buy')[:16]
    sell = _rank_zones(sell, close, 'sell')[:16]
    supports = h1.support_resistance.get('supports', []) if h1 else []
    resistances = h1.support_resistance.get('resistances', []) if h1 else []
    inv_buy = supports[-1] if supports else None
    inv_sell = resistances[0] if resistances else None
    p_bias = (probability or {}).get('bias')
    action = 'WAIT_FOR_ALIGNMENT'
    if p_bias == 'long' and buy:
        action = 'WAIT_FOR_BUY_ZONE_AND_BULLISH_TRIGGER'
    elif p_bias == 'short' and sell:
        action = 'WAIT_FOR_SELL_ZONE_AND_BEARISH_TRIGGER'
    elif bias['bias'] == 'bullish' and buy:
        action = 'WAIT_FOR_BUY_ZONE_OR_BULLISH_TRIGGER'
    elif bias['bias'] == 'bearish' and sell:
        action = 'WAIT_FOR_SELL_ZONE_OR_BEARISH_TRIGGER'
    trigger_checklist = {
        'long_trigger': ['M5/M15 sell-side sweep rejection', 'close back above swept level', 'bullish CHOCH/MSS on M5/M15', 'spread normal', 'no high-impact macro event window'],
        'short_trigger': ['M5/M15 buy-side sweep rejection', 'close back below swept level', 'bearish CHOCH/MSS on M5/M15', 'spread normal', 'no high-impact macro event window'],
        'no_trade_conditions': ['D1/H4 conflict with news macro', 'probability confidence below 12', 'inside high-impact news window', 'spread abnormal', 'no clean invalidation'],
    }
    return {
        'preferred_action': action,
        'reference_price': close,
        'buy_zones': buy,
        'sell_zones': sell,
        'buy_invalidation': inv_buy,
        'sell_invalidation': inv_sell,
        'targets_up': resistances[:8],
        'targets_down': list(reversed(supports[-8:])),
        'scalp_trigger_checklist': trigger_checklist,
        'execution_note': 'This chart engine creates evidence for ChatGPT. It does not place trades. Combine with News/Macro V8.5 before final spot/scalp opinion.',
    }


def _load_news_context(path: str | None) -> Dict[str, Any]:
    if not path:
        return {'attached': False}
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return {'attached': True, 'data': json.load(f)}
    except Exception as exc:
        return {'attached': False, 'error': str(exc)}


def _scenario_pack(prob: Dict[str, Any], trade: Dict[str, Any], quality: Dict[str, Any], mtf: Dict[str, Any]) -> Dict[str, Any]:
    bias = prob.get('bias')
    confidence = float(prob.get('confidence', 0) or 0)
    quality_score = float(quality.get('score', 0) or 0)
    if bias == 'long':
        primary = 'LONG_SCALP_ONLY_AFTER_BULLISH_TRIGGER'
        invalidation = trade.get('buy_invalidation')
        zones = trade.get('buy_zones', [])[:6]
        targets = trade.get('targets_up', [])
    elif bias == 'short':
        primary = 'SHORT_SCALP_ONLY_AFTER_BEARISH_TRIGGER'
        invalidation = trade.get('sell_invalidation')
        zones = trade.get('sell_zones', [])[:6]
        targets = trade.get('targets_down', [])
    else:
        primary = 'WAIT_NO_DIRECTIONAL_EDGE'
        invalidation = None
        zones = []
        targets = []
    readiness = 'GOOD_CONTEXT' if quality_score >= 78 and confidence >= 18 else ('WATCHLIST_CONTEXT' if quality_score >= 65 else 'WEAK_CONTEXT')
    return {
        'primary_scenario': primary,
        'readiness': readiness,
        'technical_bias': mtf.get('bias'),
        'probability_bias': bias,
        'confidence': confidence,
        'candidate_zones': zones,
        'invalidation': invalidation,
        'targets': targets,
        'what_chatgpt_should_decide': [
            'Check News/Macro V8.5 bias and event window first.',
            'Approve only if macro context does not strongly oppose chart direction.',
            'Use trigger checklist before scalp entry.',
            'If macro and chart conflict, output WAIT.',
        ],
    }


def build_fusion_context(cfg: EngineConfig, mtf: Dict[str, Any], probability: Dict[str, Any], quality: Dict[str, Any], trade: Dict[str, Any], news: Dict[str, Any]) -> Dict[str, Any]:
    return {
        'contract': 'AMB_FUSION_READY_CHART_CONTEXT_V5_DEBUG',
        'purpose': 'Chart evidence packet for the Institutional Decision Engine. Fuse with News/Macro V8.5 before spot/scalp action.',
        'symbol': cfg.symbol,
        'technical_bias': mtf.get('bias'),
        'technical_probability': probability,
        'trade_quality': quality,
        'preferred_action': trade.get('preferred_action'),
        'scenario_pack': _scenario_pack(probability, trade, quality, mtf),
        'trigger_checklist': trade.get('scalp_trigger_checklist'),
        'requires_macro_confirmation': True,
        'news_macro_context': news,
        'llm_instruction': 'Prefer latest_institutional_decision_packet.json for ChatGPT. If chart and macro conflict or event risk is high, choose WAIT.',
    }


def analyze(provider, cfg: EngineConfig) -> ChartContext:
    raw = provider.fetch_multi_timeframe(cfg.timeframes, cfg.count)
    related_raw = {}
    if hasattr(provider, 'fetch_related_multi_timeframe') and cfg.related_symbols:
        related_raw = provider.fetch_related_multi_timeframe(cfg.related_symbols, cfg.timeframes, cfg.count)
    contexts: Dict[str, TimeframeContext] = {}
    for tf, rows in raw.items():
        rel = {sym: _normalize_df(tfmap.get(tf, [])) for sym, tfmap in related_raw.items()} if related_raw else {}
        contexts[tf] = analyze_timeframe(tf, rows, cfg, rel)
    micro = provider.market_microstructure() if hasattr(provider, 'market_microstructure') else {}
    bias = mtf_bias(contexts)
    prob = probability_engine(contexts, bias, micro)
    trade = build_trade_map(contexts, bias, prob)
    quality = trade_quality(contexts, prob, trade)
    health = provider.health().details if hasattr(provider, 'health') else {}
    dq = {'timeframes_loaded': list(contexts.keys()), 'min_candles': min((c.candles for c in contexts.values()), default=0), 'warnings': [w for c in contexts.values() for w in c.warnings], 'provider_health': health}
    risks = []
    if dq['min_candles'] < 200:
        risks.append('Some timeframes have fewer than 200 candles; EMA200/structure confidence may be lower.')
    if bias['bias'] == 'mixed_wait':
        risks.append('Multi-timeframe context is mixed; prefer waiting for confirmation.')
    if prob['confidence'] < 12:
        risks.append('Probability confidence is low; avoid forcing directional scalp trades.')
    if not _load_news_context(cfg.news_context_path).get('attached'):
        risks.append('News/Macro V8.5 is not attached; final Buy/Sell/Wait must be decided after macro fusion.')
    news = _load_news_context(cfg.news_context_path)
    fusion = build_fusion_context(cfg, bias, prob, quality, trade, news)
    market_state = assess_market_state(raw=raw, contexts=contexts, micro=micro, provider_health=health)
    fusion['market_state'] = market_state
    dq['market_state'] = market_state
    if not market_state.get('actionable'):
        risks.append(f"Execution gate: {market_state.get('execution_gate')} - {market_state.get('reason')}")
    tmp_chart = {'symbol': cfg.symbol, 'provider': provider.name, 'engine': 'AMB Gold MT5 Institutional AI Learning Engine', 'generated_utc': datetime.now(timezone.utc).isoformat(), 'timeframes': {k: asdict(v) for k, v in contexts.items()}, 'market_microstructure': micro, 'mtf_bias': bias, 'probability': prob, 'trade_quality': quality, 'trade_map': trade, 'fusion_context': fusion}
    decision = build_institutional_decision_packet(tmp_chart)
    fusion['institutional_decision_packet'] = decision
    return ChartContext(engine='AMB Gold MT5 Institutional AI Learning Engine', provider=provider.name, symbol=cfg.symbol, generated_utc=datetime.now(timezone.utc).isoformat(), timeframes=contexts, market_microstructure=micro, mtf_bias=bias, probability=prob, trade_quality=quality, trade_map=trade, fusion_context=fusion, risk_notes=risks, data_quality=dq)
