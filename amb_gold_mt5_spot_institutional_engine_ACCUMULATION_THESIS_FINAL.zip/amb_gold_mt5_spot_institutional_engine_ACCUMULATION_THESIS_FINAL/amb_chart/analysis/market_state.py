from __future__ import annotations

from datetime import datetime, timezone
from statistics import median
from typing import Any, Dict, Iterable, List, Mapping


TF_SECONDS = {
    'M1': 60, 'M5': 300, 'M15': 900, 'M30': 1800,
    'H1': 3600, 'H4': 14400, 'D1': 86400,
}


def _n(v: Any, default: float = 0.0) -> float:
    try:
        if v is None or v == '':
            return default
        return float(v)
    except Exception:
        return default


def _parse_ts(v: Any) -> datetime | None:
    if isinstance(v, datetime):
        dt = v
    else:
        s = str(v or '').strip()
        if not s:
            return None
        try:
            dt = datetime.fromisoformat(s.replace('Z', '+00:00'))
        except Exception:
            return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def _age_seconds(v: Any, now: datetime) -> float | None:
    dt = _parse_ts(v)
    if dt is None:
        return None
    # Signed age is intentional: future timestamps are a clock/timezone fault and
    # must never be silently clamped to zero/fresh.
    return (now - dt).total_seconds()


def _freshness_grade(age: float | None, expected: int, market_closed: bool) -> str:
    if age is None:
        return 'missing'
    future_tolerance = max(120.0, expected * 0.20)
    if age < -future_tolerance:
        return 'future_timestamp'
    if market_closed:
        return 'stale_market_closed' if age > expected * 2 else 'fresh_but_market_closed'
    if age <= expected * 2.2:
        return 'fresh'
    if age <= expected * 5.0:
        return 'delayed'
    return 'stale'


def _recent_spread_regime(micro: Mapping[str, Any], rows: Iterable[Mapping[str, Any]]) -> Dict[str, Any]:
    live = _n(micro.get('spread'), 0.0)
    point = max(_n(micro.get('point'), 0.01), 1e-9)
    spreads_points: List[float] = []
    for r in list(rows)[-120:]:
        sp = _n(r.get('spread'), 0.0)
        if sp > 0:
            spreads_points.append(sp)
    hist_price = [x * point for x in spreads_points]
    med = median(hist_price) if hist_price else 0.0
    ratio = live / med if live > 0 and med > 0 else None
    if live <= 0:
        state = 'unknown'
    elif med > 0 and ratio is not None and ratio >= 2.5:
        state = 'extreme'
    elif med > 0 and ratio is not None and ratio >= 1.6:
        state = 'elevated'
    else:
        state = 'normal'
    return {
        'state': state,
        'live_spread': round(live, 8) if live else None,
        'median_recent_spread': round(med, 8) if med else None,
        'ratio_to_median': round(ratio, 3) if ratio is not None else None,
        'samples': len(hist_price),
    }


def _detect_reopen_gap(rows: List[Mapping[str, Any]], atr: float) -> Dict[str, Any]:
    if len(rows) < 3:
        return {'detected': False, 'reason': 'insufficient_m5_history'}
    parsed: List[tuple[int, datetime]] = []
    for i, r in enumerate(rows):
        dt = _parse_ts(r.get('time'))
        if dt is not None:
            parsed.append((i, dt))
    if len(parsed) < 3:
        return {'detected': False, 'reason': 'invalid_timestamps'}

    best = None
    recent = parsed[-80:]
    for (i0, t0), (i1, t1) in zip(recent, recent[1:]):
        gap_s = (t1 - t0).total_seconds()
        if gap_s >= 6 * 3600:
            best = (i0, i1, gap_s, t0, t1)
    if best is None:
        return {'detected': False}

    i0, i1, gap_s, t0, t1 = best
    prev_close = _n(rows[i0].get('close'))
    next_open = _n(rows[i1].get('open'))
    gap_price = next_open - prev_close if prev_close and next_open else 0.0
    atr_mult = abs(gap_price) / max(atr, 1e-9) if atr > 0 else None
    bars_after = max(0, len(rows) - 1 - i1)
    return {
        'detected': True,
        'gap_start_utc': t0.isoformat(),
        'reopen_utc': t1.isoformat(),
        'closed_duration_hours': round(gap_s / 3600.0, 2),
        'previous_close': round(prev_close, 8) if prev_close else None,
        'reopen_open': round(next_open, 8) if next_open else None,
        'gap_price': round(gap_price, 8),
        'gap_atr_multiple': round(atr_mult, 3) if atr_mult is not None else None,
        'bars_after_reopen': bars_after,
        'large_gap': bool(atr_mult is not None and atr_mult >= 0.75),
    }


def assess_market_state(*, raw: Mapping[str, List[Mapping[str, Any]]], contexts: Mapping[str, Any],
                        micro: Mapping[str, Any], provider_health: Mapping[str, Any] | None = None,
                        now: datetime | None = None) -> Dict[str, Any]:
    """Derive execution-grade market/data state for MT5 XAUUSD.

    It intentionally avoids relying on a single broker flag. Weekend/day, quote age,
    candle freshness, spread regime and reopen gap are fused into one canonical gate.
    """
    now = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    weekday = now.weekday()  # Mon=0 ... Sun=6
    weekend_day = weekday in (5, 6)

    tick_age = _age_seconds(micro.get('time'), now)
    last_times: Dict[str, Any] = {}
    freshness: Dict[str, Any] = {}
    for tf in ('M5', 'M15', 'H1', 'H4', 'D1'):
        ctx = contexts.get(tf)
        last_time = getattr(ctx, 'last_time', None) if ctx is not None else None
        last_times[tf] = last_time
        age = _age_seconds(last_time, now)
        exp = TF_SECONDS.get(tf, 300)
        freshness[tf] = {
            'last_time': last_time,
            'age_seconds': round(age, 1) if age is not None else None,
            'expected_bar_seconds': exp,
        }

    m5_age = freshness.get('M5', {}).get('age_seconds')
    m15_age = freshness.get('M15', {}).get('age_seconds')
    quote_fresh = tick_age is not None and -120 <= tick_age <= 180
    m5_fresh = m5_age is not None and -120 <= m5_age <= TF_SECONDS['M5'] * 2.2
    m15_fresh = m15_age is not None and -180 <= m15_age <= TF_SECONDS['M15'] * 2.2
    future_clock_fault = bool(
        (tick_age is not None and tick_age < -120) or
        (m5_age is not None and m5_age < -120) or
        (m15_age is not None and m15_age < -180)
    )

    # Saturday/Sunday with old quotes is a definite non-execution state for XAUUSD CFDs.
    market_closed_weekend = weekend_day and not (quote_fresh and m5_fresh)
    for tf, f in freshness.items():
        f['grade'] = _freshness_grade(f.get('age_seconds'), TF_SECONDS.get(tf, 300), market_closed_weekend)

    spread_regime = _recent_spread_regime(micro, raw.get('M5', []))
    m5_ctx = contexts.get('M5')
    atr = _n(getattr(m5_ctx, 'atr', None), 0.0) if m5_ctx is not None else 0.0
    reopen = _detect_reopen_gap(raw.get('M5', []), atr)

    history_sync = {}
    try:
        history_sync = dict((provider_health or {}).get('history_sync') or {})
    except Exception:
        history_sync = {}
    if not history_sync and isinstance(micro.get('history_sync'), Mapping):
        history_sync = dict(micro.get('history_sync') or {})
    history_unsynchronized = bool(history_sync.get('suspected') and not history_sync.get('resolved', False))

    severe_stale = (not market_closed_weekend) and (
        future_clock_fault or tick_age is None or tick_age > 900 or m5_age is None or m5_age > TF_SECONDS['M5'] * 6
    )

    reopen_cooldown = False
    if reopen.get('detected') and m5_fresh:
        bars = int(reopen.get('bars_after_reopen') or 0)
        required = 6 if reopen.get('large_gap') else 3
        reopen['cooldown_bars_required'] = required
        reopen_cooldown = bars < required
    else:
        reopen['cooldown_bars_required'] = 0

    terminal = (provider_health or {}).get('terminal') if isinstance(provider_health, Mapping) else None
    terminal_connected = True if not isinstance(terminal, Mapping) else bool(terminal.get('connected', True))
    tick_rate = _n(micro.get('recent_tick_rate_per_minute'), 0.0)
    if tick_rate <= 0 and quote_fresh:
        liquidity_condition = 'UNKNOWN'
    elif tick_rate < 2.0:
        liquidity_condition = 'THIN'
    elif tick_rate < 8.0:
        liquidity_condition = 'NORMAL'
    else:
        liquidity_condition = 'ACTIVE'

    if market_closed_weekend:
        status = 'CLOSED_WEEKEND'
        gate = 'BLOCKED_MARKET_CLOSED'
        actionable = False
        data_state = 'STALE_MARKET_CLOSED'
        reason = 'Weekend market closure: quotes/candles are historical snapshot only.'
    elif not terminal_connected:
        status = 'TERMINAL_DISCONNECTED'
        gate = 'BLOCKED_TERMINAL_DISCONNECTED'
        actionable = False
        data_state = 'UNAVAILABLE'
        reason = 'MetaTrader 5 terminal is not connected to the broker server.'
    elif future_clock_fault:
        status = 'TIME_SYNC_FAULT'
        gate = 'BLOCKED_TIME_SYNC'
        actionable = False
        data_state = 'TIME_INCOHERENT'
        reason = 'MT5 tick/bar timestamp is materially in the future after normalization; execution is blocked until time coherence is restored.'
    elif history_unsynchronized:
        status = 'HISTORY_UNSYNCHRONIZED'
        gate = 'BLOCKED_HISTORY_SYNC'
        actionable = False
        data_state = 'HISTORY_LAGGING'
        reason = 'MT5 quote is fresh but execution bars remain materially behind after bounded history refresh attempts.'
    elif severe_stale:
        status = 'DATA_STALE'
        gate = 'BLOCKED_STALE_DATA'
        actionable = False
        data_state = 'STALE'
        reason = 'Live quote or M5 data is too stale for execution.'
    elif reopen_cooldown:
        status = 'REOPEN_COOLDOWN'
        gate = 'BLOCKED_REOPEN_COOLDOWN'
        actionable = False
        data_state = 'FRESH_REOPENING'
        reason = 'Market recently reopened; wait for initial bars/spread normalization before execution.'
    elif spread_regime.get('state') == 'extreme':
        status = 'OPEN_SPREAD_EXTREME'
        gate = 'BLOCKED_SPREAD_REGIME'
        actionable = False
        data_state = 'FRESH' if (quote_fresh and m5_fresh) else 'DELAYED'
        reason = 'Market is open but spread is extreme relative to recent broker history.'
    else:
        status = 'OPEN'
        gate = 'ALLOW_EXECUTION'
        actionable = True
        data_state = 'FRESH' if (quote_fresh and m5_fresh and m15_fresh) else 'DELAYED'
        reason = 'Market and execution data are sufficiently fresh.'

    # Cross-timeframe coherence catches terminal history sync issues.
    coherence_issues: List[str] = []
    if not market_closed_weekend:
        for tf in ('M5', 'M15', 'H1'):
            if freshness[tf]['grade'] in {'stale', 'missing', 'future_timestamp'}:
                coherence_issues.append(f'{tf}_{freshness[tf]["grade"]}')
    data_quality_score = 100.0
    if tick_age is None:
        data_quality_score -= 30
    elif tick_age < -120:
        data_quality_score -= 45
    elif tick_age > 180:
        data_quality_score -= min(35.0, tick_age / 60.0)
    if not m5_fresh and not market_closed_weekend:
        data_quality_score -= 30
    if not m15_fresh and not market_closed_weekend:
        data_quality_score -= 15
    if spread_regime.get('state') == 'elevated':
        data_quality_score -= 10
    elif spread_regime.get('state') == 'extreme':
        data_quality_score -= 25
    if coherence_issues:
        data_quality_score -= min(25, 8 * len(coherence_issues))
    data_quality_score = max(0.0, min(100.0, data_quality_score))

    return {
        'status': status,
        'execution_gate': gate,
        'actionable': actionable,
        'reason': reason,
        'observed_utc': now.isoformat(),
        'weekday_utc': now.strftime('%A'),
        'weekend': weekend_day,
        'data_state': data_state,
        'quote': {
            'last_tick_utc': micro.get('time'),
            'age_seconds': round(tick_age, 1) if tick_age is not None else None,
            'fresh': quote_fresh,
            'bid': micro.get('best_bid'),
            'ask': micro.get('best_ask'),
            'last': micro.get('last'),
        },
        'timeframes': freshness,
        'spread_regime': spread_regime,
        'time_coherence': {
            'future_clock_fault': future_clock_fault,
            'tick_age_seconds_signed': round(tick_age, 1) if tick_age is not None else None,
            'provider_offset_seconds': int(_n(micro.get('server_time_offset_seconds'), 0.0)),
            'provider_offset_source': micro.get('server_time_offset_source'),
            'tick_offset_seconds': int(_n(micro.get('tick_time_offset_seconds'), 0.0)),
            'tick_offset_source': micro.get('tick_time_offset_source'),
            'bar_offset_seconds': int(_n((micro.get('time_sync') or {}).get('bar_offset_seconds') if isinstance(micro.get('time_sync'), Mapping) else 0.0, 0.0)),
            'bar_offset_source': ((micro.get('time_sync') or {}).get('bar_offset_source') if isinstance(micro.get('time_sync'), Mapping) else None),
            'system_utc': micro.get('system_utc'),
            'tick_raw_epoch': micro.get('raw_time_epoch'),
            'tick_normalized_utc': micro.get('time'),
            'policy': 'independent_tick_bar_clock_models_plus_signed_age_block',
        },
        'history_sync': history_sync,
        'history_unsynchronized': history_unsynchronized,
        'liquidity_condition': {
            'state': liquidity_condition,
            'recent_tick_rate_per_minute': micro.get('recent_tick_rate_per_minute'),
            'recent_tick_price_range': micro.get('recent_tick_price_range'),
            'recent_tick_efficiency': micro.get('recent_tick_efficiency'),
        },
        'terminal_connected': terminal_connected,
        'reopen_gap': reopen,
        'reopen_cooldown': reopen_cooldown,
        'data_quality_score': round(data_quality_score, 2),
        'cross_timeframe_coherence': {
            'ok': not coherence_issues,
            'issues': coherence_issues,
        },
        'provider_health_available': bool(provider_health),
        'weekend_outlook_only': market_closed_weekend,
    }
