from __future__ import annotations

"""AI-style fusion layer for AMB Gold.

This module intentionally does not depend on an external LLM or paid API. It is a
small deterministic inference engine: it converts macro, technical, execution and
risk evidence into a calibrated posterior. The goal is to avoid brittle "if X then
SELL" rule chains while keeping hard safety gates explicit and auditable.

Design principles:
- hard gates only block unsafe/invalid decisions (missing news, high event risk,
  macro/chart conflict, abnormal spread). They do not create trades.
- directional decision is produced by weighted probabilistic evidence aggregation.
- execution state is separated from direction: PREPARE != READY != EXECUTE.
- the LLM receives a compact final packet; raw evidence remains in debug output.
"""

from dataclasses import dataclass, asdict
from math import exp, log
from typing import Any, Dict, List, Tuple


def _num(v: Any, default: float = 0.0) -> float:
    try:
        if v is None or v == "":
            return default
        return float(v)
    except Exception:
        return default


def _clamp(v: float, lo: float = 0.0, hi: float = 100.0) -> float:
    return max(lo, min(hi, v))


def _sigmoid(x: float) -> float:
    if x > 60:
        return 1.0
    if x < -60:
        return 0.0
    return 1.0 / (1.0 + exp(-x))


def _side_to_signed(side: str) -> int:
    s = str(side or "").lower()
    if s in {"long", "bullish", "buy"} or "bull" in s:
        return 1
    if s in {"short", "bearish", "sell"} or "bear" in s:
        return -1
    return 0


@dataclass
class EvidenceFeature:
    name: str
    side: str
    strength: float
    reliability: float
    weight: float
    note: str = ""

    def contribution(self) -> float:
        signed = _side_to_signed(self.side)
        return signed * _clamp(self.strength) / 100.0 * _clamp(self.reliability) / 100.0 * self.weight


@dataclass
class FusionResult:
    model: str
    direction: str
    confidence: float
    long_probability: float
    short_probability: float
    raw_long_probability: float
    raw_short_probability: float
    calibration_samples: int
    probability_semantics: str
    edge: float
    execution_state: str
    trade_permission: str
    hard_blockers: List[str]
    soft_warnings: List[str]
    features: List[Dict[str, Any]]
    explanation: List[str]


class LocalAIFusionModel:
    """Deterministic local inference model.

    This is not a generative LLM. It behaves more like a compact institutional
    scoring model: features vote with reliability, then the final posterior is
    calibrated by confidence, execution readiness and risk. It is designed to be
    stable in Termux/offline environments.
    """

    def infer(
        self,
        *,
        macro: Dict[str, Any],
        macro_scores: Dict[str, Any],
        technical: Dict[str, Any],
        regime: Dict[str, Any],
        micro: Dict[str, Any],
        playbook: Dict[str, Any],
        trigger: Dict[str, Any],
        risk: Dict[str, Any],
        learning_profile: Dict[str, Any] | None = None,
    ) -> FusionResult:
        features: List[EvidenceFeature] = []

        tech_long = _num(technical.get("long"))
        tech_short = _num(technical.get("short"))
        tech_quality = _num(technical.get("quality"))
        tech_conf = _num(technical.get("confidence"))
        tech_bias = "long" if tech_long > tech_short else "short" if tech_short > tech_long else "neutral"
        tech_edge = abs(tech_long - tech_short)
        features.append(EvidenceFeature(
            name="technical_probability",
            side=tech_bias,
            strength=min(100.0, 50.0 + tech_edge),
            reliability=max(20.0, min(95.0, (tech_quality * 0.55) + (tech_conf * 0.45))),
            weight=2.4,
            note=f"technical long={tech_long} short={tech_short} quality={tech_quality} confidence={tech_conf}",
        ))

        macro_long = _num(macro_scores.get("long"))
        macro_short = _num(macro_scores.get("short"))
        macro_conf = _num(macro_scores.get("confidence"), _num(macro.get("confidence")))
        macro_bias = "long" if macro_long > macro_short else "short" if macro_short > macro_long else "neutral"
        macro_edge = abs(macro_long - macro_short)
        features.append(EvidenceFeature(
            name="macro_direction",
            side=macro_bias,
            strength=min(100.0, 50.0 + macro_edge),
            reliability=max(10.0, min(95.0, macro_conf)),
            weight=2.8,
            note=f"macro gold_bias={macro.get('gold_bias')} news={macro.get('news_bias')} market={macro.get('market_bias')}",
        ))

        primary_side = str(regime.get("primary_side") or "neutral")
        phase = str(regime.get("phase") or "")
        exec_alignment = str(regime.get("execution_alignment") or "")
        regime_reliability = 75.0 if exec_alignment == "aligned" else 58.0 if "pullback" in phase else 45.0
        regime_strength = 72.0 if "continuation" in phase else 62.0 if "pullback" in phase else 45.0
        features.append(EvidenceFeature(
            name="market_regime",
            side=primary_side,
            strength=regime_strength,
            reliability=regime_reliability,
            weight=2.0,
            note=f"{regime.get('name')} / {phase} / {exec_alignment}",
        ))

        pb_side = str(playbook.get("side") or "neutral")
        pb_state = str(playbook.get("state") or "WAIT")
        pb_strength = 78.0 if pb_state.startswith("READY") else 65.0 if pb_state.startswith("PREPARE") else 35.0
        features.append(EvidenceFeature(
            name="playbook_state",
            side=pb_side,
            strength=pb_strength,
            reliability=65.0 if pb_side in {"long", "short"} else 30.0,
            weight=1.4,
            note=f"{playbook.get('name')} / {pb_state}",
        ))

        trig_side = str(trigger.get("side") or "neutral")
        trig_state = str(trigger.get("state") or "WAIT")
        trig_strength = 92.0 if trig_state.startswith("EXECUTE") else 65.0 if trig_state.startswith("PREPARE") else 20.0
        trig_rel = 82.0 if trigger.get("ready") else 45.0 if trig_state.startswith("PREPARE") else 25.0
        features.append(EvidenceFeature(
            name="execution_trigger",
            side=trig_side,
            strength=trig_strength,
            reliability=trig_rel,
            weight=1.8,
            note=str(trigger.get("reason") or ""),
        ))

        depth_bias = str(micro.get("depth_bias") or "balanced")
        trade_bias = str(micro.get("trade_bias") or "balanced")
        micro_side = "neutral"
        micro_points = 0
        if depth_bias == "bid_support":
            micro_points += 1
        elif depth_bias == "ask_pressure":
            micro_points -= 1
        if trade_bias == "aggressive_buying":
            micro_points += 1
        elif trade_bias == "aggressive_selling":
            micro_points -= 1
        if micro_points > 0:
            micro_side = "long"
        elif micro_points < 0:
            micro_side = "short"
        features.append(EvidenceFeature(
            name="orderflow_microstructure",
            side=micro_side,
            strength=50.0 + abs(micro_points) * 18.0,
            reliability=52.0,
            weight=1.0,
            note=f"depth={depth_bias} trades={trade_bias} spread_ok={micro.get('spread_ok')}",
        ))

        hard_blockers: List[str] = []
        soft_warnings: List[str] = []
        if not macro.get("attached"):
            hard_blockers.append("News/Macro V8.5 missing")
        if (macro.get("event_risk") or {}).get("blocks_trade"):
            hard_blockers.append("High-impact macro event risk")
        if playbook.get("macro_conflict"):
            hard_blockers.append("Final macro direction conflicts with chart/playbook")
        elif macro.get("bias_conflict"):
            soft_warnings.append(f"Macro components disagree ({macro.get('conflict_severity','UNKNOWN')}); final macro bias remains authoritative")
        if not micro.get("spread_ok", True):
            hard_blockers.append("Spread not acceptable")
        if _num(technical.get("quality")) < 68:
            soft_warnings.append("Trade quality is below institutional threshold")
        if _num(technical.get("confidence")) < 18:
            soft_warnings.append("Technical confidence is low")
        if _num(risk.get("score")) >= 55:
            soft_warnings.append("Overall risk score is high")

        learning_profile = learning_profile or {}
        learning_enabled = bool(learning_profile.get("enabled"))
        learned_multipliers = learning_profile.get("feature_multipliers") or {}
        learned_thresholds = learning_profile.get("thresholds") or {}
        if learning_enabled and isinstance(learned_multipliers, dict):
            for f in features:
                try:
                    mult = float(learned_multipliers.get(f.name, 1.0))
                except Exception:
                    mult = 1.0
                # Keep adaptive multipliers bounded. This makes the learning layer
                # calibrate weights without letting one feature dominate forever.
                mult = _clamp(mult, 55.0, 165.0) / 100.0 if mult > 10 else max(0.55, min(1.65, mult))
                f.weight *= mult

        raw = sum(f.contribution() for f in features)
        risk_penalty = _num(risk.get("score")) / 100.0 * 1.15
        confidence_penalty = max(0.0, 22.0 - tech_conf) / 100.0 * 0.55
        adjusted = raw - risk_penalty * (1 if raw > 0 else -1 if raw < 0 else 0) - confidence_penalty * (1 if raw > 0 else -1 if raw < 0 else 0)
        # Convert signed evidence to posterior. The scale is intentionally modest;
        # weak/contradictory evidence naturally lands near 50/50.
        raw_long_probability = _sigmoid(adjusted * 1.45) * 100.0
        raw_short_probability = 100.0 - raw_long_probability

        avg_reliability = sum(_clamp(f.reliability) for f in features) / max(1, len(features))
        metrics = (learning_profile or {}).get("metrics") or {}
        try:
            calibration_samples = int(metrics.get("samples") or 0)
        except Exception:
            calibration_samples = 0
        # Shrink extreme evidence posteriors toward 50 until reliability and observed
        # calibration history justify stronger conviction. This prevents values such
        # as 99.97% from being mistaken for an empirical win probability.
        reliability_factor = 0.58 + 0.32 * (_clamp(avg_reliability) / 100.0)
        sample_factor = 0.72 + 0.28 * min(1.0, (calibration_samples / 200.0) ** 0.5)
        shrink = min(0.94, reliability_factor * sample_factor)
        long_probability = 50.0 + (raw_long_probability - 50.0) * shrink
        short_probability = 100.0 - long_probability
        if abs(long_probability - short_probability) < 3.0:
            direction = "neutral"
        else:
            direction = "long" if long_probability > short_probability else "short"
        edge = abs(long_probability - short_probability)

        confidence = _clamp(edge * 0.65 + avg_reliability * 0.22 - _num(risk.get("score")) * 0.18)
        if hard_blockers:
            confidence = min(confidence, 19.0)

        ready_threshold = _num(learned_thresholds.get("ready_confidence"), 30.0) if isinstance(learned_thresholds, dict) else 30.0
        execute_threshold = _num(learned_thresholds.get("execute_confidence"), 35.0) if isinstance(learned_thresholds, dict) else 35.0
        spot_threshold = _num(learned_thresholds.get("spot_confidence"), 32.0) if isinstance(learned_thresholds, dict) else 32.0
        scalp_threshold = _num(learned_thresholds.get("scalp_confidence"), 38.0) if isinstance(learned_thresholds, dict) else 38.0

        if direction not in {"long", "short"}:
            execution_state = "WAIT"
        elif hard_blockers:
            execution_state = "BLOCKED_" + direction.upper()
        elif trigger.get("state", "").startswith("EXECUTE") and trigger.get("side") == direction and confidence >= execute_threshold:
            execution_state = "EXECUTE_" + direction.upper()
        elif playbook.get("state", "").startswith("READY") and confidence >= ready_threshold:
            execution_state = "READY_" + direction.upper()
        elif playbook.get("state", "").startswith("PREPARE") or trigger.get("state", "").startswith("PREPARE"):
            execution_state = "PREPARE_" + direction.upper()
        else:
            execution_state = "WAIT"

        if hard_blockers:
            trade_permission = "BLOCKED"
        elif execution_state.startswith("EXECUTE") and confidence >= scalp_threshold:
            trade_permission = "ALLOW_SCALP_AND_SPOT"
        elif execution_state.startswith("READY") and confidence >= spot_threshold:
            trade_permission = "ALLOW_SPOT_ONLY"
        elif execution_state.startswith("PREPARE"):
            trade_permission = "WATCH_ONLY"
        else:
            trade_permission = "WAIT"

        explanation = []
        for f in sorted(features, key=lambda x: abs(x.contribution()), reverse=True)[:8]:
            explanation.append(
                f"{f.name}: side={f.side}, strength={round(f.strength, 2)}, reliability={round(f.reliability, 2)}, contribution={round(f.contribution(), 4)}"
            )
        if hard_blockers:
            explanation.append("Hard blockers: " + "; ".join(hard_blockers))
        if soft_warnings:
            explanation.append("Warnings: " + "; ".join(soft_warnings))

        return FusionResult(
            model="LOCAL_AI_EVIDENCE_FUSION_V2_ADAPTIVE" if learning_enabled else "LOCAL_AI_EVIDENCE_FUSION_V1",
            direction=direction,
            confidence=round(confidence, 2),
            long_probability=round(long_probability, 2),
            short_probability=round(short_probability, 2),
            raw_long_probability=round(raw_long_probability, 2),
            raw_short_probability=round(raw_short_probability, 2),
            calibration_samples=calibration_samples,
            probability_semantics="calibrated_evidence_posterior_not_empirical_win_rate",
            edge=round(edge, 2),
            execution_state=execution_state,
            trade_permission=trade_permission,
            hard_blockers=list(dict.fromkeys(hard_blockers)),
            soft_warnings=list(dict.fromkeys(soft_warnings)),
            features=[asdict(f) | {"contribution": round(f.contribution(), 5)} for f in features],
            explanation=explanation,
        )


def infer_final_decision(**kwargs: Any) -> Dict[str, Any]:
    return asdict(LocalAIFusionModel().infer(**kwargs))
