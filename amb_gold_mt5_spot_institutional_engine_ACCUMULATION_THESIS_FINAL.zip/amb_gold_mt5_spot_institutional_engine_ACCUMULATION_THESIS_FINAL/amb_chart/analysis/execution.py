from __future__ import annotations
from typing import Any, Dict, List, Tuple


def _d(v: Any) -> Dict[str, Any]:
    return v if isinstance(v, dict) else {}


def _l(v: Any) -> List[Any]:
    return v if isinstance(v, list) else []


def _n(v: Any, default: float = 0.0) -> float:
    try:
        if v is None or v == '':
            return default
        return float(v)
    except Exception:
        return default


def _clamp(x: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, x))


def _tf(chart: Dict[str, Any], tf: str) -> Dict[str, Any]:
    return _d(_d(chart.get('timeframes')).get(tf))


def _reference(chart: Dict[str, Any]) -> float:
    return (
        _n(_d(chart.get('trade_map')).get('reference_price'))
        or _n(_tf(chart, 'M15').get('last_close'))
        or _n(_tf(chart, 'H1').get('last_close'))
    )


def _atr(chart: Dict[str, Any], tf: str, fallback: float = 1.0) -> float:
    return max(_n(_tf(chart, tf).get('atr'), fallback), 1e-9)


def _zone_bounds(z: Dict[str, Any]) -> Tuple[float, float]:
    level = _n(z.get('level'))
    lo = _n(z.get('low'), level)
    hi = _n(z.get('high'), level)
    if hi < lo:
        lo, hi = hi, lo
    return lo, hi


def _zone_relation_metrics(reference: float, lo: float, hi: float, atr: float, side: str) -> Dict[str, Any]:
    if lo <= reference <= hi:
        distance = 0.0
        relation = 'inside_zone'
    elif reference > hi:
        distance = reference - hi
        relation = 'above_zone'
    else:
        distance = lo - reference
        relation = 'below_zone'
    distance_atr = distance / max(atr, 1e-9)
    chase = (side == 'long' and relation == 'above_zone') or (side == 'short' and relation == 'below_zone')
    adverse = (side == 'long' and relation == 'below_zone') or (side == 'short' and relation == 'above_zone')
    return {
        'relation': relation,
        'distance': round(distance, 6),
        'distance_atr': round(distance_atr, 3),
        'inside': relation == 'inside_zone',
        'chase_side': chase,
        'adverse_side': adverse,
    }


def _zone_score(z: Dict[str, Any], side: str, reference: float, atr: float, style: str) -> Tuple[float, Dict[str, Any]]:
    lo, hi = _zone_bounds(z)
    mid = (lo + hi) / 2.0 if hi or lo else reference
    score = _n(z.get('rank_score'), _n(z.get('score'), 55.0))
    status = str(z.get('status') or '').lower()
    source = str(z.get('source') or '').lower()
    tf = str(z.get('timeframe') or '')

    # Structural quality.
    if status == 'fresh':
        score += 16
    elif status == 'open':
        score += 10
    elif status == 'mitigated':
        score -= 5
    elif status == 'invalidated':
        score -= 60
    if 'order_block' in source:
        score += 9
    if 'fvg' in source:
        score += 5
    if source == 'support' or source == 'resistance':
        score += 2

    # Timeframe preference is deliberately different for spot and scalp.
    if style == 'spot':
        score += {'D1': 13, 'H4': 12, 'H1': 8, 'M15': 1, 'M5': 0}.get(tf, 0)
    else:
        score += {'M15': 13, 'M5': 12, 'H1': 5, 'H4': 0, 'D1': -3}.get(tf, 0)

    relation = _zone_relation_metrics(reference, lo, hi, atr, side)
    d_atr = float(relation['distance_atr'])

    # Execution proximity is a first-class variable. This fixes the previous failure
    # where a very high raw OB score could beat a realistic nearby scalp zone.
    if relation['inside']:
        score += 22
    elif d_atr <= 0.25:
        score += 16
    elif d_atr <= 0.55:
        score += 9
    elif d_atr <= 1.0:
        score += 2
    elif d_atr <= 1.8:
        score -= 10
    elif d_atr <= 3.0:
        score -= 24
    else:
        score -= 45 if style == 'spot' else 75

    # Scalp zones must be executable in the current micro horizon. Very distant zones
    # remain visible as context but are strongly de-prioritized.
    if style == 'scalp' and d_atr > 2.5:
        score -= min(80.0, (d_atr - 2.5) * 7.0)

    # Avoid chasing the wrong side of a pullback zone, but do not erase a valid
    # breakout/retest candidate because the state machine can still use it.
    if relation['chase_side']:
        score -= min(24.0, 6.0 + d_atr * 5.0)
    if relation['adverse_side'] and d_atr > 0.8:
        score -= min(18.0, d_atr * 4.0)

    # Small percentage-distance penalty as a secondary normalization.
    dist_pct = abs(mid - reference) / max(reference, 1e-9) * 100
    score -= min(10.0, dist_pct * 2.0)
    return round(score, 2), relation


def _candidate_zones(chart: Dict[str, Any], side: str, style: str) -> List[Dict[str, Any]]:
    tm = _d(chart.get('trade_map'))
    zones = _l(tm.get('buy_zones' if side == 'long' else 'sell_zones'))
    ref = _reference(chart)
    atr_tf = 'H1' if style == 'spot' else 'M15'
    atr = _atr(chart, atr_tf, _atr(chart, 'H1', 1.0))
    allowed_tfs = {'D1', 'H4', 'H1'} if style == 'spot' else {'M5', 'M15', 'H1'}
    out: List[Dict[str, Any]] = []

    for z in zones:
        if not isinstance(z, dict):
            continue
        tf = str(z.get('timeframe') or '')
        if tf not in allowed_tfs:
            continue
        lo, hi = _zone_bounds(z)
        if lo <= 0 or hi <= 0:
            continue
        item = dict(z)
        score, relation = _zone_score(item, side, ref, atr, style)
        item['execution_score'] = score
        item['mid'] = round((lo + hi) / 2.0, 6)
        item['execution_distance'] = relation
        item['atr_basis'] = {'timeframe': atr_tf, 'atr': round(atr, 6)}
        out.append(item)

    # First rank on real execution quality, then proximity. This prevents a distant
    # historical OB from becoming the primary scalp zone merely because its raw score is high.
    return sorted(
        out,
        key=lambda x: (
            _n(x.get('execution_score')),
            -_n(_d(x.get('execution_distance')).get('distance_atr'), 999.0),
        ),
        reverse=True,
    )


def _collect_levels(chart: Dict[str, Any], side: str, reference: float | None = None) -> List[float]:
    levels: List[float] = []
    ref = reference if reference is not None else _reference(chart)
    for tf in ('M5', 'M15', 'H1', 'H4', 'D1'):
        c = _tf(chart, tf)
        sr = _d(c.get('support_resistance'))
        arr = _l(sr.get('resistances' if side == 'long' else 'supports'))
        levels.extend(_n(x) for x in arr)
        liq = _d(c.get('liquidity'))
        for p in _l(liq.get('pools')):
            if not isinstance(p, dict):
                continue
            typ = str(p.get('type') or '')
            level = _n(p.get('level'))
            if side == 'long' and typ == 'BSL':
                levels.append(level)
            if side == 'short' and typ == 'SSL':
                levels.append(level)
        for f in _l(c.get('fvg'))[-20:]:
            if not isinstance(f, dict):
                continue
            typ = str(f.get('type') or '')
            if side == 'long' and typ.startswith('bearish'):
                levels.append(_n(f.get('low')))
            if side == 'short' and typ.startswith('bullish'):
                levels.append(_n(f.get('high')))
    if side == 'long':
        return sorted({round(x, 6) for x in levels if x > ref})
    return sorted({round(x, 6) for x in levels if 0 < x < ref}, reverse=True)


def _derive_targets(side: str, entry: float, stop: float, structural: List[float], atr: float) -> List[Dict[str, Any]]:
    risk = abs(entry - stop)
    if risk <= 0:
        return []
    target_candidates: List[Dict[str, Any]] = []
    for lv in structural:
        reward = (lv - entry) if side == 'long' else (entry - lv)
        if reward <= 0:
            continue
        rr = reward / risk
        if rr >= 0.8:
            target_candidates.append({'price': round(lv, 6), 'rr': round(rr, 2), 'source': 'structure'})

    rr_ladder = (1.0, 1.75, 2.5) if risk >= atr * 0.45 else (1.2, 2.0, 3.0)
    for rr in rr_ladder:
        px = entry + risk * rr if side == 'long' else entry - risk * rr
        target_candidates.append({'price': round(px, 6), 'rr': round(rr, 2), 'source': 'rr_projection'})

    merged: Dict[float, Dict[str, Any]] = {}
    for t in target_candidates:
        key = round(t['price'], 4)
        if key not in merged or (merged[key]['source'] != 'structure' and t['source'] == 'structure'):
            merged[key] = t
    ranked = sorted(merged.values(), key=lambda x: x['rr'])
    selected: List[Dict[str, Any]] = []
    for desired in (1.0, 1.7, 2.4):
        candidates = [x for x in ranked if x['rr'] >= desired and x not in selected]
        if candidates:
            selected.append(candidates[0])
    while len(selected) < 3:
        for x in ranked:
            if x not in selected:
                selected.append(x)
                if len(selected) >= 3:
                    break
        if not ranked:
            break
    return selected[:3]


def _zone_confluence(chart: Dict[str, Any], zone: Dict[str, Any], side: str, style: str) -> Dict[str, Any]:
    lo, hi = _zone_bounds(zone)
    mid = (lo + hi) / 2.0
    score = 0.0
    reasons: List[str] = []
    tf = str(zone.get('timeframe') or '')
    source = str(zone.get('source') or '').lower()
    status = str(zone.get('status') or '').lower()
    if 'order_block' in source:
        score += 24
        reasons.append('order_block')
    if 'fvg' in source:
        score += 15
        reasons.append('fvg')
    if status == 'fresh':
        score += 18
        reasons.append('fresh')
    elif status == 'open':
        score += 12
        reasons.append('open_imbalance')
    elif status == 'mitigated':
        score += 5
        reasons.append('mitigated')
    if tf in {'D1', 'H4'}:
        score += 20
    elif tf == 'H1':
        score += 14
    elif tf == 'M15':
        score += 9
    elif tf == 'M5':
        score += 6

    tol = max(abs(hi - lo), _atr(chart, 'H1', 1.0) * 0.35)
    hits = 0
    tf_hits: List[str] = []
    for t in ('M5', 'M15', 'H1', 'H4', 'D1'):
        c = _tf(chart, t)
        sr = _d(c.get('support_resistance'))
        arr = _l(sr.get('supports' if side == 'long' else 'resistances'))
        local_hit = any(abs(_n(x) - mid) <= tol for x in arr)
        for f in _l(c.get('fvg'))[-12:]:
            if not isinstance(f, dict):
                continue
            typ = str(f.get('type') or '')
            if (side == 'long' and typ.startswith('bullish')) or (side == 'short' and typ.startswith('bearish')):
                flo, fhi = _zone_bounds(f)
                if max(lo, flo) <= min(hi, fhi):
                    local_hit = True
        if local_hit:
            hits += 1
            tf_hits.append(t)
    score += min(24, hits * 4)
    if hits:
        reasons.append(f'mtf_confluence_{hits}')
    return {'score': round(_clamp(score, 0, 100), 2), 'hits': hits, 'timeframes': tf_hits, 'reasons': reasons}


def _premium_discount(chart: Dict[str, Any], reference: float) -> Dict[str, Any]:
    highs: List[float] = []
    lows: List[float] = []
    for tf in ('H1', 'H4', 'D1'):
        sw = _d(_tf(chart, tf).get('swings'))
        h = _d(sw.get('last_high'))
        l = _d(sw.get('last_low'))
        if _n(h.get('price')) > 0:
            highs.append(_n(h.get('price')))
        if _n(l.get('price')) > 0:
            lows.append(_n(l.get('price')))
    if not highs or not lows:
        return {'available': False}
    hi = max(highs)
    lo = min(lows)
    if hi <= lo:
        return {'available': False}
    pos = (reference - lo) / (hi - lo)
    return {
        'available': True,
        'range_low': round(lo, 6),
        'range_high': round(hi, 6),
        'equilibrium': round((lo + hi) / 2.0, 6),
        'position': round(pos, 4),
        'zone': 'discount' if pos < 0.45 else 'premium' if pos > 0.55 else 'equilibrium',
    }


def _timing_quality(chart: Dict[str, Any], side: str, style: str, plan: Dict[str, Any]) -> Dict[str, Any]:
    score = 50.0
    reasons: List[str] = []
    ref = _reference(chart)
    location = _d(plan.get('price_location'))
    d_atr = _n(location.get('distance_atr'), 99.0)
    if location.get('inside_primary_zone'):
        score += 22
        reasons.append('inside_primary_zone')
    elif d_atr <= 0.35:
        score += 12
        reasons.append('near_primary_zone')
    elif d_atr > 1.5:
        score -= 18
        reasons.append('far_from_primary_zone')
    if location.get('chase_risk'):
        score -= 20
        reasons.append('chase_risk')

    # Multi-timeframe directional alignment contributes to timing but does not replace
    # the dedicated state machine trigger.
    tfs = ('M5', 'M15', 'H1') if style == 'scalp' else ('M15', 'H1', 'H4')
    aligned = 0
    for tf in tfs:
        c = _tf(chart, tf)
        text = ' '.join(str(c.get(k) or '').lower() for k in ('trend', 'structure', 'momentum'))
        if side == 'long' and 'bull' in text:
            aligned += 1
        elif side == 'short' and 'bear' in text:
            aligned += 1
    score += aligned * 6
    reasons.append(f'aligned_tfs={aligned}/{len(tfs)}')

    pd = _d(plan.get('premium_discount'))
    if pd.get('available'):
        pd_zone = str(pd.get('zone') or '')
        if side == 'long' and pd_zone == 'discount':
            score += 8
            reasons.append('long_in_discount')
        if side == 'short' and pd_zone == 'premium':
            score += 8
            reasons.append('short_in_premium')
        if side == 'long' and pd_zone == 'premium':
            score -= 5
            reasons.append('long_in_premium')
        if side == 'short' and pd_zone == 'discount':
            score -= 5
            reasons.append('short_in_discount')

    return {'score': round(_clamp(score, 0, 100), 2), 'reasons': reasons, 'reference_price': round(ref, 6)}


def build_execution_plan(chart: Dict[str, Any], side: str, style: str = 'spot') -> Dict[str, Any]:
    if side not in {'long', 'short'}:
        return {'valid': False, 'reason': 'No directional side', 'entry_zones': [], 'invalidation': None, 'targets': [], 'rr': {}}

    ref = _reference(chart)
    candidates = _candidate_zones(chart, side, style)
    if not candidates:
        return {'valid': False, 'reason': 'No candidate execution zone', 'entry_zones': [], 'invalidation': None, 'targets': [], 'rr': {}}

    primary = candidates[0]
    lo, hi = _zone_bounds(primary)
    entry = (lo + hi) / 2.0
    if entry <= 0:
        entry = ref

    tf = 'H1' if style == 'spot' else 'M15'
    atr = _atr(chart, tf, _atr(chart, 'H1', 1.0))
    micro = _d(chart.get('market_microstructure'))
    spread = _n(micro.get('spread'), 0.0)

    atr_mult = 0.35 if style == 'spot' else 0.22
    buffer = max(atr * atr_mult, spread * 2.5, ref * 0.00035)
    if side == 'long':
        stop = lo - buffer
        if stop >= lo:
            stop = lo - max(buffer, atr * 0.2)
    else:
        stop = hi + buffer
        if stop <= hi:
            stop = hi + max(buffer, atr * 0.2)

    # Targets are derived from the planned entry, not the current market reference.
    structural = _collect_levels(chart, side, reference=entry)
    targets = _derive_targets(side, entry, stop, structural, atr)
    risk = abs(entry - stop)
    reward1 = abs(targets[0]['price'] - entry) if targets else 0.0
    rr1 = reward1 / risk if risk else 0.0
    valid_geometry = stop < lo <= hi if side == 'long' else stop > hi >= lo

    confluence = _zone_confluence(chart, primary, side, style)
    pd = _premium_discount(chart, ref)
    relation = _zone_relation_metrics(ref, lo, hi, atr, side)
    chase_risk = bool(relation['chase_side'] and relation['distance_atr'] > 0.55)
    min_rr = 1.0 if style == 'scalp' else 1.2
    valid = bool(valid_geometry and targets and rr1 >= min_rr * 0.8)

    base_score = _n(primary.get('execution_score'), 50.0)
    quality = _clamp(base_score * 0.56 + confluence['score'] * 0.29 + min(15.0, rr1 * 5.0), 0, 100)
    primary_entry = {
        'low': round(lo, 6),
        'high': round(hi, 6),
        'mid': round(entry, 6),
        'timeframe': primary.get('timeframe'),
        'source': primary.get('source'),
        'status': primary.get('status'),
        'quality_score': primary.get('execution_score'),
        'distance': primary.get('execution_distance'),
    }

    plan: Dict[str, Any] = {
        'valid': valid,
        'reason': 'ATR/spread buffered structural execution plan with MTF confluence' if valid_geometry else 'Invalid execution geometry',
        'style': style,
        'reference_price': round(ref, 6),
        'atr_basis': {'timeframe': tf, 'atr': round(atr, 6)},
        'entry_zones': [primary] + candidates[1:3],
        'primary_entry': primary_entry,
        'invalidation': round(stop, 6),
        'invalidation_model': {
            'method': 'zone_extreme_plus_atr_spread_buffer',
            'buffer': round(buffer, 6),
            'atr_multiple': atr_mult,
            'spread_multiple': 2.5,
        },
        'stop_distance': round(risk, 6),
        'stop_atr_multiple': round(risk / max(atr, 1e-9), 3),
        'targets': targets,
        'rr': {'tp1': round(rr1, 2), 'minimum_acceptable': min_rr},
        'quality': round(quality, 2),
        'zone_confluence': confluence,
        'premium_discount': pd,
        'price_location': {
            'inside_primary_zone': bool(relation['inside']),
            'relation': relation['relation'],
            'distance_to_zone': relation['distance'],
            'distance_atr': relation['distance_atr'],
            'chase_risk': chase_risk,
            'zone_mid': round((lo + hi) / 2.0, 6),
        },
    }
    plan['timing_quality'] = _timing_quality(chart, side, style, plan)
    plan['execution_grade'] = (
        'A+' if quality >= 90 and rr1 >= 1.5 else
        'A' if quality >= 82 and rr1 >= 1.2 else
        'B' if quality >= 70 else
        'C'
    )
    plan['professional_checks'] = {
        'geometry_valid': bool(valid_geometry),
        'rr_valid': bool(targets and rr1 >= min_rr * 0.8),
        'zone_executable_now': bool(relation['inside'] or relation['distance_atr'] <= 0.55),
        'chase_risk': chase_risk,
        'confluence_hits': confluence.get('hits'),
    }
    return plan
