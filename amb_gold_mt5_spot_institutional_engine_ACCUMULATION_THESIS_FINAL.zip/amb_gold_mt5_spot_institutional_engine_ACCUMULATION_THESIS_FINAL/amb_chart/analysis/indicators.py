from __future__ import annotations
import numpy as np
import pandas as pd


def ema(series: pd.Series, span: int) -> pd.Series:
    return series.ewm(span=span, adjust=False).mean()


def sma(series: pd.Series, period: int) -> pd.Series:
    return series.rolling(period).mean()


def rsi(close: pd.Series, period: int = 14) -> pd.Series:
    delta = close.diff()
    gain = delta.where(delta > 0, 0.0).rolling(period).mean()
    loss = (-delta.where(delta < 0, 0.0)).rolling(period).mean()
    rs = gain / loss.replace(0, np.nan)
    return 100 - (100 / (1 + rs))


def atr(df: pd.DataFrame, period: int = 14) -> pd.Series:
    high, low, close = df['high'], df['low'], df['close']
    prev_close = close.shift(1)
    tr = pd.concat([(high-low).abs(), (high-prev_close).abs(), (low-prev_close).abs()], axis=1).max(axis=1)
    return tr.rolling(period).mean()


def adx(df: pd.DataFrame, period: int = 14) -> pd.Series:
    high, low = df['high'], df['low']
    plus_dm = high.diff()
    minus_dm = -low.diff()
    plus_dm = plus_dm.where((plus_dm > minus_dm) & (plus_dm > 0), 0.0)
    minus_dm = minus_dm.where((minus_dm > plus_dm) & (minus_dm > 0), 0.0)
    tr = atr(df, 1)
    plus_di = 100 * plus_dm.rolling(period).sum() / tr.rolling(period).sum().replace(0, np.nan)
    minus_di = 100 * minus_dm.rolling(period).sum() / tr.rolling(period).sum().replace(0, np.nan)
    dx = (100 * (plus_di - minus_di).abs() / (plus_di + minus_di).replace(0, np.nan))
    return dx.rolling(period).mean()


def wilder_rma(series: pd.Series, period: int) -> pd.Series:
    return series.ewm(alpha=1 / period, adjust=False).mean()


def supertrend(df: pd.DataFrame, period: int = 10, multiplier: float = 3.0) -> tuple[pd.Series, pd.Series]:
    hl2 = (df['high'] + df['low']) / 2.0
    atrv = atr(df, period).bfill()
    upper = hl2 + multiplier * atrv
    lower = hl2 - multiplier * atrv
    final_upper = upper.copy()
    final_lower = lower.copy()
    direction = pd.Series(index=df.index, dtype=float)
    st = pd.Series(index=df.index, dtype=float)
    for i in range(len(df)):
        if i == 0:
            direction.iloc[i] = 1.0
            st.iloc[i] = final_lower.iloc[i]
            continue
        if upper.iloc[i] < final_upper.iloc[i-1] or df['close'].iloc[i-1] > final_upper.iloc[i-1]:
            final_upper.iloc[i] = upper.iloc[i]
        else:
            final_upper.iloc[i] = final_upper.iloc[i-1]
        if lower.iloc[i] > final_lower.iloc[i-1] or df['close'].iloc[i-1] < final_lower.iloc[i-1]:
            final_lower.iloc[i] = lower.iloc[i]
        else:
            final_lower.iloc[i] = final_lower.iloc[i-1]
        if df['close'].iloc[i] > final_upper.iloc[i-1]:
            direction.iloc[i] = 1.0
        elif df['close'].iloc[i] < final_lower.iloc[i-1]:
            direction.iloc[i] = -1.0
        else:
            direction.iloc[i] = direction.iloc[i-1]
        st.iloc[i] = final_lower.iloc[i] if direction.iloc[i] > 0 else final_upper.iloc[i]
    return st, direction


def stoch_rsi(close: pd.Series, period: int = 14, smooth_k: int = 3, smooth_d: int = 3) -> tuple[pd.Series, pd.Series]:
    r = rsi(close, period)
    lo = r.rolling(period).min()
    hi = r.rolling(period).max()
    k = 100 * (r - lo) / (hi - lo).replace(0, np.nan)
    k = k.rolling(smooth_k).mean()
    d = k.rolling(smooth_d).mean()
    return k, d


def ichimoku(df: pd.DataFrame) -> pd.DataFrame:
    high, low, close = df['high'], df['low'], df['close']
    tenkan = (high.rolling(9).max() + low.rolling(9).min()) / 2
    kijun = (high.rolling(26).max() + low.rolling(26).min()) / 2
    span_a = ((tenkan + kijun) / 2).shift(26)
    span_b = ((high.rolling(52).max() + low.rolling(52).min()) / 2).shift(26)
    chikou = close.shift(-26)
    out = pd.DataFrame({
        'ichimoku_tenkan': tenkan,
        'ichimoku_kijun': kijun,
        'ichimoku_span_a': span_a,
        'ichimoku_span_b': span_b,
        'ichimoku_chikou': chikou,
    }, index=df.index)
    cloud_top = pd.concat([span_a, span_b], axis=1).max(axis=1)
    cloud_bottom = pd.concat([span_a, span_b], axis=1).min(axis=1)
    out['ichimoku_cloud_top'] = cloud_top
    out['ichimoku_cloud_bottom'] = cloud_bottom
    out['ichimoku_cloud_bias'] = np.where(close > cloud_top, 1, np.where(close < cloud_bottom, -1, 0))
    out['ichimoku_tk_cross'] = np.where(tenkan > kijun, 1, np.where(tenkan < kijun, -1, 0))
    return out


def keltner_channels(df: pd.DataFrame, period: int = 20, mult: float = 1.5) -> pd.DataFrame:
    mid = ema(df['close'], period)
    a = atr(df, period)
    return pd.DataFrame({'kc_mid': mid, 'kc_upper': mid + mult*a, 'kc_lower': mid - mult*a}, index=df.index)


def donchian(df: pd.DataFrame, period: int = 20) -> pd.DataFrame:
    upper = df['high'].rolling(period).max()
    lower = df['low'].rolling(period).min()
    return pd.DataFrame({'donchian_upper': upper, 'donchian_lower': lower, 'donchian_mid': (upper+lower)/2}, index=df.index)


def vwap_session_proxy(df: pd.DataFrame) -> pd.Series:
    tp = (df['high'] + df['low'] + df['close']) / 3.0
    vol = df['volume'].replace(0, np.nan).fillna(1.0)
    if 'time' in df:
        dates = pd.to_datetime(df['time'], errors='coerce', utc=True).dt.date
        return (tp * vol).groupby(dates).cumsum() / vol.groupby(dates).cumsum().replace(0, np.nan)
    return (tp * vol).cumsum() / vol.cumsum().replace(0, np.nan)


def heikin_ashi(df: pd.DataFrame) -> pd.DataFrame:
    ha_close = (df['open'] + df['high'] + df['low'] + df['close']) / 4
    ha_open = ha_close.copy()
    for i in range(len(df)):
        if i == 0:
            ha_open.iloc[i] = (df['open'].iloc[i] + df['close'].iloc[i]) / 2
        else:
            ha_open.iloc[i] = (ha_open.iloc[i-1] + ha_close.iloc[i-1]) / 2
    ha_high = pd.concat([df['high'], ha_open, ha_close], axis=1).max(axis=1)
    ha_low = pd.concat([df['low'], ha_open, ha_close], axis=1).min(axis=1)
    return pd.DataFrame({'ha_open': ha_open, 'ha_high': ha_high, 'ha_low': ha_low, 'ha_close': ha_close}, index=df.index)


def candle_patterns(df: pd.DataFrame) -> pd.DataFrame:
    body = (df['close'] - df['open']).abs()
    rng = (df['high'] - df['low']).replace(0, np.nan)
    upper = df['high'] - pd.concat([df['open'], df['close']], axis=1).max(axis=1)
    lower = pd.concat([df['open'], df['close']], axis=1).min(axis=1) - df['low']
    bull_engulf = (df['close'] > df['open']) & (df['close'].shift(1) < df['open'].shift(1)) & (df['close'] > df['open'].shift(1)) & (df['open'] < df['close'].shift(1))
    bear_engulf = (df['close'] < df['open']) & (df['close'].shift(1) > df['open'].shift(1)) & (df['close'] < df['open'].shift(1)) & (df['open'] > df['close'].shift(1))
    pin_bull = (lower / rng > 0.55) & (body / rng < 0.35)
    pin_bear = (upper / rng > 0.55) & (body / rng < 0.35)
    return pd.DataFrame({
        'candle_body_pct': body / rng,
        'upper_wick_pct': upper / rng,
        'lower_wick_pct': lower / rng,
        'bullish_engulfing': bull_engulf.astype(int),
        'bearish_engulfing': bear_engulf.astype(int),
        'bullish_pinbar': pin_bull.astype(int),
        'bearish_pinbar': pin_bear.astype(int),
    }, index=df.index)


def pivot_levels(df: pd.DataFrame) -> pd.DataFrame:
    # Rolling prior day pivots when timestamps are available; otherwise prior candle pivots.
    h, l, c = df['high'].shift(1), df['low'].shift(1), df['close'].shift(1)
    p = (h + l + c) / 3
    return pd.DataFrame({
        'pivot': p,
        'pivot_r1': 2*p - l,
        'pivot_s1': 2*p - h,
        'pivot_r2': p + (h-l),
        'pivot_s2': p - (h-l),
    }, index=df.index)




def roc(close: pd.Series, period: int = 12) -> pd.Series:
    return (close / close.shift(period) - 1.0) * 100.0

def cci(df: pd.DataFrame, period: int = 20) -> pd.Series:
    tp = (df['high'] + df['low'] + df['close']) / 3.0
    ma = tp.rolling(period).mean()
    md = tp.rolling(period).apply(lambda x: np.mean(np.abs(x - np.mean(x))), raw=True)
    return (tp - ma) / (0.015 * md.replace(0, np.nan))

def williams_r(df: pd.DataFrame, period: int = 14) -> pd.Series:
    hh = df['high'].rolling(period).max(); ll = df['low'].rolling(period).min()
    return -100.0 * (hh - df['close']) / (hh - ll).replace(0, np.nan)

def obv(df: pd.DataFrame) -> pd.Series:
    direction = np.sign(df['close'].diff()).fillna(0.0)
    return (direction * df['volume'].fillna(0.0)).cumsum()

def cmf(df: pd.DataFrame, period: int = 20) -> pd.Series:
    rng=(df['high']-df['low']).replace(0,np.nan)
    mfm=((df['close']-df['low'])-(df['high']-df['close']))/rng
    mfv=mfm*df['volume'].fillna(0.0)
    return mfv.rolling(period).sum()/df['volume'].rolling(period).sum().replace(0,np.nan)

def mfi(df: pd.DataFrame, period: int = 14) -> pd.Series:
    tp=(df['high']+df['low']+df['close'])/3.0
    flow=tp*df['volume'].fillna(0.0)
    direction=np.sign(tp.diff())
    pos=flow.where(direction>0,0.0).rolling(period).sum()
    neg=flow.where(direction<0,0.0).rolling(period).sum().abs()
    ratio=pos/neg.replace(0,np.nan)
    return 100-(100/(1+ratio))

def choppiness(df: pd.DataFrame, period: int = 14) -> pd.Series:
    tr = pd.concat([(df['high']-df['low']).abs(),(df['high']-df['close'].shift()).abs(),(df['low']-df['close'].shift()).abs()],axis=1).max(axis=1)
    denom=(df['high'].rolling(period).max()-df['low'].rolling(period).min()).replace(0,np.nan)
    return 100*np.log10(tr.rolling(period).sum()/denom)/np.log10(period)

def efficiency_ratio(close: pd.Series, period: int = 10) -> pd.Series:
    change=(close-close.shift(period)).abs()
    volatility=close.diff().abs().rolling(period).sum()
    return change/volatility.replace(0,np.nan)

def historical_volatility(close: pd.Series, period: int = 20, annualization: float = 252.0) -> pd.Series:
    logret=np.log(close/close.shift(1))
    return logret.rolling(period).std()*np.sqrt(annualization)*100

def dmi(df: pd.DataFrame, period: int = 14) -> tuple[pd.Series,pd.Series]:
    up=df['high'].diff(); down=-df['low'].diff()
    plus=up.where((up>down)&(up>0),0.0); minus=down.where((down>up)&(down>0),0.0)
    tr=pd.concat([(df['high']-df['low']).abs(),(df['high']-df['close'].shift()).abs(),(df['low']-df['close'].shift()).abs()],axis=1).max(axis=1)
    atrw=wilder_rma(tr,period)
    return 100*wilder_rma(plus,period)/atrw.replace(0,np.nan), 100*wilder_rma(minus,period)/atrw.replace(0,np.nan)


def kama(close: pd.Series, er_period: int = 10, fast: int = 2, slow: int = 30) -> pd.Series:
    change = (close - close.shift(er_period)).abs()
    volatility = close.diff().abs().rolling(er_period).sum()
    er = (change / volatility.replace(0, np.nan)).fillna(0.0)
    fast_sc, slow_sc = 2/(fast+1), 2/(slow+1)
    sc = (er*(fast_sc-slow_sc)+slow_sc)**2
    out = close.copy().astype(float)
    for i in range(1, len(close)):
        prev = out.iloc[i-1] if np.isfinite(out.iloc[i-1]) else close.iloc[i-1]
        alpha = sc.iloc[i] if np.isfinite(sc.iloc[i]) else slow_sc**2
        out.iloc[i] = prev + alpha*(close.iloc[i]-prev)
    return out


def aroon(df: pd.DataFrame, period: int = 25) -> tuple[pd.Series, pd.Series, pd.Series]:
    up = df['high'].rolling(period+1).apply(lambda x: 100.0*np.argmax(x)/period, raw=True)
    down = df['low'].rolling(period+1).apply(lambda x: 100.0*np.argmin(x)/period, raw=True)
    return up, down, up-down


def fisher_transform(df: pd.DataFrame, period: int = 10) -> pd.Series:
    hl2=(df['high']+df['low'])/2.0
    lo=hl2.rolling(period).min(); hi=hl2.rolling(period).max()
    x=2*((hl2-lo)/(hi-lo).replace(0,np.nan)-0.5)
    x=x.clip(-0.999,0.999)
    return 0.5*np.log((1+x)/(1-x))


def rolling_zscore(series: pd.Series, period: int = 50) -> pd.Series:
    m=series.rolling(period).mean(); sd=series.rolling(period).std()
    return (series-m)/sd.replace(0,np.nan)


def anchored_vwap_extremes(df: pd.DataFrame, lookback: int = 120) -> pd.DataFrame:
    tp=(df['high']+df['low']+df['close'])/3.0
    vol=df['volume'].replace(0,np.nan).fillna(1.0)
    low_anchor=pd.Series(index=df.index,dtype=float); high_anchor=pd.Series(index=df.index,dtype=float)
    for i in range(len(df)):
        start=max(0,i-lookback+1)
        window=df.iloc[start:i+1]
        li=int(window['low'].values.argmin())+start
        hi=int(window['high'].values.argmax())+start
        v=vol.iloc[li:i+1]; t=tp.iloc[li:i+1]
        low_anchor.iloc[i]=(t*v).sum()/max(v.sum(),1e-12)
        v=vol.iloc[hi:i+1]; t=tp.iloc[hi:i+1]
        high_anchor.iloc[i]=(t*v).sum()/max(v.sum(),1e-12)
    return pd.DataFrame({'avwap_from_swing_low':low_anchor,'avwap_from_swing_high':high_anchor},index=df.index)


def displacement_metrics(df: pd.DataFrame, period: int = 20) -> pd.DataFrame:
    rng=(df['high']-df['low']).replace(0,np.nan)
    body=(df['close']-df['open'])
    close_loc=(df['close']-df['low'])/rng
    rel_vol=df['volume']/df['volume'].rolling(period).median().replace(0,np.nan)
    atrv=atr(df,14).replace(0,np.nan)
    impulse=body.abs()/atrv
    eff=body.abs()/rng
    signed=np.sign(body)*impulse*eff*rel_vol.clip(0,5)
    return pd.DataFrame({
        'close_location_value':close_loc,
        'relative_volume_20':rel_vol,
        'displacement_efficiency':eff,
        'impulse_atr':impulse,
        'institutional_impulse_score':signed,
    }, index=df.index)


def volatility_regime_percentile(df: pd.DataFrame, period: int = 20, window: int = 120) -> pd.Series:
    av=atr(df,period)/df['close'].replace(0,np.nan)
    return av.rolling(window).apply(lambda x: pd.Series(x).rank(pct=True).iloc[-1]*100.0, raw=False)

def enrich_indicators(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    c = df['close']
    for p in [8, 13, 20, 21, 34, 50, 55, 89, 100, 144, 200, 233]:
        df[f'ema_{p}'] = ema(c, p)
    for p in [20, 50, 100, 200]:
        df[f'sma_{p}'] = sma(c, p)
    df['rsi_14'] = rsi(c, 14)
    df['atr_14'] = atr(df, 14)
    df['adx_14'] = adx(df, 14)
    ema12, ema26 = ema(c, 12), ema(c, 26)
    df['macd'] = ema12 - ema26
    df['macd_signal'] = ema(df['macd'], 9)
    df['macd_hist'] = df['macd'] - df['macd_signal']
    mid = c.rolling(20).mean()
    std = c.rolling(20).std()
    df['bb_mid'] = mid
    df['bb_upper'] = mid + 2*std
    df['bb_lower'] = mid - 2*std
    st, st_dir = supertrend(df, 10, 3.0)
    df['supertrend_10_3'] = st
    df['supertrend_direction'] = st_dir
    k, d = stoch_rsi(c, 14, 3, 3)
    df['stoch_rsi_k'] = k
    df['stoch_rsi_d'] = d
    for extra in [ichimoku(df), keltner_channels(df), donchian(df), heikin_ashi(df), candle_patterns(df), pivot_levels(df)]:
        df = pd.concat([df, extra], axis=1)
    df['vwap_session'] = vwap_session_proxy(df)
    df['price_vs_vwap'] = df['close'] - df['vwap_session']
    # volume helpers
    body = df['close'] - df['open']
    df['signed_volume'] = df['volume'].fillna(0) * body.apply(lambda x: 1 if x > 0 else (-1 if x < 0 else 0))
    df['cvd_proxy'] = df['signed_volume'].cumsum()
    df['volume_ma_20'] = df['volume'].rolling(20).mean()
    df['range'] = df['high'] - df['low']
    df['body'] = body
    df['body_to_atr'] = (body.abs() / df['atr_14'].replace(0, np.nan))
    df['roc_12'] = roc(c, 12)
    df['cci_20'] = cci(df, 20)
    df['williams_r_14'] = williams_r(df, 14)
    df['obv'] = obv(df)
    df['cmf_20'] = cmf(df, 20)
    df['mfi_14'] = mfi(df, 14)
    df['choppiness_14'] = choppiness(df, 14)
    df['efficiency_ratio_10'] = efficiency_ratio(c, 10)
    df['hist_vol_20'] = historical_volatility(c, 20)
    plus_di, minus_di = dmi(df, 14)
    df['plus_di_14'] = plus_di
    df['minus_di_14'] = minus_di
    df['dmi_spread'] = plus_di - minus_di
    df['bb_width'] = (df['bb_upper'] - df['bb_lower']) / df['bb_mid'].replace(0, np.nan)
    df['kc_width'] = (df['kc_upper'] - df['kc_lower']) / df['kc_mid'].replace(0, np.nan)
    df['squeeze_on'] = (df['bb_upper'] < df['kc_upper']) & (df['bb_lower'] > df['kc_lower'])
    df['kama_10_2_30'] = kama(c, 10, 2, 30)
    ar_up, ar_down, ar_osc = aroon(df, 25)
    df['aroon_up_25'], df['aroon_down_25'], df['aroon_osc_25'] = ar_up, ar_down, ar_osc
    df['fisher_10'] = fisher_transform(df, 10)
    df['price_zscore_50'] = rolling_zscore(c, 50)
    df = pd.concat([df, anchored_vwap_extremes(df, 120), displacement_metrics(df, 20)], axis=1)
    df['volatility_regime_pct'] = volatility_regime_percentile(df, 20, 120)
    df['avwap_low_distance_atr'] = (df['close']-df['avwap_from_swing_low'])/df['atr_14'].replace(0,np.nan)
    df['avwap_high_distance_atr'] = (df['close']-df['avwap_from_swing_high'])/df['atr_14'].replace(0,np.nan)
    return df
