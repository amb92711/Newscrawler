from __future__ import annotations
from typing import Any, Dict, List, Optional, Tuple
import math
import numpy as np
import pandas as pd


def _round(x: Any, n: int = 6):
    try:
        return round(float(x), n)
    except Exception:
        return None


def _atr_now(df: pd.DataFrame, fallback_pct: float = 0.001) -> float:
    if df is None or df.empty:
        return 1.0
    if 'atr_14' in df and len(df):
        try:
            v = float(df['atr_14'].iloc[-1])
            if not math.isnan(v) and v > 0:
                return v
        except Exception:
            pass
    try:
        return max(float(df['close'].iloc[-1]) * fallback_pct, 1e-9)
    except Exception:
        return 1.0


def _safe_float(v: Any, default: float = 0.0) -> float:
    try:
        out = float(v)
        return out if not math.isnan(out) else default
    except Exception:
        return default


def _bar(df: pd.DataFrame, i: int) -> Dict[str, Any]:
    r = df.iloc[int(i)]
    return {
        'index': int(i),
        'time': str(r.get('time', '')),
        'open': _round(r.get('open')),
        'high': _round(r.get('high')),
        'low': _round(r.get('low')),
        'close': _round(r.get('close')),
        'volume': _round(r.get('volume', 0)),
    }


def detect_swings(df: pd.DataFrame, left: int = 3, right: int = 3, limit: int = 40) -> Dict[str, Any]:
    highs: List[Dict[str, Any]] = []
    lows: List[Dict[str, Any]] = []
    n = len(df)
    if n < left + right + 3:
        return {'highs': [], 'lows': [], 'last_high': None, 'last_low': None}
    for i in range(left, n - right):
        wh = df['high'].iloc[i-left:i+right+1]
        wl = df['low'].iloc[i-left:i+right+1]
        h = _safe_float(df['high'].iloc[i])
        l = _safe_float(df['low'].iloc[i])
        if h == float(wh.max()) and int((wh == h).sum()) == 1:
            highs.append({'index': int(i), 'time': str(df['time'].iloc[i]), 'price': _round(h)})
        if l == float(wl.min()) and int((wl == l).sum()) == 1:
            lows.append({'index': int(i), 'time': str(df['time'].iloc[i]), 'price': _round(l)})
    return {
        'highs': highs[-limit:],
        'lows': lows[-limit:],
        'last_high': highs[-1] if highs else None,
        'last_low': lows[-1] if lows else None,
    }


def classify_trend(df: pd.DataFrame) -> str:
    if df.empty:
        return 'unknown'
    last = df.iloc[-1]
    close = _safe_float(last.get('close'))
    e20, e50, e200 = last.get('ema_20'), last.get('ema_50'), last.get('ema_200')
    if pd.isna(e20) or pd.isna(e50) or pd.isna(e200):
        return 'unknown'
    e20, e50, e200 = float(e20), float(e50), float(e200)
    if close > e20 > e50 > e200:
        return 'strong_bullish'
    if close < e20 < e50 < e200:
        return 'strong_bearish'
    if close > e50 and e20 > e50:
        return 'bullish'
    if close < e50 and e20 < e50:
        return 'bearish'
    return 'range_mixed'


def classify_momentum(df: pd.DataFrame) -> str:
    if df.empty:
        return 'unknown'
    last = df.iloc[-1]
    r = last.get('rsi_14')
    mh = last.get('macd_hist')
    if pd.isna(r):
        return 'unknown'
    r = float(r)
    mh_ok = pd.isna(mh) or float(mh) >= 0
    mh_bad = pd.isna(mh) or float(mh) <= 0
    if r >= 70:
        return 'overbought_bullish'
    if r <= 30:
        return 'oversold_bearish'
    if r > 55 and mh_ok:
        return 'bullish'
    if r < 45 and mh_bad:
        return 'bearish'
    return 'neutral'


def classify_volatility(df: pd.DataFrame) -> str:
    if len(df) < 60 or 'atr_14' not in df:
        return 'unknown'
    atr_now = df['atr_14'].iloc[-1]
    med = df['atr_14'].tail(100).median()
    if pd.isna(atr_now) or pd.isna(med) or med <= 0:
        return 'unknown'
    ratio = float(atr_now / med)
    if ratio >= 1.35:
        return 'expanding_high'
    if ratio <= 0.75:
        return 'compressed_low'
    return 'normal'


def _swing_bias(highs: List[Dict[str, Any]], lows: List[Dict[str, Any]]) -> str:
    if len(highs) < 2 or len(lows) < 2:
        return 'unknown'
    hh = highs[-1]['price'] > highs[-2]['price']
    hl = lows[-1]['price'] > lows[-2]['price']
    lh = highs[-1]['price'] < highs[-2]['price']
    ll = lows[-1]['price'] < lows[-2]['price']
    if hh and hl:
        return 'bullish'
    if lh and ll:
        return 'bearish'
    return 'transitional'


def _find_break_events(df: pd.DataFrame, swings: Dict[str, Any], scope: str, lookback_bars: int = 160) -> List[Dict[str, Any]]:
    highs = swings.get('highs', []) or []
    lows = swings.get('lows', []) or []
    levels: List[Tuple[str, Dict[str, Any]]] = [('high', x) for x in highs] + [('low', x) for x in lows]
    events: List[Dict[str, Any]] = []
    if len(df) < 5 or not levels:
        return events
    start = max(1, len(df) - lookback_bars)
    # Use closes for confirmed structure breaks. A break is only counted after the swing existed.
    for i in range(start, len(df)):
        close = _safe_float(df['close'].iloc[i])
        prev_close = _safe_float(df['close'].iloc[i-1])
        candle = _bar(df, i)
        for side, sw in levels:
            idx = int(sw.get('index', -1))
            if idx < 0 or i <= idx + 1:
                continue
            level = _safe_float(sw.get('price'))
            if side == 'high' and prev_close <= level < close:
                events.append({
                    'scope': scope,
                    'type': 'BOS_UP',
                    'level': _round(level),
                    'swing_time': sw.get('time'),
                    'break_time': candle['time'],
                    'break_index': candle['index'],
                    'close': candle['close'],
                    'displacement_atr': None,
                })
            if side == 'low' and prev_close >= level > close:
                events.append({
                    'scope': scope,
                    'type': 'BOS_DOWN',
                    'level': _round(level),
                    'swing_time': sw.get('time'),
                    'break_time': candle['time'],
                    'break_index': candle['index'],
                    'close': candle['close'],
                    'displacement_atr': None,
                })
    # Deduplicate same direction/level breaks and compute displacement.
    dedup: List[Dict[str, Any]] = []
    seen = set()
    atr = _atr_now(df)
    for e in events:
        key = (e['type'], round(float(e['level']), 3), e['break_index'])
        if key in seen:
            continue
        seen.add(key)
        i = e['break_index']
        if 0 <= i < len(df):
            body = abs(_safe_float(df['close'].iloc[i]) - _safe_float(df['open'].iloc[i]))
            e['displacement_atr'] = _round(body / max(atr, 1e-9), 3)
            e['strong_displacement'] = bool(body >= atr * 0.45)
        dedup.append(e)
    return dedup[-20:]


def _classify_breaks_with_context(events: List[Dict[str, Any]], initial_bias: str) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    bias = initial_bias if initial_bias in ('bullish', 'bearish') else 'unknown'
    for e in events:
        typ = e.get('type')
        classified = dict(e)
        if typ == 'BOS_UP':
            if bias == 'bearish':
                classified['type'] = 'CHOCH_UP'
                classified['meaning'] = 'bearish_to_bullish_shift_attempt'
                bias = 'bullish'
            else:
                classified['type'] = 'BOS_UP'
                classified['meaning'] = 'bullish_continuation_or_range_break'
                bias = 'bullish'
        elif typ == 'BOS_DOWN':
            if bias == 'bullish':
                classified['type'] = 'CHOCH_DOWN'
                classified['meaning'] = 'bullish_to_bearish_shift_attempt'
                bias = 'bearish'
            else:
                classified['type'] = 'BOS_DOWN'
                classified['meaning'] = 'bearish_continuation_or_range_break'
                bias = 'bearish'
        classified['post_event_bias'] = bias
        out.append(classified)
    return out


def _equal_levels(arr: List[Dict[str, Any]], atr: float, key: str, side: str) -> List[Dict[str, Any]]:
    recent = arr[-18:]
    used = set()
    out = []
    for i, a in enumerate(recent):
        if i in used:
            continue
        cluster = [a]
        for j, b in enumerate(recent[i+1:], i+1):
            if abs(_safe_float(a['price']) - _safe_float(b['price'])) <= atr * 0.18:
                cluster.append(b)
                used.add(j)
        if len(cluster) >= 2:
            out.append({
                'level': _round(sum(_safe_float(x['price']) for x in cluster) / len(cluster)),
                'touches': len(cluster),
                'side': side,
                'type': key,
                'times': [x.get('time') for x in cluster[-5:]],
            })
    return out[-8:]


def detect_structure(df: pd.DataFrame, swings: Dict[str, Any]) -> Dict[str, Any]:
    highs, lows = swings.get('highs', []), swings.get('lows', [])
    label = 'unknown'
    if len(highs) >= 2 and len(lows) >= 2:
        bias = _swing_bias(highs, lows)
        label = {'bullish': 'bullish_hh_hl', 'bearish': 'bearish_lh_ll', 'transitional': 'range_or_transition'}.get(bias, 'unknown')
    events = _classify_breaks_with_context(_find_break_events(df, swings, 'basic', 80), _swing_bias(highs, lows))
    return {'label': label, 'events': events[-8:]}


def advanced_market_structure(df: pd.DataFrame, major: Dict[str, Any], internal: Dict[str, Any]) -> Dict[str, Any]:
    atr = _atr_now(df)
    result: Dict[str, Any] = {'external': {}, 'internal': {}, 'events': [], 'eqh': [], 'eql': [], 'mss': {}}
    scoped = [('external', major), ('internal', internal)]
    for name, sw in scoped:
        highs, lows = sw.get('highs', []) or [], sw.get('lows', []) or []
        swing_bias = _swing_bias(highs, lows)
        raw_events = _find_break_events(df, sw, name, 180 if name == 'external' else 100)
        events = _classify_breaks_with_context(raw_events, swing_bias)
        last_event = events[-1] if events else None
        live_bias = last_event.get('post_event_bias') if last_event else swing_bias
        part = {
            'bias': live_bias if live_bias != 'unknown' else swing_bias,
            'swing_bias': swing_bias,
            'last_break': last_event,
            'major_high': highs[-1] if highs else None,
            'major_low': lows[-1] if lows else None,
            'event_count': len(events),
        }
        result[name] = part
        result['events'].extend(events[-8:])
        result['eqh'].extend(_equal_levels(highs, atr, 'EQH', 'buy_side'))
        result['eql'].extend(_equal_levels(lows, atr, 'EQL', 'sell_side'))

    ext_bias = result['external'].get('bias') or 'unknown'
    int_break = result['internal'].get('last_break') or {}
    int_type = str(int_break.get('type') or '')
    mss: Dict[str, Any] = {}
    if int_type in ('CHOCH_UP', 'BOS_UP') and ext_bias == 'bearish':
        mss = {
            'type': 'bullish_mss_against_external_bearish',
            'level': int_break.get('level'),
            'time': int_break.get('break_time'),
            'strength': 'high' if int_break.get('strong_displacement') else 'medium',
            'reason': 'internal bullish break while external context remains bearish',
        }
    elif int_type in ('CHOCH_DOWN', 'BOS_DOWN') and ext_bias == 'bullish':
        mss = {
            'type': 'bearish_mss_against_external_bullish',
            'level': int_break.get('level'),
            'time': int_break.get('break_time'),
            'strength': 'high' if int_break.get('strong_displacement') else 'medium',
            'reason': 'internal bearish break while external context remains bullish',
        }
    elif int_type in ('CHOCH_UP', 'BOS_UP'):
        mss = {
            'type': 'bullish_internal_shift',
            'level': int_break.get('level'),
            'time': int_break.get('break_time'),
            'strength': 'medium',
            'reason': 'internal bullish shift aligned or transitional',
        }
    elif int_type in ('CHOCH_DOWN', 'BOS_DOWN'):
        mss = {
            'type': 'bearish_internal_shift',
            'level': int_break.get('level'),
            'time': int_break.get('break_time'),
            'strength': 'medium',
            'reason': 'internal bearish shift aligned or transitional',
        }
    result['mss'] = mss
    result['events'] = sorted(result['events'], key=lambda x: x.get('break_index', 0))[-16:]
    result['eqh'] = result['eqh'][-10:]
    result['eql'] = result['eql'][-10:]
    return result


def support_resistance_from_swings(df: pd.DataFrame, swings: Dict[str, Any], atr_mult: float = 0.35) -> Dict[str, List[float]]:
    tol = _atr_now(df) * atr_mult
    levels = [_safe_float(x['price']) for x in swings.get('highs', []) + swings.get('lows', [])]
    levels = sorted(set(levels))
    clusters: List[List[float]] = []
    for lvl in levels:
        if not clusters or abs(clusters[-1][-1] - lvl) > tol:
            clusters.append([lvl])
        else:
            clusters[-1].append(lvl)
    merged = [_round(sum(c) / len(c)) for c in clusters if c]
    close = _safe_float(df['close'].iloc[-1]) if not df.empty else 0
    return {'supports': [x for x in merged if x < close][-12:], 'resistances': [x for x in merged if x > close][:12]}


def liquidity_pools(df: pd.DataFrame, swings: Dict[str, Any], tolerance_atr: float = 0.18) -> Dict[str, Any]:
    atr = _atr_now(df)
    tol = atr * tolerance_atr
    pools = []
    for side, arr, lbl in [('buy_side', swings.get('highs', []), 'BSL'), ('sell_side', swings.get('lows', []), 'SSL')]:
        recent = arr[-18:]
        used = set()
        for i, a in enumerate(recent):
            if i in used:
                continue
            cluster = [a]
            for j, b in enumerate(recent[i+1:], i+1):
                if abs(_safe_float(a['price']) - _safe_float(b['price'])) <= tol:
                    cluster.append(b)
                    used.add(j)
            if len(cluster) >= 2:
                level = sum(_safe_float(x['price']) for x in cluster) / len(cluster)
                age = len(df) - max(int(x['index']) for x in cluster)
                pools.append({
                    'side': side,
                    'type': lbl,
                    'level': _round(level),
                    'touches': len(cluster),
                    'age_bars': int(age),
                    'quality': 'engineered' if len(cluster) >= 3 else 'resting',
                    'times': [x.get('time') for x in cluster[-5:]],
                })
    return {'pools': sorted(pools, key=lambda x: (x['touches'], -x['age_bars']), reverse=True)[:14]}


def liquidity_sweeps(df: pd.DataFrame, swings: Dict[str, Any]) -> List[Dict[str, Any]]:
    atr = _atr_now(df)
    out = []
    highs = swings.get('highs', [])[-10:]
    lows = swings.get('lows', [])[-10:]
    start = max(0, len(df) - 100)
    recent = df.iloc[start:].reset_index(drop=False)
    for _, row in recent.iterrows():
        idx = int(row['index'])
        for h in highs:
            if idx <= int(h['index']):
                continue
            if _safe_float(row['high']) > _safe_float(h['price']) + atr * 0.03 and _safe_float(row['close']) < _safe_float(h['price']):
                out.append({'type': 'buy_side_sweep_rejection', 'swept_level': h['price'], 'time': str(row['time']), 'high': _round(row['high']), 'close': _round(row['close'])})
        for l in lows:
            if idx <= int(l['index']):
                continue
            if _safe_float(row['low']) < _safe_float(l['price']) - atr * 0.03 and _safe_float(row['close']) > _safe_float(l['price']):
                out.append({'type': 'sell_side_sweep_rejection', 'swept_level': l['price'], 'time': str(row['time']), 'low': _round(row['low']), 'close': _round(row['close'])})
    # Deduplicate same candle/level
    dedup = []
    seen = set()
    for s in out:
        key = (s.get('type'), round(_safe_float(s.get('swept_level')), 3), s.get('time'))
        if key not in seen:
            seen.add(key)
            dedup.append(s)
    return dedup[-14:]


def _fvg_with_status(df: pd.DataFrame, i: int, typ: str, lo: float, hi: float, size: float, time: Any) -> Dict[str, Any]:
    status = 'open'
    mitigation_pct = 0.0
    fill_time = None
    width = max(hi - lo, 1e-9)
    for j in range(i + 1, len(df)):
        r = df.iloc[j]
        low = _safe_float(r['low'])
        high = _safe_float(r['high'])
        if high >= lo and low <= hi:
            overlap = max(0.0, min(high, hi) - max(low, lo))
            mitigation_pct = max(mitigation_pct, min(100.0, 100.0 * overlap / width))
            if typ.startswith('bullish') and low <= lo:
                status = 'filled'
                fill_time = str(r['time'])
                mitigation_pct = 100.0
                break
            if typ.startswith('bearish') and high >= hi:
                status = 'filled'
                fill_time = str(r['time'])
                mitigation_pct = 100.0
                break
            status = 'mitigated'
    return {'type': typ, 'from': _round(lo), 'to': _round(hi), 'low': _round(lo), 'high': _round(hi), 'time': str(time), 'size': _round(size), 'status': status, 'mitigation_pct': round(mitigation_pct, 2), 'fill_time': fill_time}


def fair_value_gaps(df: pd.DataFrame, min_atr: float = 0.08) -> List[Dict[str, Any]]:
    gaps = []
    if len(df) < 3:
        return gaps
    atrs = df['atr_14'] if 'atr_14' in df else None
    for i in range(2, len(df)):
        c0 = df.iloc[i-2]
        c2 = df.iloc[i]
        atr = _safe_float(atrs.iloc[i], _atr_now(df)) if atrs is not None else _atr_now(df)
        min_size = max(atr * min_atr, 0)
        if _safe_float(c0['high']) < _safe_float(c2['low']):
            lo, hi = _safe_float(c0['high']), _safe_float(c2['low'])
            size = hi - lo
            if size >= min_size:
                gaps.append(_fvg_with_status(df, i, 'bullish_fvg', lo, hi, size, c2['time']))
        if _safe_float(c0['low']) > _safe_float(c2['high']):
            lo, hi = _safe_float(c2['high']), _safe_float(c0['low'])
            size = hi - lo
            if size >= min_size:
                gaps.append(_fvg_with_status(df, i, 'bearish_fvg', lo, hi, size, c2['time']))
    return gaps[-24:]


def order_blocks(df: pd.DataFrame, lookback: int = 180, max_age: int = 220, fvg_list: Optional[List[Dict[str, Any]]] = None) -> List[Dict[str, Any]]:
    obs: List[Dict[str, Any]] = []
    if len(df) < 20:
        return obs
    fvg_list = fvg_list or []
    atr = _atr_now(df)
    start = max(3, len(df) - lookback)
    for i in range(start, len(df) - 2):
        cur = df.iloc[i]
        nxt = df.iloc[i+1]
        cur_open, cur_close = _safe_float(cur['open']), _safe_float(cur['close'])
        nxt_open, nxt_close = _safe_float(nxt['open']), _safe_float(nxt['close'])
        next_body = abs(nxt_close - nxt_open)
        if next_body < atr * 0.32:
            continue
        typ = None
        if cur_close < cur_open and nxt_close > nxt_open:
            typ = 'bullish_order_block'
        elif cur_close > cur_open and nxt_close < nxt_open:
            typ = 'bearish_order_block'
        if not typ:
            continue
        lo, hi = _safe_float(cur['low']), _safe_float(cur['high'])
        age = len(df) - 1 - i
        touched = False
        invalid = False
        touches = 0
        for j in range(i + 2, len(df)):
            r = df.iloc[j]
            r_low, r_high, r_close = _safe_float(r['low']), _safe_float(r['high']), _safe_float(r['close'])
            if r_high >= lo and r_low <= hi:
                touched = True
                touches += 1
            if typ.startswith('bullish') and r_close < lo:
                invalid = True
            if typ.startswith('bearish') and r_close > hi:
                invalid = True
        status = 'invalidated' if invalid else ('mitigated' if touched else 'fresh')
        score = 50.0
        score += min(25, next_body / max(atr, 1e-9) * 8)
        if not touched:
            score += 18
        elif touches <= 2:
            score += 8
        if age <= max_age:
            score += 7
        # Nearby FVG confirmation within 2 candles/time neighborhood
        if any(str(g.get('time')) == str(nxt.get('time')) or abs((_safe_float(g.get('low')) + _safe_float(g.get('high'))) / 2 - (lo + hi) / 2) <= atr for g in fvg_list):
            score += 7
        if invalid:
            score -= 35
        obs.append({'type': typ, 'low': _round(lo), 'high': _round(hi), 'time': str(cur['time']), 'impulse': _round(next_body), 'status': status, 'fresh': status == 'fresh', 'age_bars': int(age), 'touches_after_creation': touches, 'score': round(max(0, min(100, score)), 2)})
    return obs[-20:]


def build_zones(df: pd.DataFrame, sr: Dict[str, List[float]], fvg_list: List[Dict[str, Any]], obs: List[Dict[str, Any]]) -> Dict[str, Any]:
    close = _safe_float(df['close'].iloc[-1]) if not df.empty else 0
    pad = _atr_now(df) * 0.25
    buy = []
    sell = []
    for s in sr.get('supports', [])[-6:]:
        buy.append({'source': 'support', 'low': _round(s - pad), 'high': _round(s + pad), 'level': s, 'quality': 'sr'})
    for r in sr.get('resistances', [])[:6]:
        sell.append({'source': 'resistance', 'low': _round(r - pad), 'high': _round(r + pad), 'level': r, 'quality': 'sr'})
    for g in fvg_list[-10:]:
        if g.get('status') == 'filled':
            continue
        z = {'source': g['type'], 'low': g['low'], 'high': g['high'], 'time': g['time'], 'status': g.get('status'), 'quality': 'imbalance'}
        if g['type'].startswith('bullish') and _safe_float(z['high']) <= close:
            buy.append(z)
        elif g['type'].startswith('bearish') and _safe_float(z['low']) >= close:
            sell.append(z)
    for ob in sorted(obs, key=lambda x: _safe_float(x.get('score')), reverse=True):
        if ob.get('status') == 'invalidated':
            continue
        z = {'source': ob['type'], 'low': ob['low'], 'high': ob['high'], 'time': ob['time'], 'status': ob.get('status'), 'score': ob.get('score'), 'quality': 'order_block'}
        if ob['type'].startswith('bullish') and _safe_float(ob['high']) <= close:
            buy.append(z)
        elif ob['type'].startswith('bearish') and _safe_float(ob['low']) >= close:
            sell.append(z)
    return {'buy_zones': buy[-16:], 'sell_zones': sell[:16]}
