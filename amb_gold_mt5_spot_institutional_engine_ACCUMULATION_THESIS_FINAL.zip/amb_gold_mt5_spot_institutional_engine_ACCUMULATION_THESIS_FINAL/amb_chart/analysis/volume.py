from __future__ import annotations
from typing import Any, Dict, List
import numpy as np
import pandas as pd

def volume_profile(df: pd.DataFrame, bins: int = 36) -> Dict[str, Any]:
    if df.empty or 'volume' not in df:
        return {"available": False, "reason": "no_volume"}
    recent = df.tail(min(len(df), 240)).copy()
    if recent['volume'].fillna(0).sum() <= 0:
        return {"available": False, "reason": "zero_volume"}
    low, high = float(recent['low'].min()), float(recent['high'].max())
    if high <= low:
        return {"available": False, "reason": "flat_range"}
    edges = np.linspace(low, high, bins+1)
    vols = np.zeros(bins)
    for _, r in recent.iterrows():
        typical = float((r['high'] + r['low'] + r['close']) / 3)
        idx = int(np.clip(np.searchsorted(edges, typical) - 1, 0, bins-1))
        vols[idx] += float(r.get('volume', 0) or 0)
    poc_idx = int(np.argmax(vols))
    total = vols.sum()
    hvn_idx = vols.argsort()[-5:][::-1]
    lvn_idx = np.argsort(vols)[:5]
    def level(i): return round(float((edges[i] + edges[i+1])/2), 6)
    return {
        "available": True,
        "poc": level(poc_idx),
        "hvn": [{"level": level(int(i)), "share": round(float(vols[i]/total), 4)} for i in hvn_idx if total>0],
        "lvn": [{"level": level(int(i)), "share": round(float(vols[i]/total), 4)} for i in lvn_idx if total>0],
        "range_low": round(low,6), "range_high": round(high,6),
        "volume_sum": round(float(total), 6),
    }

def order_flow_proxy(df: pd.DataFrame) -> Dict[str, Any]:
    if df.empty:
        return {}
    recent = df.tail(min(120, len(df)))
    up_vol = float(recent.loc[recent['close'] > recent['open'], 'volume'].sum())
    down_vol = float(recent.loc[recent['close'] < recent['open'], 'volume'].sum())
    total = up_vol + down_vol
    imbalance = (up_vol - down_vol)/total if total else 0.0
    cvd = float(recent.get('signed_volume', pd.Series(dtype=float)).sum()) if 'signed_volume' in recent else up_vol-down_vol
    trend = "buy_pressure" if imbalance > 0.12 else ("sell_pressure" if imbalance < -0.12 else "balanced")
    return {"up_volume": round(up_vol,6), "down_volume": round(down_vol,6), "delta_proxy": round(up_vol-down_vol,6), "imbalance": round(imbalance,4), "cvd_proxy_window": round(cvd,6), "pressure": trend}
