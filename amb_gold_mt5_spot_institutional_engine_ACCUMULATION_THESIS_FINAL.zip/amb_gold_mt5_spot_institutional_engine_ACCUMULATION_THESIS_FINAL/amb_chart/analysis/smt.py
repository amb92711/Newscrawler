from __future__ import annotations
from typing import Any, Dict, List
import pandas as pd

def smt_analysis(primary: pd.DataFrame, related: Dict[str, pd.DataFrame] | None = None) -> Dict[str, Any]:
    related = related or {}
    if not related:
        return {"available": False, "reason": "single_symbol_build_or_related_symbols_not_configured", "signals": []}
    signals=[]
    p = primary.tail(80).reset_index(drop=True)
    if len(p) < 20:
        return {"available": False, "reason":"insufficient_primary", "signals": []}
    p_high_now, p_high_prev = float(p['high'].tail(10).max()), float(p['high'].iloc[-40:-10].max())
    p_low_now, p_low_prev = float(p['low'].tail(10).min()), float(p['low'].iloc[-40:-10].min())
    for sym, df in related.items():
        r=df.tail(80).reset_index(drop=True)
        if len(r)<20: continue
        r_high_now, r_high_prev = float(r['high'].tail(10).max()), float(r['high'].iloc[-40:-10].max())
        r_low_now, r_low_prev = float(r['low'].tail(10).min()), float(r['low'].iloc[-40:-10].min())
        if p_high_now > p_high_prev and r_high_now <= r_high_prev:
            signals.append({"type":"bearish_smt", "primary":"made_higher_high", "related":sym, "related_state":"failed_higher_high"})
        if p_low_now < p_low_prev and r_low_now >= r_low_prev:
            signals.append({"type":"bullish_smt", "primary":"made_lower_low", "related":sym, "related_state":"failed_lower_low"})
    return {"available": bool(signals), "signals": signals[-8:]}
