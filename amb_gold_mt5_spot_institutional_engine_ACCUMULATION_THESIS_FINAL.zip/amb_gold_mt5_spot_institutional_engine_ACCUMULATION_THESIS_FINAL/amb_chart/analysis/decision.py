from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, List, Tuple

from amb_chart.analysis.ai_fusion import infer_final_decision
from amb_chart.analysis.execution import build_execution_plan
from amb_chart.analysis.state_machine import evaluate_execution_state


def _d(v: Any) -> Dict[str, Any]:
    return v if isinstance(v, dict) else {}


def _l(v: Any) -> List[Any]:
    return v if isinstance(v, list) else []


def _s(v: Any) -> str:
    return str(v or '').strip()


def _sl(v: Any) -> str:
    return _s(v).lower()


def _n(v: Any, default: float = 0.0) -> float:
    try:
        if v is None or v == '':
            return default
        return float(v)
    except Exception:
        return default


def _pct(v: Any) -> float:
    x = _n(v, 0.0)
    return round(x * 100.0 if 0.0 <= x <= 1.0 else x, 2)


def _clamp(v: float, lo: float = 0.0, hi: float = 100.0) -> float:
    return max(lo, min(hi, v))


def _bias_side(bias: str) -> str:
    b = _sl(bias)
    if 'bull' in b or 'long' in b:
        return 'long'
    if 'bear' in b or 'short' in b or 'pressure' in b:
        return 'short'
    return 'neutral'


def _opposite(side: str) -> str:
    return 'short' if side == 'long' else 'long' if side == 'short' else 'neutral'


def _event_title(ev: Dict[str, Any]) -> str:
    title = _s(ev.get('title'))
    time = _s(ev.get('time'))
    impact = _s(ev.get('impact') or ev.get('summary'))
    src = _s(ev.get('source'))
    pieces = [x for x in [time, title, src, impact[:120]] if x]
    return ' | '.join(pieces)[:260]


def _extract_macro(news: Dict[str, Any]) -> Dict[str, Any]:
    """Normalize News/Macro V8.5 into a compact directional macro object.

    The previous builds copied large raw objects into the LLM packet. This adapter keeps
    only decision-grade fields and pushes detailed news evidence to debug output.
    """
    if not news or not news.get('attached'):
        return {
            'attached': False,
            'macro_regime': 'UNKNOWN',
            'gold_bias': 'unknown',
            'news_bias': 'unknown',
            'market_bias': 'unknown',
            'bias_conflict': False,
            'event_risk': {'level': 'UNKNOWN', 'blocks_trade': False, 'next_events': [], 'note': 'missing_news'},
            'confidence': 0.0,
            'score': 0.0,
            'gate': {'allows_trade': False, 'state': 'MISSING_NEWS', 'reason': 'News/Macro V8.5 is required.'},
            'summary': 'News/Macro V8.5 not attached.',
        }

    data = _d(news.get('data'))
    mc = _d(data.get('macro_context'))
    event_window = _d(data.get('event_window'))
    regime = _d(data.get('market_regime'))
    components = _d(data.get('bias_components'))
    combined = _d(components.get('combined_bias'))
    news_driver = _d(components.get('news_driver_bias'))
    market_val = _d(components.get('market_validation_bias'))
    contract = _d(data.get('chart_engine_contract'))

    gold_bias = _s(mc.get('final_gold_context_bias') or combined.get('bias') or data.get('final_gold_context_bias') or data.get('gold_bias') or 'unknown')
    news_bias = _s(mc.get('gold_news_bias') or combined.get('news_bias') or news_driver.get('bias') or 'unknown')
    market_bias = _s(mc.get('gold_market_bias') or combined.get('market_bias') or market_val.get('bias') or 'unknown')
    macro_regime = _s(mc.get('macro_regime') or regime.get('regime') or data.get('macro_regime') or 'UNKNOWN')
    conflict = bool(mc.get('bias_conflict') if 'bias_conflict' in mc else combined.get('conflict', False))

    risk_level = _s(mc.get('event_risk') or event_window.get('risk_level') or data.get('event_risk') or 'UNKNOWN').upper()
    if risk_level not in {'HIGH', 'MEDIUM', 'LOW', 'UNKNOWN'}:
        if 'HIGH' in risk_level:
            risk_level = 'HIGH'
        elif 'MED' in risk_level:
            risk_level = 'MEDIUM'
        elif 'LOW' in risk_level:
            risk_level = 'LOW'
        else:
            risk_level = 'UNKNOWN'
    next_events = []
    for ev in _l(event_window.get('upcoming_key_events'))[:4]:
        if isinstance(ev, dict):
            next_events.append(_event_title(ev))
    for ev in _l(event_window.get('pending_events'))[:3]:
        if isinstance(ev, dict):
            text = _event_title(ev)
            if text and text not in next_events:
                next_events.append(text)

    conf = _pct(mc.get('regime_confidence') or regime.get('confidence') or data.get('confidence') or 0.0)
    # V8.5 combined_score is directional: positive supports long, negative supports short.
    directional_score = _n(combined.get('combined_score'), _n(news_driver.get('score'), 0.0) + _n(market_val.get('score'), 0.0))
    summary_bits = []
    if macro_regime and macro_regime != 'UNKNOWN':
        summary_bits.append(f'regime={macro_regime}')
    if gold_bias:
        summary_bits.append(f'gold_bias={gold_bias}')
    if _s(event_window.get('trading_note')):
        summary_bits.append(_s(event_window.get('trading_note'))[:180])
    summary = '; '.join(summary_bits)

    # Component disagreement is not automatically a hard execution conflict.
    # The final macro bias remains authoritative unless it directly opposes the chart/playbook later.
    conflict_severity = 'NONE'
    if conflict:
        if conf >= 70 and abs(directional_score) <= 2:
            conflict_severity = 'HIGH'
        elif conf >= 45:
            conflict_severity = 'MEDIUM'
        else:
            conflict_severity = 'LOW'
    return {
        'attached': True,
        'macro_regime': macro_regime,
        'gold_bias': gold_bias or 'unknown',
        'news_bias': news_bias or 'unknown',
        'market_bias': market_bias or 'unknown',
        'bias_conflict': conflict,
        'conflict_severity': conflict_severity,
        'event_risk': {
            'level': risk_level,
            'score': _n(event_window.get('risk_score'), 0.0),
            'blocks_trade': bool(event_window.get('blocks_trade', risk_level == 'HIGH')),
            'scalp_blocks_trade': bool(event_window.get('scalp_blocks_trade', event_window.get('blocks_trade', risk_level == 'HIGH'))),
            'spot_blocks_trade': bool(event_window.get('spot_blocks_trade', False)),
            'execution_mode': _s(event_window.get('execution_mode') or ''),
            'nearest_timed_event': event_window.get('nearest_timed_event'),
            'next_blocking_event': event_window.get('next_blocking_event'),
            'model': _s(event_window.get('event_risk_model') or ''),
            'next_events': next_events[:5],
            'note': _s(event_window.get('trading_note'))[:220],
        },
        'confidence': round(conf, 2),
        'score': round(directional_score, 2),
        'chart_gate': _s(mc.get('chart_decision_gate') or contract.get('chart_decision_gate') or ''),
        'gate': {
            'allows_trade': not bool(event_window.get('blocks_trade', risk_level == 'HIGH')),
            'state': 'EVENT_BLOCKED' if bool(event_window.get('blocks_trade', risk_level == 'HIGH')) else 'MACRO_AVAILABLE',
            'reason': 'Time-proximate macro event risk blocks trading.' if bool(event_window.get('blocks_trade', risk_level == 'HIGH')) else 'Macro context attached and event risk does not block trading.',
        },
        'summary': summary,
    }


def _tf(chart: Dict[str, Any], tf: str) -> Dict[str, Any]:
    return _d(_d(chart.get('timeframes')).get(tf))


def _adv(c: Dict[str, Any]) -> Dict[str, Any]:
    return _d(c.get('advanced_structure'))


def _mss_type(c: Dict[str, Any]) -> str:
    return _sl(_d(_adv(c).get('mss')).get('type'))


def _tf_side(c: Dict[str, Any]) -> str:
    parts = [
        _sl(c.get('trend')),
        _sl(c.get('structure')),
        _sl(_d(_adv(c).get('external')).get('bias')),
        _sl(_d(_adv(c).get('internal')).get('bias')),
        _mss_type(c),
    ]
    bull = sum(1 for p in parts if 'bullish' in p or p == 'strong_bullish')
    bear = sum(1 for p in parts if 'bearish' in p or p == 'strong_bearish')
    if bull >= bear + 1:
        return 'long'
    if bear >= bull + 1:
        return 'short'
    return 'mixed'


def _timeframe_votes(chart: Dict[str, Any]) -> Dict[str, Any]:
    weights = {'D1': 4.0, 'H4': 3.0, 'H1': 2.0, 'M15': 1.25, 'M5': 1.0}
    rows: Dict[str, Any] = {}
    long_score = short_score = mixed_score = 0.0
    for tf, w in weights.items():
        c = _tf(chart, tf)
        side = _tf_side(c)
        if side == 'long':
            long_score += w
        elif side == 'short':
            short_score += w
        else:
            mixed_score += w
        rows[tf] = {
            'side': side,
            'trend': c.get('trend'),
            'structure': c.get('structure'),
            'mss': _d(_adv(c).get('mss')) or None,
        }
    total = sum(weights.values())
    return {
        'rows': rows,
        'long_score': round(long_score, 2),
        'short_score': round(short_score, 2),
        'mixed_score': round(mixed_score, 2),
        'long_pct': round((long_score / total) * 100.0, 2),
        'short_pct': round((short_score / total) * 100.0, 2),
        'mixed_pct': round((mixed_score / total) * 100.0, 2),
    }


def _market_regime(chart: Dict[str, Any]) -> Dict[str, Any]:
    votes = _timeframe_votes(chart)
    rows = votes['rows']
    d1 = rows.get('D1', {}).get('side')
    h4 = rows.get('H4', {}).get('side')
    h1 = rows.get('H1', {}).get('side')
    m15 = rows.get('M15', {}).get('side')
    m5 = rows.get('M5', {}).get('side')
    higher = [d1, h4]
    execs = [h1, m15, m5]
    higher_long = higher.count('long')
    higher_short = higher.count('short')
    exec_long = execs.count('long')
    exec_short = execs.count('short')

    if higher_short == 2 and exec_long >= 2:
        name, phase, primary_side = 'BEARISH_HIGHER_TF_PULLBACK', 'countertrend_pullback', 'short'
    elif higher_long == 2 and exec_short >= 2:
        name, phase, primary_side = 'BULLISH_HIGHER_TF_PULLBACK', 'countertrend_pullback', 'long'
    elif higher_short >= 1 and exec_short >= 2:
        name, phase, primary_side = 'BEARISH_CONTINUATION', 'trend_continuation', 'short'
    elif higher_long >= 1 and exec_long >= 2:
        name, phase, primary_side = 'BULLISH_CONTINUATION', 'trend_continuation', 'long'
    elif votes['short_score'] > votes['long_score']:
        name, phase, primary_side = 'BEARISH_TRANSITION', 'transition', 'short'
    elif votes['long_score'] > votes['short_score']:
        name, phase, primary_side = 'BULLISH_TRANSITION', 'transition', 'long'
    else:
        name, phase, primary_side = 'MIXED_RANGE', 'range_or_unclear', 'none'

    vol_text = ' '.join(_sl(_tf(chart, tf).get('volatility')) for tf in ('M5', 'M15', 'H1'))
    volatility_phase = 'compression' if 'compressed' in vol_text else ('expansion' if 'high' in vol_text or 'expanding' in vol_text else 'normal')
    execution_alignment = 'aligned' if primary_side in {'long', 'short'} and execs.count(primary_side) >= 2 else 'not_aligned'
    if phase == 'countertrend_pullback':
        execution_alignment = 'pullback_against_higher_tf'
    return {
        'name': name,
        'phase': phase,
        'primary_side': primary_side,
        'volatility_phase': volatility_phase,
        'execution_alignment': execution_alignment,
        'timeframe_votes': votes,
    }


def _microstructure(chart: Dict[str, Any]) -> Dict[str, Any]:
    m = _d(chart.get('market_microstructure'))
    spread = _n(m.get('spread'), 0.0)
    depth = _n(m.get('depth_imbalance'), 0.0)
    trades = _n(m.get('recent_trade_imbalance'), 0.0)
    spread_ok = spread == 0.0 or spread <= 0.35
    return {
        'spread': spread,
        'spread_ok': spread_ok,
        'depth_imbalance': round(depth, 4),
        'depth_bias': 'bid_support' if depth > 0.18 else 'ask_pressure' if depth < -0.18 else 'balanced',
        'recent_trade_imbalance': round(trades, 4),
        'trade_bias': 'aggressive_buying' if trades > 0.15 else 'aggressive_selling' if trades < -0.15 else 'balanced',
    }


def _macro_scores(macro: Dict[str, Any]) -> Dict[str, Any]:
    """Convert compact macro context into soft directional scores.

    This is no longer a simple rule gate. It combines final gold bias, news bias,
    market-validation bias and directional macro score into long/short evidence.
    """
    if not macro.get('attached'):
        return {'long': 0.0, 'short': 0.0, 'confidence': 0.0, 'bias': 'unknown', 'drivers': []}

    conf = _n(macro.get('confidence'), 50.0)
    directional = _n(macro.get('score'), 0.0)
    long = short = 35.0
    drivers: List[str] = []

    def add_bias(label: str, bias: str, weight: float) -> None:
        nonlocal long, short
        side = _bias_side(bias)
        if side == 'long':
            long += weight; drivers.append(f'{label}:bullish')
        elif side == 'short':
            short += weight; drivers.append(f'{label}:bearish')
        else:
            drivers.append(f'{label}:neutral')

    add_bias('final_gold', macro.get('gold_bias', ''), 28.0)
    add_bias('news_driver', macro.get('news_bias', ''), 18.0)
    add_bias('market_validation', macro.get('market_bias', ''), 14.0)

    if directional > 0:
        long += min(22.0, abs(directional) * 4.0)
        drivers.append(f'directional_score:+{round(directional,2)}')
    elif directional < 0:
        short += min(22.0, abs(directional) * 4.0)
        drivers.append(f'directional_score:{round(directional,2)}')

    # If news and market disagree, reduce reliability rather than immediately
    # flipping direction. The hard conflict gate is handled separately.
    if macro.get('bias_conflict'):
        conf = min(conf, 35.0)
        long *= 0.88
        short *= 0.88
        drivers.append('bias_conflict:confidence_reduced')

    risk_level = _s(_d(macro.get('event_risk')).get('level')).upper()
    if risk_level == 'HIGH':
        conf = min(conf, 25.0)
        drivers.append('event_risk_high:trade_blocked')
    elif risk_level == 'MEDIUM':
        conf = min(conf, 60.0)
        drivers.append('event_risk_medium:caution')

    bias = 'bullish' if long > short + 3 else 'bearish' if short > long + 3 else 'neutral'
    return {
        'long': round(_clamp(long), 2),
        'short': round(_clamp(short), 2),
        'confidence': round(_clamp(conf), 2),
        'bias': bias,
        'drivers': drivers[:8],
    }

def _technical_scores(chart: Dict[str, Any], regime: Dict[str, Any]) -> Dict[str, Any]:
    prob = _d(chart.get('probability'))
    q = _d(chart.get('trade_quality'))
    votes = _d(regime.get('timeframe_votes'))
    long = _n(prob.get('long_probability')) + _n(votes.get('long_pct')) * 0.30
    short = _n(prob.get('short_probability')) + _n(votes.get('short_pct')) * 0.30
    conf = _n(prob.get('confidence'))
    quality = _n(q.get('score'))

    # Advanced MT5 technical consensus. These are continuous evidence contributions,
    # not hard rules; missing indicators simply contribute zero.
    advanced_rows = {}
    weights = {'D1': 1.6, 'H4': 1.45, 'H1': 1.2, 'M15': 0.85, 'M5': 0.55}
    adv_long = adv_short = reliability_sum = 0.0
    for tf, w in weights.items():
        c = _tf(chart, tf)
        ind = _d(c.get('advanced_indicators'))
        ichi = _d(c.get('ichimoku'))
        mom = _d(ind.get('momentum_advanced'))
        flow = _d(ind.get('volume_flow'))
        tq = _d(ind.get('trend_quality'))
        vol = _d(ind.get('volatility_advanced'))
        st = _d(ind.get('supertrend'))
        vwap = _d(ind.get('vwap'))
        adaptive = _d(ind.get('adaptive_trend'))
        avwap = _d(ind.get('anchored_vwap'))
        ipa = _d(ind.get('institutional_price_action'))
        regime_m = _d(ind.get('regime_metrics'))
        score = 0.0
        parts = []
        cloud = _n(ichi.get('cloud_bias'))
        tk = _n(ichi.get('tk_cross'))
        if cloud > 0: score += 1.1; parts.append('ichimoku_above_cloud')
        elif cloud < 0: score -= 1.1; parts.append('ichimoku_below_cloud')
        if tk > 0: score += 0.55
        elif tk < 0: score -= 0.55
        stdir = _n(st.get('direction'))
        if stdir > 0: score += 0.9
        elif stdir < 0: score -= 0.9
        dmi = _n(tq.get('dmi_spread'))
        score += max(-1.0, min(1.0, dmi / 25.0))
        er = _n(tq.get('efficiency_ratio_10'))
        chop = _n(tq.get('choppiness_14'), 50.0)
        trend_reliability = max(0.35, min(1.0, 0.45 + er * 0.75 - max(0.0, chop-55.0)/100.0))
        cmf = _n(flow.get('cmf_20'))
        score += max(-0.7, min(0.7, cmf * 2.0))
        mfi = _n(mom.get('mfi_14'), 50.0)
        if mfi >= 58: score += 0.35
        elif mfi <= 42: score -= 0.35
        roc = _n(mom.get('roc_12'))
        score += max(-0.5, min(0.5, roc / 2.0))
        pvv = _n(vwap.get('price_vs_vwap'))
        atr = max(_n(c.get('atr'), 1.0), 1e-9)
        score += max(-0.55, min(0.55, pvv / atr * 0.35))
        # Adaptive / institutional evidence. Bounded so no single feature can dominate.
        aroon_osc = _n(adaptive.get('aroon_osc'))
        score += max(-0.55, min(0.55, aroon_osc/100.0*0.55))
        fisher = _n(adaptive.get('fisher'))
        score += max(-0.45, min(0.45, fisher/3.0*0.45))
        kama = _n(adaptive.get('kama'))
        close = _n(c.get('last_close'))
        if kama and close:
            score += 0.45 if close > kama else -0.45
        avl = _n(avwap.get('low_distance_atr'))
        avh = _n(avwap.get('high_distance_atr'))
        if avl > 0 and avh > 0: score += 0.35
        elif avl < 0 and avh < 0: score -= 0.35
        impulse = _n(ipa.get('institutional_impulse_score'))
        score += max(-0.75, min(0.75, impulse/3.0))
        relvol = _n(ipa.get('relative_volume_20'), 1.0)
        if relvol >= 1.5 and abs(impulse) >= 0.8:
            trend_reliability = min(1.0, trend_reliability*1.08)
            parts.append('high_relative_volume_displacement')
        z = _n(ipa.get('price_zscore_50'))
        if abs(z) >= 2.5:
            trend_reliability *= 0.90
            parts.append('statistical_overextension')
        vpct = _n(regime_m.get('volatility_percentile'), 50.0)
        if vpct >= 90:
            trend_reliability *= 0.92
            parts.append('volatility_extreme')
        if bool(vol.get('squeeze_on')):
            trend_reliability *= 0.82
            parts.append('volatility_squeeze')
        contribution = score * w * trend_reliability
        if contribution > 0: adv_long += contribution
        elif contribution < 0: adv_short += abs(contribution)
        reliability_sum += w * trend_reliability
        advanced_rows[tf] = {'signed_score': round(score,3), 'weighted_contribution': round(contribution,3), 'reliability': round(trend_reliability*100,2), 'notes': parts}

    scale = max(1.0, sum(weights.values()))
    long += min(18.0, adv_long / scale * 9.0)
    short += min(18.0, adv_short / scale * 9.0)
    adv_edge = abs(adv_long-adv_short)/scale
    conf = min(100.0, conf + min(14.0, adv_edge*5.0))
    return {
        'long': round(long, 2),
        'short': round(short, 2),
        'confidence': round(conf, 2),
        'quality': round(quality, 2),
        'bias': 'long' if long > short else 'short' if short > long else 'neutral',
        'advanced_consensus': {
            'long_evidence': round(adv_long,3),
            'short_evidence': round(adv_short,3),
            'reliability': round(reliability_sum/max(sum(weights.values()),1e-9)*100,2),
            'timeframes': advanced_rows,
        },
        'raw_probability': {
            'long_probability': prob.get('long_probability'),
            'short_probability': prob.get('short_probability'),
            'bias': prob.get('bias'),
            'confidence': prob.get('confidence'),
        },
    }


def _playbook(regime: Dict[str, Any], tech: Dict[str, Any], macro: Dict[str, Any]) -> Dict[str, Any]:
    name = regime.get('name')
    if name == 'BEARISH_HIGHER_TF_PULLBACK':
        pb, side = 'SELL_RALLY', 'short'
    elif name == 'BULLISH_HIGHER_TF_PULLBACK':
        pb, side = 'BUY_DIP', 'long'
    elif name == 'BEARISH_CONTINUATION':
        pb, side = 'BREAKDOWN_CONTINUATION', 'short'
    elif name == 'BULLISH_CONTINUATION':
        pb, side = 'BREAKOUT_CONTINUATION', 'long'
    elif name == 'MIXED_RANGE':
        pb, side = 'RANGE_FADE_OR_WAIT', 'none'
    else:
        pb, side = 'NO_TRADE_UNTIL_CLARITY', 'none'

    macro_side = _bias_side(macro.get('gold_bias', ''))
    directional_conflict = macro_side in {'long', 'short'} and side in {'long', 'short'} and macro_side != side
    component_conflict = bool(macro.get('bias_conflict'))
    severity = _s(macro.get('conflict_severity')).upper()
    # Internal news-vs-market disagreement is a warning unless it is explicitly HIGH.
    # A final macro bias that opposes the chart remains a true hard conflict.
    conflict = bool(directional_conflict or (component_conflict and severity == 'HIGH'))
    exec_alignment = regime.get('execution_alignment')
    # PREPARE means directional idea exists, but timing TFs are not yet aligned for entry.
    state = 'WAIT'
    if side in {'long', 'short'} and not conflict:
        state = 'PREPARE_' + side.upper()
        if exec_alignment == 'aligned' and regime.get('phase') != 'countertrend_pullback':
            state = 'READY_' + side.upper()
    return {
        'name': pb,
        'side': side,
        'state': state,
        'macro_conflict': conflict,
        'component_macro_conflict': component_conflict,
        'macro_conflict_severity': severity or 'NONE',
        'directional_macro_conflict': bool(directional_conflict),
        'reason': f"{name} + technical_bias={tech.get('bias')} + macro_gold_bias={macro.get('gold_bias')} + execution_alignment={exec_alignment}",
    }


def _recent_events(c: Dict[str, Any]) -> List[Dict[str, Any]]:
    return [x for x in _l(_adv(c).get('events'))[-10:] if isinstance(x, dict)]


def _recent_sweeps(c: Dict[str, Any]) -> List[Dict[str, Any]]:
    return [x for x in _l(_d(c.get('liquidity')).get('sweeps'))[-10:] if isinstance(x, dict)]


def _trigger_status(chart: Dict[str, Any], side: str, regime: Dict[str, Any]) -> Dict[str, Any]:
    if side not in ('long', 'short'):
        return {'state': 'WAIT', 'ready': False, 'side': side, 'reason': 'No actionable side.', 'evidence': []}
    evidence = []
    for tf in ('M5', 'M15'):
        c = _tf(chart, tf)
        mss = _d(_adv(c).get('mss'))
        events = _recent_events(c)
        sweeps = _recent_sweeps(c)
        tf_side = _tf_side(c)
        if side == 'long':
            sweep_ok = any(_sl(x.get('type')).startswith('sell_side_sweep') for x in sweeps)
            structure_ok = _sl(mss.get('type')).startswith('bullish') or any(_sl(e.get('type')) in {'choch_up', 'bos_up'} for e in events)
        else:
            sweep_ok = any(_sl(x.get('type')).startswith('buy_side_sweep') for x in sweeps)
            structure_ok = _sl(mss.get('type')).startswith('bearish') or any(_sl(e.get('type')) in {'choch_down', 'bos_down'} for e in events)
        evidence.append({'timeframe': tf, 'tf_side': tf_side, 'sweep_ok': bool(sweep_ok), 'structure_ok': bool(structure_ok), 'mss': mss or None})
    aligned = all(e['tf_side'] == side for e in evidence)
    sweep_count = sum(1 for e in evidence if e['sweep_ok'])
    structure_count = sum(1 for e in evidence if e['structure_ok'])
    if aligned and sweep_count >= 1 and structure_count == 2:
        state, ready, reason = 'EXECUTE_' + side.upper(), True, 'M5/M15 aligned with sweep + structure trigger.'
    elif sweep_count >= 1 or structure_count >= 1:
        state, ready, reason = 'PREPARE_' + side.upper(), False, 'Directional setup forming; wait for both M5/M15 structure alignment.'
    else:
        state, ready, reason = 'WAIT', False, 'Need M5/M15 sweep plus CHOCH/MSS confirmation.'
    # Countertrend pullback must flip back into higher-timeframe direction before scalp entry.
    if regime.get('phase') == 'countertrend_pullback' and state.startswith('PREPARE'):
        reason += ' Higher-timeframe pullback is not finished yet.'
    return {'state': state, 'ready': ready, 'side': side, 'evidence': evidence, 'reason': reason}


def _risk_assessment(chart: Dict[str, Any], macro: Dict[str, Any], micro: Dict[str, Any], tech: Dict[str, Any], regime: Dict[str, Any], playbook: Dict[str, Any] | None = None, trigger: Dict[str, Any] | None = None) -> Dict[str, Any]:
    score = 0.0
    reasons: List[str] = []
    if not macro.get('attached'):
        score += 40; reasons.append('missing_news_macro')
    if _d(macro.get('event_risk')).get('blocks_trade'):
        score += 45; reasons.append('high_impact_event_risk')
    if playbook and playbook.get('macro_conflict'):
        score += 35; reasons.append('macro_directional_conflict')
    elif macro.get('bias_conflict'):
        sev = _s(macro.get('conflict_severity')).upper()
        add = 16 if sev == 'MEDIUM' else 8 if sev == 'LOW' else 24 if sev == 'HIGH' else 8
        score += add; reasons.append('macro_component_disagreement')
    if not micro.get('spread_ok'):
        score += 20; reasons.append('spread_not_ok')
    if tech.get('confidence', 0) < 18:
        score += 15; reasons.append('low_technical_confidence')
    if tech.get('quality', 0) < 70:
        score += 14; reasons.append('trade_quality_below_70')
    if regime.get('phase') in ('range_or_unclear', 'transition'):
        score += 12; reasons.append('regime_not_clean')
    if playbook and playbook.get('state') == 'WAIT':
        score += 10; reasons.append('no_ready_playbook')
    level = 'HIGH' if score >= 55 else 'MEDIUM' if score >= 25 else 'LOW'
    return {'score': round(min(score, 100.0), 2), 'level': level, 'reasons': reasons or ['clean']}


def _fusion_score(tech: Dict[str, Any], macro_sc: Dict[str, Any], risk: Dict[str, Any]) -> Dict[str, Any]:
    long = tech['long'] * 0.42 + macro_sc['long'] * 0.38 + tech['quality'] * 0.10 + tech['confidence'] * 0.10
    short = tech['short'] * 0.42 + macro_sc['short'] * 0.38 + tech['quality'] * 0.10 + tech['confidence'] * 0.10
    penalty = risk['score'] * 0.32
    long = _clamp(long - penalty)
    short = _clamp(short - penalty)
    bias = 'long' if long > short else 'short' if short > long else 'neutral'
    edge = abs(long - short)
    confidence = _clamp(edge + max(tech['confidence'], macro_sc['confidence']) * 0.35 - risk['score'] * 0.20)
    return {'long': round(long, 2), 'short': round(short, 2), 'bias': bias, 'edge': round(edge, 2), 'confidence': round(confidence, 2)}


def _best_zones(chart: Dict[str, Any], side: str, limit: int = 3) -> List[Dict[str, Any]]:
    zones = _l(_d(chart.get('trade_map')).get('buy_zones' if side == 'long' else 'sell_zones'))
    cleaned = []
    for z in zones:
        if not isinstance(z, dict):
            continue
        item = {k: z.get(k) for k in ('timeframe', 'source', 'low', 'high', 'level', 'status', 'score', 'rank_score', 'distance_from_reference', 'quality') if k in z}
        cleaned.append(item)
        if len(cleaned) >= limit:
            break
    return cleaned


def _levels(chart: Dict[str, Any], side: str, style: str = 'spot') -> Dict[str, Any]:
    plan = build_execution_plan(chart, side, style=style)
    return {
        'entry_zones': plan.get('entry_zones', []),
        'primary_entry': plan.get('primary_entry'),
        'invalidation': plan.get('invalidation'),
        'targets': plan.get('targets', []),
        'execution_plan': plan,
    }


def _blockers(macro: Dict[str, Any], micro: Dict[str, Any], tech: Dict[str, Any], playbook: Dict[str, Any], fusion: Dict[str, Any], risk: Dict[str, Any], trigger: Dict[str, Any], ai: Dict[str, Any] | None = None, market_state: Dict[str, Any] | None = None) -> List[str]:
    """Return only true blockers, not ordinary low-score warnings.

    Earlier versions mixed soft weakness (low confidence) with hard safety gates.
    That made the engine feel rule-based. In this build, hard blockers come from
    missing news, high event risk, macro/chart conflict, spread, or AI permission.
    Weak evidence stays in warnings and lowers confidence instead of becoming a
    brittle rule.
    """
    b: List[str] = []
    ai = ai or {}
    for x in _l(ai.get('hard_blockers')):
        if x:
            b.append(str(x))
    if not macro.get('attached'):
        b.append('News/Macro V8.5 missing')
    if _d(macro.get('event_risk')).get('blocks_trade'):
        b.append('High-impact macro event risk')
    if playbook.get('macro_conflict'):
        b.append('Final macro direction conflicts with chart/playbook')
    if not micro.get('spread_ok'):
        b.append('Spread not acceptable')
    ms = _d(market_state)
    gate = _s(ms.get('execution_gate')).upper()
    if gate == 'BLOCKED_MARKET_CLOSED':
        b.append('Market closed: weekend snapshot only')
    elif gate == 'BLOCKED_TIME_SYNC':
        b.append('MT5 timestamp/timezone coherence fault')
    elif gate == 'BLOCKED_HISTORY_SYNC':
        b.append('MT5 quote/bar history is not synchronized')
    elif gate == 'BLOCKED_STALE_DATA':
        b.append('MT5 execution data is stale')
    elif gate == 'BLOCKED_REOPEN_COOLDOWN':
        b.append('Market reopen cooldown active')
    elif gate == 'BLOCKED_SPREAD_REGIME':
        b.append('Extreme spread regime')
    elif gate == 'BLOCKED_TERMINAL_DISCONNECTED':
        b.append('MT5 terminal disconnected')
    if ai and ai.get('trade_permission') == 'BLOCKED':
        for x in _l(ai.get('hard_blockers')):
            b.append(str(x))
    return list(dict.fromkeys([x for x in b if x]))

def _decision_payload(action: str, side: str, levels: Dict[str, Any], reason: str, setup_state: str, trigger: Dict[str, Any] | None = None) -> Dict[str, Any]:
    approved = action in {'BUY', 'SELL'}
    # WAIT must not hide the setup the engine is waiting for. Actionable fields stay
    # empty to avoid accidental execution, while watchlist_* exposes the exact zone,
    # invalidation and targets ChatGPT should monitor.
    return {
        'action': action,
        'side': side if approved else None,
        'directional_side': side if side in {'long', 'short'} else None,
        'setup_state': setup_state,
        'entry_zones': levels.get('entry_zones', []) if approved else [],
        'primary_entry': levels.get('primary_entry') if approved else None,
        'invalidation': levels.get('invalidation') if approved else None,
        'targets': levels.get('targets', []) if approved else [],
        'execution_plan': levels.get('execution_plan') if approved else None,
        'watchlist_entry_zones': levels.get('entry_zones', []) if not approved else [],
        'watchlist_primary_entry': levels.get('primary_entry') if not approved else None,
        'watchlist_invalidation': levels.get('invalidation') if not approved else None,
        'watchlist_targets': levels.get('targets', []) if not approved else [],
        'watchlist_execution_plan': levels.get('execution_plan') if not approved else None,
        'trigger': trigger,
        'reason': reason,
    }


def _paper_test_candidate(*, style: str, payload: Dict[str, Any], market_state: Dict[str, Any], trigger: Dict[str, Any] | None = None) -> Dict[str, Any]:
    """Build a paper-only candidate. Never places an MT5 order.

    PAPER_READY is emitted only when the normal production decision itself is BUY/SELL.
    This guarantees paper testing cannot bypass market, news, risk, timing or state-machine gates.
    """
    action = _s(payload.get('action')).upper()
    ready = action in {'BUY', 'SELL'} and bool(_d(market_state).get('actionable'))
    plan = _d(payload.get('execution_plan') if ready else payload.get('watchlist_execution_plan'))
    primary = payload.get('primary_entry') if ready else payload.get('watchlist_primary_entry')
    invalidation = payload.get('invalidation') if ready else payload.get('watchlist_invalidation')
    targets = payload.get('targets') if ready else payload.get('watchlist_targets')
    return {
        'mode': 'PAPER_ONLY',
        'status': 'PAPER_READY' if ready else 'NOT_READY',
        'style': style,
        'action': action if ready else 'WAIT',
        'side': payload.get('side') if ready else payload.get('directional_side'),
        'setup_state': payload.get('setup_state'),
        'market_gate': _d(market_state).get('execution_gate'),
        'reference_price': plan.get('reference_price'),
        'entry': primary if ready else None,
        'invalidation': invalidation if ready else None,
        'targets': targets if ready else [],
        'rr': plan.get('rr') if ready else None,
        'execution_grade': plan.get('execution_grade') if ready else None,
        'trigger': trigger if style == 'scalp' else payload.get('trigger'),
        'reason': ('All normal execution gates passed; candidate is ready for hypothetical/paper tracking only.'
                   if ready else payload.get('reason')),
        'safety': 'No order is sent to MetaTrader 5. Re-check live price, spread and trigger before recording a hypothetical fill.',
    }


def _canonical_permission(spot_state: Dict[str, Any], scalp_state: Dict[str, Any], blockers: List[str], spot_action: str, scalp_action: str) -> Dict[str, Any]:
    if blockers:
        sstate = _s(spot_state.get('state')).upper()
        if sstate.startswith('MARKET_CLOSED_WATCH_'):
            return {'state': spot_state.get('state'), 'permission': 'MARKET_CLOSED', 'reason': spot_state.get('reason'), 'actionable': False}
        if sstate.startswith('REOPEN_COOLDOWN_'):
            return {'state': spot_state.get('state'), 'permission': 'REOPEN_COOLDOWN', 'reason': spot_state.get('reason'), 'actionable': False}
        if sstate.startswith('TIME_SYNC_BLOCKED_'):
            return {'state': spot_state.get('state'), 'permission': 'TIME_SYNC_BLOCKED', 'reason': spot_state.get('reason'), 'actionable': False}
        if sstate.startswith('HISTORY_SYNC_BLOCKED_'):
            return {'state': spot_state.get('state'), 'permission': 'HISTORY_SYNC_BLOCKED', 'reason': spot_state.get('reason'), 'actionable': False}
        if sstate.startswith('DATA_STALE_'):
            return {'state': spot_state.get('state'), 'permission': 'DATA_STALE', 'reason': spot_state.get('reason'), 'actionable': False}
        if sstate.startswith('SPREAD_BLOCKED_'):
            return {'state': spot_state.get('state'), 'permission': 'SPREAD_BLOCKED', 'reason': spot_state.get('reason'), 'actionable': False}
        if sstate.startswith('TERMINAL_DISCONNECTED_'):
            return {'state': spot_state.get('state'), 'permission': 'TERMINAL_DISCONNECTED', 'reason': spot_state.get('reason'), 'actionable': False}
        side = _s(spot_state.get('side') or scalp_state.get('side') or '')
        state = 'BLOCKED_' + side.upper() if side in {'long', 'short'} else 'BLOCKED'
        return {'state': state, 'permission': 'BLOCKED', 'reason': '; '.join(blockers), 'actionable': False}
    if scalp_action in {'BUY', 'SELL'}:
        return {'state': scalp_state.get('state'), 'permission': 'ALLOW_SCALP_AND_SPOT', 'reason': scalp_state.get('reason'), 'actionable': True}
    if spot_action in {'BUY', 'SELL'}:
        return {'state': spot_state.get('state'), 'permission': 'ALLOW_SPOT_ONLY', 'reason': spot_state.get('reason'), 'actionable': True}

    # No execution is allowed yet. Prefer the state with the closest execution intent:
    # retest/pullback states are more informative than generic WAIT/PREPARE.
    candidates = [spot_state, scalp_state]
    priority = {
        'WAIT_RETEST': 8, 'WAIT_PULLBACK': 7, 'BREAKOUT_RETEST': 6,
        'READY': 5, 'PREPARE': 4, 'WAIT_COOLDOWN': 3, 'WAIT': 1,
    }
    best = spot_state
    best_score = -1
    for c in candidates:
        st = _s(c.get('state')).upper()
        score = max((v for k, v in priority.items() if st.startswith(k)), default=0)
        if score > best_score:
            best, best_score = c, score
    state = best.get('state') or 'WAIT'
    permission = 'WATCH_ONLY' if state and state != 'WAIT' else 'WAIT'
    return {'state': state, 'permission': permission, 'reason': best.get('reason'), 'actionable': False}


def _consistency_audit(*, canonical: Dict[str, Any], spot_state: Dict[str, Any], scalp_state: Dict[str, Any], playbook: Dict[str, Any], side: str) -> Dict[str, Any]:
    issues: List[str] = []
    cstate = _s(canonical.get('state')).upper()
    if canonical.get('permission') == 'ALLOW_SPOT_ONLY' and not spot_state.get('actionable'):
        issues.append('permission_spot_without_actionable_spot_state')
    if canonical.get('permission') == 'ALLOW_SCALP_AND_SPOT' and not scalp_state.get('actionable'):
        issues.append('permission_scalp_without_actionable_scalp_state')
    if side in {'long', 'short'} and _s(playbook.get('side')) not in {side, 'none', ''}:
        issues.append('playbook_direction_conflicts_with_fusion_direction')
    if cstate.startswith('READY_') and not (spot_state.get('actionable') or scalp_state.get('actionable')):
        issues.append('ready_state_without_actionable_execution')
    return {
        'consistent': not issues,
        'issues': issues,
        'canonical_state': canonical.get('state'),
        'canonical_permission': canonical.get('permission'),
        'spot_state': spot_state.get('state'),
        'scalp_state': scalp_state.get('state'),
    }


def _top_reasons(chart: Dict[str, Any], macro: Dict[str, Any], regime: Dict[str, Any], tech: Dict[str, Any], fusion: Dict[str, Any], playbook: Dict[str, Any], risk: Dict[str, Any], trigger: Dict[str, Any]) -> List[str]:
    reasons = [
        f"Regime: {regime.get('name')} / {regime.get('phase')} / primary_side={regime.get('primary_side')}.",
        f"Playbook: {playbook.get('name')} / state={playbook.get('state')} / side={playbook.get('side')}.",
        f"Macro: bias={macro.get('gold_bias')} news={macro.get('news_bias')} market={macro.get('market_bias')} event={_d(macro.get('event_risk')).get('level')} confidence={macro.get('confidence')}.",
        f"Technical: long={tech.get('long')} short={tech.get('short')} confidence={tech.get('confidence')} quality={tech.get('quality')}.",
        f"Fusion: long={fusion.get('long')} short={fusion.get('short')} bias={fusion.get('bias')} confidence={fusion.get('confidence')}.",
        f"Risk: {risk.get('level')} score={risk.get('score')} reasons={', '.join(risk.get('reasons', []))}.",
        f"Trigger: {trigger.get('state')} / {trigger.get('reason')}.",
    ]
    ev = _l(_d(chart.get('probability')).get('top_evidence'))
    seen = set()
    for item in ev:
        if not isinstance(item, dict):
            continue
        txt = f"Chart evidence: {item.get('tf')} {item.get('side')} {item.get('kind')} weight={item.get('weight')}"
        if txt not in seen:
            reasons.append(txt)
            seen.add(txt)
        if len(reasons) >= 10:
            break
    return reasons[:10]


def build_final_decision_packet(chart: Dict[str, Any]) -> Dict[str, Any]:
    fusion_ctx = _d(chart.get('fusion_context'))
    market_state = _d(fusion_ctx.get('market_state'))
    macro = _extract_macro(_d(fusion_ctx.get('news_macro_context')))
    regime = _market_regime(chart)
    micro = _microstructure(chart)
    tech = _technical_scores(chart, regime)
    macro_sc = _macro_scores(macro)
    playbook = _playbook(regime, tech, macro)
    learning_profile = _d(fusion_ctx.get('learning_profile'))
    learning_thresholds = _d(learning_profile.get('thresholds'))

    # Direction is inferred by the local AI-style fusion model. The playbook still
    # describes the tactical map, but it no longer forces the final side.
    provisional_side = playbook.get('side') if playbook.get('side') in {'long', 'short'} else ('long' if tech['long'] > tech['short'] else 'short' if tech['short'] > tech['long'] else 'none')
    trigger = _trigger_status(chart, provisional_side, regime)
    pre_risk = _risk_assessment(chart, macro, micro, tech, regime, playbook, trigger)
    ai = infer_final_decision(
        macro=macro,
        macro_scores=macro_sc,
        technical=tech,
        regime=regime,
        micro=micro,
        playbook=playbook,
        trigger=trigger,
        risk=pre_risk,
        learning_profile=learning_profile,
    )

    side = ai.get('direction') if ai.get('direction') in {'long', 'short'} else provisional_side
    if side != provisional_side and side in {'long', 'short'}:
        # Re-evaluate trigger and levels when the AI fusion side differs from the
        # tactical playbook. This prevents contradictions like SELL_RALLY with a
        # bullish M5/M15 trigger being marked ready.
        trigger = _trigger_status(chart, side, regime)
    risk = _risk_assessment(chart, macro, micro, tech, regime, playbook, trigger)
    ai = infer_final_decision(
        macro=macro,
        macro_scores=macro_sc,
        technical=tech,
        regime=regime,
        micro=micro,
        playbook=playbook,
        trigger=trigger,
        risk=risk,
        learning_profile=learning_profile,
    )
    fusion = {
        'long': ai.get('long_probability'),
        'short': ai.get('short_probability'),
        'bias': ai.get('direction'),
        'edge': ai.get('edge'),
        'confidence': ai.get('confidence'),
        'raw_long': ai.get('raw_long_probability'),
        'raw_short': ai.get('raw_short_probability'),
        'calibration_samples': ai.get('calibration_samples'),
        'probability_semantics': ai.get('probability_semantics'),
        'model': ai.get('model'),
        'trade_permission': ai.get('trade_permission'),
        'execution_state': ai.get('execution_state'),
    }
    blockers = _blockers(macro, micro, tech, playbook, fusion, risk, trigger, ai, market_state=market_state)
    spot_levels = _levels(chart, side if side in {'long', 'short'} else 'none', style='spot')
    scalp_levels = _levels(chart, side if side in {'long', 'short'} else 'none', style='scalp')

    spot_action = 'WAIT'
    scalp_action = 'WAIT'
    permission = ai.get('trade_permission')
    execution_state = _s(ai.get('execution_state') or 'WAIT')
    ai_conf = _n(ai.get('confidence'))

    spot_threshold = _n(learning_thresholds.get('spot_confidence'), 32.0)
    scalp_threshold = _n(learning_thresholds.get('scalp_confidence'), 38.0)

    warnings = list(dict.fromkeys(_l(ai.get('soft_warnings')) + _l(risk.get('reasons'))))
    spot_plan = _d(spot_levels.get('execution_plan'))
    scalp_plan = _d(scalp_levels.get('execution_plan'))
    spot_plan_valid = bool(spot_plan.get('valid'))
    scalp_plan_valid = bool(scalp_plan.get('valid'))
    if side in {'long', 'short'} and not spot_plan_valid:
        blockers.append('No valid RR-aware spot execution plan')
    if side in {'long', 'short'} and not scalp_plan_valid:
        warnings.append('No valid RR-aware scalp execution plan')

    # Dedicated execution state machine: directional conviction does not equal immediate entry.
    spot_state = evaluate_execution_state(
        chart=chart, side=side, style='spot', plan=spot_plan, trigger=trigger,
        macro=macro, micro=micro, regime=regime, ai_confidence=ai_conf, blockers=blockers, market_state=market_state,
    )
    scalp_state = evaluate_execution_state(
        chart=chart, side=side, style='scalp', plan=scalp_plan, trigger=trigger,
        macro=macro, micro=micro, regime=regime, ai_confidence=ai_conf, blockers=blockers, market_state=market_state,
    )

    if not blockers and side in {'long', 'short'}:
        if spot_plan_valid and permission != 'BLOCKED' and spot_state.get('actionable') and ai_conf >= spot_threshold:
            spot_action = 'BUY' if side == 'long' else 'SELL'
        if scalp_plan_valid and permission != 'BLOCKED' and scalp_state.get('actionable') and trigger.get('ready') and ai_conf >= scalp_threshold:
            scalp_action = 'BUY' if side == 'long' else 'SELL'

    # Canonicalize state AFTER price-location and execution geometry are known. The AI
    # fusion model provides direction/confidence only; it is no longer allowed to publish
    # a READY/ALLOW permission that contradicts the state machine.
    pre_execution_hint = {
        'ai_execution_state': ai.get('execution_state'),
        'ai_trade_permission': ai.get('trade_permission'),
        'playbook_state': playbook.get('state'),
    }
    canonical = _canonical_permission(spot_state, scalp_state, blockers, spot_action, scalp_action)
    fusion['execution_state'] = canonical.get('state')
    fusion['trade_permission'] = canonical.get('permission')
    playbook = dict(playbook)
    playbook['directional_state'] = pre_execution_hint.get('playbook_state')
    playbook['state'] = canonical.get('state')
    playbook['trade_permission'] = canonical.get('permission')
    playbook['execution_reason'] = canonical.get('reason')
    consistency = _consistency_audit(
        canonical=canonical, spot_state=spot_state, scalp_state=scalp_state,
        playbook=playbook, side=side,
    )

    wait_for_spot = blockers[:] if blockers else []
    wait_for_scalp = blockers[:] if blockers else []
    if spot_action == 'WAIT' and not wait_for_spot:
        wait_for_spot.append(spot_state.get('reason') or f'Execution state: {spot_state.get("state")}')
        if ai_conf < spot_threshold:
            wait_for_spot.append(f"AI confidence must be >= {spot_threshold}, now {ai_conf}")
    if scalp_action == 'WAIT':
        if not wait_for_scalp:
            wait_for_scalp.append(scalp_state.get('reason') or trigger.get('reason') or 'Execution trigger not ready')
        if ai_conf < scalp_threshold:
            wait_for_scalp.append(f"AI confidence must be >= {scalp_threshold}, now {ai_conf}")

    spot_reason = 'WAIT: ' + '; '.join(wait_for_spot) if spot_action == 'WAIT' else f"Approved by state machine: {spot_state.get('state')} / {spot_state.get('mode')}."
    scalp_reason = 'WAIT: ' + '; '.join(wait_for_scalp) if scalp_action == 'WAIT' else f"Approved by state machine: {scalp_state.get('state')} / {scalp_state.get('mode')}."

    spot_payload = _decision_payload(spot_action, side, spot_levels, spot_reason, spot_state.get('state') or execution_state)
    scalp_payload = _decision_payload(scalp_action, side, scalp_levels, scalp_reason, scalp_state.get('state') or execution_state, trigger)
    paper_test = {
        'enabled': True,
        'mode': 'PAPER_ONLY',
        'spot': _paper_test_candidate(style='spot', payload=spot_payload, market_state=market_state),
        'scalp': _paper_test_candidate(style='scalp', payload=scalp_payload, market_state=market_state, trigger=trigger),
        'note': 'Paper candidates are derived from the same canonical gates; they never bypass blockers and never place orders.',
    }

    output = {
        'contract': 'AMB_GOLD_UNIFIED_AI_LEARNING_DECISION_V5_TIME_SYNC_PAPER',
        'engine': 'AMB Gold Unified MT5 Time-Synchronized AI Learning Engine',
        'symbol': chart.get('symbol'),
        'data_provider': chart.get('provider'),
        'generated_utc': datetime.now(timezone.utc).isoformat(),
        'decision_only': True,
        'hard_rules': {
            'news_and_chart_run_together': True,
            'no_news_no_trade': True,
            'high_event_risk_blocks_trade': True,
            'macro_chart_conflict_outputs_wait': True,
            'scalp_requires_m5_m15_execution_trigger': True,
            'no_raw_news_blob_in_llm_packet': True,
            'prepare_is_not_entry': True,
            'directional_bias_is_not_market_entry': True,
            'spot_requires_price_location_or_retest': True,
            'scalp_requires_trigger_and_location': True,
            'market_closed_blocks_execution': True,
            'stale_mt5_data_blocks_execution': True,
            'reopen_gap_requires_cooldown': True,
            'extreme_dynamic_spread_blocks_execution': True,
        },
        'market_regime': {
            'name': regime.get('name'),
            'phase': regime.get('phase'),
            'primary_side': regime.get('primary_side'),
            'execution_alignment': regime.get('execution_alignment'),
            'volatility_phase': regime.get('volatility_phase'),
            'timeframe_bias': {k: v.get('side') for k, v in _d(regime.get('timeframe_votes')).get('rows', {}).items()},
        },
        'market_snapshot': {
            'reference_price': _d(chart.get('trade_map')).get('reference_price'),
            'provider': chart.get('provider'),
            'symbol': chart.get('symbol'),
            'market_status': market_state.get('status'),
            'data_state': market_state.get('data_state'),
            'execution_gate': market_state.get('execution_gate'),
        },
        'market_state': market_state,
        'weekend_outlook': {
            'enabled': bool(market_state.get('weekend_outlook_only')),
            'directional_side': side if side in {'long', 'short'} else None,
            'regime': regime.get('name'),
            'note': 'Directional context and zones are informational until market reopens and fresh-data gates clear.' if market_state.get('weekend_outlook_only') else None,
        },
        'macro_context': macro,
        'scoreboard': {
            'technical': tech,
            'macro': macro_sc,
            'fusion': fusion,
            'risk': risk,
        },
        'learning': {
            'enabled': bool(learning_profile.get('enabled')),
            'version': learning_profile.get('version'),
            'thresholds': learning_profile.get('thresholds'),
            'metrics': learning_profile.get('metrics'),
        },
        'ai_inference': {
            'model': ai.get('model'),
            'direction': ai.get('direction'),
            'confidence': ai.get('confidence'),
            'long_probability': ai.get('long_probability'),
            'short_probability': ai.get('short_probability'),
            'edge': ai.get('edge'),
            'raw_long_probability': ai.get('raw_long_probability'),
            'raw_short_probability': ai.get('raw_short_probability'),
            'calibration_samples': ai.get('calibration_samples'),
            'probability_semantics': ai.get('probability_semantics'),
            'execution_state': canonical.get('state'),
            'trade_permission': canonical.get('permission'),
            'pre_execution_hint': pre_execution_hint,
            'hard_blockers': ai.get('hard_blockers'),
            'soft_warnings': ai.get('soft_warnings'),
            'explanation': _l(ai.get('explanation'))[:8],
            'features': _l(ai.get('features'))[:12],
        },
        'execution_playbook': playbook,
        'execution_state_machine': {'spot': spot_state, 'scalp': scalp_state},
        'canonical_execution': canonical,
        'consistency_audit': consistency,
        'decision': {
            'spot': spot_payload,
            'scalp': scalp_payload,
            'blockers': blockers,
            'warnings': warnings,
            'wait_for': {
                'spot': wait_for_spot,
                'scalp': wait_for_scalp,
            },
        },
        'paper_test': paper_test,
        'reasons': _top_reasons(chart, macro, regime, tech, fusion, playbook, risk, trigger)[:7] + _l(ai.get('explanation'))[:3],
        'chatgpt_instruction': 'Use this compact AI+Learning final packet only. Do not override hard gates. If blockers exist, answer WAIT. PREPARE means watchlist, not entry.',
    }
    return output

def build_institutional_decision_packet(chart: Dict[str, Any]) -> Dict[str, Any]:
    return build_final_decision_packet(chart)
