from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict

from amb_gold_news.engine import run_engine
from amb_gold_news.report import render_report
from amb_chart.analysis.engine import analyze
from amb_chart.config import EngineConfig
from amb_chart.learning.memory import LearningMemory
from amb_chart.providers.mt5_live import MT5LiveProvider
from amb_chart.spot.engine import build_spot_decision_packet
from amb_chart.spot.writer import write_spot_outputs
from amb_chart.spot.position_registry import SpotPositionRegistry


SPOT_TIMEFRAMES = {
    "M5": "M5",      # health/spread/reopen only; excluded from spot direction
    "M15": "M15",    # timing only
    "H1": "H1",
    "H4": "H4",
    "D1": "D1",
    "W1": "W1",
    "MN1": "MN1",
}


def _load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="AMB Gold MT5 Institutional Spot Engine")
    p.add_argument("--symbol", default="XAUUSD")
    p.add_argument("--mt5-path", default=None)
    p.add_argument("--mt5-login", type=int, default=None)
    p.add_argument("--mt5-password", default=None)
    p.add_argument("--mt5-server", default=None)
    p.add_argument("--mt5-portable", action="store_true")
    p.add_argument("--count", type=int, default=900)
    p.add_argument("--days", type=int, default=3)
    p.add_argument("--workers", type=int, default=10)
    p.add_argument("--output-dir", default="outputs_spot")
    p.add_argument("--state-dir", default="state_spot")
    p.add_argument("--learning", action="store_true")
    p.add_argument("--news-context", default=None, help="Use an existing latest_macro_context.json instead of scraping")
    p.add_argument("--chart-only", action="store_true", help="Skip news scraping; requires --news-context for actionable output")
    p.add_argument("--news-only", action="store_true")
    p.add_argument("--skip-heavy", action="store_true")
    p.add_argument("--no-google", action="store_true")
    p.add_argument("--no-source-caps", action="store_true")
    p.add_argument("--exhaustive", action="store_true")
    p.add_argument("--debug-full-output", action="store_true")
    p.add_argument("--position-file", default=None, help="Persistent paper/manual spot position registry JSON; defaults under --state-dir")
    p.add_argument("--paper-open-position", action="store_true", help="Register the current planned spot setup as an open paper position after analysis")
    p.add_argument("--paper-close-position", action="store_true", help="Close the persisted paper/manual spot position")
    p.add_argument("--position-entry-price", type=float, default=None, help="Actual/manual entry price used with --paper-open-position; defaults to weighted planned entry")
    p.add_argument("--position-note", default="", help="Optional note stored with a registered paper/manual position")
    p.add_argument("--paper-fill-tranche", type=int, choices=[1, 2, 3], default=None, help="Record one adaptive accumulation tranche as a paper fill; the current packet must mark it price-eligible and accumulation-permitted")
    p.add_argument("--tranche-fill-price", type=float, default=None, help="Optional actual/manual fill price used with --paper-fill-tranche; defaults to the planned tranche price")
    return p.parse_args()


def run_news(args: argparse.Namespace, root: Path) -> Path:
    news_out = root / "news"
    news_out.mkdir(parents=True, exist_ok=True)
    days = max(args.days, 7) if args.exhaustive else args.days
    include_heavy = True if args.exhaustive else not args.skip_heavy
    include_google = True if args.exhaustive else not args.no_google
    source_caps = False if args.exhaustive else not args.no_source_caps
    items, stats = run_engine(
        days=days,
        workers=args.workers,
        include_heavy=include_heavy,
        include_google=include_google,
        output_dir=str(news_out),
        source_caps=source_caps,
    )
    render_report(items, stats, output_dir=str(news_out))
    path = news_out / "latest_macro_context.json"
    if not path.exists():
        raise RuntimeError(f"News engine did not produce {path}")
    return path


def main() -> None:
    args = parse_args()
    root = Path(args.output_dir)
    root.mkdir(parents=True, exist_ok=True)

    macro_path = Path(args.news_context) if args.news_context else None
    if not args.chart_only:
        print("▶ Running unchanged News/Macro engine ...")
        macro_path = run_news(args, root)
        print(f"✅ Macro context: {macro_path}")
    elif macro_path:
        print(f"▶ Using macro context: {macro_path}")
    else:
        print("⚠️ Spot chart-only run without macro context; output will remain non-actionable.")

    if args.news_only:
        return

    provider = MT5LiveProvider(
        symbol=args.symbol,
        terminal_path=args.mt5_path,
        login=args.mt5_login,
        password=args.mt5_password,
        server=args.mt5_server,
        portable=args.mt5_portable,
    )
    cfg = EngineConfig(
        symbol=args.symbol,
        count=args.count,
        output_dir=str(root / "chart"),
        timeframes=dict(SPOT_TIMEFRAMES),
        news_context_path=str(macro_path) if macro_path else None,
    )

    print("▶ Running MT5 Spot context (MN1/W1/D1/H4/H1 + M15 timing; M5 health only) ...")
    ctx = analyze(provider, cfg)
    chart = ctx.to_dict()
    # The core analyzer already attaches the news packet through cfg.news_context_path.
    learning_profile = LearningMemory(args.state_dir).profile(enabled=True) if args.learning else None
    position_path = Path(args.position_file) if args.position_file else Path(args.state_dir) / "spot_position.json"
    registry = SpotPositionRegistry(position_path)

    if args.paper_close_position:
        registry.close(reason=args.position_note or "manual_paper_close")

    position_record = registry.load()
    packet = build_spot_decision_packet(chart, learning_profile=learning_profile, position_record=position_record)

    if args.paper_fill_tranche is not None:
        registry.fill_tranche_from_packet(packet, tranche=args.paper_fill_tranche, fill_price=args.tranche_fill_price, note=args.position_note)
        position_record = registry.load()
        packet = build_spot_decision_packet(chart, learning_profile=learning_profile, position_record=position_record)

    if args.paper_open_position:
        if position_record and str(position_record.get("status") or "").lower() == "open":
            raise RuntimeError(f"A spot position is already registered at {position_path}; close/clear it before opening another.")
        registry.open_from_packet(packet, entry_price=args.position_entry_price, note=args.position_note)
        position_record = registry.load()
        packet = build_spot_decision_packet(chart, learning_profile=learning_profile, position_record=position_record)

    # Persist monotonic objective/thesis/review state, then rebuild once so the output
    # reflects any newly reached stage or D1/W1 allocation review from this run.
    if position_record and str(position_record.get("status") or "").lower() == "open":
        registry.update_from_packet(packet)
        position_record = registry.load()
        packet = build_spot_decision_packet(chart, learning_profile=learning_profile, position_record=position_record)

    write_spot_outputs(root, packet, debug_chart=chart if args.debug_full_output else None)

    print(f"✅ Spot decision: {root / 'latest_spot_decision.txt'}")
    print(f"✅ Spot ChatGPT packet: {root / 'latest_spot_chatgpt_prompt.txt'}")
    print(f"✅ Action={packet['decision']['action']} State={packet['decision']['state']} Actionable={packet['decision']['actionable']}")
    life = packet.get("position_lifecycle") or {}
    acc = packet.get("accumulation_plan") or {}
    thesis = packet.get("thesis_health") or {}
    knife = packet.get("falling_knife_guard") or {}
    print(f"✅ Lifecycle={life.get('state')} PositionRegistry={position_path}")
    print(f"✅ Accumulation={acc.get('state')} Permission={acc.get('permission')} NewAllocation={acc.get('recommended_new_allocation_pct_now')}%")
    print(f"✅ ThesisHealth={thesis.get('health_score_0_100')} {thesis.get('state')} | FallingKnife={knife.get('risk_score_0_100')} {knife.get('level')}")


if __name__ == "__main__":
    main()
