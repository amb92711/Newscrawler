from datetime import datetime, timezone, timedelta
from amb_gold_news.event_risk import evaluate_event_risk

NOW=datetime(2026,8,24,6,0,tzinfo=timezone.utc)

def ev(title, mins, impact='Medium', state='upcoming'):
    return {'title':title,'time':(NOW+timedelta(minutes=mins)).isoformat(),'summary':f'Impact: {impact} | Previous: | Forecast: | Actual:','event_state':state,'categories':['major_currency'],'source':'test'}

def test_distant_medium_usd_speech_not_high():
    r=evaluate_event_risk([ev('USD Treasury Sec Bessent Speaks',720,'Medium')],[],now=NOW)
    assert r['risk_level']=='LOW'
    assert not r['blocks_trade']

def test_critical_near_event_blocks():
    r=evaluate_event_risk([ev('USD Core PCE Price Index m/m',30,'High')],[],now=NOW)
    assert r['risk_level']=='HIGH'
    assert r['blocks_trade']

def test_untimed_final_is_context_only():
    r=evaluate_event_risk([], [{'title':'US Fed Interest Rate Decision 3.75%','time':None,'summary':'','event_state':'final','categories':['calendar_critical']}], now=NOW)
    assert r['risk_level']=='LOW'
    assert not r['blocks_trade']
    assert r['untimed_context_events']
