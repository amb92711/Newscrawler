from amb_chart.analysis.decision import _canonical_permission, _consistency_audit
from amb_chart.analysis.execution import build_execution_plan


def test_canonical_wait_pullback_overrides_old_ready_hint():
    spot = {'state': 'WAIT_PULLBACK_LONG', 'actionable': False, 'side': 'long', 'reason': 'wait pullback'}
    scalp = {'state': 'PREPARE_LONG', 'actionable': False, 'side': 'long', 'reason': 'wait timing'}
    c = _canonical_permission(spot, scalp, [], 'WAIT', 'WAIT')
    assert c['state'] == 'WAIT_PULLBACK_LONG'
    assert c['permission'] == 'WATCH_ONLY'
    audit = _consistency_audit(canonical=c, spot_state=spot, scalp_state=scalp, playbook={'side': 'long'}, side='long')
    assert audit['consistent'] is True


def _c(close, atr, side='bullish'):
    return {
        'last_close': close,
        'atr': atr,
        'trend': side,
        'structure': 'bullish_hh_hl' if side == 'bullish' else 'bearish_lh_ll',
        'momentum': side,
        'swings': {'last_high': {'price': close + 20}, 'last_low': {'price': close - 20}},
        'support_resistance': {'supports': [close - 8, close - 15], 'resistances': [close + 8, close + 15]},
        'liquidity': {'pools': [], 'sweeps': []},
        'fvg': [],
    }


def test_scalp_zone_ranking_penalizes_extreme_distance():
    ref = 4617.0
    chart = {
        'trade_map': {
            'reference_price': ref,
            'buy_zones': [
                {'timeframe': 'H1', 'source': 'bullish_order_block', 'low': 4300.0, 'high': 4310.0, 'status': 'fresh', 'rank_score': 150},
                {'timeframe': 'M15', 'source': 'bullish_fvg', 'low': 4609.0, 'high': 4613.0, 'status': 'open', 'rank_score': 70},
            ],
            'sell_zones': [],
        },
        'market_microstructure': {'spread': 0.3},
        'timeframes': {
            'M5': _c(ref, 4),
            'M15': _c(ref, 8),
            'H1': _c(ref, 15),
            'H4': _c(ref, 30),
            'D1': _c(ref, 60),
        },
    }
    plan = build_execution_plan(chart, 'long', style='scalp')
    assert plan['primary_entry']['timeframe'] == 'M15'
    assert plan['price_location']['distance_atr'] < 2.0


def test_execution_plan_stop_and_targets_are_geometrically_valid():
    ref = 4617.0
    chart = {
        'trade_map': {
            'reference_price': ref,
            'buy_zones': [
                {'timeframe': 'H4', 'source': 'bullish_order_block', 'low': 4563.36, 'high': 4604.57, 'status': 'fresh', 'rank_score': 90},
            ],
            'sell_zones': [],
        },
        'market_microstructure': {'spread': 0.3},
        'timeframes': {
            'M5': _c(ref, 4),
            'M15': _c(ref, 8),
            'H1': _c(ref, 15),
            'H4': _c(ref, 30),
            'D1': _c(ref, 60),
        },
    }
    plan = build_execution_plan(chart, 'long', style='spot')
    assert plan['invalidation'] < 4563.36
    assert len(plan['targets']) == 3
    assert all(t['price'] > plan['primary_entry']['mid'] for t in plan['targets'])
