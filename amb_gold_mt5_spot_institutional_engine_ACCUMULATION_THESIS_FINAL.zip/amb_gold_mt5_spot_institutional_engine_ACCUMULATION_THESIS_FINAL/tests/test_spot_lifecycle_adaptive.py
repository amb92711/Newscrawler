from amb_chart.spot.engine import build_spot_decision_packet
from tests.test_spot_engine import _chart


def _with_markers(c, d1="2026-08-24T00:00:00+00:00", w1="2026-08-23T00:00:00+00:00"):
    c["timeframes"]["D1"]["last_time"] = d1
    c["timeframes"]["W1"]["last_time"] = w1
    return c


def _position(packet, *, realized=None, d1="2026-08-23T00:00:00+00:00", w1="2026-08-16T00:00:00+00:00", htf=80.0, macro=55.0):
    pm = packet["position_management_30_60d"]
    weights = pm["allocation_policy"]["stage_weights_pct"]
    return {
        "position_id": "spot-test-1",
        "status": "open",
        "side": "long",
        "opened_utc": "2026-08-20T00:00:00+00:00",
        "entry_price": packet["spot_opportunity"]["weighted_entry"],
        "realized_roles": realized or [],
        "realized_pct": sum(weights.get(r, 0.0) for r in (realized or [])),
        "entry_snapshot": {"htf_score": htf, "macro_score": macro},
        "entry_review_markers": {"D1": d1, "W1": w1},
        "last_allocation_review_markers": {"D1": d1, "W1": w1},
        "allocation_weights_pct": weights,
        "thesis_invalidation": packet["spot_opportunity"]["thesis_invalidation"],
    }


def test_pre_entry_is_not_hold_or_position_open():
    p = build_spot_decision_packet(_with_markers(_chart(price=100.0)))
    life = p["position_lifecycle"]
    assert life["state"] == "ENTRY_ARMED"
    assert life["position_open"] is False
    assert p["position_management_30_60d"]["management_state"]["state"] == "ENTRY_ARMED"


def test_registered_position_moves_to_position_open():
    c = _with_markers(_chart(price=100.0))
    base = build_spot_decision_packet(c)
    rec = _position(base)
    p = build_spot_decision_packet(c, position_record=rec)
    assert p["position_lifecycle"]["state"] == "POSITION_OPEN"
    assert p["position_lifecycle"]["position_open"] is True


def test_realized_tp1_is_monotonic_lifecycle_state():
    c = _with_markers(_chart(price=100.0))
    base = build_spot_decision_packet(c)
    rec = _position(base, realized=["TP1"])
    p = build_spot_decision_packet(c, position_record=rec)
    assert p["position_lifecycle"]["state"] == "TP1_REALIZED"
    stage = {x["role"]: x for x in p["position_lifecycle"]["canonical_stage_plan"]}
    assert stage["TP1"]["status"] == "REALIZED"
    assert stage["TP1"]["effective_future_reduction_pct"] == 0.0


def test_adaptive_reallocation_requires_new_d1_or_w1_close():
    c = _with_markers(_chart(price=100.0), d1="2026-08-24T00:00:00+00:00", w1="2026-08-23T00:00:00+00:00")
    base = build_spot_decision_packet(c)
    rec = _position(base, d1="2026-08-24T00:00:00+00:00", w1="2026-08-23T00:00:00+00:00")
    p = build_spot_decision_packet(c, position_record=rec)
    adapt = p["position_lifecycle"]["adaptive_reallocation"]
    assert adapt["review_eligible"] is False
    assert adapt["decision"] == "LOCK_CURRENT_ALLOCATION"


def test_adaptive_reallocation_can_extend_core_only_after_new_close():
    c = _with_markers(_chart(price=100.0), d1="2026-08-25T00:00:00+00:00", w1="2026-08-23T00:00:00+00:00")
    base = build_spot_decision_packet(c)
    # Entry snapshots deliberately weaker than current to create confirmed improvement.
    rec = _position(base, d1="2026-08-24T00:00:00+00:00", w1="2026-08-23T00:00:00+00:00", htf=70.0, macro=35.0)
    p = build_spot_decision_packet(c, position_record=rec)
    adapt = p["position_lifecycle"]["adaptive_reallocation"]
    assert adapt["review_eligible"] is True
    assert adapt["decision"] in {"EXTEND_STRATEGIC_CORE", "HOLD_ALLOCATION", "DE_RISK_EARLIER"}
    assert round(sum(adapt["effective_future_weights_pct"].values()), 1) == 100.0
