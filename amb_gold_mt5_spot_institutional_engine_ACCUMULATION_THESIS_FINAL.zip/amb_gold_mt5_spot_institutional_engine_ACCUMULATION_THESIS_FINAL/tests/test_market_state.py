from datetime import datetime, timezone, timedelta
from types import SimpleNamespace

from amb_chart.analysis.market_state import assess_market_state
from amb_chart.analysis.state_machine import evaluate_execution_state


def _rows(start, count=20, gap_at=None, gap_hours=0, spread=25):
    rows=[]
    t=start
    price=4600.0
    for i in range(count):
        if gap_at is not None and i == gap_at:
            t += timedelta(hours=gap_hours)
            price += 4.0
        rows.append({'time': t.isoformat(), 'open': price, 'high': price+1, 'low': price-1, 'close': price+0.2, 'spread': spread})
        t += timedelta(minutes=5)
        price += 0.1
    return rows


def _contexts(last_time, atr=6.0):
    return {
        'M5': SimpleNamespace(last_time=last_time, atr=atr),
        'M15': SimpleNamespace(last_time=last_time, atr=atr*2),
        'H1': SimpleNamespace(last_time=last_time, atr=atr*4),
        'H4': SimpleNamespace(last_time=last_time, atr=atr*8),
        'D1': SimpleNamespace(last_time=last_time, atr=atr*12),
    }


def test_saturday_stale_quotes_are_market_closed():
    now = datetime(2026, 8, 22, 8, 0, tzinfo=timezone.utc)  # Saturday
    last = now - timedelta(hours=10)
    raw={'M5': _rows(last - timedelta(minutes=95), 20)}
    ms=assess_market_state(raw=raw, contexts=_contexts(last.isoformat()), micro={'time': last.isoformat(), 'spread':0.35, 'point':0.01}, now=now)
    assert ms['status'] == 'CLOSED_WEEKEND'
    assert ms['execution_gate'] == 'BLOCKED_MARKET_CLOSED'
    assert ms['weekend_outlook_only'] is True


def test_open_fresh_market_allows_execution():
    now = datetime(2026, 8, 24, 10, 0, tzinfo=timezone.utc)  # Monday
    last = now - timedelta(minutes=2)
    raw={'M5': _rows(last - timedelta(minutes=95), 20)}
    ms=assess_market_state(raw=raw, contexts=_contexts(last.isoformat()), micro={'time': last.isoformat(), 'spread':0.25, 'point':0.01}, now=now)
    assert ms['status'] == 'OPEN'
    assert ms['execution_gate'] == 'ALLOW_EXECUTION'
    assert ms['actionable'] is True


def test_reopen_gap_cooldown_blocks_early_bars():
    start = datetime(2026, 8, 21, 20, 0, tzinfo=timezone.utc)
    rows = _rows(start, count=12, gap_at=9, gap_hours=51)
    last = datetime.fromisoformat(rows[-1]['time'])
    now = last + timedelta(minutes=2)
    ms=assess_market_state(raw={'M5':rows}, contexts=_contexts(last.isoformat(), atr=3.0), micro={'time': last.isoformat(), 'spread':0.25, 'point':0.01}, now=now)
    assert ms['reopen_gap']['detected'] is True
    assert ms['status'] == 'REOPEN_COOLDOWN'
    assert ms['execution_gate'] == 'BLOCKED_REOPEN_COOLDOWN'


def test_state_machine_preserves_weekend_watch_state():
    chart={'trade_map':{'reference_price':4617.0}, 'timeframes':{}}
    market_state={'status':'CLOSED_WEEKEND','execution_gate':'BLOCKED_MARKET_CLOSED','weekend_outlook_only':True}
    st=evaluate_execution_state(chart=chart, side='long', style='spot', plan={}, trigger={}, macro={}, micro={}, regime={}, ai_confidence=60, blockers=['Market closed: weekend snapshot only'], market_state=market_state)
    assert st['state'] == 'MARKET_CLOSED_WATCH_LONG'
    assert st['actionable'] is False
