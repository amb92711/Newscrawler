from datetime import datetime, timezone, timedelta
from types import SimpleNamespace

from amb_chart.providers.mt5_live import MT5LiveProvider
from amb_chart.analysis.market_state import assess_market_state


def _ctx(t, atr=5.0):
    return SimpleNamespace(last_time=t, atr=atr)


def test_tick_and_bar_offsets_are_independent_helpers():
    p = MT5LiveProvider('XAUUSD')
    m = p._model()
    m.update({
        'calibrated': True,
        'tick_offset_seconds': 10800,
        'bar_offset_seconds': 0,
    })
    raw_tick = 1_800_000_000
    raw_bar = 1_799_989_200
    assert p._normalize_tick_epoch(raw_tick) == raw_tick - 10800
    assert p._normalize_bar_epoch(raw_bar) == raw_bar


def test_history_unsynchronized_has_dedicated_hard_gate():
    now = datetime(2026, 8, 24, 6, 0, tzinfo=timezone.utc)
    tick = now - timedelta(seconds=10)
    old = now - timedelta(hours=8)
    contexts = {
        'M5': _ctx(old.isoformat()),
        'M15': _ctx(old.isoformat()),
        'H1': _ctx(old.isoformat()),
        'H4': _ctx(old.isoformat()),
        'D1': _ctx((now - timedelta(days=1)).isoformat()),
    }
    raw = {tf: [] for tf in ('M5','M15','H1','H4','D1')}
    micro = {
        'time': tick.isoformat(),
        'spread': 0.2,
        'point': 0.01,
        'history_sync': {
            'suspected': True,
            'resolved': False,
            'refresh_attempted': True,
            'tick_to_m5_gap_seconds': 8*3600,
        },
    }
    state = assess_market_state(raw=raw, contexts=contexts, micro=micro, provider_health={}, now=now)
    assert state['status'] == 'HISTORY_UNSYNCHRONIZED'
    assert state['execution_gate'] == 'BLOCKED_HISTORY_SYNC'
    assert state['actionable'] is False
    assert state['history_unsynchronized'] is True


def test_future_tick_still_blocks_even_if_history_sync_claims_resolved():
    now = datetime(2026, 8, 24, 6, 0, tzinfo=timezone.utc)
    future = now + timedelta(hours=3)
    contexts = {tf: _ctx(now.isoformat()) for tf in ('M5','M15','H1','H4','D1')}
    raw = {tf: [] for tf in ('M5','M15','H1','H4','D1')}
    micro = {'time': future.isoformat(), 'spread': 0.2, 'point': 0.01, 'history_sync': {'suspected': False, 'resolved': True}}
    state = assess_market_state(raw=raw, contexts=contexts, micro=micro, provider_health={}, now=now)
    assert state['status'] == 'TIME_SYNC_FAULT'
    assert state['execution_gate'] == 'BLOCKED_TIME_SYNC'
