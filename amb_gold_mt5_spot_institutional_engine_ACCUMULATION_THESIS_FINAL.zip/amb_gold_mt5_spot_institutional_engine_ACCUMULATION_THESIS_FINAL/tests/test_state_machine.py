from amb_chart.analysis.state_machine import evaluate_execution_state

def _chart(ref):
    def c(close, atr):
        return {
            "last_close": close, "atr": atr, "trend": "bullish", "structure": "bullish_hh_hl", "rsi": 55,
            "bollinger": {"upper": close+20, "lower": close-20},
            "advanced_structure": {"external":{"bias":"bullish"},"internal":{"bias":"bullish"},
                "mss":{"type":"bullish_internal_shift"},"events":[{"type":"BOS_UP","level":4605.0}]},
        }
    return {"trade_map":{"reference_price":ref},"timeframes":{"M5":c(ref,4),"M15":c(ref,8),"H1":c(ref,15),"H4":c(ref,30),"D1":c(ref,60)}}

PLAN={"valid":True,"quality":88,"primary_entry":{"low":4563.36,"high":4604.57,"mid":4583.965},"targets":[{"price":4632,"rr":1.7}],"invalidation":4556}
MACRO={"event_risk":{"level":"LOW"}}
MICRO={"spread_ok":True}
REGIME={"primary_side":"long"}
TRIGGER={"ready":True,"side":"long"}

def test_above_zone_waits_for_pullback():
    o=evaluate_execution_state(chart=_chart(4617.03),side="long",style="spot",plan=PLAN,trigger=TRIGGER,macro=MACRO,micro=MICRO,regime=REGIME,ai_confidence=55,blockers=[])
    assert o["state"]=="WAIT_PULLBACK_LONG"

def test_inside_zone_can_buy_now():
    o=evaluate_execution_state(chart=_chart(4590.0),side="long",style="spot",plan=PLAN,trigger=TRIGGER,macro=MACRO,micro=MICRO,regime=REGIME,ai_confidence=55,blockers=[])
    assert o["state"]=="BUY_NOW"

def test_breakout_retest_state():
    o=evaluate_execution_state(chart=_chart(4606.0),side="long",style="spot",plan=PLAN,trigger=TRIGGER,macro=MACRO,micro=MICRO,regime=REGIME,ai_confidence=55,blockers=[])
    assert o["state"]=="BREAKOUT_RETEST_LONG"
