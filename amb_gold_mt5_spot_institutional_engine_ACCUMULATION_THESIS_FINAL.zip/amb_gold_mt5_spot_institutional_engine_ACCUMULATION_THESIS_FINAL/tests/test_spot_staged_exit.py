from amb_chart.spot.engine import build_spot_decision_packet
from tests.test_spot_engine import _chart


def test_staged_exit_plan_preserves_100_percent_allocation():
    p = build_spot_decision_packet(_chart(price=100.0))
    pm = p["position_management_30_60d"]
    assert pm["valid"] is True
    weights = pm["allocation_policy"]["stage_weights_pct"]
    assert round(sum(weights.values()), 6) == 100.0
    assert [x["role"] for x in pm["stages"]][:3] == ["TP1", "TP2", "TP3"]


def test_adaptive_exit_policy_keeps_runner_exposure():
    p = build_spot_decision_packet(_chart(price=100.0))
    pm = p["position_management_30_60d"]
    weights = pm["allocation_policy"]["stage_weights_pct"]
    assert weights["TP1"] > 0.0
    assert weights["TP3"] >= weights["TP1"]
    assert weights["RUNNER"] > 0.0


def test_reachability_is_explicitly_not_empirical_probability():
    p = build_spot_decision_packet(_chart(price=100.0))
    for stage in p["position_management_30_60d"]["stages"]:
        r = stage["reachability"]
        assert 0.0 <= r["model_estimated_reachability_score_0_100"] <= 100.0
        assert r["semantics"] == "model_estimated_reachability_not_empirical_probability"


def test_management_state_detects_reached_objectives_without_new_targets():
    p = build_spot_decision_packet(_chart(price=100.0))
    pm = p["position_management_30_60d"]
    assert pm["philosophy"] == "manage_one_30_60_day_spot_thesis_with_staged_realization_not_more_targets"
    assert pm["management_state"]["state"] in {"PRE_ENTRY_WATCH", "ENTRY_ARMED"}
    assert pm["legacy_price_only_management_state"]["state"] in {"HOLD_AND_REVIEW", "TACTICAL_OBJECTIVE_REACHED", "SWING_OBJECTIVE_REACHED", "STRATEGIC_OBJECTIVE_REACHED", "RUNNER_OBJECTIVE_REACHED", "THESIS_INVALIDATED"}
