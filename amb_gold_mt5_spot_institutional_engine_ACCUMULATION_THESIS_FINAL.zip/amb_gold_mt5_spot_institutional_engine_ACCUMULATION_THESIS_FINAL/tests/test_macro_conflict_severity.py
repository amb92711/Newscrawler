from amb_chart.analysis.decision import _playbook

def test_internal_component_conflict_not_hard_when_final_bias_aligns():
    regime={'name':'BULLISH_CONTINUATION','execution_alignment':'aligned','phase':'continuation'}
    tech={'bias':'long'}
    macro={'gold_bias':'bullish','bias_conflict':True,'conflict_severity':'MEDIUM'}
    p=_playbook(regime,tech,macro)
    assert p['side']=='long'
    assert not p['macro_conflict']
    assert p['state'].startswith('READY')

def test_final_macro_opposition_is_hard_conflict():
    regime={'name':'BULLISH_CONTINUATION','execution_alignment':'aligned','phase':'continuation'}
    tech={'bias':'long'}
    macro={'gold_bias':'bearish','bias_conflict':False,'conflict_severity':'NONE'}
    p=_playbook(regime,tech,macro)
    assert p['macro_conflict']
    assert p['state']=='WAIT'
