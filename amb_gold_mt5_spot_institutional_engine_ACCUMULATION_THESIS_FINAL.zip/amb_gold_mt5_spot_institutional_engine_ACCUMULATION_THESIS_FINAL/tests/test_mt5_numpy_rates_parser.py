import numpy as np

from amb_chart.providers.mt5_live import MT5LiveProvider


def _provider_without_mt5_init():
    provider = object.__new__(MT5LiveProvider)
    provider.symbol = "XAUUSD"
    provider._clock_models = {
        "XAUUSD": {
            "bar_offset_seconds": 0,
            "bar_offset_source": "test",
            "tick_offset_seconds": 0,
            "tick_offset_source": "test",
        }
    }
    provider._normalize_bar_epoch = lambda x: int(x)
    provider._iso_from_epoch = lambda x: f"epoch:{int(x)}"
    return provider


def test_rows_from_structured_numpy_array_does_not_use_boolean_context():
    p = _provider_without_mt5_init()
    rates = np.array([
        (100, 1.0, 2.0, 0.5, 1.5, 10, 3, 7),
        (200, 1.5, 2.5, 1.0, 2.0, 20, 4, 8),
    ], dtype=[
        ("time", "i8"), ("open", "f8"), ("high", "f8"), ("low", "f8"),
        ("close", "f8"), ("tick_volume", "i8"), ("spread", "i8"),
        ("real_volume", "i8"),
    ])
    rows = p._rows_from_rates("M5", rates)
    assert len(rows) == 2
    assert rows[0]["raw_time_epoch"] == 100
    assert rows[0]["open"] == 1.0
    assert rows[0]["volume"] == 7.0
    assert rows[1]["spread"] == 4.0


def test_rows_from_empty_numpy_array_returns_empty():
    p = _provider_without_mt5_init()
    rates = np.array([], dtype=[("time", "i8")])
    assert p._rows_from_rates("M5", rates) == []


def test_rows_from_none_returns_empty():
    p = _provider_without_mt5_init()
    assert p._rows_from_rates("M5", None) == []
