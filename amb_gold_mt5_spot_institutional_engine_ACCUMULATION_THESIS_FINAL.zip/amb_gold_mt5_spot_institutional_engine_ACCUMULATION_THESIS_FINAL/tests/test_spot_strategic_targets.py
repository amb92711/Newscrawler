from amb_chart.spot.engine import build_spot_decision_packet
from tests.test_spot_engine import _chart


def test_strategic_tp3_has_one_month_horizon_and_runner():
    p = build_spot_decision_packet(_chart(price=100.0))
    strategic = p["strategic_target_engine"]
    assert strategic["valid"] is True
    tp3 = strategic["tp3"]
    cal = tp3["horizon"]["estimated_calendar_horizon"]
    assert cal["high_days"] >= 30
    assert strategic["one_month_outlook"]["minimum_analysis_horizon_days"] == 30
    assert strategic["runner"] is not None


def test_entry_and_thesis_invalidations_are_separate():
    p = build_spot_decision_packet(_chart(price=100.0))
    plan = p["execution_plan"]
    assert plan["entry_invalidation"] == plan["invalidation"]
    thesis = plan["thesis_invalidation"]
    assert thesis["available"] is True
    assert thesis["price"] < plan["entry_invalidation"]
    assert thesis["semantics"] == "thesis_invalidation_not_entry_stop"


def test_targets_are_not_behind_live_reference_for_pullback_plan():
    c = _chart(price=104.0)
    p = build_spot_decision_packet(c)
    targets = p["execution_plan"]["targets"]
    assert len(targets) == 3
    assert all(t["price"] > p["reference_price"] for t in targets)


def test_target_engine_is_structure_first_not_rr_generator():
    p = build_spot_decision_packet(_chart(price=100.0))
    strategic = p["strategic_target_engine"]
    assert strategic["target_generation_policy"] == "structure_first_rr_validation_only"
    assert strategic["tp1"]["evidence_quality"] != "fallback_volatility_projection"
    assert strategic["tp2"]["evidence_quality"] != "fallback_volatility_projection"
    assert strategic["tp3"]["evidence_quality"] != "fallback_volatility_projection"
