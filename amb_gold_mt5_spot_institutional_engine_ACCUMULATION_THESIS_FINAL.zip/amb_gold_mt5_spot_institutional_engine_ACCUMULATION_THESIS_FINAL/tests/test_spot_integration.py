from __future__ import annotations
from datetime import datetime, timedelta, timezone

from amb_chart.analysis.engine import analyze
from amb_chart.config import EngineConfig
from amb_chart.models import ProviderHealth


class FakeProvider:
    name = "fake_mt5"
    def __init__(self):
        self.now = datetime.now(timezone.utc)
    def _rows(self, tf: str, count: int):
        sec = {"M5":300,"M15":900,"H1":3600,"H4":14400,"D1":86400,"W1":604800,"MN1":2592000}[tf]
        rows=[]
        base=4000.0
        for i in range(count):
            t=self.now-timedelta(seconds=sec*(count-1-i))
            px=base+i*0.25
            rows.append({"time":t.isoformat(),"open":px-0.1,"high":px+0.8,"low":px-0.8,"close":px+0.2,"volume":100+i%10,"spread":10,"real_volume":0})
        return rows
    def fetch_multi_timeframe(self, timeframes, count):
        return {tf:self._rows(tf, min(count, 260)) for tf in timeframes}
    def market_microstructure(self):
        px=4000+259*0.25+0.2
        return {"time":self.now.isoformat(),"best_bid":px-0.1,"best_ask":px,"last":px,"spread":0.1,"point":0.01,"recent_tick_rate_per_minute":12}
    def health(self):
        return ProviderHealth(provider=self.name, ok=True, symbol="XAUUSD", message="ok", details={"terminal":{"connected":True}})


def test_analyze_accepts_spot_extended_timeframes():
    p=FakeProvider()
    cfg=EngineConfig(symbol="XAUUSD",count=260,timeframes={"M5":"M5","M15":"M15","H1":"H1","H4":"H4","D1":"D1","W1":"W1","MN1":"MN1"})
    ctx=analyze(p,cfg)
    assert "W1" in ctx.timeframes
    assert "MN1" in ctx.timeframes
    assert ctx.data_quality["market_state"]["status"] in {"OPEN","OPEN_SPREAD_EXTREME","REOPEN_COOLDOWN"}
