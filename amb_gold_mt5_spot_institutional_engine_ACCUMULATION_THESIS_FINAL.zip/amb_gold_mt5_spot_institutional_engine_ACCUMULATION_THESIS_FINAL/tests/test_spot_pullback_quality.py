from __future__ import annotations

from amb_chart.spot.engine import build_spot_decision_packet
from amb_chart.spot.pullback_quality import build_pullback_quality


def _ctx(close=100.0, rsi=58.0, z=0.8, volpct=55.0, trend="strong_bullish", structure="bullish_hh_hl"):
    return {
        "last_close": close,
        "trend": trend,
        "momentum": "bullish",
        "structure": structure,
        "rsi": rsi,
        "atr": 4.0,
        "adx": 32.0,
        "ema": {"20": 98.0, "50": 95.0, "200": 90.0},
        "advanced_structure": {
            "external": {"bias": "bullish"},
            "internal": {"bias": "bullish"},
            "mss": {"type": "bullish_internal_shift"},
        },
        "ichimoku": {"cloud_bias": 1, "tk_cross": 1, "kijun": 97.0},
        "advanced_indicators": {
            "adaptive_trend": {"aroon_osc": 45.0, "fisher": 0.8},
            "trend_quality": {"dmi_spread": 15.0, "efficiency_ratio_10": 0.45, "choppiness_14": 42.0},
            "volume_flow": {"cmf_20": 0.12},
            "institutional_price_action": {"institutional_impulse_score": 1.2, "price_zscore_50": z},
            "anchored_vwap": {"from_swing_low": 96.0, "from_swing_high": 99.0, "low_distance_atr": 0.45, "high_distance_atr": 0.15},
            "regime_metrics": {"volatility_percentile": volpct},
        },
        "price_action": {"last_candle": {"bullish_pinbar": True, "bullish_engulfing": False, "bearish_pinbar": False, "bearish_engulfing": False}},
        "swings": {"highs": [{"price": 110.0}], "lows": [{"price": 90.0}]},
        "support_resistance": {"supports": [96.0, 92.0], "resistances": [105.0, 110.0, 116.0]},
        "liquidity": {"pools": [{"type": "BSL", "level": 106.0}], "sweeps": [{"type": "sell_side_sweep_rejection", "swept_level": 97.0}]},
        "volume_profile": {"order_flow_proxy": {"pressure": "buy_pressure"}},
    }


def _chart(price=100.0):
    tfs = {tf: _ctx(price) for tf in ("M5", "M15", "H1", "H4", "D1", "W1", "MN1")}
    return {
        "symbol": "XAUUSD",
        "provider": "mt5_live_windows",
        "timeframes": tfs,
        "market_microstructure": {"best_ask": price, "spread": 0.1},
        "trade_map": {
            "reference_price": price,
            "buy_zones": [{"timeframe": "H4", "source": "bullish_order_block", "low": 96.0, "high": 101.0, "status": "fresh", "score": 82.0, "rank_score": 82.0}],
            "sell_zones": [],
        },
        "fusion_context": {
            "market_state": {"status": "OPEN", "execution_gate": "ALLOW_EXECUTION", "actionable": True, "data_state": "FRESH", "data_quality_score": 95},
            "news_macro_context": {"attached": True, "data": {
                "macro_context": {"final_gold_context_bias": "bullish", "gold_news_bias": "bullish", "gold_market_bias": "bullish", "event_risk": "LOW"},
                "market_regime": {"regime": "FED_USD_YIELD_DRIVEN", "confidence": 0.7},
                "event_window": {"risk_level": "LOW", "spot_blocks_trade": False, "execution_mode": "NORMAL", "upcoming_key_events": []},
                "bias_components": {"combined_bias": {"bias": "bullish", "conflict": False}},
            }},
        },
    }


def test_late_extended_can_resolve_into_buy_now():
    c = _chart(price=100.0)
    # Keep D1 statistically extended so the slow maturity engine remains late_extended.
    c["timeframes"]["D1"]["rsi"] = 80.0
    c["timeframes"]["D1"]["advanced_indicators"]["institutional_price_action"]["price_zscore_50"] = 2.6
    p = build_spot_decision_packet(c)
    assert p["trend_maturity"]["overextended"] is True
    assert p["pullback_quality"]["quality_score_0_100"] >= 72.0
    assert p["pullback_quality"]["entry_ready"] is True
    assert p["decision"]["state"] == "BUY_NOW"
    assert p["position_lifecycle"]["state"] == "ENTRY_ARMED"


def test_late_extended_above_zone_stays_wait_until_pullback_resolves():
    c = _chart(price=106.0)
    for tf in ("D1", "H4"):
        c["timeframes"][tf]["rsi"] = 81.0
        c["timeframes"][tf]["advanced_indicators"]["institutional_price_action"]["price_zscore_50"] = 2.8
        c["timeframes"][tf]["advanced_indicators"]["regime_metrics"]["volatility_percentile"] = 96.0
    p = build_spot_decision_packet(c)
    assert p["trend_maturity"]["overextended"] is True
    assert p["decision"]["action"] == "WAIT"
    assert p["decision"]["state"] == "WAIT_COOL_OFF_LONG"
    assert p["pullback_quality"]["entry_ready"] is False
    assert p["position_lifecycle"]["state"] == "PRE_ENTRY_WATCH"


def test_structure_break_hard_fails_pullback_engine():
    c = _chart(price=100.0)
    c["timeframes"]["H4"]["structure"] = "bearish_lh_ll"
    c["timeframes"]["H4"]["advanced_structure"]["external"]["bias"] = "bearish"
    p = build_spot_decision_packet(c)
    assert p["pullback_quality"]["hard_fail"] is True
    assert "D1_or_H4_external_structure_broken" in p["pullback_quality"]["hard_fail_reasons"]
    assert p["decision"]["action"] == "WAIT"


def test_prompt_exposes_pullback_quality_contract():
    from amb_chart.spot.writer import render_spot_prompt
    p = build_spot_decision_packet(_chart(price=100.0))
    prompt = render_spot_prompt(p)
    assert '"pullback_quality"' in prompt
    assert "late_extended is NOT an automatic blocker" in prompt
