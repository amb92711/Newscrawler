import numpy as np, pandas as pd
from amb_chart.analysis.indicators import enrich_indicators

def test_advanced_features_present_and_finite():
    n=260
    x=np.arange(n,dtype=float)
    close=4500+0.35*x+4*np.sin(x/8)
    df=pd.DataFrame({'time':pd.date_range('2026-01-01',periods=n,freq='5min',tz='UTC').astype(str),'open':close-0.3,'high':close+1.2,'low':close-1.0,'close':close,'volume':100+(x%20)*3})
    out=enrich_indicators(df)
    for col in ['kama_10_2_30','aroon_osc_25','fisher_10','avwap_from_swing_low','avwap_from_swing_high','institutional_impulse_score','volatility_regime_pct']:
        assert col in out.columns
        assert np.isfinite(float(out[col].dropna().iloc[-1]))
