from __future__ import annotations

from pathlib import Path

from amb_chart.spot.engine import build_spot_decision_packet
from amb_chart.spot.position_registry import SpotPositionRegistry
from amb_chart.spot.falling_knife import build_falling_knife_guard


def _ctx(close=100.0, trend="strong_bullish", structure="bullish_hh_hl", rsi=58.0, impulse=1.2, z=0.6, cmf=0.12, vol=55.0):
    return {
        "last_close": close,
        "trend": trend,
        "momentum": "bullish" if "bull" in trend else "bearish",
        "structure": structure,
        "rsi": rsi,
        "atr": 4.0,
        "adx": 32.0,
        "ema": {"20": 98.0, "50": 95.0, "200": 90.0},
        "advanced_structure": {
            "external": {"bias": "bullish" if "bull" in structure else "bearish"},
            "internal": {"bias": "bullish" if "bull" in structure else "bearish"},
            "mss": {"type": "bullish_internal_shift" if "bull" in structure else "bearish_internal_shift"},
        },
        "ichimoku": {"cloud_bias": 1 if "bull" in trend else -1, "tk_cross": 1 if "bull" in trend else -1, "kijun": 97.0},
        "advanced_indicators": {
            "adaptive_trend": {"aroon_osc": 45.0, "fisher": 0.8},
            "trend_quality": {"dmi_spread": 15.0 if "bull" in trend else -22.0, "efficiency_ratio_10": 0.55, "choppiness_14": 40.0},
            "volume_flow": {"cmf_20": cmf},
            "institutional_price_action": {"institutional_impulse_score": impulse, "price_zscore_50": z},
            "anchored_vwap": {"from_swing_low": 96.0, "from_swing_high": 99.0, "low_distance_atr": 0.45, "high_distance_atr": 0.15},
            "regime_metrics": {"volatility_percentile": vol},
        },
        "price_action": {"last_candle": {"bullish_pinbar": True, "bullish_engulfing": False, "bearish_pinbar": False, "bearish_engulfing": False}},
        "swings": {"highs": [{"price": 110.0}], "lows": [{"price": 90.0}]},
        "support_resistance": {"supports": [96.0, 92.0], "resistances": [105.0, 110.0, 116.0]},
        "liquidity": {"pools": [{"type": "BSL", "level": 106.0}], "sweeps": [{"type": "sell_side_sweep_rejection", "swept_level": 97.0}]},
        "volume_profile": {"order_flow_proxy": {"pressure": "buy_pressure"}},
    }


def _chart(price=100.0):
    tfs = {tf: _ctx(price) for tf in ("M5", "M15", "H1", "H4", "D1", "W1", "MN1")}
    for tf, tm in (("D1", "2026-08-23T21:00:00+00:00"), ("W1", "2026-08-22T21:00:00+00:00")):
        tfs[tf]["last_time"] = tm
    return {
        "symbol": "XAUUSD",
        "provider": "mt5_live_windows",
        "timeframes": tfs,
        "market_microstructure": {"best_ask": price, "spread": 0.1},
        "trade_map": {
            "reference_price": price,
            "buy_zones": [{"timeframe": "H4", "source": "bullish_order_block", "low": 96.0, "high": 101.0, "status": "fresh", "score": 82.0, "rank_score": 82.0}],
            "sell_zones": [],
        },
        "fusion_context": {
            "market_state": {"status": "OPEN", "execution_gate": "ALLOW_EXECUTION", "actionable": True, "data_state": "FRESH", "data_quality_score": 95},
            "news_macro_context": {"attached": True, "data": {
                "macro_context": {"final_gold_context_bias": "bullish", "gold_news_bias": "bullish", "gold_market_bias": "bullish", "event_risk": "LOW"},
                "market_regime": {"regime": "FED_USD_YIELD_DRIVEN", "confidence": 0.75},
                "event_window": {"risk_level": "LOW", "spot_blocks_trade": False, "execution_mode": "NORMAL", "upcoming_key_events": []},
                "bias_components": {"combined_bias": {"bias": "bullish", "conflict": False}},
            }},
        },
    }


def test_healthy_spot_uses_accumulation_not_all_in_semantics():
    p = build_spot_decision_packet(_chart(100.0))
    acc = p["accumulation_plan"]
    assert p["decision"]["action"] == "BUY"
    assert p["decision"]["state"] == "BUY_NOW"
    assert acc["permission"] == "ACCUMULATE"
    assert 0 < acc["recommended_new_allocation_pct_now"] <= 100
    assert acc["eligible_tranches_now"]
    assert p["spot_opportunity"]["accumulation_plan"]["engine"].startswith("AMB_SPOT_ADAPTIVE_ACCUMULATION")


def test_falling_knife_pauses_new_accumulation():
    c = _chart(100.0)
    for tf in ("D1", "H4"):
        c["timeframes"][tf] = _ctx(100.0, trend="strong_bearish", structure="bearish_lh_ll", rsi=34.0, impulse=-4.5, z=-2.8, cmf=-0.25, vol=97.0)
    guard = build_falling_knife_guard(chart=c, plan={"thesis_invalidation": {"price": 85.0}, "entry_invalidation": 92.0}, macro={"bias": "bullish", "confidence": 60, "spot_blocks_trade": False})
    assert guard["level"] in {"HIGH", "CRITICAL"}
    assert guard["block_new_accumulation"] is True
    assert guard["hard_fail"] is True


def test_thesis_health_is_slow_and_exposed_to_llm_packet():
    p = build_spot_decision_packet(_chart(100.0))
    th = p["thesis_health"]
    assert th["health_score_0_100"] >= 55
    assert th["state"] in {"HEALTHY", "STRONG", "WATCH"}
    assert th["semantics"] == "30_60d_thesis_health_score_not_empirical_win_probability"
    assert p["position_lifecycle"]["thesis_health_overlay"]["state"] == th["state"]


def test_partial_tranche_fill_creates_accumulating_lifecycle(tmp_path: Path):
    c = _chart(100.0)
    p = build_spot_decision_packet(c)
    reg = SpotPositionRegistry(tmp_path / "spot_position.json")
    eligible = p["accumulation_plan"]["eligible_tranches_now"]
    assert eligible
    reg.fill_tranche_from_packet(p, eligible[0])
    rec = reg.load()
    p2 = build_spot_decision_packet(c, position_record=rec)
    assert p2["position_lifecycle"]["state"] == "ACCUMULATING"
    assert 0 < p2["position_lifecycle"]["position_registry"]["accumulated_pct"] < 100
    assert p2["position_lifecycle"]["position_registry"]["actual_cost_basis"] > 0


def test_legacy_full_position_registration_remains_compatible(tmp_path: Path):
    c = _chart(100.0)
    p = build_spot_decision_packet(c)
    reg = SpotPositionRegistry(tmp_path / "spot_position.json")
    reg.open_from_packet(p)
    rec = reg.load()
    p2 = build_spot_decision_packet(c, position_record=rec)
    assert p2["position_lifecycle"]["state"] == "POSITION_OPEN"
    assert p2["position_lifecycle"]["position_registry"]["accumulated_pct"] == 100.0


def test_accumulation_does_not_change_structural_entry_prices():
    p = build_spot_decision_packet(_chart(100.0))
    structural = [round(float(x["price"]), 8) for x in p["execution_plan"]["entry_ladder"]]
    adaptive = [round(float(x["price"]), 8) for x in p["accumulation_plan"]["adaptive_ladder"]]
    assert structural == adaptive

def test_bearish_m15_micro_timing_does_not_hard_block_spot_accumulation():
    c = _chart(100.0)
    c["timeframes"]["M15"] = _ctx(100.0, trend="strong_bearish", structure="bearish_lh_ll", rsi=40.0, impulse=-1.5, z=-1.0, cmf=-0.08, vol=70.0)
    p = build_spot_decision_packet(c)
    assert p["thesis_health"]["state"] in {"HEALTHY", "STRONG", "WATCH"}
    assert p["falling_knife_guard"]["level"] in {"LOW", "MODERATE"}
    assert p["accumulation_plan"]["permission"] in {"ACCUMULATE", "ARMED"}
    assert p["decision"]["state"] != "WAIT_FALLING_KNIFE"


def test_late_extension_shifts_adaptive_weight_deeper():
    c = _chart(100.0)
    for tf in ("D1", "H4"):
        c["timeframes"][tf]["rsi"] = 79.0
        c["timeframes"][tf]["advanced_indicators"]["institutional_price_action"]["price_zscore_50"] = 2.3
    baseline = build_spot_decision_packet(_chart(100.0))["accumulation_plan"]["dynamic_allocation"]["weights_pct"]
    p = build_spot_decision_packet(c)
    w = p["accumulation_plan"]["dynamic_allocation"]["weights_pct"]
    assert round(sum(w), 2) == 100.0
    assert w[2] > baseline[2]


def test_two_partial_fills_update_actual_cost_basis(tmp_path: Path):
    reg = SpotPositionRegistry(tmp_path / "spot_position.json")
    p1 = build_spot_decision_packet(_chart(100.0))
    reg.fill_tranche_from_packet(p1, 1, fill_price=100.0)
    p2 = build_spot_decision_packet(_chart(98.0), position_record=reg.load())
    assert 2 in p2["accumulation_plan"]["eligible_tranches_now"]
    reg.fill_tranche_from_packet(p2, 2, fill_price=98.0)
    rec = reg.load()
    assert len(rec["accumulation_fills"]) == 2
    assert rec["accumulated_pct"] > 40.0
    assert 98.0 < rec["actual_cost_basis"] < 100.0
