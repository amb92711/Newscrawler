from amb_chart.spot.engine import _dealing_range, _higher_timeframe_consensus, _spot_execution_cost_model, _annotate_dual_risk
from amb_chart.spot.strategic_targets import _review_milestones


def test_corrected_long_ote_is_discount_retracement():
    chart = {
        "market_microstructure": {"best_ask": 50.0},
        "timeframes": {
            "D1": {"swings": {"highs": [{"price": 100.0}], "lows": [{"price": 0.0}, {"price": 10.0}]}},
        },
    }
    v = _dealing_range(chart)
    assert v["ote_model_version"] == "CORRECTED_DIRECTIONAL_RETRACEMENT_V2"
    assert v["ote_long_zone"]["high"] < v["equilibrium"]
    assert v["ote_short_zone"]["low"] > v["equilibrium"]


def test_htf_trend_structure_disagreement_is_penalized():
    ctx = {
        "trend": "strong_bullish",
        "structure": "bearish_lh_ll",
        "momentum": "neutral",
        "advanced_structure": {"external": {}, "internal": {}, "mss": {}},
        "ichimoku": {"cloud_bias": 1, "tk_cross": 0},
        "advanced_indicators": {},
        "rsi": 55,
    }
    chart = {"timeframes": {"W1": ctx}}
    h = _higher_timeframe_consensus(chart)
    d = h["details"]["W1"]
    assert d["trend_structure_disagreement"] is True
    assert d["raw_score"] < d["raw_score_pre_penalty"]


def test_spot_spread_relative_spike_can_be_acceptable():
    chart = {
        "market_microstructure": {"best_ask": 4632.0, "spread": 0.34},
        "fusion_context": {"market_state": {"spread_regime": {"state": "extreme", "live_spread": 0.34, "ratio_to_median": 3.09}}},
        "timeframes": {"H1": {"atr": 20.0}},
    }
    plan = {"primary_zone": {"low": 4605.0, "high": 4623.0}, "risk_distance": 14.0}
    c = _spot_execution_cost_model(chart, plan)
    assert c["relative_spread_spike_only"] is True
    assert c["acceptable_for_spot"] is True


def test_dual_risk_uses_thesis_denominator():
    strategic = {
        "tp1": {"price": 4890.0, "rr": 20.0},
        "tp2": {"price": 5120.0, "rr": 35.0},
        "tp3": {"price": 5420.0, "rr": 56.0},
        "runner": {"price": 5600.0, "rr": 68.0},
        "targets": [{"price": 4890.0, "rr": 20.0}, {"price": 5120.0, "rr": 35.0}, {"price": 5420.0, "rr": 56.0}],
        "all_objectives": [{"price": 4890.0, "rr": 20.0}, {"price": 5120.0, "rr": 35.0}, {"price": 5420.0, "rr": 56.0}, {"price": 5600.0, "rr": 68.0}],
        "one_month_outlook": {"primary_30_60d_objective": {"price": 5420.0}, "runner_45_90d_objective": {"price": 5600.0}},
    }
    out = _annotate_dual_risk(strategic, entry=4615.0, entry_stop=4600.0, thesis_stop={"price": 4567.0})
    assert out["tp1"]["thesis_rr"] < out["tp1"]["execution_rr"]
    assert out["dual_risk_model"]["thesis_risk_distance"] == 48.0


def test_milestones_are_checkpoints_not_targets():
    clusters = [
        {"price": 4650.0, "cluster_score": 100, "structural_evidence_count": 2, "evidence_count": 3, "sources": ["resistance"], "timeframes": ["D1"], "kinds": ["structure"]},
        {"price": 4720.0, "cluster_score": 95, "structural_evidence_count": 1, "evidence_count": 2, "sources": ["swing_high"], "timeframes": ["D1"], "kinds": ["swing"]},
        {"price": 4890.0, "cluster_score": 110, "structural_evidence_count": 3, "evidence_count": 5, "sources": ["resistance"], "timeframes": ["W1"], "kinds": ["structure"]},
    ]
    objectives = [{"price": 4890.0}, {"price": 5120.0}, {"price": 5420.0}, {"price": 5600.0}]
    m = _review_milestones(clusters, side="long", entry=4615.0, objectives=objectives, weekly_atr=225.0)
    assert m
    assert all(x["action"] == "REVIEW_THESIS_ONLY_NO_AUTOMATIC_EXIT" for x in m)
    assert all(x["price"] != 4890.0 for x in m)


def test_compact_prompt_omits_forensic_candidate_clusters():
    from amb_chart.spot.writer import render_spot_prompt, render_spot_prompt_full
    packet = {
        "contract": "X",
        "symbol": "XAUUSD",
        "spot_opportunity": {"targets": {}, "one_month_outlook": {}},
        "strategic_target_engine": {"candidate_clusters": [{"price": 1, "evidence": [1,2,3]}], "review_milestones": []},
        "position_lifecycle": {},
        "market_state": {},
    }
    compact = render_spot_prompt(packet)
    full = render_spot_prompt_full(packet)
    assert "candidate_clusters" not in compact
    assert "candidate_clusters" in full
