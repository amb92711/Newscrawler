from __future__ import annotations

from amb_chart.spot.engine import build_spot_decision_packet


def _ctx(close=100.0, trend="strong_bullish", structure="bullish_hh_hl", rsi=58.0):
    return {
        "last_close": close,
        "trend": trend,
        "momentum": "bullish" if "bull" in trend else "bearish",
        "structure": structure,
        "rsi": rsi,
        "atr": 4.0,
        "adx": 30.0,
        "ema": {"20": 98.0, "50": 95.0, "200": 90.0},
        "advanced_structure": {"external": {"bias": "bullish"}, "internal": {"bias": "bullish"}, "mss": {"type": "bullish_internal_shift"}},
        "ichimoku": {"cloud_bias": 1, "tk_cross": 1, "kijun": 97.0},
        "advanced_indicators": {
            "adaptive_trend": {"aroon_osc": 45.0, "fisher": 0.8},
            "trend_quality": {"dmi_spread": 15.0, "efficiency_ratio_10": 0.45, "choppiness_14": 42.0},
            "volume_flow": {"cmf_20": 0.12},
            "institutional_price_action": {"institutional_impulse_score": 1.2, "price_zscore_50": 0.8},
            "anchored_vwap": {"from_swing_low": 96.0, "from_swing_high": 99.0, "low_distance_atr": 1.0, "high_distance_atr": 0.25},
            "regime_metrics": {"volatility_percentile": 55.0},
        },
        "swings": {"highs": [{"price": 110.0}], "lows": [{"price": 90.0}]},
        "support_resistance": {"supports": [96.0, 92.0], "resistances": [105.0, 110.0, 116.0]},
        "liquidity": {"pools": [{"type": "BSL", "level": 106.0}]},
        "volume_profile": {"order_flow_proxy": {"pressure": "buy_pressure"}},
    }


def _chart(price=100.0, event_block=False):
    tfs = {tf: _ctx(price) for tf in ("M5", "M15", "H1", "H4", "D1", "W1", "MN1")}
    tfs["H1"]["zones"] = {"buy_zones": [], "sell_zones": []}
    return {
        "symbol": "XAUUSD",
        "provider": "mt5_live_windows",
        "timeframes": tfs,
        "market_microstructure": {"best_ask": price, "spread": 0.2},
        "trade_map": {
            "reference_price": price,
            "buy_zones": [
                {"timeframe": "H4", "source": "bullish_order_block", "low": 96.0, "high": 101.0, "status": "fresh", "score": 82.0, "rank_score": 82.0}
            ],
            "sell_zones": [],
        },
        "fusion_context": {
            "market_state": {"status": "OPEN", "execution_gate": "ALLOW_EXECUTION", "actionable": True, "data_state": "FRESH", "data_quality_score": 95},
            "news_macro_context": {"attached": True, "data": {
                "macro_context": {"final_gold_context_bias": "bullish", "gold_news_bias": "bullish", "gold_market_bias": "bullish", "event_risk": "LOW"},
                "market_regime": {"regime": "FED_USD_YIELD_DRIVEN", "confidence": 0.7},
                "event_window": {"risk_level": "HIGH" if event_block else "LOW", "spot_blocks_trade": event_block, "execution_mode": "BLOCK" if event_block else "NORMAL", "upcoming_key_events": []},
                "bias_components": {"combined_bias": {"bias": "bullish", "conflict": False}},
            }},
        },
    }


def test_spot_buy_now_inside_zone():
    p = build_spot_decision_packet(_chart(price=100.0))
    assert p["decision"]["state"] == "BUY_NOW"
    assert p["decision"]["action"] == "BUY"
    assert p["decision"]["actionable"] is True
    assert len(p["decision"]["targets"]) == 3
    assert p["decision"]["invalidation"] < p["decision"]["weighted_entry"]


def test_spot_wait_on_macro_event_gate():
    p = build_spot_decision_packet(_chart(price=100.0, event_block=True))
    assert p["decision"]["action"] == "WAIT"
    assert p["decision"]["state"] == "WAIT_EVENT_WINDOW"


def test_m5_not_directional():
    c = _chart(price=100.0)
    c["timeframes"]["M5"] = _ctx(100.0, trend="strong_bearish", structure="bearish_lh_ll", rsi=25.0)
    p = build_spot_decision_packet(c)
    assert p["higher_timeframe_consensus"]["bias"] == "bullish"
    assert "M5" in p["higher_timeframe_consensus"]["excluded_from_direction"]


def test_blocked_market_keeps_buy_watch_plan_visible():
    c = _chart(price=104.0)
    c["fusion_context"]["market_state"] = {
        "status": "OPEN_SPREAD_EXTREME",
        "execution_gate": "BLOCKED_SPREAD_REGIME",
        "actionable": False,
        "data_state": "FRESH",
        "data_quality_score": 75,
    }
    p = build_spot_decision_packet(c)
    assert p["decision"]["action"] == "WAIT"
    assert p["decision"]["actionable"] is False
    opp = p["spot_opportunity"]
    assert opp["buy_setup_available"] is True
    assert opp["execution_permission"] == "WATCH_ONLY"
    assert opp["best_buy_zone"] is not None
    assert len(opp["entry_ladder"]) == 3
    assert opp["invalidation"] is not None
    assert opp["targets"]["tp1"] is not None
    assert opp["targets"]["tp2"] is not None
    assert opp["targets"]["tp3"] is not None
    assert opp["actionable_now"] is False


def test_spot_opportunity_buy_now_semantics_match_decision():
    p = build_spot_decision_packet(_chart(price=100.0))
    opp = p["spot_opportunity"]
    assert opp["setup_state"] == "BUY_NOW"
    assert opp["actionable_now"] is True
    assert opp["execution_permission"] == "ACTIONABLE_NOW"
    assert opp["entry_status"]["relation"] == "INSIDE_ZONE"


def test_prompt_contract_preserves_watch_zone_when_waiting():
    from amb_chart.spot.writer import render_spot_prompt
    c = _chart(price=104.0)
    c["fusion_context"]["market_state"] = {
        "status": "OPEN_SPREAD_EXTREME",
        "execution_gate": "BLOCKED_SPREAD_REGIME",
        "actionable": False,
        "data_state": "FRESH",
        "data_quality_score": 75,
    }
    p = build_spot_decision_packet(c)
    prompt = render_spot_prompt(p)
    assert "ALWAYS report best_buy_zone" in prompt
    assert '"spot_opportunity"' in prompt
    assert '"buy_setup_available": true' in prompt.lower()
    assert '"execution_permission": "WATCH_ONLY"' in prompt
