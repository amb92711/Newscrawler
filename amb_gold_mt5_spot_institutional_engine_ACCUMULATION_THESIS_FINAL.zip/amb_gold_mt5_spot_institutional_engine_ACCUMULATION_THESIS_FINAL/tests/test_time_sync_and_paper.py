from datetime import datetime, timezone
from types import SimpleNamespace

from amb_chart.analysis.market_state import assess_market_state
from amb_chart.analysis.decision import _paper_test_candidate


def _ctx(t, atr=5.0):
    return SimpleNamespace(last_time=t, atr=atr)


def test_future_timestamp_is_blocked_not_clamped_fresh():
    now = datetime(2026, 8, 24, 6, 0, tzinfo=timezone.utc)
    raw = {tf: [] for tf in ['M5','M15','H1','H4','D1']}
    contexts = {
        'M5': _ctx('2026-08-24T09:00:00+00:00'),
        'M15': _ctx('2026-08-24T09:00:00+00:00'),
        'H1': _ctx('2026-08-24T05:00:00+00:00'),
        'H4': _ctx('2026-08-24T04:00:00+00:00'),
        'D1': _ctx('2026-08-24T00:00:00+00:00'),
    }
    micro = {'time': '2026-08-24T09:00:00+00:00', 'spread': 0.2, 'point': 0.01}
    state = assess_market_state(raw=raw, contexts=contexts, micro=micro, provider_health={}, now=now)
    assert state['status'] == 'TIME_SYNC_FAULT'
    assert state['execution_gate'] == 'BLOCKED_TIME_SYNC'
    assert state['actionable'] is False
    assert state['time_coherence']['future_clock_fault'] is True


def test_paper_candidate_ready_only_after_real_decision_approval():
    market = {'actionable': True, 'execution_gate': 'ALLOW_EXECUTION'}
    ready_payload = {
        'action': 'BUY', 'side': 'long', 'directional_side': 'long', 'setup_state': 'BUY_NOW',
        'primary_entry': {'low': 4600, 'high': 4602}, 'invalidation': 4595,
        'targets': [{'price': 4608}, {'price': 4612}, {'price': 4618}],
        'execution_plan': {'reference_price': 4601, 'rr': {'tp1': 1.2}, 'execution_grade': 'A'},
    }
    c = _paper_test_candidate(style='scalp', payload=ready_payload, market_state=market, trigger={'ready': True})
    assert c['status'] == 'PAPER_READY'
    assert c['action'] == 'BUY'
    assert c['entry']['low'] == 4600

    wait_payload = dict(ready_payload)
    wait_payload.update({'action': 'WAIT', 'side': None, 'primary_entry': None, 'invalidation': None, 'targets': [], 'execution_plan': None,
                         'watchlist_primary_entry': {'low': 4600, 'high': 4602}, 'watchlist_invalidation': 4595,
                         'watchlist_targets': [{'price': 4608}], 'watchlist_execution_plan': {'reference_price': 4601}})
    c2 = _paper_test_candidate(style='scalp', payload=wait_payload, market_state=market, trigger={'ready': False})
    assert c2['status'] == 'NOT_READY'
    assert c2['entry'] is None
    assert c2['action'] == 'WAIT'
