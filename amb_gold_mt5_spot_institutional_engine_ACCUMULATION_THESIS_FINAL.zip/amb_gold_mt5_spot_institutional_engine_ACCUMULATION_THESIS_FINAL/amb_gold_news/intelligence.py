from __future__ import annotations
import hashlib
import math
import re
from collections import defaultdict, Counter
from datetime import datetime, timezone
from difflib import SequenceMatcher
from .models import NewsItem
from .config import SOURCE_SOFT_CAPS

# v6 principle: maximize coverage of genuinely XAUUSD-moving news, then convert items into driver stories.
# MUST_READ = direct spot-gold / Fed-Dollar-Yields / US inflation-jobs / major geopolitical shock.
# MACRO_WATCH = meaningful macro risk that can move USD, rates, real yields, risk appetite, oil.
# BACKGROUND = gold industry, mining, central-bank reserve pages, physical-demand context.

NARRATIVE_RULES = [
    ("fed_policy", {"fed_rates", "yields"}),
    ("inflation_data", {"inflation"}),
    ("usd_pressure", {"usd_dxy"}),
    ("jobs_growth", {"jobs", "growth"}),
    ("geopolitical_risk", {"geopolitics", "risk"}),
    ("physical_gold_flows", {"flows_reserves", "gold"}),
    ("commodities_cross", {"oil_commodities"}),
    ("calendar_risk", {"calendar_critical", "calendar_high"}),
]

DIRECT_XAU_CATS = {"gold"}
CORE_MACRO_CATS = {"fed_rates", "inflation", "usd_dxy", "yields", "jobs", "calendar_critical"}
RISK_CATS = {"geopolitics", "risk", "oil_commodities"}
BACKGROUND_CATS = {"flows_reserves", "central_banks", "china_global", "growth"}

DIRECT_GOLD_TERMS = [
    "xau", "xau/usd", "xauusd", "spot gold", "gold price", "gold prices", "gold futures",
    "bullion", "precious metals", "gold and silver", "gold falls", "gold drops", "gold slumps",
    "gold rises", "gold rallies", "gold gains", "gold rebounds", "gold holds", "gold consolidates",
    "gold forecast", "gold outlook", "comex gold", "gld", "gold etf",
]

TRUE_MACRO_TERMS = [
    "fomc", "federal reserve", "fed", "powell", "fed chair", "fed official", "rate cut", "rate hike",
    "interest rate", "monetary policy", "hawkish", "dovish", "higher for longer", "core pce", "pce",
    "core cpi", "cpi", "inflation", "nonfarm", "nfp", "payrolls", "jobless claims", "unemployment",
    "treasury yield", "real yields", "bond yields", "dollar index", "dxy", "us dollar", "u.s. dollar",
]

MAJOR_RISK_TERMS = [
    "iran", "israel", "hormuz", "strait of hormuz", "red sea", "ukraine", "russia", "gaza",
    "middle east", "war", "missile", "ceasefire", "sanctions", "oil flows", "safe haven", "risk-off",
]

NOISE_TERMS = [
    "buy/sell gold & silver bullion coins", "stock crowded with sellers", "shares of", "environmental approval",
    "drilling", "intersects", "mineral resource", "gold project", "gold mine", "gold mining", "bullion coins", "bars", "stock", "shares", "tsx:", "nyse:",
    "agrees to sell", "announces extension", "credit facility", "managing director", "accounting probe",
    "receives final environmental", "oversold territory", "stock crowded", "company announces",
]

BEARISH_GOLD_RULES = [
    r"gold\s+(falls|drops|slumps|sinks|slides|tumbles|breaks below|under pressure|pressured|vulnerable)",
    r"stronger\s+(us\s+)?dollar", r"dollar\s+(rallies|jumps|surges|strengthens|hits)",
    r"yields?\s+(rise|rises|jump|jumps|climb|climbs)", r"real yields?\s+(rise|rises|climb|climbs)",
    r"hawkish\s+fed", r"fed\s+(hike|hikes|tightening)", r"tighter\s+fed", r"higher\s+rates",
    r"rate\s+hike\s+bets", r"weighs\s+on", r"weighs\s+on\s+haven", r"rates\s+repricing\s+weighs", r"debasement\s+trade\s+(is\s+)?(unraveling|killed)", r"pressure\s+on\s+(gold|bullion|metals)", r"inflation\s+(cools|eases|slows)",
]
BULLISH_GOLD_RULES = [
    r"gold\s+(rises|rallies|gains|rebounds|surges|jumps)",
    r"dollar\s+(falls|drops|slips|weakens)", r"weaker\s+(us\s+)?dollar",
    r"yields?\s+(fall|falls|drop|drops|ease|eases)", r"real yields?\s+(fall|falls|drop|drops|ease|eases)",
    r"dovish\s+fed", r"rate\s+cut", r"fed\s+cut", r"safe\s+haven", r"risk-off", r"flight\s+to\s+safety",
    r"central\s+bank\s+(buying|purchases)", r"geopolitical\s+(tension|risk|risks)",
]


def _tokens(text: str) -> list[str]:
    words = re.findall(r"[a-z0-9]{3,}", text.lower())
    stop = {"the","and","for","with","from","this","that","says","after","before","into","over","amid","more","news","market","markets","update"}
    return [w for w in words if w not in stop]


def text_of(item: NewsItem) -> str:
    return f"{item.title} {item.summary} {item.body}".lower()


def contains_any(text: str, terms: list[str]) -> bool:
    return any(t in text for t in terms)


def semantic_key(title: str) -> str:
    toks = _tokens(title)[:14]
    if not toks:
        return hashlib.sha1(title.encode()).hexdigest()[:12]
    return hashlib.sha1(" ".join(sorted(set(toks))).encode()).hexdigest()[:12]


def similar(a: str, b: str) -> float:
    return SequenceMatcher(None, a.lower(), b.lower()).ratio()


def parse_dt(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except Exception:
        return None


def time_decay(published_utc: str | None, item_type: str) -> float:
    dt = parse_dt(published_utc)
    if not dt:
        return 0.82
    hours = max(0.0, (datetime.now(timezone.utc) - dt).total_seconds() / 3600.0)
    half_life = 48.0 if item_type == "event" else 24.0
    return max(0.15, math.exp(-math.log(2) * hours / half_life))


def event_state(item: NewsItem) -> str:
    if item.item_type != "event":
        return "na"
    dt = parse_dt(item.published_utc)
    actual = str(item.summary or "").lower().split("actual:")[-1].strip() if "actual:" in str(item.summary).lower() else ""
    if dt and dt > datetime.now(timezone.utc):
        return "upcoming"
    if "actual:" in str(item.summary).lower() and not actual:
        return "pending"
    return "final"


def detect_narrative(item: NewsItem) -> str:
    cats = set(item.categories)
    txt = text_of(item)
    if item.item_type == "event":
        return "calendar_risk"
    if "gold" in cats and contains_any(txt, DIRECT_GOLD_TERMS):
        if {"fed_rates", "usd_dxy", "yields", "inflation"} & cats:
            return "fed_policy" if "fed_rates" in cats or "yields" in cats else "inflation_data"
        return "spot_gold"
    for name, need in NARRATIVE_RULES:
        if cats & need:
            return name
    return "other"


def conservative_direction(item: NewsItem) -> str:
    """Only return bullish/bearish when the wording is explicit. Otherwise unknown/neutral."""
    txt = text_of(item)
    bearish = sum(1 for p in BEARISH_GOLD_RULES if re.search(p, txt))
    bullish = sum(1 for p in BULLISH_GOLD_RULES if re.search(p, txt))
    # If direct gold text says pressure/weighs/hawkish dollar/yields, bearish should win.
    if bullish and bearish:
        # Do not let incidental words such as "safe haven" flip an explicitly negative gold headline.
        if re.search(r"(gold|silver|metals).{0,80}(falls|drops|slumps|sinks|pressured|vulnerable|under pressure|weighs)", txt) or re.search(r"(stronger dollar|higher rates|rising yields|rate hike|hawkish fed)", txt):
            return "bearish"
        if re.search(r"(gold|silver|metals).{0,80}(rises|rebounds|rallies|surges|gains)", txt) or re.search(r"(weaker dollar|lower yields|rate cut|dovish fed|safe-haven bid)", txt):
            return "bullish"
        return "mixed"
    if bearish:
        return "bearish"
    if bullish:
        return "bullish"
    # Events generally should not be guessed before actual data.
    if item.item_type == "event":
        return "unknown"
    return "unknown"


def event_is_xau_relevant(item: NewsItem) -> tuple[str, list[str]]:
    txt = text_of(item)
    title = item.title.upper()
    reasons: list[str] = []
    is_usd = "USD" in title or "US " in item.title or "United States" in item.title
    # Very important for gold even if not USD: Fed speeches, PCE/CPI, NFP-like, major central bank decisions.
    critical_terms = ["core pce", "pce", "cpi", "core cpi", "fomc", "fed ", "powell", "rate decision", "non farm", "nonfarm", "payrolls", "nfp", "jobless claims", "unemployment claims"]
    high_terms = ["gdp", "retail sales", "ism", "pmi", "consumer confidence", "durable goods", "ppi", "treasury", "bond auction"]
    if is_usd and any(t in txt for t in critical_terms):
        reasons += ["usd_high_impact_calendar", "direct_xauusd_macro"]
        return "MUST_READ", reasons
    if is_usd and any(t in txt for t in high_terms):
        reasons += ["usd_macro_calendar"]
        return "MACRO_WATCH", reasons
    if any(t in txt for t in ["fomc", "powell", "federal reserve", "fed chair"]):
        reasons += ["fed_event"]
        return "MUST_READ", reasons
    if "gold reserves" in txt or "central bank" in txt and "gold" in txt:
        reasons += ["gold_reserves_context"]
        return "BACKGROUND", reasons
    if any(c in title for c in ["EUR", "GBP", "JPY", "CAD", "AUD", "CNY", "CHF"]) and any(t in txt for t in ["rate decision", "central bank", "ecb", "boj", "boe", "boc", "rba", "pboc"]):
        reasons += ["major_central_bank_calendar"]
        return "MACRO_WATCH", reasons
    if any(c in title for c in ["EUR", "GBP", "JPY", "CAD", "AUD", "CNY", "CHF"]) and any(t in txt for t in critical_terms + high_terms):
        reasons += ["major_currency_background_calendar"]
        return "BACKGROUND", reasons
    return "BACKGROUND", ["non_core_calendar"]


def route_xauusd_relevance(item: NewsItem) -> None:
    cats = set(item.categories)
    txt = text_of(item)
    reasons: list[str] = []

    company_or_mining_noise = contains_any(txt, NOISE_TERMS)
    # Company/mining items are useful as context, but should not displace macro/gold drivers.
    if company_or_mining_noise and not ({"fed_rates", "usd_dxy", "yields", "inflation", "geopolitics", "risk"} & cats):
        item.relevance_bucket = "BACKGROUND"
        item.xauusd_relevance = "background"
        item.actionability = "background"
        item.rank_reasons = ["company_or_mining_context"]
        return

    if item.item_type == "event":
        bucket, reasons = event_is_xau_relevant(item)
        item.relevance_bucket = bucket
        item.actionability = bucket.lower()
        item.xauusd_relevance = "direct" if bucket == "MUST_READ" else ("macro" if bucket == "MACRO_WATCH" else "background")
        item.rank_reasons = reasons
        return

    direct_gold = "gold" in cats and contains_any(txt, DIRECT_GOLD_TERMS)
    macro_core = bool(cats & CORE_MACRO_CATS) or contains_any(txt, TRUE_MACRO_TERMS)
    major_risk = contains_any(txt, MAJOR_RISK_TERMS) or bool(cats & {"geopolitics", "risk"})
    gold_price_action = direct_gold and any(t in txt for t in ["gold falls", "gold drops", "gold slumps", "gold sinks", "gold rises", "gold rallies", "gold rebounds", "gold gains", "gold breaks", "gold vulnerable", "gold pressured", "gold forecast", "gold outlook", "xau/usd", "xauusd"])
    explicit_gold_macro = direct_gold and (macro_core or major_risk or gold_price_action or {"oil_commodities", "flows_reserves"} & cats)

    if explicit_gold_macro:
        if direct_gold: reasons.append("direct_gold")
        if macro_core: reasons.append("gold_macro_driver")
        if major_risk: reasons.append("geopolitical_or_safe_haven_driver")
        item.relevance_bucket = "MUST_READ"
        item.actionability = "must_read"
        item.xauusd_relevance = "direct"
    elif macro_core and ({"fed_rates", "usd_dxy", "yields", "inflation", "jobs"} & cats):
        reasons.append("core_macro_affects_gold")
        item.relevance_bucket = "MACRO_WATCH"
        item.actionability = "macro_watch"
        item.xauusd_relevance = "macro"
    elif major_risk and any(t in txt for t in ["iran", "israel", "hormuz", "red sea", "ukraine", "russia", "middle east", "safe haven", "risk-off"]):
        reasons.append("risk_premium_watch")
        item.relevance_bucket = "MACRO_WATCH"
        item.actionability = "macro_watch"
        item.xauusd_relevance = "macro"
    elif "gold" in cats or cats & BACKGROUND_CATS:
        reasons.append("gold_background_context")
        item.relevance_bucket = "BACKGROUND"
        item.actionability = "background"
        item.xauusd_relevance = "background"
    else:
        item.relevance_bucket = "DISCARD"
        item.actionability = "discard"
        item.xauusd_relevance = "discard"
        reasons.append("not_xauusd_actionable")

    item.rank_reasons = reasons


def score_item(item: NewsItem) -> None:
    # Score remains only for sorting inside each bucket; it is no longer the decision criterion.
    cats = set(item.categories)
    bucket_base = {"MUST_READ": 90, "MACRO_WATCH": 68, "BACKGROUND": 38, "DISCARD": 0}.get(item.relevance_bucket, 30)
    source_bonus = item.source_quality * 8.0
    freshness = item.time_decay_score * 6.0
    direct_bonus = 4.0 if item.source_mode in {"direct", "api"} else -3.0
    cluster_bonus = min(5.0, item.cross_source_confidence * 6.0)
    category_bonus = 0.0
    if "gold" in cats: category_bonus += 4
    if {"fed_rates", "usd_dxy", "yields", "inflation"} & cats: category_bonus += 4
    if item.item_type == "event" and item.event_state == "upcoming": category_bonus += 3
    if item.gold_direction in {"bullish", "bearish", "mixed"}: category_bonus += 2
    item.market_impact_score = round(min(100.0, bucket_base + category_bonus), 2)
    item.gold_impact_score = round(max(0.0, min(100.0, bucket_base + source_bonus + freshness + direct_bonus + cluster_bonus + category_bonus)), 2)

    if item.relevance_bucket == "MUST_READ":
        item.impact_label = "MUST_READ"; item.impact = 5
    elif item.relevance_bucket == "MACRO_WATCH":
        item.impact_label = "MACRO_WATCH"; item.impact = max(item.impact, 4)
    elif item.relevance_bucket == "BACKGROUND":
        item.impact_label = "BACKGROUND"; item.impact = max(1, min(item.impact, 3))
    else:
        item.impact_label = "DISCARD"; item.impact = 0


def enrich_items(items: list[NewsItem]) -> list[NewsItem]:
    for it in items:
        it.time_decay_score = round(time_decay(it.published_utc, it.item_type), 3)
        it.event_state = event_state(it)
        it.narrative = detect_narrative(it)
        it.semantic_cluster_id = semantic_key(it.title)
        it.gold_direction = conservative_direction(it)
        route_xauusd_relevance(it)

    clusters: dict[str, list[NewsItem]] = defaultdict(list)
    for it in items:
        if it.relevance_bucket == "DISCARD":
            continue
        clusters[f"{it.narrative}:{it.semantic_cluster_id}"].append(it)
    keys = list(clusters.keys())
    for i, k1 in enumerate(keys):
        if k1 not in clusters or not clusters[k1]:
            continue
        rep1 = clusters[k1][0].title
        for k2 in keys[i+1:]:
            if k2 not in clusters or not clusters[k2]:
                continue
            if k1.split(':',1)[0] != k2.split(':',1)[0]:
                continue
            if similar(rep1, clusters[k2][0].title) > 0.84:
                clusters[k1].extend(clusters.pop(k2))

    for cid, arr in clusters.items():
        sources = {x.source for x in arr}
        conf = min(1.0, 0.22 + 0.18 * len(sources) + 0.05 * len(arr))
        for x in arr:
            x.semantic_cluster_id = hashlib.sha1(cid.encode()).hexdigest()[:12]
            x.source_cluster_size = len(arr)
            x.cross_source_confidence = round(conf, 3)

    for it in items:
        score_item(it)
    return items


def apply_source_caps(items: list[NewsItem]) -> list[NewsItem]:
    # Coverage priority: never cap MUST_READ or MACRO_WATCH. Cap only background-heavy feeds.
    buckets: dict[str, list[NewsItem]] = defaultdict(list)
    for it in items:
        if it.relevance_bucket == "DISCARD":
            continue
        buckets[it.source].append(it)
    kept: list[NewsItem] = []
    bucket_order = {"MUST_READ": 0, "MACRO_WATCH": 1, "BACKGROUND": 2}
    for src, arr in buckets.items():
        arr.sort(key=lambda x: (bucket_order.get(x.relevance_bucket, 9), -x.gold_impact_score, x.item_type != "event", x.title.lower()))
        cap = SOURCE_SOFT_CAPS.get(src)
        if cap and len(arr) > cap:
            core = [x for x in arr if x.relevance_bucket in {"MUST_READ", "MACRO_WATCH"}]
            bg = [x for x in arr if x.relevance_bucket == "BACKGROUND"]
            selected = core + bg[:max(0, cap - len(core))]
            kept.extend(selected)
        else:
            kept.extend(arr)
    kept.sort(key=lambda x: (bucket_order.get(x.relevance_bucket, 9), -x.gold_impact_score, -x.source_quality, x.source, x.title.lower()))
    return kept


def build_macro_snapshot(items: list[NewsItem]) -> dict:
    routed = [it for it in items if it.relevance_bucket != "DISCARD"]
    narr = Counter(it.narrative for it in routed)
    cats = Counter(c for it in routed for c in it.categories)
    buckets = Counter(it.relevance_bucket for it in routed)
    dirs = Counter(it.gold_direction for it in routed if it.gold_direction not in {"unknown", "neutral"})
    bullish = sum(1 for it in routed if it.gold_direction == "bullish" and it.relevance_bucket in {"MUST_READ", "MACRO_WATCH"})
    bearish = sum(1 for it in routed if it.gold_direction == "bearish" and it.relevance_bucket in {"MUST_READ", "MACRO_WATCH"})
    if bullish > bearish * 1.35 and bullish >= 3:
        bias = "bullish"
    elif bearish > bullish * 1.35 and bearish >= 3:
        bias = "bearish"
    elif bullish or bearish:
        bias = "mixed"
    else:
        bias = "unknown"
    return {
        "total_items": len(routed),
        "must_read_count": buckets.get("MUST_READ", 0),
        "macro_watch_count": buckets.get("MACRO_WATCH", 0),
        "background_count": buckets.get("BACKGROUND", 0),
        "narratives": dict(narr.most_common(10)),
        "categories": dict(cats.most_common(14)),
        "direction_counts": dict(dirs),
        "bullish_count": bullish,
        "bearish_count": bearish,
        "macro_gold_bias": bias,
    }
