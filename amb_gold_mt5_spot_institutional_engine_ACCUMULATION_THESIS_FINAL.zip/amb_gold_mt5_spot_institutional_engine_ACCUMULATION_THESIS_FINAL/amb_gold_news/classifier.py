from __future__ import annotations
import re
from dataclasses import dataclass
from typing import Iterable

@dataclass
class Classification:
    is_relevant: bool
    impact: int
    impact_label: str
    categories: list[str]
    matched_keywords: list[str]
    gold_direction: str

def norm(*parts: str | None) -> str:
    return " ".join(str(p or "") for p in parts).lower()

def has_phrase(text: str, phrase: str) -> bool:
    p = re.escape(phrase.lower()).replace(r"\ ", r"\s+")
    return bool(re.search(rf"(?<![a-z0-9]){p}(?![a-z0-9])", text))

BLOCK_PATTERNS = [
    r"gold medal", r"gold-medal", r"olympic", r"golden globe", r"golden state",
    r"gold cup", r"football", r"basketball", r"nba", r"nfl", r"soccer", r"award show",
]

GROUPS: dict[str, tuple[int, list[str]]] = {
    "gold": (5, ["gold", "xau", "xauusd", "bullion", "precious metal", "precious metals", "gold futures", "comex", "gld", "gold etf", "gold price", "spot gold"]),
    "fed_rates": (5, ["federal reserve", "fomc", "jerome powell", "fed chair", "fed rate", "fed rates", "fed cuts", "fed hike", "fed official", "interest rate", "rate cut", "rate cuts", "rate hike", "rate decision", "monetary policy", "higher for longer", "terminal rate"]),
    "inflation": (5, ["inflation", "core inflation", "cpi", "core cpi", "ppi", "pce", "core pce", "consumer price index", "producer price index", "price pressures", "disinflation"]),
    "usd_dxy": (5, ["dxy", "dollar index", "u.s. dollar", "us dollar", "greenback", "dollar weakens", "dollar strengthens", "dollar rises", "dollar falls"]),
    "yields": (5, ["treasury yield", "bond yield", "yields", "10-year treasury", "10 year treasury", "2-year treasury", "2 year treasury", "real yields", "tips yield"]),
    "jobs": (4, ["nonfarm", "non-farm", "payrolls", "nfp", "jobs report", "unemployment", "jobless claims", "employment change", "labor market"]),
    "growth": (4, ["gdp", "retail sales", "consumer confidence", "ism", "pmi", "manufacturing", "services", "housing", "recession", "soft landing", "hard landing"]),
    "geopolitics": (5, ["war", "conflict", "attack", "missile", "strike", "iran", "israel", "gaza", "middle east", "ukraine", "russia", "red sea", "strait of hormuz", "sanctions", "ceasefire"]),
    "risk": (4, ["risk-off", "risk off", "safe haven", "flight to safety", "volatility", "vix", "stocks slump", "selloff", "market turmoil", "haven demand"]),
    "central_banks": (4, ["central bank", "central banks", "ecb", "boe", "boj", "pboc", "reserve bank", "gold reserves"]),
    "china_global": (3, ["china", "yuan", "stimulus", "imports", "exports", "eurozone", "global economy"]),
    "oil_commodities": (3, ["oil", "crude", "commodity", "commodities", "silver", "copper", "metals"]),
    "flows_reserves": (4, ["etf flows", "gold etf", "central bank buying", "central bank purchases", "gold reserves", "physical demand", "jewelry demand"]),
}

EVENT_CRITICAL = ["fomc", "rate decision", "powell", "cpi", "core cpi", "pce", "core pce", "nonfarm", "nfp", "payrolls", "fed minutes", "fomc minutes"]
EVENT_HIGH = ["ppi", "jobless", "unemployment", "gdp", "retail sales", "ism", "pmi", "consumer confidence", "durable goods"]
MAJOR = {"USD", "EUR", "GBP", "JPY", "CAD", "AUD", "NZD", "CHF", "CNY"}

BULLISH_PATTERNS = [
    "dollar weakens", "dollar falls", "dollar slips", "greenback weakens", "yields fall", "yields drop", "real yields fall",
    "rate cut", "rate cuts", "dovish", "safe haven", "risk-off", "risk off", "flight to safety", "inflation rises", "hot inflation",
    "geopolitical tensions", "war", "conflict", "central bank buying", "gold rises", "gold rallies", "gold gains", "bullion rises", "debasement",
]
BEARISH_PATTERNS = [
    "dollar strengthens", "dollar rises", "greenback rises", "greenback strengthens", "yields rise", "yields climb", "real yields rise",
    "rate hike", "hawkish", "higher for longer", "gold falls", "gold drops", "gold slips", "bullion falls", "risk appetite", "stocks rally", "inflation cools", "cooling inflation",
]

def impact_label(score: int) -> str:
    if score >= 5: return "CRITICAL"
    if score == 4: return "HIGH"
    if score == 3: return "MEDIUM"
    if score == 2: return "LOW"
    return "VERY_LOW"

def classify_article_for_gold(title: str, summary: str = "", body: str = "", tags: Iterable[str] | None = None, item_type: str = "news") -> Classification:
    text = norm(title, summary, body, " ".join(tags or []))
    for pat in BLOCK_PATTERNS:
        if re.search(pat, text):
            return Classification(False, 0, "REJECTED", [], [], "neutral")

    cats: set[str] = set(); matched: set[str] = set(); impact = 0
    for cat, (weight, kws) in GROUPS.items():
        found = [kw for kw in kws if has_phrase(text, kw)]
        if found:
            cats.add(cat); matched.update(found); impact = max(impact, weight)

    # Avoid false Fed matches such as "federal judge" or "federal prosecutors".
    if "fed_rates" in cats and not any(has_phrase(text, kw) for kw in GROUPS["fed_rates"][1]):
        cats.discard("fed_rates")

    if item_type == "event":
        upper_words = set(re.findall(r"\b[A-Z]{3}\b", f"{title} {summary}"))
        is_major_currency = bool(upper_words & MAJOR)
        if is_major_currency:
            cats.add("major_currency")
        if any(has_phrase(text, k) for k in EVENT_CRITICAL):
            cats.add("calendar_critical"); impact = max(impact, 5 if "USD" in upper_words or "fed" in text else 4)
        elif any(has_phrase(text, k) for k in EVENT_HIGH):
            cats.add("calendar_high"); impact = max(impact, 4 if "USD" in upper_words else 3)
        if not is_major_currency and not ({"calendar_critical", "fed_rates", "gold", "inflation"} & cats):
            return Classification(False, 0, "REJECTED", [], [], "neutral")

    if not cats:
        return Classification(False, 0, "REJECTED", [], [], "neutral")

    if item_type != "event" and "gold" not in cats:
        strong = {"fed_rates", "inflation", "usd_dxy", "yields", "jobs", "geopolitics", "risk", "flows_reserves"}
        if not (cats & strong):
            return Classification(False, 0, "REJECTED", [], [], "neutral")
        impact = max(impact, 3)

    bull = sum(1 for p in BULLISH_PATTERNS if has_phrase(text, p))
    bear = sum(1 for p in BEARISH_PATTERNS if has_phrase(text, p))
    if bull > bear: direction = "bullish"
    elif bear > bull: direction = "bearish"
    elif bull and bear: direction = "mixed"
    else: direction = "neutral"

    impact = max(1, min(5, impact))
    return Classification(True, impact, impact_label(impact), sorted(cats), sorted(matched), direction)
