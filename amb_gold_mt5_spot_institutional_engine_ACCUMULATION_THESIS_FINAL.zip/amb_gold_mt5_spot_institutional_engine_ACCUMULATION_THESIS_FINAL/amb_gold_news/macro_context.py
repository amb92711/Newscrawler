from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
from typing import Any

from .models import NewsItem
from .event_risk import evaluate_event_risk

# V8.5 is the freeze layer between News Intelligence and Chart Intelligence.
# It converts noisy news/narrative output into a compact, stable Macro Context
# schema that a future chart engine can consume without needing to understand
# hundreds of headlines.

BIAS_VALUES = {"bullish", "bearish", "mixed", "neutral", "unknown"}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _instrument(ctx: dict[str, Any], key: str) -> dict[str, Any]:
    return ((ctx.get("instruments") or {}).get(key) or {})


def _dir(ctx: dict[str, Any], key: str) -> str:
    return _instrument(ctx, key).get("direction", "unknown")


def _effect_to_score(effect: str) -> int:
    effect = (effect or "unknown").lower()
    if effect == "bullish":
        return 1
    if effect == "bearish":
        return -1
    return 0


def _market_gold_bias(market_ctx: dict[str, Any]) -> dict[str, Any]:
    dxy = _dir(market_ctx, "dxy")
    us10y = _dir(market_ctx, "us10y")
    us13w = _dir(market_ctx, "us13w")
    gold = _dir(market_ctx, "gold_futures")
    silver = _dir(market_ctx, "silver_futures")
    oil = _dir(market_ctx, "oil_wti")
    vix = _dir(market_ctx, "vix")

    score = 0
    reasons: list[str] = []

    if dxy == "higher":
        score -= 2; reasons.append("DXY higher pressures gold")
    elif dxy == "lower":
        score += 2; reasons.append("DXY lower supports gold")

    if us10y == "higher":
        score -= 2; reasons.append("US10Y higher pressures non-yielding gold")
    elif us10y == "lower":
        score += 2; reasons.append("US10Y lower supports gold")

    if us13w == "higher":
        score -= 1; reasons.append("short-rate proxy higher keeps Fed pressure on gold")
    elif us13w == "lower":
        score += 1; reasons.append("short-rate proxy lower eases Fed pressure")

    if gold == "higher":
        score += 1; reasons.append("gold futures are confirming upside")
    elif gold == "lower":
        score -= 1; reasons.append("gold futures are confirming downside")

    if silver == "higher":
        score += 1; reasons.append("silver confirms precious-metals bid")
    elif silver == "lower":
        score -= 1; reasons.append("silver weakens precious-metals confirmation")

    if vix == "higher":
        score += 1; reasons.append("VIX higher supports safe-haven demand")
    elif vix == "lower":
        score -= 1; reasons.append("VIX lower reduces safe-haven demand")

    if oil == "higher":
        reasons.append("oil higher may support inflation/geopolitical premium")
    elif oil == "lower":
        reasons.append("oil lower reduces inflation/geopolitical premium")

    if score >= 3:
        bias = "bullish"
    elif score <= -3:
        bias = "bearish"
    elif -2 <= score <= 2:
        bias = "mixed"
    else:
        bias = "neutral"

    return {"bias": bias, "score": score, "reasons": reasons[:8]}


def _news_driver_bias(packet: dict[str, Any]) -> dict[str, Any]:
    stories = packet.get("driver_stories") or []
    score = 0
    weights: dict[str, int] = {}
    reasons: list[str] = []
    for st in stories:
        key = st.get("driver_key", "unknown")
        effect = (st.get("net_effect_on_xauusd") or "unknown").lower()
        strength = int(st.get("story_strength") or st.get("must_read_count", 0) * 3 + st.get("macro_watch_count", 0) * 2)
        w = max(1, min(5, strength // 4 if strength else 1))
        weights[key] = w
        score += _effect_to_score(effect) * w
        if effect in {"bullish", "bearish"}:
            reasons.append(f"{st.get('title')}: {effect} (weight {w})")
        elif effect == "mixed":
            reasons.append(f"{st.get('title')}: mixed")

    if score >= 4:
        bias = "bullish"
    elif score <= -4:
        bias = "bearish"
    elif score == 0:
        bias = "neutral"
    else:
        bias = "mixed"
    return {"bias": bias, "score": score, "weights": weights, "reasons": reasons[:10]}


def _combine_bias(news: dict[str, Any], market: dict[str, Any]) -> dict[str, Any]:
    ns = int(news.get("score") or 0)
    ms = int(market.get("score") or 0)
    combined = ns + ms
    if combined >= 5:
        bias = "bullish"
    elif combined <= -5:
        bias = "bearish"
    elif abs(combined) <= 2:
        bias = "mixed"
    else:
        bias = "neutral"
    conflict = news.get("bias") in {"bullish", "bearish"} and market.get("bias") in {"bullish", "bearish"} and news.get("bias") != market.get("bias")
    return {
        "bias": bias,
        "combined_score": combined,
        "news_bias": news.get("bias"),
        "market_bias": market.get("bias"),
        "conflict": bool(conflict),
        "interpretation": "news and market data conflict; chart confirmation is mandatory" if conflict else "news and market context are not in major conflict",
    }


def _event_window(packet: dict[str, Any], items: list[NewsItem]) -> dict[str, Any]:
    cal = packet.get("calendar_digest") or {}
    upcoming = cal.get("upcoming_high_risk") or []
    pending = cal.get("pending_missing_actual") or []
    recent_final = cal.get("recent_final") or []

    risk = evaluate_event_risk(upcoming, pending)
    level = risk["risk_level"]
    trading_note = {
        "HIGH": "high-proximity/high-severity macro event risk; wait for release/reaction normalization",
        "MEDIUM": "macro event risk is moderate; require stronger execution confirmation and avoid chasing",
        "LOW": "no execution-blocking macro event detected in the active window",
    }[level]

    # Preserve legacy keys while adding the richer, time-aware model.
    timed = risk.get("scored_events") or []
    key_titles = {x.get('title') for x in timed[:8]}
    upcoming_key = [ev for ev in upcoming if ev.get('title') in key_titles]
    return {
        "risk_level": level,
        "risk_score": risk.get("risk_score"),
        "blocks_trade": risk.get("blocks_trade"),
        "scalp_blocks_trade": risk.get("scalp_blocks_trade"),
        "spot_blocks_trade": risk.get("spot_blocks_trade"),
        "execution_mode": risk.get("execution_mode"),
        "trading_note": trading_note,
        "upcoming_key_events": upcoming_key[:8],
        "pending_events": pending[:6],
        "recent_final_events": recent_final[:6],
        "nearest_timed_event": risk.get("nearest_timed_event"),
        "next_blocking_event": risk.get("next_blocking_event"),
        "scored_events": timed[:12],
        "untimed_context_events": risk.get("untimed_context_events", [])[:12],
        "event_risk_model": risk.get("model"),
        "raw_window_label": cal.get("window", ""),
    }


def _regime(packet: dict[str, Any], market_validation: dict[str, Any], items: list[NewsItem]) -> dict[str, Any]:
    stories = packet.get("driver_stories") or []
    if not stories:
        return {"regime": "UNKNOWN", "confidence": 0.0, "drivers": []}
    top = stories[:5]
    driver_names = [s.get("driver_key") for s in top]
    counts = Counter(driver_names)
    mapping = {
        "fed_usd_yields": "FED_USD_YIELD_DRIVEN",
        "inflation_jobs_growth": "DATA_RELEASE_DRIVEN",
        "geopolitical_safe_haven": "GEOPOLITICAL_RISK_DRIVEN",
        "direct_gold": "SPOT_GOLD_PRICE_ACTION_DRIVEN",
        "physical_flows": "PHYSICAL_AND_FLOW_DRIVEN",
        "oil_commodities": "COMMODITY_RISK_DRIVEN",
    }
    primary_key = top[0].get("driver_key")
    regime = mapping.get(primary_key, "MIXED_MACRO_DRIVEN")
    validation_counts = market_validation.get("verdict_counts") or {}
    confirmed = validation_counts.get("confirmed", 0)
    mixed = validation_counts.get("mixed_validation", 0)
    contradicted = validation_counts.get("contradicted", 0)
    confidence = 0.45 + min(0.25, len(top) * 0.04) + min(0.20, confirmed * 0.05) - min(0.20, contradicted * 0.06) - min(0.10, mixed * 0.03)
    confidence = max(0.10, min(0.95, confidence))
    return {"regime": regime, "confidence": round(confidence, 2), "drivers": [s.get("title") for s in top], "driver_keys": driver_names}


def _chart_instructions(combined: dict[str, Any], event: dict[str, Any], regime: dict[str, Any]) -> dict[str, Any]:
    bias = combined.get("bias")
    conflict = combined.get("conflict")
    risk = event.get("risk_level")
    allow = "WAIT_FOR_CONFIRMATION"
    if risk == "HIGH":
        allow = "EVENT_RISK_WAIT_OR_REACTION_ONLY"
    elif conflict:
        allow = "WAIT_FOR_ALIGNMENT"
    elif bias == "bullish":
        allow = "LOOK_FOR_LONG_SETUP_ONLY_IF_CHART_CONFIRMS"
    elif bias == "bearish":
        allow = "AVOID_SPOT_BUY_UNLESS_SUPPORT_REVERSAL_CONFIRMS"
    elif bias == "mixed":
        allow = "RANGE_OR_WAIT_FOR_BREAKOUT_CONFIRMATION"
    return {
        "chart_decision_gate": allow,
        "required_chart_evidence": [
            "1D and 4H trend/structure must not directly contradict macro context",
            "1H should confirm direction with break/reclaim or rejection at key level",
            "15M/5M only for timing; never override macro/event risk alone",
            "Check DXY and US10Y intraday alignment before entry",
            "Avoid new spot entries immediately before high-impact USD/Fed events",
        ],
        "regime_for_chart_engine": regime.get("regime"),
    }


def _top_headlines(items: list[NewsItem], bucket: str, limit: int) -> list[dict[str, Any]]:
    arr = [x for x in items if x.relevance_bucket == bucket]
    arr.sort(key=lambda x: (-x.time_decay_score, -x.source_quality, x.source, x.title.lower()))
    out = []
    seen: set[str] = set()
    for it in arr:
        k = it.title.lower()[:120]
        if k in seen:
            continue
        seen.add(k)
        out.append({
            "source": it.source,
            "title": it.title,
            "url": it.url,
            "published_utc": it.published_utc,
            "direction_hint": it.gold_direction,
            "narrative": it.narrative,
            "categories": it.categories,
            "event_state": it.event_state,
            "summary": it.summary[:500] if it.summary else "",
        })
        if len(out) >= limit:
            break
    return out


def build_macro_context_packet(items: list[NewsItem], intelligence_packet: dict[str, Any], market_context: dict[str, Any], market_validation: dict[str, Any], state_delta: dict[str, Any]) -> dict[str, Any]:
    news_bias = _news_driver_bias(intelligence_packet)
    market_bias = _market_gold_bias(market_context)
    combined = _combine_bias(news_bias, market_bias)
    events = _event_window(intelligence_packet, items)
    regime = _regime(intelligence_packet, market_validation, items)
    chart = _chart_instructions(combined, events, regime)

    return {
        "version": "AMB_GOLD_MACRO_CONTEXT_V8_5",
        "generated_utc": _now(),
        "purpose": "Frozen news/macro context layer for the future Chart Intelligence Engine. This is the stable interface between news and chart modules.",
        "asset": "XAUUSD",
        "macro_context": {
            "macro_regime": regime["regime"],
            "regime_confidence": regime["confidence"],
            "gold_news_bias": news_bias["bias"],
            "gold_market_bias": market_bias["bias"],
            "final_gold_context_bias": combined["bias"],
            "bias_conflict": combined["conflict"],
            "event_risk": events["risk_level"],
            "chart_decision_gate": chart["chart_decision_gate"],
        },
        "bias_components": {
            "news_driver_bias": news_bias,
            "market_validation_bias": market_bias,
            "combined_bias": combined,
        },
        "event_window": events,
        "market_regime": regime,
        "chart_engine_contract": chart,
        "market_context": market_context,
        "market_validation": market_validation,
        "what_changed_since_previous_run": state_delta,
        "driver_stories": intelligence_packet.get("driver_stories", [])[:8],
        "causal_chains": intelligence_packet.get("causal_chains", [])[:6],
        "contradictions": intelligence_packet.get("contradictions", [])[:6],
        "top_must_read": _top_headlines(items, "MUST_READ", 20),
        "top_macro_watch": _top_headlines(items, "MACRO_WATCH", 16),
        "background_context": _top_headlines(items, "BACKGROUND", 8),
        "llm_instruction": "Use this macro context with chart data. Do not make trade decisions from news alone. First check event risk, then confirm final_gold_context_bias against 1D/4H/1H/15M chart structure.",
    }


def render_macro_context_text(packet: dict[str, Any]) -> str:
    mc = packet["macro_context"]
    lines: list[str] = []
    lines.append("AMB GOLD MACRO CONTEXT V8.5 — FREEZE LAYER FOR CHART ENGINE")
    lines.append("=" * 92)
    lines.append(f"Generated UTC: {packet['generated_utc']}")
    lines.append(f"Asset: {packet['asset']}")
    lines.append("")
    lines.append("FINAL CONTEXT")
    lines.append("-" * 92)
    lines.append(f"Macro regime: {mc['macro_regime']} | confidence={mc['regime_confidence']}")
    lines.append(f"News bias: {mc['gold_news_bias'].upper()} | Market validation bias: {mc['gold_market_bias'].upper()} | Final context bias: {mc['final_gold_context_bias'].upper()}")
    lines.append(f"Bias conflict: {mc['bias_conflict']} | Event risk: {mc['event_risk']} | Chart gate: {mc['chart_decision_gate']}")
    lines.append("")
    lines.append("WHY")
    lines.append("-" * 92)
    for r in packet["bias_components"]["news_driver_bias"].get("reasons", [])[:6]:
        lines.append(f"- News: {r}")
    for r in packet["bias_components"]["market_validation_bias"].get("reasons", [])[:6]:
        lines.append(f"- Market: {r}")
    lines.append("")
    lines.append("EVENT WINDOW")
    lines.append("-" * 92)
    lines.append(packet["event_window"].get("trading_note", ""))
    for ev in packet["event_window"].get("upcoming_key_events", [])[:8]:
        lines.append(f"- {ev.get('time')} | {ev.get('title')} | {ev.get('source')}")
    lines.append("")
    lines.append("CHART ENGINE CONTRACT")
    lines.append("-" * 92)
    lines.append(f"Decision gate: {packet['chart_engine_contract']['chart_decision_gate']}")
    for req in packet["chart_engine_contract"].get("required_chart_evidence", []):
        lines.append(f"- {req}")
    lines.append("")
    lines.append("TOP CAUSAL CHAINS")
    lines.append("-" * 92)
    for ch in packet.get("causal_chains", [])[:5]:
        lines.append(f"- {ch.get('current_effect','unknown').upper()} | {ch.get('name')}: {' -> '.join(ch.get('chain', []))}")
    lines.append("")
    lines.append("MUST READ")
    lines.append("-" * 92)
    for it in packet.get("top_must_read", [])[:16]:
        lines.append(f"- {it['source']} | {it['direction_hint']} | {it['narrative']} | {it['title']}")
    lines.append("")
    lines.append("MACRO WATCH")
    lines.append("-" * 92)
    for it in packet.get("top_macro_watch", [])[:12]:
        lines.append(f"- {it['source']} | {it['direction_hint']} | {it['narrative']} | {it['title']}")
    lines.append("")
    lines.append("NEXT STEP")
    lines.append("-" * 92)
    lines.append("Attach 1D/4H/1H/15M chart structure to this packet. Use the chart gate before any spot buy/sell decision.")
    return "\n".join(lines).rstrip() + "\n"
