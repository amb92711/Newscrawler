from __future__ import annotations
import json
from datetime import datetime, timezone
from pathlib import Path
from collections import defaultdict
from .models import NewsItem, SourceStats
from .intelligence import build_macro_snapshot
from .narratives import build_intelligence_packet, compact_item
from .market_context import fetch_market_context, build_market_validation
from .state import build_state_delta
from .macro_context import build_macro_context_packet, render_macro_context_text

BUCKET_ORDER = ["MUST_READ", "MACRO_WATCH", "BACKGROUND", "DISCARD"]


def _dir(it: NewsItem) -> str:
    return it.gold_direction.upper() if it.gold_direction not in {"unknown", "neutral"} else "DIR_UNKNOWN"


def _one_line_item(it: NewsItem) -> str:
    return f"{it.title} | {_dir(it)} | {it.narrative} | {it.source}"


def _item_block(lines: list[str], idx: int, it: NewsItem) -> None:
    mark = "EVENT" if it.item_type == "event" else "NEWS"
    lines.append(f"{idx:02d}. [{mark}] {_one_line_item(it)}")
    lines.append(f"    bucket={it.relevance_bucket} relevance={it.xauusd_relevance} state={it.event_state} mode={it.source_mode} cluster={it.source_cluster_size}")
    lines.append(f"    categories={','.join(it.categories)} reasons={','.join(it.rank_reasons)}")
    if it.published_utc:
        lines.append(f"    time={it.published_utc}")
    if it.summary:
        lines.append(f"    summary={it.summary[:620]}")
    if it.url:
        lines.append(f"    url={it.url}")
    lines.append("")


def _evidence_line(ev: dict) -> str:
    direction = (ev.get("direction") or "unknown").upper()
    return f"{ev.get('bucket','')} | {ev.get('source','')} | {direction} | {ev.get('title','')}"


def _driver_block(lines: list[str], idx: int, story: dict) -> None:
    lines.append(f"{idx:02d}. {story['title']} | net_effect={story['net_effect_on_xauusd'].upper()} | must={story['must_read_count']} macro={story['macro_watch_count']} sources={story['source_count']}")
    lines.append(f"    why: {story['why_it_matters']}")
    lines.append(f"    evidence split: bullish={story['bullish_evidence_count']} bearish={story['bearish_evidence_count']} mixed={story['mixed_evidence_count']}")
    for ev in story.get("evidence", [])[:7]:
        lines.append("    - " + _evidence_line(ev))
    lines.append("")


def _chain_block(lines: list[str], idx: int, chain: dict) -> None:
    lines.append(f"{idx:02d}. {chain['name']} | current_effect={chain['current_effect'].upper()}")
    lines.append("    chain: " + " -> ".join(chain.get("chain", [])))
    lines.append("    summary: " + chain.get("summary", ""))
    for ev in chain.get("evidence", [])[:4]:
        lines.append("    - " + _evidence_line(ev))
    lines.append("")


def _contradiction_block(lines: list[str], idx: int, c: dict) -> None:
    a = c.get("driver_a", {})
    b = c.get("driver_b", {})
    lines.append(f"{idx:02d}. {c.get('name','Contradiction')}")
    lines.append(f"    A: {a.get('title')} ({a.get('effect')})")
    lines.append(f"    B: {b.get('title')} ({b.get('effect')})")
    lines.append(f"    meaning: {c.get('meaning_for_xauusd')}")
    lines.append("")


def render_report(items: list[NewsItem], stats: list[SourceStats], output_dir: str = "outputs") -> str:
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    ts = datetime.now(timezone.utc).isoformat()
    order_map = {b: i for i, b in enumerate(BUCKET_ORDER)}
    items = sorted(items, key=lambda x: (order_map.get(x.relevance_bucket, 9), -x.gold_impact_score, -x.source_quality, x.source, x.title.lower()))

    grouped: dict[str, list[NewsItem]] = defaultdict(list)
    by_narr: dict[str, list[NewsItem]] = defaultdict(list)
    for it in items:
        grouped[it.relevance_bucket].append(it)
        by_narr[it.narrative].append(it)

    snap = build_macro_snapshot(items)
    packet = build_intelligence_packet(items, stats)
    market_context = fetch_market_context()
    market_validation = build_market_validation(packet, market_context)
    state_delta = build_state_delta(packet, items, output_dir, market_validation)
    packet["market_context"] = market_context
    packet["market_validation"] = market_validation
    packet["state_delta"] = state_delta
    macro_context_packet = build_macro_context_packet(items, packet, market_context, market_validation, state_delta)
    macro_context_text = render_macro_context_text(macro_context_packet)
    packet["macro_context_v85"] = macro_context_packet
    final_story = packet["final_market_story"]
    stories = packet.get("driver_stories", [])
    chains = packet.get("causal_chains", [])
    contradictions = packet.get("contradictions", [])
    calendar = packet.get("calendar_digest", {})

    lines: list[str] = []
    lines.append("AMB GOLD NEWS + MACRO CONTEXT v8.5 — FINAL FREEZE LAYER BEFORE CHART")
    lines.append(f"Generated UTC: {ts}")
    lines.append("=" * 116)
    lines.append("")

    total_raw = sum(s.raw for s in stats)
    total_relevant = sum(s.relevant for s in stats)
    total_kept = len(items)
    lines.append("SOURCE SUMMARY")
    lines.append("-" * 116)
    lines.append(f"Raw candidates: {total_raw} | Relevant before global dedup: {total_relevant} | Final routed/kept: {total_kept}")
    lines.append("")
    for s in sorted(stats, key=lambda x: x.source):
        display_status = "PARTIAL_OK" if s.kept and s.errors else s.status
        lines.append(f"{s.source:18} status={display_status:10} raw={s.raw:4} direct={s.direct_raw:4} fallback={s.fallback_raw:4} relevant={s.relevant:4} kept={s.kept:4} dup={s.duplicates:3} rejected={s.rejected:4}")
        if s.notes:
            lines.append(f"  notes: {'; '.join(s.notes[:5])}")
        if s.errors:
            lines.append(f"  errors: {' | '.join(s.errors[:3])}")
    lines.append("")

    lines.append("TODAY'S XAUUSD MARKET STORY")
    lines.append("=" * 116)
    lines.append(f"Headline bias: {final_story['headline_bias'].upper()}")
    lines.append(final_story["summary"])
    lines.append("")
    lines.append("WHAT CHANGED SINCE PREVIOUS RUN")
    lines.append("-" * 116)
    for ch in state_delta.get("changes", [])[:8]:
        lines.append(f"- {ch}")
    for dc in state_delta.get("driver_changes", [])[:8]:
        label = dc.get("driver", "driver")
        kind = dc.get("change", "changed")
        if kind == "effect_changed":
            lines.append(f"- {label}: effect changed {dc.get('previous_effect')} -> {dc.get('current_effect')}")
        elif kind == "must_read_count_shift":
            lines.append(f"- {label}: must-read count shifted {dc.get('previous')} -> {dc.get('current')}")
        else:
            lines.append(f"- {label}: {kind} ({dc.get('current_effect', '')})")
    if state_delta.get("new_must_read_risks"):
        lines.append("New must-read risks: " + "; ".join(state_delta.get("new_must_read_risks", [])[:6]))
    lines.append("")
    lines.append("MARKET VALIDATION — BEST-EFFORT DXY / YIELDS / GOLD / OIL / VIX")
    lines.append("-" * 116)
    lines.append(f"Market data status: {market_context.get('status')}")
    inst = market_context.get("instruments", {})
    for key in ["gold_futures", "dxy", "us10y", "us13w", "silver_futures", "oil_wti", "vix"]:
        node = inst.get(key, {})
        if node.get("status") == "OK":
            lines.append(f"- {node.get('label')}: last={node.get('last')} change={node.get('change')} pct={node.get('pct_change')} direction={node.get('direction')}")
        else:
            lines.append(f"- {node.get('label', key)}: unavailable")
    for mv in market_validation.get("driver_validations", [])[:8]:
        checks = "; ".join(mv.get("checks", [])[:3])
        lines.append(f"  * {mv.get('story_title')}: {mv.get('validation_verdict')} | {checks}")
    if final_story.get("primary_driver"):
        p = final_story["primary_driver"]
        lines.append(f"Primary driver: {p['title']} ({p['net_effect_on_xauusd'].upper()})")
    if final_story.get("counter_drivers"):
        lines.append("Counter drivers: " + "; ".join(f"{x['title']} ({x['net_effect_on_xauusd']})" for x in final_story["counter_drivers"]))
    lines.append(f"Router buckets: MUST_READ={snap['must_read_count']} | MACRO_WATCH={snap['macro_watch_count']} | BACKGROUND={snap['background_count']}")
    lines.append("Narratives: " + ", ".join(f"{k}={v}" for k, v in snap["narratives"].items()))
    lines.append("Categories: " + ", ".join(f"{k}={v}" for k, v in snap["categories"].items()))
    lines.append("")

    lines.append("CAUSAL CHAINS — CAUSE -> TRANSMISSION -> XAUUSD EFFECT")
    lines.append("=" * 116)
    if not chains:
        lines.append("No causal chain detected.\n")
    for idx, chain in enumerate(chains[:8], start=1):
        _chain_block(lines, idx, chain)

    lines.append("CONTRADICTION / OFFSET DETECTOR")
    lines.append("=" * 116)
    if not contradictions:
        lines.append("No major conflicting driver detected in this run.\n")
    for idx, c in enumerate(contradictions[:8], start=1):
        _contradiction_block(lines, idx, c)

    lines.append("CALENDAR DIGEST — EVENT RISK WINDOW")
    lines.append("=" * 116)
    lines.append(f"Window: {calendar.get('window', '')}")
    for label, title in [("upcoming_high_risk", "Upcoming high-risk"), ("pending_missing_actual", "Pending / missing actual"), ("recent_final", "Recent final")]:
        arr = calendar.get(label, [])
        lines.append(f"\n{title}:")
        if not arr:
            lines.append("- none")
        for ev in arr[:12]:
            lines.append(f"- {ev.get('source')} | {ev.get('event_state')} | {ev.get('time')} | {ev.get('title')}")
    lines.append("")

    lines.append("MARKET DRIVER STORIES")
    lines.append("=" * 116)
    if not stories:
        lines.append("No strong market-driver story detected in this run.\n")
    for idx, story in enumerate(stories[:12], start=1):
        _driver_block(lines, idx, story)

    must = grouped.get("MUST_READ", [])
    macro = grouped.get("MACRO_WATCH", [])
    bg = grouped.get("BACKGROUND", [])

    lines.append("MUST_READ — DIRECT XAUUSD MOVERS")
    lines.append("=" * 116)
    if not must:
        lines.append("No must-read XAUUSD items found in this run.\n")
    for idx, it in enumerate(must[:60], start=1):
        _item_block(lines, idx, it)

    lines.append("MACRO_WATCH — IMPORTANT MACRO/RISK DRIVERS FOR GOLD")
    lines.append("=" * 116)
    if not macro:
        lines.append("No macro-watch items found in this run.\n")
    for idx, it in enumerate(macro[:55], start=1):
        _item_block(lines, idx, it)

    lines.append("BACKGROUND — CONTEXT ONLY / DO NOT LET THIS DOMINATE")
    lines.append("=" * 116)
    if not bg:
        lines.append("No background context items found in this run.\n")
    for idx, it in enumerate(bg[:35], start=1):
        _item_block(lines, idx, it)

    lines.append("MACRO CONTEXT V8.5 — CHART ENGINE READY BRIEF")
    lines.append("=" * 116)
    lines.append(macro_context_text.rstrip())
    lines.append("")

    lines.append("LLM READY FINAL BRIEF")
    lines.append("=" * 116)
    lines.append("Use this brief for ChatGPT macro/news analysis of XAUUSD spot. News, event digest, state change and basic market validation are included. Chart structure is not included yet.")
    lines.append(f"Overall news/macro bias: {final_story['headline_bias'].upper()}")
    lines.append(f"Market story: {final_story['summary']}")
    lines.append("\nWhat changed since previous run:")
    for ch in state_delta.get("changes", [])[:5]:
        lines.append(f"- {ch}")
    if state_delta.get("new_must_read_risks"):
        lines.append("New must-read risks: " + "; ".join(state_delta.get("new_must_read_risks", [])[:5]))
    lines.append("\nMarket validation:")
    for mv in market_validation.get("driver_validations", [])[:5]:
        lines.append(f"- {mv.get('story_title')}: {mv.get('validation_verdict')} | " + "; ".join(mv.get("checks", [])[:3]))
    lines.append("\nTop causal chains:")
    for ch in chains[:5]:
        lines.append(f"- {ch['current_effect'].upper()} | {ch['name']}: {' -> '.join(ch.get('chain', []))}")
    lines.append("\nTop driver stories:")
    for st in stories[:8]:
        lines.append(f"- {st['net_effect_on_xauusd'].upper()} | {st['title']} | must={st['must_read_count']} macro={st['macro_watch_count']}")
    if contradictions:
        lines.append("\nImportant contradictions:")
        for c in contradictions[:5]:
            lines.append(f"- {c['name']}: {c['meaning_for_xauusd']}")
    lines.append("\nMust-read headlines:")
    for it in must[:18]:
        lines.append(f"- {it.source} | {_dir(it)} | {it.narrative} | {it.title}")
    lines.append("\nMacro-watch headlines:")
    for it in macro[:14]:
        lines.append(f"- {it.source} | {_dir(it)} | {it.narrative} | {it.title}")
    lines.append("\nAsk ChatGPT next:")
    lines.append("1. What is the current macro/news bias for XAUUSD?")
    lines.append("2. Which driver dominates and which driver offsets it?")
    lines.append("3. Which upcoming event can invalidate the bias?")
    lines.append("4. What chart evidence is required before a spot buy/sell?")

    text = "\n".join(lines).rstrip() + "\n"
    (out / "latest_news_report.txt").write_text(text, encoding="utf-8")
    (out / "latest_macro_snapshot.json").write_text(json.dumps(snap, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "latest_market_context.json").write_text(json.dumps(market_context, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "latest_market_validation.json").write_text(json.dumps(market_validation, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "latest_intelligence_packet.json").write_text(json.dumps(packet, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "latest_macro_context.json").write_text(json.dumps(macro_context_packet, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "latest_macro_context.txt").write_text(macro_context_text, encoding="utf-8")
    (out / "latest_llm_brief.txt").write_text("\n".join(lines[lines.index("MACRO CONTEXT V8.5 — CHART ENGINE READY BRIEF"):]).rstrip() + "\n", encoding="utf-8")
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    (out / f"news_report_{stamp}.txt").write_text(text, encoding="utf-8")
    (out / f"intelligence_packet_{stamp}.json").write_text(json.dumps(packet, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / f"macro_context_{stamp}.json").write_text(json.dumps(macro_context_packet, ensure_ascii=False, indent=2), encoding="utf-8")
    return text
