from __future__ import annotations
from collections import Counter, defaultdict
from datetime import datetime, timezone, timedelta
import re
from .models import NewsItem, SourceStats

# V7 philosophy:
# The important unit is not a numeric score. The important unit is an XAUUSD-moving
# driver story: What happened? Why does it matter for gold? Is there a counter-driver?

DRIVERS = {
    "fed_usd_yields": {
        "title": "Fed / USD / Treasury yields",
        "core_categories": {"fed_rates", "usd_dxy", "yields"},
        "bullish_terms": ["rate cut", "dovish", "weaker dollar", "dollar falls", "dollar slips", "yields fall", "yields ease", "recession", "soft data"],
        "bearish_terms": ["hawkish", "rate hike", "higher rates", "stronger dollar", "dollar jumps", "dollar rallies", "dollar hits", "yields rise", "rising yields", "real yields", "tightening"],
        "why": "Gold is highly sensitive to the USD and real yields. Stronger USD / higher yields usually pressure XAUUSD; weaker USD / lower yields usually support it.",
    },
    "inflation_jobs_growth": {
        "title": "US inflation / jobs / growth data",
        "core_categories": {"inflation", "jobs", "growth", "calendar_critical", "calendar_high"},
        "bullish_terms": ["cooler inflation", "soft pce", "weak payrolls", "jobless claims rise", "growth slows", "recession", "misses forecast"],
        "bearish_terms": ["hot inflation", "sticky inflation", "strong payrolls", "resilient consumer", "strong gdp", "beats forecast", "low jobless"],
        "why": "US macro surprises change Fed pricing and dollar/yield direction, so they can move gold even before chart confirmation.",
    },
    "direct_gold": {
        "title": "Direct gold / XAUUSD price action and forecasts",
        "core_categories": {"gold"},
        "bullish_terms": ["gold rises", "gold rallies", "gold gains", "gold rebounds", "gold surges", "gold jumps", "breaks above"],
        "bearish_terms": ["gold falls", "gold drops", "gold slumps", "gold sinks", "gold breaks below", "gold pressured", "gold vulnerable", "gold under pressure", "cuts gold forecast", "gold risk"],
        "why": "Direct gold headlines show the market's immediate interpretation of macro, positioning and flow changes.",
    },
    "geopolitical_safe_haven": {
        "title": "Geopolitical / safe-haven risk",
        "core_categories": {"geopolitics", "risk"},
        "bullish_terms": ["war", "missile", "hormuz", "iran", "israel", "red sea", "ukraine", "russia", "sanctions", "risk-off", "safe haven", "escalation", "threat"],
        "bearish_terms": ["ceasefire", "deal optimism", "tensions ease", "pullback", "oil flows resume", "risk stabilisation", "risk stabilization"],
        "why": "Escalating geopolitical stress can add a safe-haven bid to gold; easing stress removes part of that premium.",
    },
    "physical_flows": {
        "title": "Physical demand / ETF / central-bank gold flows",
        "core_categories": {"flows_reserves", "central_banks", "china_global"},
        "bullish_terms": ["central bank buying", "gold reserves", "imports hit", "imports rise", "demand rises", "etf inflows", "purchases", "buying"],
        "bearish_terms": ["outflows", "demand drops", "imports fall", "liquidation", "selling", "investor demand drops"],
        "why": "Physical and official-sector flows are slower-moving, but they shape the medium-term floor or ceiling for gold.",
    },
    "oil_commodities": {
        "title": "Oil / silver / broad commodities",
        "core_categories": {"oil_commodities"},
        "bullish_terms": ["oil surges", "oil jumps", "silver rallies", "metals rally", "commodity inflation"],
        "bearish_terms": ["oil falls", "oil crashes", "silver down", "silver falls", "metals pressure", "commodities slump"],
        "why": "Oil and silver are not primary gold signals, but they matter when they affect inflation, risk premium or precious-metals positioning.",
    },
}

EFFECT_STRENGTH = {"bullish": 1, "bearish": -1, "mixed": 0, "unclear": 0, "unknown": 0, "neutral": 0}


def _text(it: NewsItem) -> str:
    return f"{it.title} {it.summary} {it.body}".lower()


def _contains_any(text: str, terms: list[str]) -> bool:
    return any(t in text for t in terms)


def _parse_dt(value: str | None):
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except Exception:
        return None


def driver_keys_for_item(it: NewsItem) -> set[str]:
    cats = set(it.categories)
    text = _text(it)
    keys: set[str] = set()
    if it.relevance_bucket not in {"MUST_READ", "MACRO_WATCH", "BACKGROUND"}:
        return keys
    for key, spec in DRIVERS.items():
        if cats & spec["core_categories"]:
            keys.add(key)
        elif _contains_any(text, spec["bullish_terms"] + spec["bearish_terms"]):
            keys.add(key)
    # Make direct gold items belong to direct_gold even if category tagging missed it.
    if any(x in text for x in ["xau/usd", "xauusd", "gold price", "gold futures", "spot gold"]):
        keys.add("direct_gold")
    return keys


def item_effect_for_driver(it: NewsItem, driver_key: str) -> str:
    text = _text(it)
    spec = DRIVERS[driver_key]
    bullish = _contains_any(text, spec["bullish_terms"])
    bearish = _contains_any(text, spec["bearish_terms"])
    # Explicit conservative direction can confirm, but text rules win when obvious.
    if it.gold_direction == "bullish":
        bullish = True
    elif it.gold_direction == "bearish":
        bearish = True
    if bullish and bearish:
        # Direct negative gold wording should not be overridden by incidental words like safe-haven.
        if driver_key in {"direct_gold", "fed_usd_yields"} and any(t in text for t in ["weigh", "pressure", "slump", "drop", "fall", "stronger dollar", "higher rates"]):
            return "bearish"
        return "mixed"
    if bullish:
        return "bullish"
    if bearish:
        return "bearish"
    return "unclear"


def evidence_sort_key(it: NewsItem) -> tuple:
    bucket_rank = {"MUST_READ": 0, "MACRO_WATCH": 1, "BACKGROUND": 2}.get(it.relevance_bucket, 9)
    direct_rank = 0 if it.source_mode in {"direct", "api"} else 1
    fresh = it.time_decay_score if hasattr(it, "time_decay_score") else 0
    return (bucket_rank, direct_rank, -fresh, -it.source_quality, it.source, it.title.lower())


def compress_evidence(items: list[NewsItem], limit: int = 10) -> list[NewsItem]:
    seen: set[str] = set()
    out: list[NewsItem] = []
    for it in sorted(items, key=evidence_sort_key):
        key = re.sub(r"[^a-z0-9]+", " ", it.title.lower()).strip()[:110]
        if key in seen:
            continue
        seen.add(key)
        out.append(it)
        if len(out) >= limit:
            break
    return out


def build_driver_stories(items: list[NewsItem]) -> list[dict]:
    buckets: dict[str, list[NewsItem]] = defaultdict(list)
    for it in items:
        if it.relevance_bucket not in {"MUST_READ", "MACRO_WATCH"}:
            continue
        for key in driver_keys_for_item(it):
            buckets[key].append(it)

    stories: list[dict] = []
    for key, arr in buckets.items():
        effects = Counter(item_effect_for_driver(it, key) for it in arr)
        bull = effects.get("bullish", 0)
        bear = effects.get("bearish", 0)
        mixed = effects.get("mixed", 0)
        if bear > bull * 1.25 and bear >= 1:
            net = "bearish"
        elif bull > bear * 1.25 and bull >= 1:
            net = "bullish"
        elif bull or bear or mixed:
            net = "mixed"
        else:
            net = "unclear"
        must = [x for x in arr if x.relevance_bucket == "MUST_READ"]
        macro = [x for x in arr if x.relevance_bucket == "MACRO_WATCH"]
        evidence = compress_evidence(arr, limit=10)
        sources = sorted({x.source for x in arr})
        story_strength = len(must) * 3 + len(macro) * 2 + min(4, len(sources))
        stories.append({
            "driver_key": key,
            "title": DRIVERS[key]["title"],
            "why_it_matters": DRIVERS[key]["why"],
            "net_effect_on_xauusd": net,
            "bullish_evidence_count": bull,
            "bearish_evidence_count": bear,
            "mixed_evidence_count": mixed,
            "must_read_count": len(must),
            "macro_watch_count": len(macro),
            "source_count": len(sources),
            "sources": sources,
            "story_strength": story_strength,
            "evidence": [compact_item(x, include_summary=False) for x in evidence],
        })
    stories.sort(key=lambda s: (-s["story_strength"], s["driver_key"]))
    return stories


def build_causal_chains(stories: list[dict]) -> list[dict]:
    by_key = {s["driver_key"]: s for s in stories}
    chains: list[dict] = []
    fed = by_key.get("fed_usd_yields")
    direct = by_key.get("direct_gold")
    infl = by_key.get("inflation_jobs_growth")
    geo = by_key.get("geopolitical_safe_haven")
    flows = by_key.get("physical_flows")
    oil = by_key.get("oil_commodities")

    if fed:
        effect = fed["net_effect_on_xauusd"]
        chains.append({
            "name": "Policy-to-gold transmission",
            "chain": ["Fed pricing / rate expectations", "USD and Treasury yields", "Opportunity cost of holding gold", "XAUUSD pressure/support"],
            "current_effect": effect,
            "summary": f"Fed/USD/yield evidence is currently {effect}; this is usually the cleanest short-term macro transmission into gold.",
            "evidence": fed["evidence"][:5],
        })
    if infl:
        chains.append({
            "name": "Data-risk transmission",
            "chain": ["US inflation/jobs/growth data", "Fed repricing", "DXY / yields reaction", "Gold repricing"],
            "current_effect": infl["net_effect_on_xauusd"],
            "summary": "US data risk is active; actual releases can flip the gold narrative quickly, especially around PCE/CPI/NFP/jobless claims.",
            "evidence": infl["evidence"][:5],
        })
    if geo:
        chains.append({
            "name": "Risk-premium transmission",
            "chain": ["Geopolitical headline", "Energy/risk sentiment", "Safe-haven demand", "Gold risk premium"],
            "current_effect": geo["net_effect_on_xauusd"],
            "summary": f"Geopolitical evidence is {geo['net_effect_on_xauusd']}; this can offset or amplify the Fed/USD story.",
            "evidence": geo["evidence"][:5],
        })
    if flows:
        chains.append({
            "name": "Flow/floor transmission",
            "chain": ["ETF/physical/central-bank demand", "Investor positioning", "Medium-term gold floor/ceiling", "XAUUSD trend context"],
            "current_effect": flows["net_effect_on_xauusd"],
            "summary": "Flow evidence matters more for medium-term bias than for minute-to-minute entries.",
            "evidence": flows["evidence"][:5],
        })
    if oil and geo:
        chains.append({
            "name": "Oil-geopolitics cross-current",
            "chain": ["Oil/Hormuz/news shock", "Inflation and risk sentiment", "Fed/risk-premium expectations", "Gold cross-current"],
            "current_effect": "mixed",
            "summary": "Oil can pull gold in opposite directions: inflation/risk premium can support gold, while easing geopolitical oil stress can remove safe-haven demand.",
            "evidence": (oil["evidence"] + geo["evidence"])[:5],
        })
    if direct:
        chains.append({
            "name": "Observed gold-price confirmation",
            "chain": ["Direct gold headline", "Market interpretation", "Price-action confirmation/risk", "Chart layer should validate"],
            "current_effect": direct["net_effect_on_xauusd"],
            "summary": "Direct gold headlines show how the market has already digested macro and flow drivers; chart analysis should validate whether it is extended or actionable.",
            "evidence": direct["evidence"][:5],
        })
    return chains


def build_contradictions(stories: list[dict]) -> list[dict]:
    effects = {s["driver_key"]: s for s in stories}
    out: list[dict] = []
    fed = effects.get("fed_usd_yields")
    geo = effects.get("geopolitical_safe_haven")
    flows = effects.get("physical_flows")
    direct = effects.get("direct_gold")
    infl = effects.get("inflation_jobs_growth")

    def add(name: str, a: dict, b: dict, meaning: str):
        out.append({
            "name": name,
            "driver_a": {"title": a["title"], "effect": a["net_effect_on_xauusd"]},
            "driver_b": {"title": b["title"], "effect": b["net_effect_on_xauusd"]},
            "meaning_for_xauusd": meaning,
        })

    if fed and geo and fed["net_effect_on_xauusd"] != geo["net_effect_on_xauusd"] and "unclear" not in {fed["net_effect_on_xauusd"], geo["net_effect_on_xauusd"]}:
        add("Macro pressure vs safe-haven bid", fed, geo, "Gold may chop: USD/yields can cap rallies while geopolitical risk supports dips.")
    if fed and flows and fed["net_effect_on_xauusd"] != flows["net_effect_on_xauusd"] and "unclear" not in {fed["net_effect_on_xauusd"], flows["net_effect_on_xauusd"]}:
        add("Short-term macro vs medium-term flows", fed, flows, "Intraday pressure can conflict with central-bank/physical demand support.")
    if direct and fed and direct["net_effect_on_xauusd"] != fed["net_effect_on_xauusd"] and "unclear" not in {direct["net_effect_on_xauusd"], fed["net_effect_on_xauusd"]}:
        add("Observed gold price vs macro driver", direct, fed, "Gold price headlines may be lagging or reacting to an offsetting driver; chart confirmation is required.")
    if infl and fed and infl["net_effect_on_xauusd"] == "mixed":
        out.append({
            "name": "Event risk can override current Fed/USD narrative",
            "driver_a": {"title": infl["title"], "effect": infl["net_effect_on_xauusd"]},
            "driver_b": {"title": fed["title"], "effect": fed["net_effect_on_xauusd"]},
            "meaning_for_xauusd": "Upcoming or fresh data can invalidate the current macro story; avoid over-trusting pre-release direction.",
        })
    return out


def build_calendar_digest(items: list[NewsItem], hours_forward: int = 36, hours_back: int = 12) -> dict:
    now = datetime.now(timezone.utc)
    upcoming: list[NewsItem] = []
    pending: list[NewsItem] = []
    final: list[NewsItem] = []
    for it in items:
        if it.item_type != "event":
            continue
        dt = _parse_dt(it.published_utc)
        if dt:
            if now - timedelta(hours=hours_back) <= dt <= now + timedelta(hours=hours_forward):
                if it.event_state == "upcoming":
                    upcoming.append(it)
                elif it.event_state == "pending":
                    pending.append(it)
                elif it.event_state == "final":
                    final.append(it)
        elif it.relevance_bucket in {"MUST_READ", "MACRO_WATCH"}:
            pending.append(it)
    return {
        "window": f"-{hours_back}h/+{hours_forward}h",
        "upcoming_high_risk": [compact_item(x) for x in sorted(upcoming, key=lambda i: _parse_dt(i.published_utc) or now)[:15]],
        "pending_missing_actual": [compact_item(x) for x in sorted(pending, key=evidence_sort_key)[:12]],
        "recent_final": [compact_item(x) for x in sorted(final, key=evidence_sort_key)[:12]],
    }


def compact_item(it: NewsItem, include_summary: bool = True) -> dict:
    d = {
        "bucket": it.relevance_bucket,
        "type": it.item_type,
        "source": it.source,
        "mode": it.source_mode,
        "title": it.title,
        "direction": it.gold_direction,
        "narrative": it.narrative,
        "categories": it.categories,
        "event_state": it.event_state,
        "time": it.published_utc,
        "url": it.url,
        "reasons": it.rank_reasons,
    }
    if include_summary and it.summary:
        d["summary"] = it.summary[:700]
    return d


def build_final_market_story(stories: list[dict], contradictions: list[dict]) -> dict:
    weighted = Counter()
    for s in stories:
        effect = s["net_effect_on_xauusd"]
        weight = max(1, s["must_read_count"] * 2 + s["macro_watch_count"])
        if effect == "bullish":
            weighted["bullish"] += weight
        elif effect == "bearish":
            weighted["bearish"] += weight
        elif effect == "mixed":
            weighted["mixed"] += max(1, weight // 2)
    bull = weighted["bullish"]
    bear = weighted["bearish"]
    if bear >= bull * 1.35 and bear >= 3:
        bias = "bearish"
    elif bull >= bear * 1.35 and bull >= 3:
        bias = "bullish"
    elif bull or bear or weighted["mixed"]:
        bias = "mixed"
    else:
        bias = "unknown"

    primary = stories[0] if stories else None
    secondaries = stories[1:4]
    counter = []
    if primary:
        p_eff = primary["net_effect_on_xauusd"]
        counter = [s for s in stories[1:] if s["net_effect_on_xauusd"] not in {p_eff, "unclear", "mixed"}]

    if primary:
        summary = f"Primary story: {primary['title']} is {primary['net_effect_on_xauusd']} for XAUUSD."
        if secondaries:
            summary += " Secondary drivers: " + "; ".join(f"{s['title']} ({s['net_effect_on_xauusd']})" for s in secondaries[:3]) + "."
        if contradictions:
            summary += " There are active contradictions, so chart confirmation and event timing matter."
    else:
        summary = "No dominant XAUUSD-moving news narrative was detected in this run."
    return {
        "headline_bias": bias,
        "weighted_counts": dict(weighted),
        "summary": summary,
        "primary_driver": primary,
        "secondary_drivers": secondaries,
        "counter_drivers": counter[:3],
        "contradiction_count": len(contradictions),
    }


def build_llm_packet(items: list[NewsItem], stories: list[dict], final_story: dict, contradictions: list[dict], calendar_digest: dict) -> dict:
    must = [x for x in items if x.relevance_bucket == "MUST_READ"]
    macro = [x for x in items if x.relevance_bucket == "MACRO_WATCH"]
    bg = [x for x in items if x.relevance_bucket == "BACKGROUND"]
    return {
        "instruction_for_llm": "Analyze macro/news impact on XAUUSD spot only. Do not give a chart entry unless chart data is provided later. Focus on bias, risk windows, invalidation news, and what chart evidence would be needed.",
        "market_story": final_story,
        "driver_stories": stories[:8],
        "causal_chains": build_causal_chains(stories),
        "contradictions": contradictions,
        "calendar_digest": calendar_digest,
        "must_read_news": [compact_item(x) for x in compress_evidence(must, 25)],
        "macro_watch": [compact_item(x) for x in compress_evidence(macro, 25)],
        "background_context": [compact_item(x) for x in compress_evidence(bg, 15)],
        "recommended_llm_questions": [
            "What is the current macro/news bias for XAUUSD?",
            "Which driver is dominant and which driver is the strongest counter-force?",
            "Which upcoming event could invalidate the bias?",
            "What chart evidence is needed before considering a spot buy or sell?",
        ],
    }


def build_intelligence_packet(items: list[NewsItem], stats: list[SourceStats]) -> dict:
    routed = [x for x in items if x.relevance_bucket in {"MUST_READ", "MACRO_WATCH", "BACKGROUND"}]
    stories = build_driver_stories(routed)
    contradictions = build_contradictions(stories)
    calendar_digest = build_calendar_digest(routed)
    final_story = build_final_market_story(stories, contradictions)
    source_health = []
    for s in sorted(stats, key=lambda x: x.source):
        source_health.append({
            "source": s.source,
            "status": "PARTIAL_OK" if s.kept and s.errors else s.status,
            "raw": s.raw,
            "relevant": s.relevant,
            "kept": s.kept,
            "duplicates": s.duplicates,
            "rejected": s.rejected,
            "direct_raw": s.direct_raw,
            "fallback_raw": s.fallback_raw,
            "notes": s.notes,
            "errors": s.errors,
        })
    buckets = Counter(x.relevance_bucket for x in routed)
    return {
        "version": "v8_institutional_news_memory_market_validation",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "summary_counts": {
            "total_routed": len(routed),
            "must_read": buckets.get("MUST_READ", 0),
            "macro_watch": buckets.get("MACRO_WATCH", 0),
            "background": buckets.get("BACKGROUND", 0),
        },
        "final_market_story": final_story,
        "driver_stories": stories,
        "causal_chains": build_causal_chains(stories),
        "contradictions": contradictions,
        "calendar_digest": calendar_digest,
        "llm_ready_packet": build_llm_packet(routed, stories, final_story, contradictions, calendar_digest),
        "source_health": source_health,
    }
