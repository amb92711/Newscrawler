from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List, Optional
import re

_CRITICAL_PATTERNS = (
    'fomc interest rate', 'fed interest rate decision', 'interest rate decision',
    'fomc statement', 'fomc economic projections', 'fed chair', 'powell', 'warsh speech',
    'non farm payroll', 'nonfarm payroll', 'nfp', 'unemployment rate',
    'core pce', 'pce price index', 'cpi ', 'consumer price index',
)
_HIGH_PATTERNS = (
    'fomc', 'fed ', 'payroll', 'jobless', 'unemployment claims', 'ism ',
    'retail sales', 'gdp', 'jolts', 'adp ', 'ppi ', 'treasury sec',
)


def _parse_time(value: Any) -> Optional[datetime]:
    if not value:
        return None
    try:
        text = str(value).replace('Z', '+00:00')
        dt = datetime.fromisoformat(text)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except Exception:
        return None


def _impact_from_summary(summary: str) -> str:
    m = re.search(r'Impact\s*:\s*(High|Medium|Low)', summary or '', flags=re.I)
    return m.group(1).upper() if m else 'UNKNOWN'


def classify_event(ev: Dict[str, Any]) -> Dict[str, Any]:
    title = str(ev.get('title') or '')
    low_title = title.lower()
    summary = str(ev.get('summary') or '')
    impact = _impact_from_summary(summary)
    cats = {str(x).lower() for x in (ev.get('categories') or [])}

    if any(k in low_title for k in _CRITICAL_PATTERNS):
        tier = 'CRITICAL'
    elif impact == 'HIGH' or 'calendar_critical' in cats or any(k in low_title for k in _HIGH_PATTERNS):
        tier = 'HIGH'
    elif impact == 'MEDIUM' or 'calendar_high' in cats:
        tier = 'MEDIUM'
    else:
        tier = 'LOW'

    # Generic speeches are not equivalent to a policy decision unless they are explicitly the Fed Chair.
    if 'speaks' in low_title or 'speech' in low_title:
        if not any(k in low_title for k in ('fed chair', 'powell', 'warsh speech')):
            if tier == 'CRITICAL':
                tier = 'HIGH'
            elif tier == 'HIGH' and impact != 'HIGH':
                tier = 'MEDIUM'

    return {'tier': tier, 'impact': impact}


def _proximity_score(tier: str, minutes: float) -> float:
    # Negative means event already occurred. Post-release windows remain risky briefly.
    m = float(minutes)
    am = abs(m)
    post = m < 0
    if tier == 'CRITICAL':
        if post and am <= 60: return 100.0
        if not post and am <= 45: return 100.0
        if am <= 120: return 88.0
        if am <= 240: return 70.0
        if am <= 720: return 38.0
        if am <= 2160: return 18.0
        return 4.0
    if tier == 'HIGH':
        if post and am <= 45: return 90.0
        if not post and am <= 45: return 90.0
        if am <= 120: return 72.0
        if am <= 240: return 48.0
        if am <= 720: return 24.0
        if am <= 1440: return 10.0
        return 2.0
    if tier == 'MEDIUM':
        if post and am <= 30: return 55.0
        if not post and am <= 30: return 55.0
        if am <= 90: return 38.0
        if am <= 180: return 24.0
        if am <= 360: return 14.0
        if am <= 1440: return 5.0
        return 1.0
    if am <= 30: return 18.0
    if am <= 120: return 8.0
    return 0.0


def evaluate_event_risk(upcoming: Iterable[Dict[str, Any]], pending: Iterable[Dict[str, Any]], *, now: Optional[datetime] = None) -> Dict[str, Any]:
    now = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    scored: List[Dict[str, Any]] = []
    untimeable: List[Dict[str, Any]] = []

    for origin, arr in (('upcoming', upcoming), ('pending', pending)):
        for ev in arr:
            if not isinstance(ev, dict):
                continue
            meta = classify_event(ev)
            dt = _parse_time(ev.get('time'))
            # Final archival rows with no timestamp are context, not execution blockers.
            if dt is None:
                untimeable.append({
                    'origin': origin,
                    'title': ev.get('title'),
                    'source': ev.get('source'),
                    'event_state': ev.get('event_state'),
                    **meta,
                    'execution_relevance': 'context_only_no_timestamp',
                })
                continue
            minutes = (dt - now).total_seconds() / 60.0
            # Ignore events well outside the digest execution window even if stale scrapers retained them.
            if minutes < -180 or minutes > 2160:
                continue
            score = _proximity_score(meta['tier'], minutes)
            scored.append({
                'title': ev.get('title'), 'source': ev.get('source'), 'time': dt.isoformat(),
                'minutes_to_event': round(minutes, 1), 'hours_to_event': round(minutes/60.0, 2),
                'tier': meta['tier'], 'impact': meta['impact'], 'risk_score': round(score, 1),
                'event_state': ev.get('event_state'), 'summary': ev.get('summary', ''),
            })

    scored.sort(key=lambda x: (-float(x['risk_score']), abs(float(x['minutes_to_event']))))
    peak = float(scored[0]['risk_score']) if scored else 0.0
    # A cluster of medium/high events adds uncertainty, but cannot convert a distant medium speech into HIGH.
    cluster = sum(1 for x in scored if x['risk_score'] >= 20 and abs(x['minutes_to_event']) <= 360)
    aggregate = min(100.0, peak + max(0, cluster-1)*4.0)
    if aggregate >= 70:
        level = 'HIGH'
    elif aggregate >= 30:
        level = 'MEDIUM'
    else:
        level = 'LOW'

    scalp_block = aggregate >= 70
    spot_block = aggregate >= 82
    next_blocking = next((x for x in sorted(scored, key=lambda x: abs(x['minutes_to_event'])) if x['risk_score'] >= 70), None)
    nearest = min(scored, key=lambda x: abs(x['minutes_to_event'])) if scored else None
    return {
        'risk_level': level,
        'risk_score': round(aggregate, 1),
        'blocks_trade': scalp_block,
        'scalp_blocks_trade': scalp_block,
        'spot_blocks_trade': spot_block,
        'execution_mode': 'BLOCK' if scalp_block else ('CONFIRMATION_ONLY' if level == 'MEDIUM' else 'NORMAL'),
        'nearest_timed_event': nearest,
        'next_blocking_event': next_blocking,
        'scored_events': scored[:12],
        'untimed_context_events': untimeable[:12],
        'model': 'EVENT_RISK_PROXIMITY_SEVERITY_V2',
    }
