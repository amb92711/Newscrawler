from __future__ import annotations
import json
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn
from rich.table import Table
from .models import NewsItem, SourceStats
from .utils import write_jsonl
from .intelligence import enrich_items, apply_source_caps
from .sources.ap import ApScraper
from .sources.rss_sources import CnbcScraper, ForexLiveScraper, FxStreetScraper, YahooScraper
from .sources.dailyforex import DailyForexScraper
from .sources.calendar import ForexFactoryScraper, TradingEconomicsScraper
from .sources.market_sites import NasdaqScraper, MarketWatchScraper, BloombergPublicScraper, IgDailyFxScraper
from .sources.google_news import GoogleNewsScraper
from .sources.specialist import GoldOrgScraper, BarchartScraper, FxEmpireGoldScraper, InvestingGoldScraper

console = Console()

DEFAULT_SOURCES = [
    ApScraper,
    CnbcScraper,
    DailyForexScraper,
    ForexFactoryScraper,
    ForexLiveScraper,
    FxStreetScraper,
    FxEmpireGoldScraper,
    GoldOrgScraper,
    BarchartScraper,
    InvestingGoldScraper,
    MarketWatchScraper,
    NasdaqScraper,
    TradingEconomicsScraper,
    YahooScraper,
]

HEAVY_SOURCES = [BloombergPublicScraper, IgDailyFxScraper]
FALLBACK_SOURCES = [GoogleNewsScraper]


def dedupe_items(items: list[NewsItem]) -> tuple[list[NewsItem], dict[str, int]]:
    # Prefer direct/API and higher institutional score; semantic_cluster_id is created later,
    # so first pass uses novelty_key to remove exact duplicates only.
    items = sorted(items, key=lambda x: (x.source_mode == "fallback", -x.impact, -x.source_quality, x.source))
    seen: set[str] = set()
    kept: list[NewsItem] = []
    dup_by_source: dict[str, int] = {}
    for it in items:
        key = it.novelty_key
        if key in seen:
            dup_by_source[it.source] = dup_by_source.get(it.source, 0) + 1
            continue
        seen.add(key)
        kept.append(it)
    return kept, dup_by_source


def semantic_dedupe(items: list[NewsItem]) -> tuple[list[NewsItem], dict[str, int]]:
    # After enrichment, keep one representative per semantic cluster when titles are essentially the same.
    buckets: dict[str, list[NewsItem]] = {}
    for it in items:
        buckets.setdefault(it.semantic_cluster_id or it.novelty_key, []).append(it)
    kept: list[NewsItem] = []
    dup: dict[str, int] = {}
    for _, arr in buckets.items():
        arr.sort(key=lambda x: (-x.gold_impact_score, x.source_mode == "fallback", -x.source_quality))
        kept.append(arr[0])
        for x in arr[1:]:
            dup[x.source] = dup.get(x.source, 0) + 1
    kept.sort(key=lambda x: (-x.gold_impact_score, -x.source_quality, x.source))
    return kept, dup


def run_engine(days: int = 3, workers: int = 6, include_heavy: bool = False, include_google: bool = True, output_dir: str = "outputs", source_caps: bool = True) -> tuple[list[NewsItem], list[SourceStats]]:
    source_classes = list(DEFAULT_SOURCES)
    if include_heavy:
        source_classes += HEAVY_SOURCES
    if include_google:
        source_classes += FALLBACK_SOURCES

    all_items: list[NewsItem] = []
    stats: list[SourceStats] = []

    console.print(f"\n[bold cyan]AMB Gold News Institutional Intelligence v8[/bold cyan] | days={days} | sources={len(source_classes)} | workers={workers}\n")

    with Progress(
        SpinnerColumn(), TextColumn("[bold blue]{task.description}"), BarColumn(),
        TextColumn("{task.completed}/{task.total}"), TimeElapsedColumn(), console=console,
    ) as progress:
        task = progress.add_task("Scraping sources", total=len(source_classes))
        with ThreadPoolExecutor(max_workers=max(1, workers)) as ex:
            futs = {}
            for cls in source_classes:
                scraper = cls(days=days, include_heavy=include_heavy)
                futs[ex.submit(scraper.run)] = cls.name
            for fut in as_completed(futs):
                name = futs[fut]
                try:
                    items, st = fut.result()
                    all_items.extend(items)
                    stats.append(st)
                    progress.console.print(f"[green]✓[/green] {name}: relevant={st.relevant} raw={st.raw} status={st.status}")
                except Exception as e:
                    st = SourceStats(source=name, status="FAIL")
                    st.error(f"{type(e).__name__}: {e}")
                    stats.append(st)
                    progress.console.print(f"[red]✗[/red] {name}: {e}")
                progress.update(task, advance=1)

    exact_kept, exact_dup = dedupe_items(all_items)
    enriched = enrich_items(exact_kept)
    sem_kept, sem_dup = semantic_dedupe(enriched)
    final_items = apply_source_caps(sem_kept) if source_caps else sem_kept

    final_sources = {id(x) for x in final_items}
    for st in stats:
        st.duplicates = exact_dup.get(st.source, 0) + sem_dup.get(st.source, 0)
        st.kept = sum(1 for x in final_items if x.source == st.source)

    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    now = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    write_jsonl(out / "latest_news.jsonl", [x.to_dict() for x in final_items])
    write_jsonl(out / f"news_{now}.jsonl", [x.to_dict() for x in final_items])
    (out / "latest_stats.json").write_text(json.dumps([s.__dict__ for s in sorted(stats, key=lambda s: s.source)], ensure_ascii=False, indent=2), encoding="utf-8")

    show_stats_table(stats)
    return final_items, stats


def show_stats_table(stats: list[SourceStats]) -> None:
    table = Table(title="Source Health / Coverage")
    for col in ["Source", "Status", "Raw", "Direct", "Fallback", "Relevant", "Kept", "Dup", "Rejected", "Notes / Errors"]:
        table.add_column(col, overflow="fold")
    for st in sorted(stats, key=lambda s: s.source):
        status = "✅ OK" if st.status == "OK" else ("⚠️ PARTIAL" if st.status == "PARTIAL" else "❌ FAIL")
        notes = "; ".join(st.notes[:4])
        errors = " | ".join(st.errors[:2])
        msg = notes + ((" | ERR: " + errors) if errors else "")
        table.add_row(st.source, status, str(st.raw), str(st.direct_raw), str(st.fallback_raw), str(st.relevant), str(st.kept), str(st.duplicates), str(st.rejected), msg)
    console.print(table)
