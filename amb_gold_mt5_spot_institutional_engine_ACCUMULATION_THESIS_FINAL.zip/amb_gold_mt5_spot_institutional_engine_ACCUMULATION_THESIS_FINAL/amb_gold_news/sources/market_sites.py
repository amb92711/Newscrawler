from __future__ import annotations
from .base import SourceScraper
from ..utils import parse_feed, soup_from_url, clean_text, absolute

class NasdaqScraper(SourceScraper):
    name = "nasdaq"
    feeds = {
        "markets": "https://www.nasdaq.com/feed/rssoutbound?category=Markets",
        "economy": "https://www.nasdaq.com/feed/rssoutbound?category=Economy",
        "commodities": "https://www.nasdaq.com/feed/rssoutbound?category=Commodities",
    }
    def collect_raw(self) -> list[dict]:
        rows = []
        for feed, url in self.feeds.items():
            try:
                items = parse_feed(url, session=self.session)
                self.stats.direct_raw += len(items)
                self.stats.note(f"{feed}: {len(items)} RSS")
                for it in items:
                    it.update({"source": self.name, "feed": feed, "source_mode": "direct"})
                    rows.append(it)
            except Exception as e:
                self.stats.error(f"{feed}: {type(e).__name__}: {e}")
        return rows

class MarketWatchScraper(SourceScraper):
    name = "marketwatch"
    feeds = {
        "topstories": "https://feeds.content.dowjones.io/public/rss/mw_topstories",
        "marketpulse": "https://feeds.content.dowjones.io/public/rss/mw_marketpulse",
        "realtime": "https://feeds.content.dowjones.io/public/rss/mw_realtimeheadlines",
    }
    def collect_raw(self) -> list[dict]:
        rows = []
        for feed, url in self.feeds.items():
            try:
                items = parse_feed(url, session=self.session)
                self.stats.direct_raw += len(items)
                self.stats.note(f"{feed}: {len(items)} RSS")
                for it in items:
                    it.update({"source": self.name, "feed": feed, "source_mode": "direct"})
                    rows.append(it)
            except Exception as e:
                self.stats.error(f"{feed}: {type(e).__name__}: {e}")
        return rows

class BloombergPublicScraper(SourceScraper):
    name = "bloomberg"
    pages = ["https://www.bloomberg.com/fx-center", "https://www.bloomberg.com/economics", "https://www.bloomberg.com/markets/etfs"]
    def collect_raw(self) -> list[dict]:
        if not self.include_heavy:
            self.stats.note("skipped; run with --include-heavy for public Bloomberg pages")
            return []
        rows = []
        for page in self.pages:
            try:
                soup = soup_from_url(page, self.session)
                count = 0
                for a in soup.select("a[href]"):
                    title = clean_text(a.get_text(" ", strip=True))
                    href = a.get("href", "")
                    if len(title) < 10:
                        continue
                    if any(x in href for x in ["/news/articles/", "/markets/", "/economics"]):
                        rows.append({"source": self.name, "title": title, "url": absolute("https://www.bloomberg.com", href), "summary": "", "source_mode": "direct"})
                        count += 1
                self.stats.note(f"{page.split('/')[-1]}: {count} public links")
            except Exception as e:
                self.stats.error(f"Bloomberg public {page}: {type(e).__name__}: {e}")
        self.stats.direct_raw = len(rows)
        return rows

class IgDailyFxScraper(SourceScraper):
    name = "ig"
    base = "https://www.ig.com/uk/news-and-trade-ideas"
    def collect_raw(self) -> list[dict]:
        if not self.include_heavy:
            self.stats.note("skipped; run with --include-heavy for IG/JS pages")
            return []
        rows = []
        try:
            soup = soup_from_url(self.base, self.session)
            for a in soup.select("a[href]"):
                title = clean_text(a.get_text(" ", strip=True))
                href = a.get("href", "")
                if len(title) > 10 and "/news-and-trade-ideas/" in href:
                    rows.append({"source": self.name, "title": title, "url": absolute("https://www.ig.com", href), "summary": "", "source_mode": "direct"})
            self.stats.direct_raw = len(rows)
            self.stats.note(f"IG public links: {len(rows)}")
        except Exception as e:
            self.stats.error(f"IG public: {type(e).__name__}: {e}")
        return rows
