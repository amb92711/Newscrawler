from __future__ import annotations
from datetime import datetime, timezone
import requests
from .base import SourceScraper
from ..utils import parse_date, clean_text, soup_from_url

MAJOR_CCYS = {"USD", "EUR", "GBP", "JPY", "CHF", "CAD", "AUD", "NZD"}
IMPORTANT_TERMS = [
    "cpi", "ppi", "pce", "inflation", "fomc", "federal funds", "rate decision", "rate statement",
    "powell", "non-farm", "nonfarm", "payrolls", "nfp", "unemployment", "jobless", "gdp",
    "retail sales", "pmi", "ism", "consumer confidence", "durable goods", "treasury", "bond auction",
]

class ForexFactoryScraper(SourceScraper):
    name = "forexfactory"
    url = "https://nfs.faireconomy.media/ff_calendar_thisweek.json"
    def collect_raw(self) -> list[dict]:
        rows = []
        try:
            r = self.session.get(self.url, timeout=25, headers={"User-Agent": "Mozilla/5.0"})
            r.raise_for_status()
            data = r.json()
            self.stats.direct_raw = len(data)
            self.stats.note(f"official JSON: {len(data)} events")
            for ev in data:
                title = clean_text(ev.get("title") or ev.get("event") or "")
                currency = clean_text(ev.get("currency") or ev.get("country") or "")
                impact_raw = clean_text(ev.get("impact") or "")
                text = f"{currency} {title} {impact_raw}"
                if currency and currency not in MAJOR_CCYS:
                    continue
                if not any(t in text.lower() for t in IMPORTANT_TERMS) and impact_raw.lower() not in {"high", "medium"}:
                    continue
                pub = parse_date(ev.get("date") or ev.get("datetime") or "")
                rows.append({
                    "source": self.name, "title": f"{currency} {title}".strip(), "summary": f"Impact: {impact_raw} | Previous: {ev.get('previous','')} | Forecast: {ev.get('forecast','')} | Actual: {ev.get('actual','')}",
                    "url": self.url, "published_utc": pub, "item_type": "event", "source_mode": "api", "extra": ev,
                })
        except Exception as e:
            self.stats.error(f"ForexFactory JSON: {type(e).__name__}: {e}")
        return rows

class TradingEconomicsScraper(SourceScraper):
    name = "tradingeconomics"
    urls = [
        "https://tradingeconomics.com/calendar",
        "https://tradingeconomics.com/united-states/calendar",
        "https://tradingeconomics.com/commodity/gold",
        "https://tradingeconomics.com/united-states/news",
    ]
    def collect_raw(self) -> list[dict]:
        rows = []
        for url in self.urls:
            try:
                soup = soup_from_url(url, self.session)
                count = 0
                # Calendar table rows
                for tr in soup.find_all("tr"):
                    txt = clean_text(tr.get_text(" ", strip=True))
                    if len(txt) < 8:
                        continue
                    low = txt.lower()
                    if not any(term in low for term in IMPORTANT_TERMS + ["gold", "dollar", "fed"]):
                        continue
                    # keep only likely macro/calendar rows, not menu junk
                    rows.append({"source": self.name, "title": txt[:180], "summary": txt, "url": url, "item_type": "event", "source_mode": "direct"})
                    count += 1
                # News links
                for a in soup.find_all("a", href=True):
                    title = clean_text(a.get_text(" ", strip=True))
                    if len(title) < 8:
                        continue
                    low = title.lower()
                    if any(term in low for term in ["gold", "dollar", "fed", "inflation", "cpi", "pce", "treasury", "yield"]):
                        href = a.get("href", "")
                        full = href if href.startswith("http") else "https://tradingeconomics.com" + (href if href.startswith("/") else "/" + href)
                        rows.append({"source": self.name, "title": title, "summary": "", "url": full, "item_type": "news", "source_mode": "direct"})
                        count += 1
                self.stats.note(f"{url.split('/')[-1] or 'calendar'}: {count} candidates")
            except Exception as e:
                self.stats.error(f"TE {url}: {type(e).__name__}: {e}")
        self.stats.direct_raw = len(rows)
        return rows
