from __future__ import annotations
from .base import SourceScraper
from ..utils import soup_from_url, absolute, clean_text, parse_date

class ApScraper(SourceScraper):
    name = "ap"
    urls = [
        "https://apnews.com/search?q=gold&sort=date",
        "https://apnews.com/hub/financial-markets",
        "https://apnews.com/hub/economy",
        "https://apnews.com/hub/china",
        "https://apnews.com/hub/middle-east",
        "https://apnews.com/hub/tariffs",
    ]
    def collect_raw(self) -> list[dict]:
        links: dict[str, str] = {}
        for page in self.urls:
            try:
                soup = soup_from_url(page, self.session)
                count = 0
                for a in soup.select("a[href]"):
                    href = a.get("href", "")
                    title = clean_text(a.get_text(" ", strip=True))
                    if "/article/" in href and title:
                        url = absolute("https://apnews.com", href)
                        links[url] = title
                        count += 1
                self.stats.note(f"{page.split('/')[-1] or 'search'}: {count} links")
            except Exception as e:
                self.stats.error(f"AP page {page}: {type(e).__name__}: {e}")
        self.stats.direct_raw = len(links)
        rows = []
        for url, fallback_title in list(links.items())[:240]:
            try:
                soup = soup_from_url(url, self.session)
                title = clean_text((soup.find("h1") or {}).get_text(" ", strip=True) if soup.find("h1") else fallback_title)
                meta_desc = soup.find("meta", attrs={"name": "description"}) or soup.find("meta", attrs={"property": "og:description"})
                summary = clean_text(meta_desc.get("content", "") if meta_desc else "")
                if not summary:
                    paras = [clean_text(p.get_text(" ", strip=True)) for p in soup.find_all("p")]
                    summary = " ".join([p for p in paras if len(p) > 40])[:900]
                meta_dt = soup.find("meta", attrs={"property": "article:published_time"})
                pub = parse_date(meta_dt.get("content", "") if meta_dt else "")
                rows.append({"source": self.name, "title": title, "url": url, "summary": summary, "published_utc": pub, "source_mode": "direct"})
            except Exception as e:
                self.stats.error(f"AP article: {type(e).__name__}: {e}")
        return rows
