from __future__ import annotations
from .base import SourceScraper
from ..utils import parse_feed


class CnbcScraper(SourceScraper):
    name = "cnbc"
    feeds = {
        "us_economy": "https://www.cnbc.com/id/20910258/device/rss/rss.html",
        "global_economy": "https://www.cnbc.com/id/10001147/device/rss/rss.html",
        "forex": "https://www.cnbc.com/id/10000664/device/rss/rss.html",
        "markets": "https://www.cnbc.com/id/100003114/device/rss/rss.html",
    }
    def collect_raw(self) -> list[dict]:
        rows = []
        for feed, url in self.feeds.items():
            try:
                items = parse_feed(url, session=self.session)
                self.stats.direct_raw += len(items)
                self.stats.note(f"{feed}: {len(items)} RSS")
                for it in items:
                    it.update({"source": self.name, "feed": feed, "source_mode": "direct"})
                    rows.append(it)
            except Exception as e:
                self.stats.error(f"{feed}: {type(e).__name__}: {e}")
        return rows


class ForexLiveScraper(SourceScraper):
    name = "forexlive"
    feeds = {
        "news": "https://www.forexlive.com/feed/news",
        "main": "https://www.forexlive.com/feed",
    }
    def collect_raw(self) -> list[dict]:
        rows = []
        for feed, url in self.feeds.items():
            try:
                items = parse_feed(url, session=self.session)[:80]
                self.stats.direct_raw += len(items)
                self.stats.note(f"{feed}: {len(items)} RSS")
                for it in items:
                    it.update({"source": self.name, "feed": feed, "source_mode": "direct"})
                    rows.append(it)
            except Exception as e:
                self.stats.error(f"{feed}: {type(e).__name__}: {e}")
        return rows


class FxStreetScraper(SourceScraper):
    name = "fxstreet"
    feeds = {
        "latest": "https://www.fxstreet.com/rss/news",
        "analysis": "https://www.fxstreet.com/rss/analysis",
    }
    def collect_raw(self) -> list[dict]:
        rows = []
        for feed, url in self.feeds.items():
            try:
                items = parse_feed(url, session=self.session)[:80]
                self.stats.direct_raw += len(items)
                self.stats.note(f"{feed}: {len(items)} RSS")
                for it in items:
                    it.update({"source": self.name, "feed": feed, "source_mode": "direct"})
                    rows.append(it)
            except Exception as e:
                self.stats.error(f"{feed}: {type(e).__name__}: {e}")
        return rows


class YahooScraper(SourceScraper):
    name = "yahoo"
    feeds = {
        "topstories": "https://finance.yahoo.com/rss/topstories",
        "gold_futures": "https://feeds.finance.yahoo.com/rss/2.0/headline?s=GC=F&region=US&lang=en-US",
        "dxy": "https://feeds.finance.yahoo.com/rss/2.0/headline?s=DX-Y.NYB&region=US&lang=en-US",
    }
    def collect_raw(self) -> list[dict]:
        rows = []
        for feed, url in self.feeds.items():
            try:
                items = parse_feed(url, session=self.session)[:80]
                self.stats.direct_raw += len(items)
                self.stats.note(f"{feed}: {len(items)} RSS")
                for it in items:
                    it.update({"source": self.name, "feed": feed, "source_mode": "direct"})
                    rows.append(it)
            except Exception as e:
                self.stats.error(f"{feed}: {type(e).__name__}: {e}")
        return rows
