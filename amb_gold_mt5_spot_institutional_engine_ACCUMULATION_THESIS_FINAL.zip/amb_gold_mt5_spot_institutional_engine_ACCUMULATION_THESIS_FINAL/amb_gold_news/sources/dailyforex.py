from __future__ import annotations
import re
from .base import SourceScraper
from ..utils import soup_from_url, absolute, clean_text, parse_date

class DailyForexScraper(SourceScraper):
    name = "dailyforex"
    base = "https://www.dailyforex.com/forex-news"
    pages_to_scan = 2
    raw_limit = 60

    def _clean_body(self, text: str) -> str:
        patterns = [r"Risk Disclaimer:.*", r"DailyForex will not be held liable.*", r"Adam Lemon.*?(?=Forex Today|$)"]
        out = text
        for p in patterns:
            out = re.sub(p, " ", out, flags=re.I | re.S)
        return clean_text(out)

    def collect_raw(self) -> list[dict]:
        links: dict[str, str] = {}
        for p in range(1, self.pages_to_scan + 1):
            url = f"{self.base}/page-{p}"
            try:
                soup = soup_from_url(url, self.session)
                count = 0
                for a in soup.select("a[href]"):
                    href = a.get("href", "")
                    title = clean_text(a.get_text(" ", strip=True))
                    if "/forex-news/" in href and len(title) > 5:
                        links[absolute("https://www.dailyforex.com", href)] = title
                        count += 1
                self.stats.note(f"page-{p}: {count} links")
            except Exception as e:
                self.stats.error(f"page-{p}: {type(e).__name__}: {e}")
        self.stats.direct_raw = len(links)
        rows = []
        for url, title in list(links.items())[:self.raw_limit]:
            try:
                soup = soup_from_url(url, self.session)
                h1 = soup.find("h1")
                if h1:
                    title = clean_text(h1.get_text(" ", strip=True)) or title
                paras = [clean_text(p.get_text(" ", strip=True)) for p in soup.find_all("p")]
                body = self._clean_body("\n\n".join([p for p in paras if len(p) > 30]))
                meta_dt = soup.find("meta", attrs={"property": "article:published_time"})
                pub = parse_date(meta_dt.get("content", "") if meta_dt else "")
                rows.append({"source": self.name, "title": title, "url": url, "summary": body[:500], "body": body, "published_utc": pub, "source_mode": "direct"})
            except Exception as e:
                self.stats.error(f"article: {type(e).__name__}: {e}")
        return rows
