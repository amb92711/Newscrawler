from __future__ import annotations
from abc import ABC, abstractmethod
from datetime import datetime, timezone, timedelta
import requests
from ..models import NewsItem, SourceStats
from ..classifier import classify_article_for_gold
from ..config import SOURCE_QUALITY, MAX_SUMMARY_CHARS
from ..utils import clean_text, is_recent, stable_key


class SourceScraper(ABC):
    name: str = "base"

    def __init__(self, days: int = 3, include_heavy: bool = False):
        self.days = days
        self.include_heavy = include_heavy
        self.min_dt = datetime.now(timezone.utc) - timedelta(days=days)
        self.session = requests.Session()
        self.stats = SourceStats(source=self.name)

    @abstractmethod
    def collect_raw(self) -> list[dict]:
        raise NotImplementedError

    def classify_and_build(self, raw: dict) -> NewsItem | None:
        title = clean_text(raw.get("title", ""))
        if not title:
            return None
        summary = clean_text(raw.get("summary", ""))[:MAX_SUMMARY_CHARS]
        body = clean_text(raw.get("body", ""))
        item_type = raw.get("item_type", "news")
        cls = classify_article_for_gold(title, summary, body, raw.get("tags") or [], item_type=item_type)
        if not cls.is_relevant:
            return None
        source = raw.get("source") or self.name
        it = NewsItem(
            source=source,
            title=title,
            url=raw.get("url", "") or "",
            summary=summary,
            body=body[:2500],
            published_utc=raw.get("published_utc"),
            item_type=item_type,
            feed=raw.get("feed"),
            impact=cls.impact,
            impact_label=cls.impact_label,
            categories=cls.categories,
            matched_keywords=cls.matched_keywords,
            gold_direction=cls.gold_direction,
            source_quality=SOURCE_QUALITY.get(source, 0.5),
            source_mode=raw.get("source_mode", "direct"),
            extra=raw.get("extra", {}),
        )
        it.novelty_key = stable_key(it.title, it.url)
        return it

    def run(self) -> tuple[list[NewsItem], SourceStats]:
        try:
            raw_items = self.collect_raw()
            self.stats.raw = len(raw_items)
            if raw_items and self.stats.status == "FAIL":
                self.stats.status = "PARTIAL"
            kept: list[NewsItem] = []
            for raw in raw_items:
                if not is_recent(raw.get("published_utc"), self.min_dt, keep_unknown=True):
                    self.stats.rejected += 1
                    continue
                item = self.classify_and_build(raw)
                if item:
                    kept.append(item)
                    self.stats.relevant += 1
                else:
                    self.stats.rejected += 1
            if kept and self.stats.status == "FAIL":
                self.stats.status = "PARTIAL"
            return kept, self.stats
        except Exception as e:
            self.stats.error(f"{type(e).__name__}: {e}")
            return [], self.stats
