from __future__ import annotations
from urllib.parse import quote_plus
from .base import SourceScraper
from ..utils import parse_feed, soup_from_url, clean_text, absolute


def google_rss_query(query: str) -> str:
    return "https://news.google.com/rss/search?q=" + quote_plus(query) + "&hl=en-US&gl=US&ceid=US:en"


class KitcoScraper(SourceScraper):
    name = "kitco"
    feeds = {
        "news": "https://www.kitco.com/rss/news",
        "commentaries": "https://www.kitco.com/rss/commentaries",
    }
    pages = ["https://www.kitco.com/news", "https://www.kitco.com/markets"]
    fallback_queries = ["site:kitco.com gold fed dollar yields", "site:kitco.com XAUUSD gold price"]
    def collect_raw(self) -> list[dict]:
        rows = []
        for feed, url in self.feeds.items():
            try:
                items = parse_feed(url, session=self.session)[:80]
                self.stats.direct_raw += len(items); self.stats.note(f"{feed}: {len(items)} RSS")
                for it in items:
                    it.update({"source": self.name, "feed": feed, "source_mode": "direct"}); rows.append(it)
            except Exception as e:
                self.stats.error(f"{feed}: {type(e).__name__}: {e}")
        for page in self.pages:
            try:
                soup = soup_from_url(page, self.session); count = 0
                for a in soup.select("a[href]"):
                    title = clean_text(a.get_text(" ", strip=True)); href = a.get("href", "")
                    if len(title) > 14 and any(k in title.lower() for k in ["gold", "fed", "dollar", "inflation", "rates", "silver", "pce", "yield"]):
                        rows.append({"source": self.name, "title": title, "url": absolute("https://www.kitco.com", href), "source_mode": "direct"}); count += 1
                self.stats.direct_raw += count
                self.stats.note(f"{page.rsplit('/',1)[-1]}: {count} links")
            except Exception as e:
                self.stats.error(f"page {page}: {type(e).__name__}: {e}")
        # If Kitco changes RSS/pages again, preserve coverage through Google News site search.
        for q in self.fallback_queries:
            try:
                items = parse_feed(google_rss_query(q), session=self.session)[:50]
                self.stats.fallback_raw += len(items); self.stats.note(f"google fallback {q[:22]}: {len(items)}")
                for it in items:
                    it.update({"source": self.name, "feed": "google_site_fallback", "source_mode": "fallback"}); rows.append(it)
            except Exception as e:
                self.stats.error(f"kitco google fallback: {type(e).__name__}: {e}")
        return rows


class MiningScraper(SourceScraper):
    name = "mining"
    feeds = {"mining": "https://www.mining.com/feed/"}
    fallback_queries = ["site:mining.com gold price miners fed dollar", "site:mining.com gold mining central bank demand"]
    def collect_raw(self) -> list[dict]:
        rows=[]
        for feed, url in self.feeds.items():
            try:
                items=parse_feed(url, session=self.session)[:80]
                self.stats.direct_raw += len(items); self.stats.note(f"{feed}: {len(items)} RSS")
                for it in items:
                    it.update({"source": self.name, "feed": feed, "source_mode": "direct"}); rows.append(it)
            except Exception as e:
                self.stats.error(f"{feed}: {type(e).__name__}: {e}")
        for q in self.fallback_queries:
            try:
                items = parse_feed(google_rss_query(q), session=self.session)[:50]
                self.stats.fallback_raw += len(items); self.stats.note(f"google fallback {q[:24]}: {len(items)}")
                for it in items:
                    it.update({"source": self.name, "feed": "google_site_fallback", "source_mode": "fallback"}); rows.append(it)
            except Exception as e:
                self.stats.error(f"mining google fallback: {type(e).__name__}: {e}")
        return rows


class GoldOrgScraper(SourceScraper):
    name = "gold_org"
    pages = ["https://www.gold.org/goldhub/research", "https://www.gold.org/goldhub/data"]
    def collect_raw(self) -> list[dict]:
        rows=[]
        for page in self.pages:
            try:
                soup=soup_from_url(page, self.session); count=0
                for a in soup.select("a[href]"):
                    title=clean_text(a.get_text(" ", strip=True)); href=a.get("href", "")
                    if len(title)>12 and any(k in title.lower() for k in ["gold", "central bank", "etf", "demand", "reserves", "safe haven", "market"]):
                        rows.append({"source": self.name, "title": title, "url": absolute("https://www.gold.org", href), "source_mode": "direct", "summary": "World Gold Council / Goldhub research or data item"}); count+=1
                self.stats.direct_raw += count; self.stats.note(f"{page.rsplit('/',1)[-1]}: {count} links")
            except Exception as e:
                self.stats.error(f"{page}: {type(e).__name__}: {e}")
        return rows


class BarchartScraper(SourceScraper):
    name = "barchart"
    # Barchart often appears through Yahoo syndication; this explicit site fallback keeps the source visible.
    fallback_queries = [
        "site:barchart.com gold dollar fed yields",
        "site:barchart.com gold futures DXY rate hike",
        "site:barchart.com commodities gold silver fed",
    ]
    def collect_raw(self) -> list[dict]:
        rows=[]
        for q in self.fallback_queries:
            try:
                items = parse_feed(google_rss_query(q), session=self.session)[:50]
                self.stats.fallback_raw += len(items); self.stats.note(f"google site {q[:26]}: {len(items)}")
                for it in items:
                    it.update({"source": self.name, "feed": "google_site_fallback", "source_mode": "fallback"}); rows.append(it)
            except Exception as e:
                self.stats.error(f"barchart fallback: {type(e).__name__}: {e}")
        return rows

class FxEmpireGoldScraper(SourceScraper):
    """Gold-specific FXEmpire coverage.

    Replaces Kitco as a practical public source. It targets the Gold news and
    forecast pages directly, then falls back to Google News site search if the
    page structure changes.
    """
    name = "fxempire_gold"
    pages = [
        "https://www.fxempire.com/commodities/gold/news",
        "https://www.fxempire.com/forecasts/gold",
        "https://www.fxempire.com/commodities/gold",
    ]
    fallback_queries = [
        "site:fxempire.com gold XAUUSD price forecast Fed dollar yields",
        "site:fxempire.com forecasts gold XAUUSD PCE CPI Fed",
        "site:fxempire.com commodities gold silver dollar yields",
    ]
    def collect_raw(self) -> list[dict]:
        rows=[]
        for page in self.pages:
            try:
                soup=soup_from_url(page, self.session); count=0
                for a in soup.select("a[href]"):
                    title=clean_text(a.get_text(" ", strip=True)); href=a.get("href", "")
                    tl=title.lower()
                    if len(title)>16 and any(k in tl for k in ["gold", "xau", "silver", "fed", "dollar", "pce", "cpi", "yield", "forecast"]):
                        rows.append({"source": self.name, "title": title, "url": absolute("https://www.fxempire.com", href), "source_mode": "direct", "summary": "FXEmpire gold news/forecast"}); count+=1
                self.stats.direct_raw += count; self.stats.note(f"{page.rsplit('/',1)[-1]}: {count} links")
            except Exception as e:
                self.stats.error(f"{page}: {type(e).__name__}: {e}")
        for q in self.fallback_queries:
            try:
                items = parse_feed(google_rss_query(q), session=self.session)[:60]
                self.stats.fallback_raw += len(items); self.stats.note(f"google site {q[:28]}: {len(items)}")
                for it in items:
                    it.update({"source": self.name, "feed": "google_site_fallback", "source_mode": "fallback"}); rows.append(it)
            except Exception as e:
                self.stats.error(f"fxempire fallback: {type(e).__name__}: {e}")
        return rows


class InvestingGoldScraper(SourceScraper):
    """Investing.com gold/commodities coverage.

    Replaces Mining.com for this trading-focused engine. Mining equities are not
    as directly actionable for intraday XAUUSD as gold futures / commodities / FX macro.
    """
    name = "investing_gold"
    pages = [
        "https://www.investing.com/commodities/gold-news",
        "https://www.investing.com/news/commodities-news",
    ]
    fallback_queries = [
        "site:investing.com/commodities/gold-news gold dollar Fed yields",
        "site:investing.com/news/commodities-news gold XAUUSD CPI PCE",
        "site:investing.com gold prices dollar yields Fed commodities",
    ]
    def collect_raw(self) -> list[dict]:
        rows=[]
        for page in self.pages:
            try:
                soup=soup_from_url(page, self.session); count=0
                for a in soup.select("a[href]"):
                    title=clean_text(a.get_text(" ", strip=True)); href=a.get("href", "")
                    tl=title.lower()
                    if len(title)>16 and any(k in tl for k in ["gold", "xau", "dollar", "fed", "yield", "pce", "cpi", "inflation", "commodities"]):
                        rows.append({"source": self.name, "title": title, "url": absolute("https://www.investing.com", href), "source_mode": "direct", "summary": "Investing.com gold/commodities item"}); count+=1
                self.stats.direct_raw += count; self.stats.note(f"{page.rsplit('/',1)[-1]}: {count} links")
            except Exception as e:
                self.stats.error(f"{page}: {type(e).__name__}: {e}")
        for q in self.fallback_queries:
            try:
                items = parse_feed(google_rss_query(q), session=self.session)[:60]
                self.stats.fallback_raw += len(items); self.stats.note(f"google site {q[:30]}: {len(items)}")
                for it in items:
                    it.update({"source": self.name, "feed": "google_site_fallback", "source_mode": "fallback"}); rows.append(it)
            except Exception as e:
                self.stats.error(f"investing fallback: {type(e).__name__}: {e}")
        return rows
