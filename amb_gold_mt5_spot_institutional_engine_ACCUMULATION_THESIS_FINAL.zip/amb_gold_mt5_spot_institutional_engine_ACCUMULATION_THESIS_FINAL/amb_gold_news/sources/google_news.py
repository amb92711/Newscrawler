from __future__ import annotations
from urllib.parse import quote_plus
from .base import SourceScraper
from ..utils import parse_feed

class GoogleNewsScraper(SourceScraper):
    name = "google_news"
    queries = [
        "gold price fed dollar yields inflation",
        "XAUUSD gold forecast dollar yields",
        "site:fxstreet.com gold XAUUSD",
        "site:dailyfx.com gold XAUUSD",
        "site:barchart.com gold dollar fed",
        "site:reuters.com gold Fed dollar Treasury yields",
        "site:fxempire.com gold XAUUSD Fed dollar yields",
    ]
    def collect_raw(self) -> list[dict]:
        rows = []
        for q in self.queries:
            url = "https://news.google.com/rss/search?q=" + quote_plus(q) + "&hl=en-US&gl=US&ceid=US:en"
            try:
                items = parse_feed(url, session=self.session)[:50]
                self.stats.fallback_raw += len(items)
                self.stats.note(f"{q[:32]}: {len(items)} Google RSS")
                for it in items:
                    it.update({"source": self.name, "feed": q, "source_mode": "fallback"})
                    rows.append(it)
            except Exception as e:
                self.stats.error(f"Google {q}: {type(e).__name__}: {e}")
        return rows
