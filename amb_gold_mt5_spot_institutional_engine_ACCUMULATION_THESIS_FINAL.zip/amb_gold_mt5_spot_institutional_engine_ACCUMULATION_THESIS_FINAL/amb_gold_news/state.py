from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .models import NewsItem

STATE_DIRNAME = "state"
HISTORY_FILE = "run_history.jsonl"
LATEST_STATE_FILE = "latest_state.json"


def _sha(text: str) -> str:
    return hashlib.sha1(text.encode("utf-8", "ignore")).hexdigest()[:16]


def _story_signature(packet: dict[str, Any]) -> str:
    final = packet.get("final_market_story", {}) or {}
    stories = packet.get("driver_stories", []) or []
    basis = [str(final.get("headline_bias", "")), str(final.get("summary", ""))]
    for s in stories[:8]:
        basis.append(f"{s.get('driver_key')}:{s.get('net_effect_on_xauusd')}:{s.get('must_read_count')}:{s.get('macro_watch_count')}")
    return _sha("|".join(basis))


def _headline_signature(items: list[NewsItem]) -> str:
    titles = []
    for it in items:
        if it.relevance_bucket in {"MUST_READ", "MACRO_WATCH"}:
            titles.append(f"{it.source}:{it.title}".lower())
    return _sha("|".join(sorted(titles)[:120]))


def _compact_current(packet: dict[str, Any], items: list[NewsItem], market_validation: dict[str, Any] | None = None) -> dict[str, Any]:
    final = packet.get("final_market_story", {}) or {}
    stories = packet.get("driver_stories", []) or []
    counts = packet.get("summary_counts", {}) or {}
    top_titles = []
    for it in items:
        if it.relevance_bucket == "MUST_READ":
            top_titles.append({"source": it.source, "title": it.title, "direction": it.gold_direction, "narrative": it.narrative})
        if len(top_titles) >= 20:
            break
    current = {
        "version": "v8_state_snapshot",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "headline_bias": final.get("headline_bias", "unknown"),
        "market_story_summary": final.get("summary", ""),
        "summary_counts": counts,
        "primary_driver": None,
        "driver_effects": {},
        "top_must_read": top_titles,
        "story_signature": _story_signature(packet),
        "headline_signature": _headline_signature(items),
        "market_validation_counts": (market_validation or {}).get("verdict_counts", {}),
    }
    primary = final.get("primary_driver")
    if isinstance(primary, dict):
        current["primary_driver"] = {
            "driver_key": primary.get("driver_key"),
            "title": primary.get("title"),
            "effect": primary.get("net_effect_on_xauusd"),
        }
    for s in stories[:12]:
        current["driver_effects"][s.get("driver_key") or s.get("title")] = {
            "title": s.get("title"),
            "effect": s.get("net_effect_on_xauusd"),
            "must": s.get("must_read_count", 0),
            "macro": s.get("macro_watch_count", 0),
        }
    return current


def _read_json(path: Path) -> dict[str, Any] | None:
    try:
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None
    return None


def _append_jsonl(path: Path, obj: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False) + "\n")


def build_state_delta(packet: dict[str, Any], items: list[NewsItem], output_dir: str, market_validation: dict[str, Any] | None = None) -> dict[str, Any]:
    out = Path(output_dir)
    state_dir = out / STATE_DIRNAME
    state_dir.mkdir(parents=True, exist_ok=True)
    latest_path = state_dir / LATEST_STATE_FILE
    hist_path = state_dir / HISTORY_FILE

    previous = _read_json(latest_path)
    current = _compact_current(packet, items, market_validation)

    changes: list[str] = []
    new_risks: list[str] = []
    resolved_or_missing: list[str] = []
    driver_changes: list[dict[str, Any]] = []

    if not previous:
        changes.append("No previous run found. This is the baseline state snapshot.")
    else:
        if previous.get("headline_bias") != current.get("headline_bias"):
            changes.append(f"Bias changed: {previous.get('headline_bias')} -> {current.get('headline_bias')}")
        prev_primary = (previous.get("primary_driver") or {}).get("title")
        cur_primary = (current.get("primary_driver") or {}).get("title")
        if prev_primary != cur_primary:
            changes.append(f"Primary driver changed: {prev_primary or 'none'} -> {cur_primary or 'none'}")
        if previous.get("story_signature") != current.get("story_signature"):
            changes.append("Market-story signature changed; narrative mix or driver effects shifted.")
        prev_effects = previous.get("driver_effects", {}) or {}
        cur_effects = current.get("driver_effects", {}) or {}
        for key, cur in cur_effects.items():
            prev = prev_effects.get(key)
            if not prev:
                driver_changes.append({"driver": cur.get("title", key), "change": "new_driver", "current_effect": cur.get("effect")})
                continue
            if prev.get("effect") != cur.get("effect"):
                driver_changes.append({"driver": cur.get("title", key), "change": "effect_changed", "previous_effect": prev.get("effect"), "current_effect": cur.get("effect")})
            if abs(int(cur.get("must", 0)) - int(prev.get("must", 0))) >= 4:
                driver_changes.append({"driver": cur.get("title", key), "change": "must_read_count_shift", "previous": prev.get("must"), "current": cur.get("must")})
        for key, prev in prev_effects.items():
            if key not in cur_effects:
                resolved_or_missing.append(prev.get("title", key))
        prev_titles = {x.get("title") for x in previous.get("top_must_read", []) if x.get("title")}
        cur_titles = {x.get("title") for x in current.get("top_must_read", []) if x.get("title")}
        for title in sorted(cur_titles - prev_titles)[:12]:
            new_risks.append(title)
        for title in sorted(prev_titles - cur_titles)[:12]:
            resolved_or_missing.append(title)

    if not changes and not driver_changes and not new_risks:
        changes.append("No major state change versus previous run.")

    delta = {
        "version": "v8_state_delta",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "has_previous_run": previous is not None,
        "changes": changes,
        "driver_changes": driver_changes[:20],
        "new_must_read_risks": new_risks[:20],
        "resolved_or_missing_from_top": resolved_or_missing[:20],
        "previous_snapshot": previous,
        "current_snapshot": current,
    }

    latest_path.write_text(json.dumps(current, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "latest_state_delta.json").write_text(json.dumps(delta, ensure_ascii=False, indent=2), encoding="utf-8")
    _append_jsonl(hist_path, current)
    return delta
