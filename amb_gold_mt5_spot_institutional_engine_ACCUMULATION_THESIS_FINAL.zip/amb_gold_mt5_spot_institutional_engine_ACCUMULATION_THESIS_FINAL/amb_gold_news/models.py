from __future__ import annotations
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class NewsItem:
    source: str
    title: str
    url: str = ""
    summary: str = ""
    body: str = ""
    published_utc: str | None = None
    fetched_utc: str = field(default_factory=utc_now_iso)
    item_type: str = "news"  # news | event
    feed: str | None = None
    impact: int = 0
    impact_label: str = "UNSCORED"
    categories: list[str] = field(default_factory=list)
    matched_keywords: list[str] = field(default_factory=list)
    gold_direction: str = "unknown"  # bullish | bearish | mixed | neutral | unknown
    novelty_key: str = ""
    source_quality: float = 0.50
    source_mode: str = "direct"  # direct | fallback | selenium | api
    extra: dict[str, Any] = field(default_factory=dict)

    # Intelligence fields. v6 prioritizes XAUUSD-moving coverage and driver stories over numeric scoring.
    gold_impact_score: float = 0.0
    market_impact_score: float = 0.0
    novelty_score: float = 1.0
    time_decay_score: float = 1.0
    cross_source_confidence: float = 0.0
    source_cluster_size: int = 1
    narrative: str = "other"
    event_state: str = "na"  # upcoming | pending | final | na
    actionability: str = "background"  # must_read | macro_watch | background | discard
    relevance_bucket: str = "BACKGROUND"  # MUST_READ | MACRO_WATCH | BACKGROUND | DISCARD
    xauusd_relevance: str = "background" # direct | macro | background | discard
    rank_reasons: list[str] = field(default_factory=list)
    semantic_cluster_id: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class SourceStats:
    source: str
    status: str = "OK"
    raw: int = 0
    relevant: int = 0
    kept: int = 0
    duplicates: int = 0
    rejected: int = 0
    direct_raw: int = 0
    fallback_raw: int = 0
    notes: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    def note(self, text: str) -> None:
        if text and text not in self.notes:
            self.notes.append(text)

    def error(self, text: str) -> None:
        self.status = "PARTIAL" if self.raw or self.relevant or self.kept or self.direct_raw or self.fallback_raw else "FAIL"
        if text and text not in self.errors:
            self.errors.append(text)
