from __future__ import annotations
import hashlib
import html
import json
import re
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from pathlib import Path
from typing import Any
from urllib.parse import urljoin
import requests
try:
    import feedparser  # type: ignore
except Exception:  # fallback if dependency is not installed yet
    feedparser = None
from bs4 import BeautifulSoup
from .config import HEADERS_HTML, HEADERS_RSS


def clean_text(text: str | None) -> str:
    text = html.unescape(text or "")
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def parse_date(value: str | None) -> str | None:
    if not value:
        return None
    value = str(value).strip()
    if not value:
        return None
    try:
        dt = parsedate_to_datetime(value)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc).isoformat()
    except Exception:
        pass
    try:
        v = value.replace("Z", "+00:00")
        dt = datetime.fromisoformat(v)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc).isoformat()
    except Exception:
        return None


def is_recent(published_utc: str | None, min_dt: datetime, keep_unknown: bool = True) -> bool:
    if not published_utc:
        return keep_unknown
    try:
        dt = datetime.fromisoformat(published_utc.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt >= min_dt
    except Exception:
        return keep_unknown


def stable_key(title: str, url: str = "") -> str:
    title_norm = re.sub(r"[^a-z0-9]+", " ", (title or "").lower()).strip()
    if title_norm:
        base = title_norm[:180]
    else:
        base = url or ""
    return hashlib.sha1(base.encode("utf-8", "ignore")).hexdigest()[:16]


def request_text(url: str, *, timeout: int = 25, rss: bool = False, session: requests.Session | None = None) -> str:
    sess = session or requests.Session()
    headers = HEADERS_RSS if rss else HEADERS_HTML
    r = sess.get(url, headers=headers, timeout=timeout)
    r.raise_for_status()
    return r.text


def parse_feed(xml_or_url: str, *, from_url: bool = True, session: requests.Session | None = None) -> list[dict[str, Any]]:
    data = request_text(xml_or_url, rss=True, session=session) if from_url else xml_or_url
    items: list[dict[str, Any]] = []
    if feedparser is not None:
        feed = feedparser.parse(data)
        entries = feed.entries or []
    else:
        entries = []
    for e in entries:
        title = clean_text(e.get("title", ""))
        link = (e.get("link", "") or "").strip()
        summary = clean_text(e.get("summary", "") or e.get("description", ""))
        pub = parse_date(e.get("published", "") or e.get("updated", ""))
        tags = []
        for t in e.get("tags", []) or []:
            term = t.get("term") if isinstance(t, dict) else getattr(t, "term", None)
            if term:
                tags.append(str(term))
        if title or link:
            items.append({"title": title, "url": link, "summary": summary, "published_utc": pub, "tags": tags})
    if items:
        return items
    # Very forgiving fallback for malformed RSS
    parts = data.split("<item")
    for p in parts[1:]:
        block = p.split("</item>")[0]
        def ext(tag: str) -> str:
            m = re.search(fr"<{tag}[^>]*>(.*?)</{tag}>", block, flags=re.I | re.S)
            return clean_text(m.group(1)) if m else ""
        title = ext("title")
        link = ext("link")
        summary = ext("description")
        pub = parse_date(ext("pubDate"))
        if title or link:
            items.append({"title": title, "url": link, "summary": summary, "published_utc": pub, "tags": []})
    return items


def soup_from_url(url: str, session: requests.Session | None = None) -> BeautifulSoup:
    return BeautifulSoup(request_text(url, session=session), "html.parser")


def absolute(base: str, href: str) -> str:
    return urljoin(base, href or "")


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
