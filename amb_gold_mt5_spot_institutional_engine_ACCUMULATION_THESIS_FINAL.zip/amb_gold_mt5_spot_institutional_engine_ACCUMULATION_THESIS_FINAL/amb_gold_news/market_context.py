from __future__ import annotations

import json
import math
from datetime import datetime, timezone
from typing import Any
from urllib.parse import quote

import requests

from .config import HEADERS_HTML

# V8 market validation is intentionally optional and best-effort.
# The news engine must still work when Yahoo blocks/rate-limits market data.
# These instruments are used only to validate whether news narratives about USD,
# yields, gold, silver, oil and risk are currently confirmed by market context.
MARKET_SYMBOLS = {
    "gold_futures": {"symbol": "GC=F", "kind": "price", "label": "COMEX Gold Futures"},
    "silver_futures": {"symbol": "SI=F", "kind": "price", "label": "COMEX Silver Futures"},
    "dxy": {"symbol": "DX-Y.NYB", "kind": "price", "label": "US Dollar Index"},
    "us10y": {"symbol": "^TNX", "kind": "yield", "label": "US 10Y Treasury Yield proxy"},
    "us13w": {"symbol": "^IRX", "kind": "yield", "label": "US 13W / short-rate proxy"},
    "oil_wti": {"symbol": "CL=F", "kind": "price", "label": "WTI Crude Oil Futures"},
    "vix": {"symbol": "^VIX", "kind": "price", "label": "VIX"},
}


def _safe_float(x: Any) -> float | None:
    try:
        if x is None:
            return None
        v = float(x)
        if math.isnan(v):
            return None
        return v
    except Exception:
        return None


def _fetch_yahoo_chart(symbol: str, timeout: int = 16) -> dict[str, Any]:
    url = f"https://query1.finance.yahoo.com/v8/finance/chart/{quote(symbol, safe='')}?range=7d&interval=1d"
    r = requests.get(url, headers=HEADERS_HTML, timeout=timeout)
    r.raise_for_status()
    data = r.json()
    result = (data.get("chart", {}) or {}).get("result") or []
    if not result:
        raise RuntimeError("Yahoo chart returned no result")
    node = result[0]
    meta = node.get("meta", {}) or {}
    quote_node = ((node.get("indicators", {}) or {}).get("quote") or [{}])[0]
    closes = [_safe_float(x) for x in quote_node.get("close", [])]
    closes = [x for x in closes if x is not None]
    regular = _safe_float(meta.get("regularMarketPrice"))
    last = regular if regular is not None else (closes[-1] if closes else None)
    prev = closes[-2] if len(closes) >= 2 else None
    if last is None:
        raise RuntimeError("Yahoo chart returned no usable price")
    change = None if prev is None else last - prev
    pct = None if prev in (None, 0) else (change / prev) * 100.0
    return {
        "symbol": symbol,
        "last": round(last, 5),
        "previous_close": round(prev, 5) if prev is not None else None,
        "change": round(change, 5) if change is not None else None,
        "pct_change": round(pct, 4) if pct is not None else None,
        "currency": meta.get("currency"),
        "exchange": meta.get("exchangeName"),
        "source": "yahoo_chart",
        "status": "OK",
    }


def _direction_from_change(change: float | None, pct: float | None, kind: str) -> str:
    if change is None and pct is None:
        return "unknown"
    if kind == "yield":
        # ^TNX is quoted as yield*10 on Yahoo. Direction still works.
        threshold = 0.015
        val = change or 0.0
        if val > threshold:
            return "higher"
        if val < -threshold:
            return "lower"
        return "flat"
    val = pct if pct is not None else 0.0
    if val > 0.15:
        return "higher"
    if val < -0.15:
        return "lower"
    return "flat"


def fetch_market_context() -> dict[str, Any]:
    generated = datetime.now(timezone.utc).isoformat()
    instruments: dict[str, Any] = {}
    errors: list[str] = []
    for key, spec in MARKET_SYMBOLS.items():
        try:
            data = _fetch_yahoo_chart(spec["symbol"])
            data["label"] = spec["label"]
            data["kind"] = spec["kind"]
            data["direction"] = _direction_from_change(data.get("change"), data.get("pct_change"), spec["kind"])
            instruments[key] = data
        except Exception as e:
            instruments[key] = {
                "symbol": spec["symbol"],
                "label": spec["label"],
                "kind": spec["kind"],
                "status": "UNAVAILABLE",
                "error": f"{type(e).__name__}: {e}",
            }
            errors.append(f"{key}: {type(e).__name__}: {e}")
    return {
        "version": "v8_market_context",
        "generated_utc": generated,
        "status": "OK" if not errors else "PARTIAL" if len(errors) < len(MARKET_SYMBOLS) else "UNAVAILABLE",
        "instruments": instruments,
        "errors": errors,
        "note": "Best-effort validation only. If unavailable, use news-only narrative and validate manually with broker/TradingView data.",
    }


def _market_dir(ctx: dict[str, Any], key: str) -> str:
    return ((ctx.get("instruments", {}) or {}).get(key, {}) or {}).get("direction", "unknown")


def validate_story_against_market(story: dict[str, Any], ctx: dict[str, Any]) -> dict[str, Any]:
    key = story.get("driver_key")
    expected = story.get("net_effect_on_xauusd", "unclear")
    checks: list[str] = []
    confirmed = 0
    contradicted = 0
    unknown = 0

    dxy = _market_dir(ctx, "dxy")
    us10y = _market_dir(ctx, "us10y")
    gold = _market_dir(ctx, "gold_futures")
    silver = _market_dir(ctx, "silver_futures")
    oil = _market_dir(ctx, "oil_wti")
    vix = _market_dir(ctx, "vix")

    def add(name: str, got: str, bullish_when: set[str], bearish_when: set[str]) -> None:
        nonlocal confirmed, contradicted, unknown
        if got == "unknown":
            unknown += 1
            checks.append(f"{name}: unavailable")
            return
        implied = "bullish" if got in bullish_when else "bearish" if got in bearish_when else "mixed"
        if expected in {"bullish", "bearish"} and implied in {"bullish", "bearish"}:
            if implied == expected:
                confirmed += 1
                checks.append(f"{name}: {got} confirms {expected}")
            else:
                contradicted += 1
                checks.append(f"{name}: {got} contradicts {expected}")
        else:
            checks.append(f"{name}: {got} ({implied})")

    if key == "fed_usd_yields":
        add("DXY", dxy, bullish_when={"lower"}, bearish_when={"higher"})
        add("US10Y", us10y, bullish_when={"lower"}, bearish_when={"higher"})
    elif key == "direct_gold":
        add("Gold futures", gold, bullish_when={"higher"}, bearish_when={"lower"})
        add("Silver futures", silver, bullish_when={"higher"}, bearish_when={"lower"})
    elif key == "geopolitical_safe_haven":
        add("VIX", vix, bullish_when={"higher"}, bearish_when={"lower"})
        add("Oil", oil, bullish_when={"higher"}, bearish_when={"lower"})
    elif key == "oil_commodities":
        add("Oil", oil, bullish_when={"higher"}, bearish_when={"lower"})
        add("Silver", silver, bullish_when={"higher"}, bearish_when={"lower"})
    elif key in {"inflation_jobs_growth", "physical_flows"}:
        add("DXY", dxy, bullish_when={"lower"}, bearish_when={"higher"})
        add("US10Y", us10y, bullish_when={"lower"}, bearish_when={"higher"})
        add("Gold futures", gold, bullish_when={"higher"}, bearish_when={"lower"})

    if not checks:
        verdict = "not_applicable"
    elif confirmed and not contradicted:
        verdict = "confirmed"
    elif contradicted and not confirmed:
        verdict = "contradicted"
    elif confirmed and contradicted:
        verdict = "mixed_validation"
    else:
        verdict = "unconfirmed"
    return {
        "driver_key": key,
        "story_title": story.get("title"),
        "news_effect": expected,
        "validation_verdict": verdict,
        "checks": checks,
        "confirmed_count": confirmed,
        "contradicted_count": contradicted,
        "unknown_count": unknown,
    }


def build_market_validation(packet: dict[str, Any], ctx: dict[str, Any]) -> dict[str, Any]:
    stories = packet.get("driver_stories", []) or []
    validations = [validate_story_against_market(s, ctx) for s in stories[:10]]
    counts: dict[str, int] = {}
    for v in validations:
        counts[v["validation_verdict"]] = counts.get(v["validation_verdict"], 0) + 1
    return {
        "version": "v8_market_validation",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "market_context_status": ctx.get("status"),
        "verdict_counts": counts,
        "driver_validations": validations,
    }
