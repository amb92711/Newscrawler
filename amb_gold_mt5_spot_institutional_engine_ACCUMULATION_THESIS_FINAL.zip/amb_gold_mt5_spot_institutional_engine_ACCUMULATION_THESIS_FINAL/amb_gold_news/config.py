HEADERS_HTML = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Cache-Control": "no-cache",
}
HEADERS_RSS = {
    "User-Agent": HEADERS_HTML["User-Agent"],
    "Accept": "application/rss+xml,application/xml,text/xml,text/html,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
}
MAX_SUMMARY_CHARS = 900

SOURCE_QUALITY = {
    "reuters_google": 0.98,
    "ap": 0.95,
    "bloomberg": 0.94,
    "cnbc": 0.86,
    "marketwatch": 0.82,
    "barchart": 0.82,
    "yahoo": 0.80,
    "nasdaq": 0.78,
    "fxempire_gold": 0.84,
    "investing_gold": 0.82,
    "gold_org": 0.88,
    "investing": 0.76,
    "fxstreet": 0.74,
    "forexlive": 0.72,
    "ig": 0.70,
    "dailyforex": 0.62,
    "forexfactory": 0.86,
    "tradingeconomics": 0.82,
    "google_news": 0.55,
}

SOURCE_SOFT_CAPS = {
    "tradingeconomics": 80,
    "google_news": 45,
    "barchart": 30,
    "investing_gold": 35,
    "fxempire_gold": 35,
    "ap": 35,
    "forexfactory": 55,
}
